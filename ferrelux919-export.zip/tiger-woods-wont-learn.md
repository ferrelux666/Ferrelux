---
title: "⛳Tiger Woods Won’t Learn❤️‍\U0001FA79"
date: '2013-03-21T01:08:00.000Z'
slug: tiger-woods-wont-learn
tags:
  - golf
  - boyfriend
  - celebrity
  - romance
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672196159557/HMwqn3iju.jpeg
canonical: 'https://ferrelux666.wordpress.com/2013/03/20/tiger-woods-dating/'
---
[![Tiger Woods, Dating](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196157002/s4McxSN30.jpeg align="left")](https://nypost.com/2010/04/29/tiger-woods-had-120-affairs-including-one-with-young-neighbor/)

Okay he’s done it again, setting himself up for another media attack. Had he gone with either an Asian or African-American woman, he would never had come under the scrutiny of the paparazzi or the vile attacks of bigoted Whites in the industry bent on stalking the lives of certain successful Blacks to bring shame & embarrassment to them simply because they represent the breaking of a color line, & for him it was golf. It’s a damn shame that Tiger won’t learn that lesson, & I feel that this White Woman he’s seeing now *(& the ones before)* have an agenda to be next in line to get paid because they know it’s just a matter of time until he screws up again & they can use that for a divorce & cash in BIG. [http://www.huffingtonpost.com/…ger-woods-girlfriend](http://www.huffingtonpost.com/news/tiger-woods-girlfriend/)

![Tiger Woods Cheating Scandal](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196158324/oQtpveCOi.jpeg align="left")

~ LHISA
