---
title: "\U0001F5DEThe Biden-Harris Transition To Power\U0001F4C8"
date: '2021-01-20T23:19:16.000Z'
slug: the-biden-harris-transition-to-power
tags:
  - trump
  - gender
  - legal
  - community
  - vp
  - society
  - government
  - blm
  - covid-19
  - race
  - coronavirus
  - politics
  - election
  - police
  - nation
  - russia
  - green
  - fraud
  - voting
  - joe-biden
  - president
  - revolution
  - orange
  - city
  - laws
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672193557126/AQpgH5ESN.jpeg
canonical: 'https://ferrelux666.wordpress.com/2021/01/20/inauguration2021/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193532904/-qgEz4aQk.jpeg align="left")](https://www.dailymotion.com/video/x7yw6uo)

**Imperium Et Libertatem 🗽 Empire & Liberty**

[Buffalo Springfield – “For What It’s Worth”](https://m.youtube.com/watch?v=NK52YsvjSws)  
[The ‘Black Lives Matter’ Version](https://m.youtube.com/watch?v=J7L7F8U398Q)  
[The Trump Supporters Version](https://m.youtube.com/watch?v=6ohVNFaoPAA)

Okay, so the 2021 Inauguration of both the President & VP Elect, went well today. Things looked the way it should and we now have POTUS #46, and a new First Lady even though Trump did not attend, but he did leave the traditional exit note which Biden read and chose to keep private until he spoke with him, calling it generous. Ex-Vice President Mike Pence attended, extending diplomacy. Now, let’s go back to 2-weeks ago when The Nation experienced an uproar almost similar to The Boston Tea Party, just to reference something from America’s past. Do you know that it’s the Constitutional Right for The People to rise up and overthrow their government if they no longer see it fit? So when Prosecutors are rounding these folks up, they need to realize that. A charge of treason wouldn’t apply. Remember over The Spring & Summer when there were racial issues continually arising with the senseless murder of Blacks at the hands of The Police and other White Men, during The Covid-19 Crisis, it sparked major tension throughout our cities leading to riots, burning & looting, and so forth, by a mix of Colored & Non-Colored Protesters, yet there was no major Prosecution of that. So what we learn is as long as The Fight remains in The Street, tearing down businesses, marching & chanting, then that’s not seen by ‘The American Powers That Be’ as a revolution. But when a mainly Caucasoid group march forth protesting against an Election lost, and storm Capitol Hill breaking in, then you see that as shocking. You were so frightened that it invoked the reality of The French Revolution possibly happening here. Well you wouldn’t have hesitated to shoot had you seen a bunch of angry Blacks marching forth. You would have already been geared up with every trooper in sight. Well many Blacks have made the sacrifice willing to die in the past fighting your bigot government. That’s how we got to where we are today. The reason why this time around The Troopers stepped aside and let The White Protesters in, is because they felt the same way. They believed The Democrats stole The Election. So let’s be fair. When Trump won The Election in Nov 2016, and was accused of collusion with Russia, Democrats didn’t storm The Capitol, they just talked about it, and let a case slip through their fingers. So fast forward to the events a few weeks ago where 5 people died, when a disgruntled Republican President with a lot of power who was made fun of, was able to stand up at a podium, wave his Ivy League hand at a rally of furious fans and made a couple comments which they followed through on, showing you how many voters he really had. They were even willing to lynch Vice President Mike Pence for not using his power at the time to declare Trump, The Winner but to be fair, he did not comply with the democratic interest of impeaching Trump and taking the reins about 2-weeks before this Inauguration. And to this day, these Voters still hold to their conviction that Trump is still their President. So now showing proof of voter fraud is irrelevant. You now have a problem trying to be President over these people. So now that you hold The Reins of Power Joseph R. Biden, are you prepared to make possible racial decisions that may not sit well with The Public? You see, when you look out the corporate window of your White House you’re not exactly going to see a mix of people from all races, shapes & sizes, what you are going to see is just a sterile inanimate non-gender being looking back at you with one half of its face white & the other half black. That’s how decisions are going to be made. They’re mainly perceived that way because America is not the integrated melting pot we pretend to be and The Trump people know that. They don’t pretend everything is alright. They know the problem. You might need to make the unpopular choice one day of needing to do something racist for political reasons. With your current alliance with novel ideals, it will be pretty hard to assert a much needed racial move to globally protect The Nation, without upsetting The Apple Cart. But if your color is Orange, and you care about the color green, you made no promise either way that a black & white gender-less being can hold you to. So you go about your way leading and building, and IT can’t impose a demand or make a case for something. Many Black Men have not forgotten your racist rhetoric back in the day Joe, about eliminating them from The Streets because they’re Super Predators. And now you have former Prosecutor & Senator, now Vice President Kamala Harris at your side who was criticized for locking up many Blacks on trivial charges. Do you realize how you look? Trump didn’t look any better, but why did certain Blacks choose him instead, well it was The Lesser Of Two Evils, Trump’s realism and off-the-rails ways sometimes appeals to some Progressive Blacks because it led to something good. If you had 2 Plantation Owners contending against one another. You notice that Joe goes around smiling with the local Politicians, he has Black friends, he pretends he cares about certain issues over the years, but signs on to policies that cripple any chances of Black Liberation. Meanwhile, openly racist Don goes around to his golf course, hangs out at his Country Club, and so forth, not really caring too much about poor people’s problems, but some Abolitionist out there doing some outreach program in his parts, sells an idea to him, he listens and funds the program and then a week later he sees the rehabilitation of some hapless Black Person, and the Negro moved on a week later to becoming a Corporate ShareCropper, then he’s doing a little better than that other Black Person stuck on the Democratic Plantation looking at a ‘Black Lives Matter’ sign his Master just painted as a commemorative accomplishment, after a negro he knew died, after a terrible whipping on that spot. Now I’m sorry for coming up with an analogy like that, but this is how a lot of Sensitive Blacks in some communities are seeing you. They weren’t very happy with Barrack Obama either. Mainly Black Women liked him. So now, let’s look forward to Kamala Harris becoming President. It will be the first, a humongous step from Slavery since the 1600s. It took this nation that long to overcome the idea of electing a Colored Female to such a prominent Public Office. The expectations and burden she’ll have to bear. Anyway, good luck to your occupancy in The White House. And beware that your Presidency isn’t overshadowed by the harrowing figure of Donald J. Trump.

Sign,  
Lhisa Mrklon  
Agent Of Fortune

### Do You Have Faith In Joe Biden & Kamala Harris Leading You? Scroll Down And Leave Your Reply Below.

[![Ferrelux Homepage_Biden Inauguration](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193534053/2wRW56OwCo.jpeg align="left")](https://ferrelux666.wordpress.com/ferrelux-homepage_biden-inauguration/)

[![We The People 2021](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193535472/jvXK86jaB.jpeg align="left")](https://ferrelux666.wordpress.com/we-the-people-2021/)

[![Violent Trump Protesters At Capitol Hill](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193536575/8DzFegfCr.jpeg align="left")](https://ferrelux666.wordpress.com/violent-trump-protesters-at-capitol-hill/)

[![The United States Capitol Building in Washington, D.C. was breached by thousands of protesters during a "Stop The Steal" rally in support of President Donald Trump.](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193537865/azaN7hIrL.jpeg align="left")](https://ferrelux666.wordpress.com/capitol-building-breach-stop-the-steal-rally-in-d-c-1-6-21/)

The United States Capitol Building in Washington, D.C. was breached by thousands of protesters during a “Stop The Steal” rally in support of President Donald Trump.

[![Trumpers At The Hill](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193539322/gWc4maAaz.jpeg align="left")](https://ferrelux666.wordpress.com/trumpers-at-the-hill/)

[![Trump Supporters Scaling The Wall](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193540622/HL3lLhD1K.jpeg align="left")](https://ferrelux666.wordpress.com/trump-supporters-scaling-the-wall/)

[![Inauguration Day, Bide Harris](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193541933/EyzMa5aH4.jpeg align="left")](https://ferrelux666.wordpress.com/news/inauguration-day-bide-harris/)

[![Mob Storms The Hill](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193543452/Zin6hZ8tl.jpeg align="left")](https://ferrelux666.wordpress.com/mob-storms-the-hill/)

[![The Hill, Breached](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193544938/6NuCQemqa.jpeg align="left")](https://ferrelux666.wordpress.com/the-hill-breached/)

[![Troops In DC](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193546080/kqwg2mXsu.jpeg align="left")](https://ferrelux666.wordpress.com/troops-in-dc/)

[![ATLANTA, GEORGIA - NOVEMBER 26: Daniel Blackman speaks onstage during Hosea Helps Thanksgiving Dinner Drive Thru at Georgia World Congress Center on November 26, 2020 in Atlanta, Georgia. The annual event was converted into an drive thru outdoor concept due to ongoing COVID-19 pandemic. (Photo by Paras Griffin/Getty Images)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193547311/lkI9ZVGxG.jpeg align="left")](https://ferrelux666.wordpress.com/hosea-helps-thanksgiving-dinner/)

ATLANTA, GEORGIA – NOVEMBER 26: Daniel Blackman speaks onstage during Hosea Helps Thanksgiving Dinner Drive Thru at Georgia World Congress Center on November 26, 2020 in Atlanta, Georgia. The annual event was converted into an drive thru outdoor concept due to ongoing COVID-19 pandemic. (Photo by Paras Griffin/Getty Images)

[![Angry Trump 2021](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193548937/QW-Adw7jc.jpeg align="left")](https://ferrelux666.wordpress.com/angry-trump-2021/)

[![Inauguration Day 2021](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193550273/rckkHHUdm.jpeg align="left")](https://ferrelux666.wordpress.com/inauguration-day-2021/)

[![Biden-Harris Inauguration 2021](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193551217/uSooZggbO.jpeg align="left")](https://ferrelux666.wordpress.com/biden-harris-inauguration-2021/)

[![Capitol Hill, MAGA](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193552441/QUyWyY-HU.jpeg align="left")](https://ferrelux666.wordpress.com/capitol-hill-maga/)

[![Capitol Hill](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193553693/vYev7pGzJ.jpeg align="left")](https://ferrelux666.wordpress.com/capitol-hill/)

SHOP ITEMS ON SALE  

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193555463/MqA-ydmcL.jpeg align="left")](https://lightinthebox.tv2h87.net/c/3170166/805530/8199?prodsku=8739485&u=https%3A%2F%2Fwww.lightinthebox.com%2Fmen-s-rain-suit-rain-jacket-pants-hoodie-jacket-outdoor-reflective-waterproof-breathable-stain-resistant-jacket-pants-trousers-top-fishing-camping-hik_p8739485.html%3Fcurrency%3DUSD&intsrc=PUI2_5801)
