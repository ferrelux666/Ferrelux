---
title: "\U0001F6F8Avengers: Infinity War (Movie Review)\U0001F30D"
date: '2018-08-10T22:13:01.000Z'
slug: avengers-infinity-war-movie-review
tags:
  - space
  - entertainment
  - thanos
  - earth
  - planet
  - angel
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195399155/fSFTVEXkl.png
canonical: 'https://ferrelux666.wordpress.com/2018/08/10/thanos/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195361360/5NhQ47E4T.png align="left")](https://en.wikipedia.org/wiki/Thanos)

[Megadeth ~ ‘Symphony of Destruction’](https://myspace.com/megadeth/music/song/symphony-of-destruction-2139937-99176914)  
Optima Mors Parca Quae Venit Apta Die 🏴‍☠️ The Best Death Is That Which Comes On The Day Chosen By Fate (Propertius)

**Oh my! When this movie was released back in April of this year, I couldn’t wait to see it. After that, like everybody else who knows better, I had to contain myself from spilling the secret of what happened so others can enjoy the movie without spoilers. So I concentrated on writing other meaningful blogs that mattered in the world for my followers, until this time to share my views on the film.**

**Like the movie ‘Black Panther’ it was an experience. Okay! Thanos won. YES, the villain won. Had the Creators of the film left it with the original title, ‘Avengers: Infinity Wars Part 1′ it would have been obvious. People were so mad/disappointed in the theater, even the after credit scenes where we see Thanos’ power eliminating anticipated enemies. There are so many spoof videos I keep tripping over on Youtube, with opinions about how the film should have ended, to making fun of it outright & I bet this will STILL go on till we see the next Avengers movie, because the content, like ‘Black Panther’ leaves one with a lot to think & talk about.**

**Oh where do I start. I’m going to be all over the place with this. Some people prefer to see the movie as a simple comic form come to life with an entertaining storyline. Many films though, tend to have other meaning behind it, so if you are into conspiracy, supernatural stuff, then one can see the movie in those terms. First off, you will have to decide whether our villain, Thanos had his head chakra open already with the possession of 1 infinity stone at the start of the film, or whether his head chakra opened after he possessed the other 5. He’s a giant alien being form the planet Titan seeking to be a god. Now……in biblical times there were giants on the Earth brought about through the copulation of Angels & Humans. Their offspring were called Nephilim. The bible said they were great in the land, ruling over humans. Archaeologists have found evidence of the biblical story being true in the form of skeletons, writings, & stone imagery but our society today don’t bring it up much in any of the  mainstream media. So with Thanos, I got the sense that he was lacking something, lost something, or cut off from something. In the Marvel comics world, he was not someone I followed since I had other favorites including these three: The Mandarin (who battles Iron Man & The Avengers at times) & Galactus (who “owns” the Silver Surfer as his Herald), & Apocalypse (who battles the X-Men) all of whom Thanos should remind you of. Now, I loved watching his progress as he intelligently & relentlessly went around the Universe getting those stones. He had a competent team dedicated to helping him. I particularly liked Ebony Maw, that ugly gray alien with all the powers who’s a member of the Black Order. He was soooo effective until he got frozen drifting in space. I hope he’s brought back in action in Part 2. The dude had a mission that was personal & did not allow Superheroes to stand in his way. While the good guys were making jokes about nonsense, standing there deliberating shit, Thanos was thinking about quickly acquiring POWER. And while the Superheroes were talking shit, joking around the galaxy, imminent galactic domination was happening all around them & they didn’t have the collective power to stop it.**

**Now let’s look at the 6 infinity stones……..Time, Power, Mind, Reality, Space, & Soul. The object was to gather them one by one for his gauntlet. Thanos was already in possession of one of them. He certainly had the power as this imposing giant tore apart worlds to get what he wanted, acquiring another stone & then another increasing his near-god power. His successful team, some of them coming from young persons he would save from the planets he went around destroying whom he’d father. One of those children turned out to be Gamora. Who made valiant attempts to stop him, but with that kind of universal power, it became an impossibility. She ended up losing her life because if you think about it, she’s an enemy now to HIM, so sacrificing her for the soul stone made sense.**

**We see a pivotal moment of the film where the last great battle ends up being in Wakanda, where the Black Panther & all his united tribal warriors are out there with him shouting something that sounds like ‘Evonpeh’ or ‘Ebombeh’ as some war cry & them repeating it. You would think at this point in the film, the good guys would win with all those powerful Superheroes working towards defeating Thanos. Instead we see, the giant catch Black Panther as he leaped up on him & his giant fist punched the side of Black Panthers head & he fell.  Oh well…….on a side note, had a previous enemy of the ‘Black Panther’ in that movie, Eric Killmonger, succeeded, he would have been the leader, probably an ally to Thanos & Wakanda would have been spared being casualties of the war. Nobody else on the battlefield was able to stop Thanos as he eventually battled the Marvel Comics hero, Vision for the last stone. Well, I didn’t expect him to win, he was already failing & the Scarlet Witch could only do so much. I blame 2 Marvel heroes for this: Doctor Strange & The Might Thor. It didn’t need to go that far. Before, Doctor Strange & Iron Man were battling him. It could have been stopped there had Doctor Strange set aside his stupid moral ethic of never using the Time stone for fear of the theory of absolute power corrupts abosolutely or some other do-gooder philosophy BECAUSE in a situation like that, he wold have been wiser to compromise his code for the GREATER GOOD. Now……There is a scene in the film where Doctor Strange did use the time stone to see the ONE opportunity to defeat Thanos. I still say, why all the deaths & time wasting. Why even let it get there. Just use the stone & stop the WHOLE  damn thing. Even if he waited through virtue of his own conscience, to bring people BACK, you’re still using the same power. At the end of the film, I blame Thor because he made a MIGHTY leap up in the air with his godly hammer & struck Thanos in the chest (heart) & thought that would work. Well…Thanos smirked & remarked ‘you should have struck the head’. That should have made more sense to Thor as Thanos was coming into his last god-like power. When someone can control time & reality and you successfully defeated him once, you won’t get a second time to do so. They were not thinking. That was Gamora’s problem the first time. So now, Thanos, anticipates future problems & decides to get rid of ANYBODY now that will pose a threat including Spiderman, Black Panther, Groot, etc. We are left with whoever he doesn’t feel threatened by like, Rocket The Racoon, Iron Man, The Hulk, Shuri & the other Black Panther women along with M’baku & his tribe & others. So what now, with other people in the Marvel Universe removed from the scene like Nick Fury, who was trying to send off a signal to someone at the end credits of the film, maybe The Fantastic 4 or X-Men, so in the next film we get to see what happens, like does The Incredible Hulk ever get his act together to fight Thanos. He was having annoying comic relief problems throughout the movie.  For now, we see an accomplished giant still ruling the planet Titan, seated on his armed throne, using his powers to maintain a universal balance, and delighting in seeing the sunrise. I don’t know what the next film will bring, but I do expect a heroic victory.**

**SOME LINKS**  
[https://en.wikipedia.org/wiki/Thanos](https://en.wikipedia.org/wiki/Thanos)  
[https://en.wikipedia.org/wiki/Ebony\_Maw](https://en.wikipedia.org/wiki/Ebony_Maw)

[https://www.express.co.uk/entertainment/films/951691/Avengers-Infinity-War-ending-EXPLAINED-Doctor-Strange-how-to-beat-Thanos-Avengers-4](https://www.express.co.uk/entertainment/films/951691/Avengers-Infinity-War-ending-EXPLAINED-Doctor-Strange-how-to-beat-Thanos-Avengers-4)

**~ Lhisa Mrklon**

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195362921/aXp_kSSg0.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195364282/BKYQlrGnG.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195366426/J6Aflzhw9.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195367948/NDC5aIwUj.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195369145/ufyTCxrg3.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195370531/JoTaLlyvr.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195372526/_KtzQ-Wgv.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195375236/mw8QiyIn9.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195377431/K3qZTTUeF.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195379927/PGxDoyyKJ.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195382490/ZW0FY_TjC.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195385194/z2Om779mR.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195388663/m1yjOA_to.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195392330/hplZi9MsR.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195396049/KoaVDkYZF.png align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195397367/UWK5Sdlo8.png align="left")](https://ferrelux.com/adverts/)
