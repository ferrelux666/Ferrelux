---
title: "\U0001F3A4 Jussie Smollet In Court Again \U0001F3DB"
date: '2021-12-06T05:12:45.000Z'
slug: jussie-smollet-in-court-again
tags:
  - attack
  - tv
  - scam
  - africa
  - nigeria
  - pandemic
  - covid-19
  - race
  - fake
  - fraud
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672192367667/Wc9188l53.jpeg
canonical: 'https://ferrelux666.wordpress.com/2021/12/06/jussie-smollet/'
---
[![Jussie Smollett Trial](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192315611/EOJkHzRZW.jpeg align="left")](https://www.foxnews.com/entertainment/breakdown-charges-jussie-smollett-trial)

\*\*[“Battle Cry” ~ Jussie Smollet (Jamal Lyon, Empire)](https://www.youtube.com/watch?v=hp3BtVFP4OQ)  
\*\***I Refuse To Lose This Battle…….No I Will Not Fall Today**

**Ego Vis Permanere Esto Idem Homo Semper Fui 🎹 I Want To Continue To Be The Same Man I’ve Always Been (Jussie Smollet)**

This is where I left off on Juicy Smullet’s case previously in [2019](https://ferrelux.com/2019/07/31/jussie/), and [2020](https://ferrelux.com/2020/03/18/smollett/). So Jussie’s Attorneys tried to get his case dismissed, but The Judge said no. Why is this going to trial in the Leighton Criminal Court? Well, somebody wants him convicted. It wasn’t enough to see him get off the first time, with a resolution in place that all Parties agreed upon. And because he didn’t act in a manor they thought was atoning, he incurred their wrath coming against him yet AGAIN, this time with charges they believe are more provable, 6 counts of disorderly conduct, made possible since the former Judge on his first case, Michael Toomin, ordered Special Prosecutor Dan K. Webb, to look into that case further, which he was all too eager to do, AND NOW securing The Nigerian Brothers, Abel (Bola) & Ola Osundairo (Abimbola & Olabinjo) to testify for The Prosecution, when in the first trial, they were more interested in leaving the whole thing alone. Well, I think Cook County would do best going after some hardcore criminals worthy of the media attention. Almost everybody sees Jussie guilty already since the first time, that all the prejudice out there is not good for his what it seems like **\_***‘double jeopardy’***\_** case over the same issue this time around. He’s getting the speedy trial, but how long will this mess play out though before he can get back to his life and the media projects he is working on? Does he need to be put through this again? We all should have moved on from this issue. Judge James Linn did not grant a Mistrial. Now I get that The Chicago Police Department have a right to be upset over the whole thing if it was all a **HOAX** but we shouldn’t be hearing more of it if certain things can be settled out of Court. I’d rather the hate crime be a hoax than it being real in any city. There are real unsolved hate crimes happening all over the country though that needs the attention more, than Jussie Smollet. Trying to make an example out of him subtracts from the reality of a true Perpetrator more deserving. Given Jussie’s tragic situation already he has to live with, rather than focus on trying to hate him, why not use the circumstance. Awareness has already been drawn on to a supposed **FAKE HATE CRIME**, so now what? How do we bridge that to the many still happening? While we wait, Jussie’s trial case resumes as he is keeping to his original claim that he suffered a biased attack on his way to pick up a sandwich at **SUBWAY**, with many already anticipating his further downfall, while others like myself are expecting a bit more favor awarded to him. It would be interesting if he actually takes The Stand. There may be **\_***some***\_** information to disclose explaining **EVERYTHING ! ! !** Remember before, the previous Prosecutor on his first case, upon hearing **\_***something***\_**, went no further with his case nor commented much on it. And The Public, as well as The Judicial System should have respected the decision, and let it remain that way. They should not have been that concerned over some gay boy’s nigger shit. And even if it concerned something a bit more substantial, you see the powerful people who came to his aid though. Mayor Lori Lightfoot, Kim Foxx and others did the right thing. I don’t know why Former Mayor Rahm Emanuel felt like he needed to disrespect Jussie after the fact. That Former Superintendant of Police Eddie T. Johnson who was talking the loudest, eventually got terminated from his job, and is still facing some problems in his life cropping up to this day. Now Judge Michael Toomin is out there complaining that The Democratic Party retaliated against him for what he did in that case the first time around by not keeping him installed as a Judge any more. Well, sometimes, you need to think about THE BIGGER PICTURE, and the possible consequences of not complying. I’ve BEEN telling Ya’ll. Just studying some things out here, I’m well aware of more than you think. Sometimes when I say or write stuff, and you see me act a certain way, I’m not only thinking about the things underlying certain issues, who the person is and his or her connections, but I’m also sensing other things, and am more concerned about **The Greater Good** or **some other purpose**. A part of being moral is also recognizing **\_***when***\_** not to be so absolute. And when you are in a position to decide and act on resolving an issue as if you were God, you must weigh your choices carefully, because not only might it affect you, but you are also setting forth something In Effect.

**SOME LINKS**

[https://www.cnn.com/2021/11/29/us/jussie-smollett-how-we-got-here/index.html](https://www.cnn.com/2021/11/29/us/jussie-smollett-how-we-got-here/index.html)

[https://pantagraph.com/news/state-and-regional/crime-and-courts/chicago-activist-banned-from-courthouse-during-jussie-smollett-trial/article\_9363e815-1651-500f-aae7-d1cee33c685c.html](https://pantagraph.com/news/state-and-regional/crime-and-courts/chicago-activist-banned-from-courthouse-during-jussie-smollett-trial/article_9363e815-1651-500f-aae7-d1cee33c685c.html)

[https://www.usatoday.com/story/entertainment/celebrities/2021/11/29/jussie-smollett-chicago-trial-everything-to-know/8790967002/](https://www.usatoday.com/story/entertainment/celebrities/2021/11/29/jussie-smollett-chicago-trial-everything-to-know/8790967002/)

Sign,  
Lhisa Mrklon

### Should They Have Pursued Trying Jussie Smollet Again, Even Though His Case Could Have Been Left Alone Under The Original Agreement? Scroll Down And Leave Your Reply Below.

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/zl3aEVhg72U?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192317157/Xz2TZ51JJ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192318891/IhqXYapGj.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192320551/aLmtKMpK4.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192321886/cxCSN2SU-.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192322985/JqrVDN27Z.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192325220/DObCe3xKx.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192327109/M2CD_NERr.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192329791/KiRy_qjMs.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192332195/Zm1Fh_HAO.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192339992/kpWbRdFJf.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192341423/6aae1oA6U.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192342659/mA-LzMYMv.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192343851/wdbrMibWB.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192345176/1Ufu9VigW.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192346876/ocGG02sFB.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192348335/D2_NL87c6.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192350092/OGzGbNNmi.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192351318/nekfNi61o.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192352935/yvoHBIxGo.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192354417/mVjC8tcn1.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192355639/hfV8kz9zz.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192357012/nyHJ_RNgb.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192358723/_CujdC8Ym.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192360070/SULVXnvH8.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192361286/LzvFINqLr.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192362543/2BSW8VXue.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192363930/eX438fM4v.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192365146/02BbpaLA9.jpeg align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192366472/-RbZES3C_.jpeg align="left")](https://ferrelux.com/adverts/)

### Like this:

Like Loading...

### *Related*
