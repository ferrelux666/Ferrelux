---
title: "\U0001F628 Terror Israel, But Iran \U0001F631"
date: '2024-04-16T00:04:30.867Z'
slug: terror-israel-but-iran
tags:
  - bomb
  - terror-attack
  - israel
  - iran
  - russian
  - terrorists
  - muslim
  - city
  - bible-prophecy
  - social-justice
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1714531259899/c6fb7c7f-7fec-451b-8ed4-c04701c20650.png
---
🎵 [**The War Song By Culture Club (Boy George)**](https://www.youtube.com/watch?v=qxZ713xyacY)

*Ex Dolore Animas Fortissimas Emergere; Maxime Ingens Characteres Sunt Adusta Cum Cicatricibus* 📜 🕌 ☪️ 🕋 ✡️ 🕍 📖

Out Of suffering Have Emerged The Strongest Souls; The Most Massive Characters Are Seared With Scars *(Khalil Gibran)*

🎮 **Sponsor:** [Support Ferrelux's News Reporting By Buying Gaming Products Here](https://www.stacksocial.com/collections/electronics-gadgets/gaming-toys/?aid=a-1af3pey3)

✍🏻 **Social Justice:** [https://act.uscpr.org/a/callforgaza](https://act.uscpr.org/a/callforgaza)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1714535391240/703abb23-0e2a-4010-83ae-33511b840731.jpeg align="center")

Another one of my play on words, Terror Is Real, But I Ran. This is talking about the current missile attacks on Israel right now coming from Iran, and I’m also alluding to the recent terrorist attack that happened in Moscow a few weeks back, which I found odd, but let me go back to where this first began in October 2023 when Israel first came under an unprecedented attack. You knew it was going to go on and war might pop over the globe due to Alliances. And since it involves some surviving Captives that day being regularly tortured, Israel is being tactful. Now their weaponry to combat incoming missiles is impressive, it’s called **Israel’s Defense Dome**. They are holding it down over there with help from America. Whether they will ultimately win or not remains to be seen. They are surrounded by competent Arab Nations who are more likely to align than remain neutral. So it is tit for tat. Biblically, we do know that at some point, an Amazing World Leader will arise uniting Christians, Arabs, & Jews since the religious leaders from each group will recognize Him as The One. And I’ll share more in the future. For now, it is any nation’s game. The Arabs may or may not win their struggle. This round depends of The God each one prays to since some Christians in recent years are **NOW** disputing whether Allah is actually the same God as Jehovah or Yahweh, same difference citing their perception of Scripture. Well this raises problems because for many years they have accepted Muslims as worshiping The One True God. What is happening is that many Free People around the globe, don’t agree with their way of life or how they look and their unequal treatment of Women. Conversely, they can make an argument of hypocrisy in how The West operates in that regard also. The Monotheistic Faiths concur though for the most part. To be questioning it now would be political, so instead of a Trinity among those 3 Beliefs, you’ll have just **The Christian & The Jew**, but there can be problems there also since Today’s Modern Jews don’t exactly hold Jesus in The Highest regard or his Mom. Muslims at least treat him with respect, but only seeing him as a Prophet and not The Begotten Son Of God. So The Christian appear to stand alone on this. Without Islam or Judaism to side with, is there any other related Faith that acknowledges Jesus’ True Status? *Well,* there is without question, depending on The Believer. The average Satanist generally claim that they do not believe in Satan, but the rites say otherwise. Depending on who you follow “practicing” it, the person may not shove off the belief in an actual Devil, by claiming themselves engaged in Free Will activities as being antithetic to Christian values, but the person may actually engage you into a real in-depth spiritual conversation that might intrigue you. I have done it on occasion, not trying to tempt or convert that Christian or Atheist, but to de-mystify myself a little when asked, and talk Scripture. On occasions in the past after the 4 or so hours of talking to the person, I won. And I mention this because if you are some lost soul, someone with little Faith in God, mad at Jesus, having little or no knowledge of The Bible, it’s not good. All this happening around you is a part of a greater Spiritual War. And some people that appear to be non-religious actually are. Some wear their Faith their sleeves, being easily offended. For a mighty long time, people just assumed I was some type of Christian in the traditional sense. I don’t look like the Stereotypical Satanist and many of them with Mainstream Occupations don’t seem like it either, but we can read one another in Public. They look and sound like Christians coming from that. This may surprise YOU, but it is no shock to some. My point is, the best **Marriage Partner** for a Christian right now **IS** The Enemy. He believes in you. What Devil or Demon does not know God? They know The Scripture and can quote it. They recognize God. A real devout Satanist / Luciferian knows disregarding Christ and who He is as just some Prophet like Muslims regard him is misguided, and seeing HIM as a product of sex out of marriage with Mary sleeping with a Roman Soldier as some Jews regard, is totally devaluing his existence. **Satan has never seen Jesus anything less than who HE IS**. And We Know. So if The Christian Church is looking for a Monotheistic Partner right now Luciferians are The Ones. Last I checked, they revere Lucifer and see his Divine Opponent as Gold Almighty as fully described in The Holy Bible without question, yet you cleave to Muslims and Jews in your Pantheon though you know they criticize the cornerstone of your Faith. When I here somebody say one or two disparaging comment about The Existence of Jesus, what I hear is that you don’t believe in Lucifer or Satan either because you cannot have One without the Other and I’m there arguing with you better than that Christian. And I have more philosophies to share with you as we go on because it entails trying to teach profound concepts in a way you will comprehend. So back to this thing with **Israel Vs The Arab Nations**, it may appear to be a dispute over LAND, but it is more a fight over FAITH & CREED. Though **The Muslim & The Jew** have more in common than **The Christian**, when it comes down to the core of things, The Christian will have to stay out of it stand alone because you are an offense to them. Right now siding with either Party in that conflict, looks a certain way to either side and you are not being a **Peace Keeper** or adequately trying to resolve it, especially if you might be **The Culprit** behind the problem in the first place.

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1714529328961/f9b30a20-38cd-4d2a-b358-975048d8d1b6.jpeg align="center")

And now fifteen days later, it's **Tuesday April 30<sup>th</sup> 2024**, the end of Passover, although I Observe Myself. So tying the theme of my last [Easter](https://ferrelux.com/a-dark-easter-sacrifice) article into this whole occult thing, notice that the ancient Assyrian city of Nineveh plays a role and The World is partly at war right now until it reaches all The Prospective Players. Their problem should not be our problem as it was better contained in Pre-Millennial times all the way back to The 60s and perhaps beyond in a way that nearly did not affect us. The great failure from yesterdays until recent was not conquering the entire region.

[https://www.ancient-origins.net/ancient-places-asia/nineveh-0010595](https://www.ancient-origins.net/ancient-places-asia/nineveh-0010595)

[https://www.youtube.com/watch?v=IB21UoMTPeo](https://www.youtube.com/watch?v=IB21UoMTPeo)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1714531627819/8362bde1-1a9a-4a7e-bde4-39db83e64888.jpeg align="center")

I did the below short video weeks ago talking about when Russia suffered a recent terrorist attack as if it deserved to. It’s debatable as to who that really came from. I guess ignorant Arabs might hurt the city of Moscow, failing to notice how Russian President Vladimir Putin’s name actually can partly be translated to **Vlad Aemer** Putin meaning A Powerful Ruler. And not only that, some non-classical buildings in Russia in part resemble Middle Eastern architecture, like a mosque and maybe the word Moscow was derived from that.

🫨 [https://ferrelux.substack.com/p/terrorist-attack-in-russia](https://ferrelux.substack.com/p/terrorist-attack-in-russia)

Sign,

Lhisa Mrklon

The Goddess Has Risen

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1714528947697/b403b661-727d-465b-ab19-a956d892d475.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1714531947825/0f10546f-5391-4a7c-b964-50fab213178c.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1714531983908/75bbfe78-97de-4c5b-b791-452187bee8f6.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1714532508706/e6c3b57d-b5af-4f1d-bcc1-594b5bbcdbbc.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1714532561891/c63fec4e-d20b-42c4-b870-95e896c12b89.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1714532579971/250d9d9c-ab40-45f9-bf08-d9cc8e2e3d7d.jpeg align="center")

💣💣💣💣💣💣💣💣💣💣💣💣💣💣💣💣💣💣💣💣💣💣💣💣💣💣💣💣💣

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1723426080076/42eb9d21-1c83-46b7-ab4d-894e194a9d64.jpeg align="center")](https://www.stacksocial.com/sales/treblab-hd-360-portable-bluetooth-speaker/?aid=a-1af3pey3)

#169
