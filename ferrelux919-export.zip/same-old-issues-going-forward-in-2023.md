---
title: "\U0001F55B Same Old Issues Going Forward In 2023 \U0001F387"
date: '2023-01-14T21:08:24.000Z'
slug: same-old-issues-going-forward-in-2023
tags:
  - news
  - inspiration
  - tv
  - new-year
  - field
  - entertainment
  - topics
  - '2022'
  - '2023'
  - december
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1675292501179/a0e1af80-8e63-4943-a649-0f1ed7fad1ec.jpeg
canonical: 'https://ferrelux666.wordpress.com/2023/01/14/new-year-2023/'
---
[![NYC 2023 Fireworks](https://cdn.hashnode.com/res/hashnode/image/upload/v1673755997653/FstGLt1f0.jpeg align="left")](https://www.dailymotion.com/video/x8gtysk)

[`Scott Joplin - The Entertainer`](https://odysee.com/@sound10gic:6/scott-joplin-the-entertainer-%281902%29:b)

Magnus Ab Integro Saeculorum⏳The Great Cycle Of The Ages Is Born Again (Virgil)

**So we closed out 2022. Was that year good for YOU? It certainly wasn’t for me, but we’ll discuss that matter future on. I see already for the New Year The Biden’s are still being plagued by that Burisma issue and the newfound paperwork The Feds dug up, but was it real or planted. I guess with 2024 drawing nearer and nearer by the time you toss here and there, blink and stare forward, The Feds are wasting no time in developing a plan to stop Biden also from moving forward, as they tried with Trump. And I’ll disclose later on my views on that as things progress. For Now, see my gallery showcasing 2022 topics I covered and be mindful of The Dr. King Celebration Week.**

**DR KING EVENT STREAMING LIVE**

[![MLK Speech Art_square](https://cdn.hashnode.com/res/hashnode/image/upload/v1673755998748/oCMYNMCCx.png align="left")](https://www.wbtv.com/2023/01/13/2023-dr-martin-luther-king-jr-television-special-airs-monday-wbtv/)

\*\*  
[People Who Died In 2023](https://people.com/celebrity/celebrity-deaths-2023/)\*\*

**Was 2022 The Year For You?**

**Sign,  
Lhisa Mrklon**

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756000416/YHlP8XJ3j.jpeg align="left")](https://miniinthebox.8zwg.net/c/3170166/461413/8200?prodsku=6385251&u=https%3A%2F%2Fwww.miniinthebox.com%2Fmen-s-plus-size-casual-daily-simple-hoodie-sweatshirt-3d-print-hooded-inelastic-cotton-long-sleeves-fall-winter_p6385251.html%3Fcurrency%3DUSD&intsrc=PUI2_2952)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756001773/Y0Ct1r60Q.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756003547/lhVpzIgfN.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756004832/_d40gIaoi.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756006840/crrVOj2K-.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756008374/k-9kEptp0.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756009468/gvcjfio7m.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756011273/KQP7mVzpi.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756013313/oXFCQ36nB.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756015071/1-XxNitmp.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756017002/wTBLho56M.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756019385/DeFbb-X38.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756021383/_fmxxoY0N.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756023612/KPx5NMALY.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756025842/F0jHOZZqD.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756027641/_uUdsxe0y.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756029445/Vmfq3Lxm5.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756031246/MMfAIsh8f.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756033116/n_KDGAnQY.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756035029/jHzegOrnU.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756036993/zzMKRb4QN.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756039119/_mcWhhhJw.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756041878/8cS06MuWF.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756044107/ujWU34duo.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756046272/mnkCluXQW.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756048372/uBlZiBQyB.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756050493/Jzd7RSmmZ.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756052935/HaoKXvTKs.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756055126/FEZIkoWJC.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756057014/uKQH7qMtv.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756058919/tSJj7-CT-.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756060983/WhlJ5k8pE.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756062741/nHYgCSsGF.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756064823/MyI8jswWZ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1673756067228/Ytks99qH1.jpeg align="left")

Advertisement

### Like this:

Like Loading...

### *Related*
