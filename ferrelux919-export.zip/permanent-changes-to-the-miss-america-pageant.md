---
title: "Permanent Changes To The Miss America Pageant \U0001F621\U0001F92C"
date: '2018-06-27T17:21:41.000Z'
slug: permanent-changes-to-the-miss-america-pageant
tags:
  - rights
  - women
  - values
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195441521/dEyyZNljA.png
canonical: 'https://ferrelux666.wordpress.com/2018/06/27/miss-america-pageant/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195418765/GC1JG3Pfk.jpeg align="left")](https://www.ferrelux.us/)

Res Controversa 😲 Things In Controversy

**The Misguided Feminists are on the attack again. This time bashing a conventional symbol of feminism in an effort to carry on being a damn slob everyday. How can a man respect your feminine value in a cheap competition? One of the people responsible on the Board for this position is former Miss America Gretchen Carlson 1989. We remember her from raising the sexual harassment complaint about her former boss Roger Ailes, who was a major Fox 5 TV Executive. She won her lawsuit against him & he eventually died of bad health. That “Me Too” & “Times Up” move was her own personal win & a win for other women who were subject to that predicament, but now she’s reached over to a beauty competition that she won nearly 30 years ago & attacked it with an agenda. How sad, especially when she benefitted from it. She’s a part of the decision to erode the standards by getting rid of the Swimsuit & Evening Gown sections. The dismantling of showing a woman’s beauty is all an effort to just make it a plain competition. It will no longer hold women to a shapely health standard or the regal divinity. A heavyset woman with no grooming or polish, can just enter the competition, be a beer slugging slob on TV with a filthy mouth, & expect a young man to value that in her. She can basically be uncouth doing some kind of trick talent, without the worry of being seen out of shape & perceived as un-elegant, nor fear being judged for it. You could win the crown now for just being mediocre & men must just accept that & be proud of you for just being a low-quality you. THIS IS AMERICA! This is what the women have descended to & it started with ratchet Reality TV. ZERO aspiration to being “proper” & a person with beauty & strength to look up to, yet they wonder why their men are looking at foreign women. The typical American Broad looks like a dude & so she’s handled like one. No respect. Even the sportish looking foreign girl still looks feminine & fit. I’m a foreign Black Woman who is constantly receiving attention from all kinds of men in general & a lot of that has to do with being different. I might be the oldest female in the room at times, but I still look younger. The actual young female there has a problem out-running or out-swimming me. They also get angry when they realize how smart I am. WHY? Well when you are from certain parts in the world where you are expected to MEET A STANDARD, people notice. Because in these places around the globe it is still a practice. A Noble man can basically venture to common parts & still find a respectable poor girl to fall in love with & marry, who can fit into his preppy world since she holds the same interests & values. There is a quiet running joke amongst foreigners everywhere about the low-caliber of Americans & this is proven when they make moves like this. I wasn’t surprised to hear it, but saddened that the standards are getting even lower & how much stranger I might look to people out here still holding to mine.**

**~ Lhisa Mrklon**

**Some Links**  
[**https://en.wikipedia.org/wiki/Roger\_Ailes**](https://en.wikipedia.org/wiki/Roger_Ailes)

[**https://www.nytimes.com/2018/06/05/business/miss-america-swimsuit.html**](https://www.nytimes.com/2018/06/05/business/miss-america-swimsuit.html)

\*\*[https://www.usatoday.com/story/life/2018/06/05/miss-america-made-welcome-change-but-pageants-arent-problem/673819002/](https://www.usatoday.com/story/life/2018/06/05/miss-america-made-welcome-change-but-pageants-arent-problem/673819002/)  
\*\*  
[**https://abcnews.go.com/GMA/Culture/miss-america-scrapping-swimsuit-competition-longer-judge-based/story?id=55638426**](https://abcnews.go.com/GMA/Culture/miss-america-scrapping-swimsuit-competition-longer-judge-based/story?id=55638426)

> #### [Microfiber Summer Fall Comfort Novelty Club Walking Stiletto Heel Open Toe Rhinestone Shoes](https://www.spreesy.com/ferrelux/57/promotionId/94930)
> 
> Microfiber Summer Fall Comfort Novelty Club Walking Stiletto Heel Open Toe Rhinestone Shoes Colors: Blue, Purple & Gold Sizes: US6/ EU36/ UK4 CN36 US6.

[//cdn.embedly.com/widgets/platform.js](https://cdn.embedly.com/widgets/platform.js)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195419844/HN_IbQWgd.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195421702/CqH1hZH2K.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195423363/mE3WRqyoQD.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195424849/ocJhXGI7s.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195426645/qntSKLpN2.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195428632/hoUZUWbuj.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195430300/M3OfHtwh9.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195431869/2XY8GW7--.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195434113/ofcpGw3BO.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195435732/EfM-Q5Nva.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195437183/L-YUw7cEq.png align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195438876/ijLC5jR3P.jpeg align="left")](https://ferrelux.com/adverts/)
