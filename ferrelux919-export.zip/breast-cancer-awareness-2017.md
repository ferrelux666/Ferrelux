---
title: "\U0001F497 Breast Cancer Awareness 2017 \U0001F3E5"
date: '2017-10-11T17:30:29.000Z'
slug: breast-cancer-awareness-2017
tags:
  - health
  - food
  - exam
  - cancer
  - medicine
  - october
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195695966/3JwI8BaQ2.png
canonical: 'https://ferrelux666.wordpress.com/2017/10/11/breast-cancer-awareness/'
---
\*\*

[![Breast Cancer Awareness 2017](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195691023/9fLqNJBml.jpeg align="left")](https://www.dailymotion.com/search/breast%20cancer%20awareness%202017/videos)

Feminae Erit Bonus Salus 👩‍👧 Women, Be Of Good Health\*\*

**October is Breast Cancer Awareness Month.**

**Here Are Some Articles**  
[Everyday Health](https://www.everydayhealth.com/breast-cancer/breast-cancer-awareness-month/)  
[The Pink Ribbon](https://www.thesun.co.uk/fabulous/4651689/pink-ribbon-breast-cancer-awareness-2017-campaign/)  
[WHO On The Topic](http://www.who.int/cancer/events/breast_cancer_month/en/)  
[Wikipedia On The Topic](https://en.wikipedia.org/wiki/National_Breast_Cancer_Awareness_Month)

\*\*  
Some Videos On The Subject\*\*

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/V0R5S9hP7wM?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/tD9HVREnnYs?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/7D6OZnn0P5A?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/d8B2oqCN3Ao?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/2y4XfzsYF1E?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/K0hir_tGIqw?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195692439/mKa_PDZ2N.png align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195693907/w7vz2DdPg.jpeg align="left")](https://sovrn.co/1j4ozqd)
