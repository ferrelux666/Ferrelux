---
title: "CREED II (Review) \U0001F4B0\U0001F49E\U0001F306"
date: '2019-03-08T23:11:10.000Z'
slug: creed-ii-review
tags:
  - entertainment
  - boxing
  - america
  - russia
  - movie-review
  - romance
  - fighting
  - hollywood
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195204063/NKNYGDbGC.jpeg
canonical: 'https://ferrelux666.wordpress.com/2019/03/08/creed2/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195178482/FWKDPB4MV.jpeg align="left")](https://www.ferrelux.us/)

  
Iuvenis Bellator 👊🏾 Young Warrior  
[Creed 2 Soundtrack “Runnin” By Ludwig Goransson](https://www.youtube.com/watch?v=LPdsoKgljkc)

**I liked it. I held off from doing this story right after I saw the film because I wanted to see if it would win an Academy Award so I can include that too in my article, BUT, ‘The Oscars’ snubbed even nominating the movie.** **I don’t know why. They deserved attention. I thought the storyline was well written, & had some of the 80s Rocky charm. The film however was appreciated elsewhere and won other awards. Now, some guys thought it was a girl movie, & that it didn’t live up to Creed I, but they’re forgetting the evolvement of The Rocky franchise. You need to show the softer side of a tough guy. This happened with The Rocky movies, and now Creed. Here you had a boxer and his girlfriend committing their relationship further, and then a tragedy happens. History sort of repeats itself when like his father, Apollo Creed, Adonis gets his ass kicked by Viktor Drago to near death, but the referee, who I bet admired his Father’s greatness, stopped the fight leaving Adonis still with his rights to the championship belt intact. When Ivan Drago left Russia with his son Viktor, the agenda was to place Russia back on the map in the boxing world, through his son defeating Rocky’s protégé since Rocky defeated Ivan decades ago in his own homeland. Ofcourse, Rocky was trying to get Adonis to avoid this murderous challenge, barely surviving the onslaught himself back in the day avenging his dead friend Apollo in the movie ‘Rocky IV’, but Adonis could not shun destiny. And so we see a failed Adonis, eventually getting the help he needed from his father-like Coach, Rocky, training out there in God knows where, to gain the strength & skill he needed to withstand Viktor, because his dad trained him to be a killer in the ring. Also, he has a very injured casualty, his daughter, from womb trauma, was born deaf when her mom was in the arena watching in great pain as Adonis endured a vicious beat down by Viktor in the first fight. So we’re dealing with the need to win for vengeance & being the greater fighter. So, yeah, he won the second time around with even the opposing Fight Promoter himself applauding Creed on his victory. It was a great American moment as Russia lost again & Creed also winning the applause & respect of many of the Russians in the crowd. Viktor didn’t expect it, saved by his father telling them to stop the fight. He later consoled his son. At the end of the movie, they still train. What I especially loved towards the end, was Adonis going over to his fathers grave transmitting thoughts as he looked down at it with the famous signature stare of his dad, Apollo Creed.**

**Sign,  
Lhisa Mrklon**

**SOME LINKS**

[http://www.creedthemovie.com/](http://www.creedthemovie.com/)

[https://en.wikipedia.org/wiki/Creed\_II](https://en.wikipedia.org/wiki/Creed_II)

[https://www.facebook.com/creedmovie/](https://www.facebook.com/creedmovie/)

[https://www.imdb.com/title/tt6343314/awards](https://www.imdb.com/title/tt6343314/awards)

[https://www.thefourohfive.com/film/article/will-creed-11-finally-win-stallone-that-elusive-academy-award-154](https://www.thefourohfive.com/film/article/will-creed-11-finally-win-stallone-that-elusive-academy-award-154)

[![16-dolph-lundgren-creed.w700.h700](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195179997/KBgPcfx-q.jpeg align="left")](https://ferrelux666.wordpress.com/16-dolph-lundgren-creed-w700-h700/)

[![104459599](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195181244/Nq2aWNSLe.jpeg align="left")](https://ferrelux666.wordpress.com/104459599/)

[![1547129185_Creed-II](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195182584/KHK-ND3VB.jpeg align="left")](https://ferrelux666.wordpress.com/1547129185_creed-ii/)

[![CRD205_000084.tif](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195183746/pPBT2Yggi.jpeg align="left")](https://ferrelux666.wordpress.com/crd205_000084-tif/)

[![creed_ii_still_2](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195185038/YJY-mfUJs.jpeg align="left")](https://ferrelux666.wordpress.com/creed_ii_still_2/)

[![creed-2-crop-2-no-wm](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195186380/pRQrXnGKB.jpeg align="left")](https://ferrelux666.wordpress.com/creed-2-crop-2-no-wm/)

[![Creed-2-Movie-Teaser-Poster](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195187558/zvfpaj-jw.jpeg align="left")](https://ferrelux666.wordpress.com/creed-2-movie-teaser-poster/)

[![creed-2-rocky-references](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195189107/40CMegUBM.jpeg align="left")](https://ferrelux666.wordpress.com/creed-2-rocky-references/)

[![Creed-II-2018-movie-poster](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195190250/7wZJCIRtE.jpeg align="left")](https://ferrelux666.wordpress.com/creed-ii-2018-movie-poster/)

[![david_harbour_rocky_and_creed_split-h_2018](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195191739/dXGIyC_Bm.jpeg align="left")](https://ferrelux666.wordpress.com/david_harbour_rocky_and_creed_split-h_2018/)

[![Dolph-Lundgren-and-Florian-Munteanu-from-Creed-2-1](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195192861/VXfoq4KBJ.jpeg align="left")](https://ferrelux666.wordpress.com/dolph-lundgren-and-florian-munteanu-from-creed-2-1/)

[![untitled](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195194884/C8sbqu-GR.png align="left")](https://ferrelux666.wordpress.com/untitled-7/)

[![Real-Boxing-2-CREED-7](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195196504/u5YeNBF5u.png align="left")](https://ferrelux666.wordpress.com/real-boxing-2-creed-7/)

[![VR4Player-creed-date-01](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195197868/d8EQ5HSkv.jpeg align="left")](https://ferrelux666.wordpress.com/vr4player-creed-date-01/)

[![F](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195199638/GtdIm9daC.png align="left")](https://ferrelux666.wordpress.com/f/)

[![Ferrelux Homepage_March2019-Creed](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195201273/6aC4wJski.png align="left")](https://ferrelux666.wordpress.com/ferrelux-homepage_march2019-creed/)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195202662/eKO8Rs5rs.jpeg align="left")](https://ferrelux.com/adverts/)
