---
title: "Ecstasy Of The Rap Group Whodini Died \U0001F3A4\U0001F9E5\U0001F306"
date: '2021-01-08T02:56:57.000Z'
slug: ecstasy-of-the-rap-group-whodini-died
tags:
  - music
  - icon
  - group
  - entertainment
  - rock
  - artist
  - death
  - black
  - city
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672193593136/i53K0Wbjn.jpeg
canonical: 'https://ferrelux666.wordpress.com/2021/01/07/whodini/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193564024/hhkr1K0Ia.jpeg align="left")](https://www.rollingstone.com/music/music-news/whodini-john-fletcher-dead-1107571/)

[**Whodini – “Five Minutes Of Funk”**](https://m.youtube.com/watch?v=kwbtgcAo20k)**  
Principes Viros In Ludo 😎 Pioneers In The Game**

**I’m not going to let reckless events happening in 2021 throw off too much of my orderly list of topics this year like it did in 2020. So I’ll discuss my controversial views on that recent Capitol Hill Insurrection and other political stuff as they play out, AFTER I see whether or not a transition to President Biden happens or not in the coming days because it’s important to see people make their own independent choices sometimes without outside influence. For now, I’ll entertain you with the recent passing of a Rap Icon I felt should have received more mainstream coverage.**

**I recently learned that John “Ecstasy” Fletcher of the Iconic Rap Trio Whodini, died at age 56 on December 23rd 2020. The cause of death is unknown. Whodini was one of my all-time favorite rap acts. I simply loved their rap and fashion sense. I don’t have much to say because in cases like this, losing yet another musical favorite, I just grieve and enjoy the nostalgic past.**

---

SOME ARTICLES\*\*\*\*

[https://www.billboard.com/articles/news/9504425/john-fletcher-dead-whodini-ecstasy-obit/](https://www.billboard.com/articles/news/9504425/john-fletcher-dead-whodini-ecstasy-obit/)

[https://www.tmz.com/2020/12/23/whodini-john-ecstasy-fletcher-dead-dies-56/](https://www.tmz.com/2020/12/23/whodini-john-ecstasy-fletcher-dead-dies-56/)

[https://www.wsws.org/en/articles/2021/01/05/whod-j05.html](https://www.wsws.org/en/articles/2021/01/05/whod-j05.html)

[https://www.nytimes.com/2020/12/26/arts/music/john-fletcher-dead.html](https://www.nytimes.com/2020/12/26/arts/music/john-fletcher-dead.html)

[https://www.huffpost.com/entry/john-ecstacy-fletcher-whodini-dies\_n\_5fe4b32ec5b66809cb3090a7](https://www.huffpost.com/entry/john-ecstacy-fletcher-whodini-dies_n_5fe4b32ec5b66809cb3090a7)

[https://www.rollingstone.com/music/music-news/whodini-john-fletcher-dead-1107571/](https://www.rollingstone.com/music/music-news/whodini-john-fletcher-dead-1107571/)

---

THE MUSIC OF WHODINI  
\*\*\*\*[“Big Mouth”](https://m.youtube.com/watch?v=MBwQdKq9wRs)  
[“Funky Beat”](https://m.youtube.com/watch?v=WaVIPfN5HPg)  
[“Echo Scratch”](https://m.youtube.com/watch?v=N9UHetlKkec)  
[“One Love”](https://m.youtube.com/watch?v=qMnTawcUZLQ)  
[“Escape”](https://m.youtube.com/watch?v=f_AMhnkvUEc)  
[“Growing Up”](https://m.youtube.com/watch?v=v-GbnVjw3Pk)  
[“Be Yourself” Ft. Millie Jackson](https://m.youtube.com/watch?v=IHZKl8B9fpg)  
[“Freaks Come Out At Night”](https://m.youtube.com/watch?v=FxwrLLlQwBw)  
[“Friends”](https://m.youtube.com/watch?v=LRn2VQWNkgA)  
[“Rock You Again”](https://m.youtube.com/watch?v=QnCLTTe62kc)  
[“Rap Machine”](https://m.youtube.com/watch?v=FEZEiympuBM)

[John “Ecstasy” Fletcher of Whodini Dies At 56yrs Old](https://m.youtube.com/watch?v=zir6ae9bkQI)  
[Clip Of Black Music Honors, Awarding Whodini](https://m.youtube.com/watch?v=JRH8w1UrctM)  
[Past Music Award Show Doing A Whodini Tribute](https://m.youtube.com/watch?v=ACDtw2kq6G4)  
[Whodini, John “Ecstasy” Fletcher Interview](https://m.youtube.com/watch?v=_lV4b7z_zaM)  
[Whodini, Grandmaster Dee Interview](https://m.youtube.com/watch?v=v8QUq7foa3M)

\*\*  
Sign,\*\*  
**Lhisa**

### Compared To Other Rap Groups, Whodini Should Have Been Embraced More By The Hip Hop World Than They Were In Latter Years. Scroll Down And Leave Your Reply Below.

[![Whodini On Stage](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193565224/dVOlAF92J.jpeg align="left")](https://ferrelux666.wordpress.com/whodini-on-stage/)

[![PHILADELPHIA, PA - NOVEMBER 30: Rapper John "Ecstacy" Fletcher of Whodini performs during the Hip Hop Gods Classic Tourfest Revue at the Liacouras Center on November 30, 2012 in Philadelphia City. (Photo by Gilbert Carrasquillo/Getty Images)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193566591/kghDVtAct.jpeg align="left")](https://ferrelux666.wordpress.com/hip-hop-gods-classic-tourfest-revue-philadelphia/)

PHILADELPHIA, PA – NOVEMBER 30: Rapper John “Ecstacy” Fletcher of Whodini performs during the Hip Hop Gods Classic Tourfest Revue at the Liacouras Center on November 30, 2012 in Philadelphia City. (Photo by Gilbert Carrasquillo/Getty Images)

[![Whodini Posing](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193567907/EwLsg-569.jpeg align="left")](https://ferrelux666.wordpress.com/whodini-posing/)

[![Whodini Rappin'](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193569212/XZsQBLhvf.jpeg align="left")](https://ferrelux666.wordpress.com/whodini-rappin/)

[![Whodini, Awarded](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193570690/JjbXHctmE.jpeg align="left")](https://ferrelux666.wordpress.com/whodini-awarded/)

[![Whodini, Evolving Over The Years](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193572040/4Nwd0UdAP.jpeg align="left")](https://ferrelux666.wordpress.com/news/whodini-evolving-over-the-years/)

[![Whodini, Jalil & John](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193573466/28uTO8Fkf.jpeg align="left")](https://ferrelux666.wordpress.com/whodini-jalil-john/)

[![Whodini, John Ecstasy Fletcher Beside Himself](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193574667/viAHqWWep.png align="left")](https://ferrelux666.wordpress.com/whodini-john-ecstasy-fletcher-beside-himself/)

[![Whodini, Looking Fly](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193575834/eCbhcV7ac.jpeg align="left")](https://ferrelux666.wordpress.com/whodini-looking-fly/)

[![Whodini, Old School Photo](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193577127/TCPheO1Tw.jpeg align="left")](https://ferrelux666.wordpress.com/whodini-old-school-photo/)

[![Whodini, Old School](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193578205/SXoRaO2Qz.jpeg align="left")](https://ferrelux666.wordpress.com/whodini-old-school/)

[![Whodini, Rapper John Ecstasy Fletcher Died At Age 56](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193579537/x4BRs2Ig-.jpeg align="left")](https://ferrelux666.wordpress.com/whodini-rapper-john-ecstasy-fletcher-died-at-age-56/)

[![Whodini, Stage Shot](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193580646/p2XhqmkEn.jpeg align="left")](https://ferrelux666.wordpress.com/whodini-stage-shot/)

[![Whodini](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193581854/w8xsA0IN-.jpeg align="left")](https://ferrelux666.wordpress.com/whodini/)

[![Whodini's Magic](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193583408/VGRu6If5s.jpeg align="left")](https://ferrelux666.wordpress.com/whodinis-magic/)

[![Ferrelux Homepage_Whodini-Jan2021](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193586318/TCVkdgn2M.png align="left")](https://ferrelux666.wordpress.com/ferrelux-homepage_whodini-jan2021/)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193588169/W6yLE3W6s.html align="left")](https://belkin.evyy.net/c/3170166/221098/3736?prodsku=AUC001btBK&u=http%3A%2F%2Fwww.belkin.com%2Fus%2FAUC001-Belkin%2Fp%2FP-AUC001&intsrc=PUI2_1607)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193591540/mSCs3CqFP.png align="left")](https://www.discovercars.com/?a_aid=Ferrelux)
