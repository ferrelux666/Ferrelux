---
title: "Trump, ‘You’re Fired!’ \U0001F681\U0001F4F0\U0001F3BA"
date: '2020-12-07T19:51:18.000Z'
slug: trump-youre-fired
tags:
  - trump
  - business
  - country
  - vote
  - american
  - evidence
  - politics
  - democracy
  - biden
  - fraud
  - elections
  - president
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672193668790/XCr-oN34H1.jpeg
canonical: 'https://ferrelux666.wordpress.com/2020/12/07/trump-fired/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193637442/YXanLfdBT.png align="left")](https://rumble.com/search/video?q=Trump%20loses%20the%202020%20Election)

[**The Apprentice (Getting Fired Theme)**](https://www.youtube.com/watch?v=ovy0LuuZc7o)

*Si Vis Vincere, Non Tamen Oportet Quod. Si Non Explicare Perdet, Si Tibi Non Est Explicare.* 📝  
*If You Win, You Need Not Have To Explain. If You Lose, You Should Not Be There To Explain.*  
~ Adolf Hitler (German Dictator) Latinized Version Of His Quote

Alright. Remember that NBC TV Show ‘**The Apprentice’** when they all gathered in the boardroom to discuss which team won the task and who lost and why? Well, in Trump’s political life in The Presidential Edition, this happened when the multi-cultural face of the American People sat up in the head chair deciding in favor of the rival company Biden-Harris. So now, the Trump-Pence team took a low blow and their team leader Donald Trump is stuck explaining to the American People how Biden-Harris cheated them out of the win. Donald Trump Junior agrees that Biden hardly campaigned and couldn’t have had that many people vote him into office. Rudy Giuliani is in there talking about an election fraud scheme, and William Barr is still being blamed for failing to zealously find enough evidence. All this going on still because Trump does not want to go. Biden can’t get a comfortable foothold in the White House because the Biden-Harris thing would have been much better right after Obama’s 2nd Presidential Term was about to end had everything worked out fine for him then to run, he would have been number 45 instead and kept that democratic reign going for sixteen years. **\_***The Country would not have experienced Trump.***\_** Because of a break in the normal transition of power after Obama, a person name Donald J. Trump was able to seize power and wield it. So he can keep using his efforts to block Biden. Him not conceding defeat, using all kinds of political legal maneuvering is yet another example of how he understands the use of power. In other words, unlike the typical democrat ready to lose, a republican is going to look into all kind of ways to get and hold on to a political seat for a purpose. So when you’re in a company and your boss is trying to fire you, but he or she isn’t exactly “The Leader” with the power, then it don’t mean anything. You curse out the person and stay there knowing damn well that some deliberation can be made in your favor once you get word to that real person in charge. You can’t deny a significant portion of the Country who’s out there protesting his loss even if you don’t like those people. BUT, arguably it’s globally well known that MANY PEOPLE WANTED HIM OUT OF OFFICE. So the majority rules. If there’s any real evidence contrary to that like voter fraud because deceased people can’t vote, then we might see Trump in there after all. So while in that politically legal courtroom, **\_***oh excuse me***\_**, I meant The Apprentice Boardroom, giving testimony and evidence, Trump is looking for the other face of The American People to call The Biden-Harris Team’s ass back into the boardroom to explain fraud, and somebody is getting fired. But the classy thing to do though is give an elegant concession speech. Reach out to us ‘The People’ viewing you in your Apprentice Style Limo ride out of there giving us your thoughts. And when the time comes in January 2021, you left your little goodwill presidential note to the new Incumbent President, and gathered yourself for that helicopter ride off the property, but in your case it would be in the Apprentice Style. There is life after losing. It’s time to look at your fan base, see where the wind is blowing and decide which Trump you should start grooming for Office next time around. Right now to me, it looks more like Ivanka Trump and/or Donald Trump Jr. Strategy is important here. I’m not a fan of “President Trump”, I liked “Apprentice Trump” better. Now Apprentice Trump back in those days would be looking at why President Trump failed, and would be asking him questions. After pointing out a failure, one of his arguments would be, ‘well why didn’t you……’ so and so and so? A business-minded Trump back in the day would file a bankruptcy on that experience and get the fuck out of there and be looking at the new experience while his Attorneys are cleaning up the mess. So now using Donald Trump Junior who has shown some political grit might be an option, but with VP Elect Kamala Harris poised to be the First Black Female American President, The Republicans might need strong White Female Contenders appealing enough to beat her. To test the waters to bring back Trump interest from all those old time supporters, throwing Ivanka in there after being further politically groomed might be interesting. I doubt The People would vote for any of you given a taste of your father, but it’s something to do. Right now, The Democrats are back in power with their non-conservative agenda, and we stand to see whether that administration will be any better.

Sign,  
Lhisa Mrklon,  
Your Political Observer

### Are You Glad To See Trump Go? Scroll Down And Leave Your Reply Below.

[![Ferrelux Homepage_Trump Fired_12-2020](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193639076/SRBMP7mwR.jpeg align="left")](https://ferrelux666.wordpress.com/2020/12/24/goodbye-2020/ferrelux-homepage_trump-fired_12-2020/)

[![William Barr & Trump](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193640578/aQ0keaJlv.jpeg align="left")](https://ferrelux666.wordpress.com/william-barr-trump/)

[![Trump Witch Hunt](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193642061/AKG20uphi.jpeg align="left")](https://ferrelux666.wordpress.com/trump-witch-hunt/)

[![Trump Political Art](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193643572/rnLsB5tIa.jpeg align="left")](https://ferrelux666.wordpress.com/trump-political-art/)

[![President Donald Trump walks on the South Lawn after arriving on Marine One at the White House, Thursday, June 25, 2020, in Washington. Trump is returning from Wisconsin. (AP Photo/Alex Brandon)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193644947/Uxbev9zmb.jpeg align="left")](https://ferrelux666.wordpress.com/donald-trump-2/)

President Donald Trump walks on the South Lawn after arriving on Marine One at the White House, Thursday, June 25, 2020, in Washington. Trump is returning from Wisconsin. (AP Photo/Alex Brandon)

[![Trump Exits In Defeat](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193646717/5xbnGsm-U.png align="left")](https://ferrelux666.wordpress.com/news/trump-exits-in-defeat/)

[![Trump Being Consoled](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193647979/ZN3pBouSi.jpeg align="left")](https://ferrelux666.wordpress.com/trump-being-consoled/)

[![Trump Art Tweeting](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193649107/6lNRivZ-k.jpeg align="left")](https://ferrelux666.wordpress.com/trump-art-tweeting/)

[![Trump Against McCain](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193650505/Z9tg7cA4L.jpeg align="left")](https://ferrelux666.wordpress.com/trump-against-mccain/)

[![Trump Acquitted](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193651669/5BW0BYkAE.jpeg align="left")](https://ferrelux666.wordpress.com/trump-acquitted/)

[![Trump About To Address The Public](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193653045/HZNUnYK7W.jpeg align="left")](https://ferrelux666.wordpress.com/trump-about-to-address-the-public/)

[![Secretary Pompeo](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193654263/sUKhD-TJB.jpeg align="left")](https://ferrelux666.wordpress.com/secretary-pompeo/)

[![Sec Pompeo](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193655381/SR-I8jdmH.jpeg align="left")](https://ferrelux666.wordpress.com/sec-pompeo/)

[![Rudy's Talking](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193656442/wO8gTxbH6.jpeg align="left")](https://ferrelux666.wordpress.com/rudys-talking/)

[![Rudy Giuliani, Associated Press](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193657490/u6JrXCpWl.jpeg align="left")](https://ferrelux666.wordpress.com/rudy-giuliani-associated-press/)

[![President Trump Art Covid-19 In America](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193658917/b46QyvrN7.jpeg align="left")](https://ferrelux666.wordpress.com/president-trump-art-covid-19-in-america/)

[![President Trump Art By Carole Foret](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193660406/bdngJFHPx.jpeg align="left")](https://ferrelux666.wordpress.com/president-trump-art-by-carole-foret/)

[![President Trump & William Barr](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193661699/4xV8iSOkf.jpeg align="left")](https://ferrelux666.wordpress.com/president-trump-william-barr/)

[![Kellyanne Conway](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193662677/XFkjYV_Pv.jpeg align="left")](https://ferrelux666.wordpress.com/kellyanne-conway/)

[![K. Conway](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193663799/gYJBb4csE.jpeg align="left")](https://ferrelux666.wordpress.com/k-conway/)

[![Donald Trump Against John McCain](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193665116/V7N56EEa6.jpeg align="left")](https://ferrelux666.wordpress.com/donald-trump-against-john-mccain/)

[![Donald & Melania Ride](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193666221/tGgzC70ZB.jpeg align="left")](https://ferrelux666.wordpress.com/donald-melania-ride/)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193667328/p56FaL71H.png align="left")](https://voropro.com/training/get-your-real-estate-license/invite/2654/)
