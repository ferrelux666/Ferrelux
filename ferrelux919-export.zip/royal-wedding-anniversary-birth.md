---
title: "Royal Wedding Anniversary Birth \U0001F49D\U0001F48D"
date: '2019-05-15T19:28:27.000Z'
slug: royal-wedding-anniversary-birth
tags:
  - kids
  - parenting
  - uk
  - love
  - united-kingdom
  - matrimony
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195090990/xOchQsRMr.png
canonical: 'https://ferrelux666.wordpress.com/2019/05/15/archie/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195063630/hlDxTI2b6.jpeg align="left")](https://www.ferrelux.us/)

[Spice Girls ~ ‘Mama’](https://mysp.ac/4QNRl?play=1)

*Mater Regalis* 👰🏾 *Royal Mother*

**So we have the matrimonial ritual ceremony come back around in full circle with Meghan Markle being wedded to Prince Harry in May 19, 2018 and now the royal birth of their baby boy, Archie Harrison Mountbatten-Windsor (Baby Sussex) on May 6th 2019 to celebrate for their anniversary and Mother’s Day. What a joyous moment.**

\*\*Lhisa Mrklon  
\*\*

[**ROYAL BIRTH PHOTAGE**](https://www.youtube.com/results?search_query=royal+birth)[**ROYAL WEDDING 2018**](https://www.youtube.com/results?search_query=royal+wedding)

[![Ferrelux Homepage_SussexRoyalBaby](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195065051/oWSFGfqOP.png align="left")](https://ferrelux666.wordpress.com/ferrelux-homepage_sussexroyalbaby/)

[![wedding-dress-t](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195066318/ERldtkMWR.jpeg align="left")](https://ferrelux666.wordpress.com/wedding-dress-t/)

[![rs_1920x900-181012042455-lt-3Jack-Eugenie-Stairs-princess-eugenie-wedding](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195067764/c5Qrg_8bO.jpeg align="left")](https://ferrelux666.wordpress.com/rs_1920x900-181012042455-lt-3jack-eugenie-stairs-princess-eugenie-wedding/)

[![three-royal-weddings-WEDDINGRULES0118](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195068995/AfxCcmz0u.jpeg align="left")](https://ferrelux666.wordpress.com/three-royal-weddings-weddingrules0118/)

[![Royal-Wedding-Slideshow-slide-SZ42-superJumbo](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195070465/JRNi5o-vr.jpeg align="left")](https://ferrelux666.wordpress.com/royal-wedding-slideshow-slide-sz42-superjumbo/)

[![ZC6Z2UH4PRB3DBDUPQLV3XRD6M](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195071606/3S5XU1c-y.jpeg align="left")](https://ferrelux666.wordpress.com/zc6z2uh4prb3dbdupqlv3xrd6m/)

[![Mandatory Credit: Photo by David Fisher/REX/Shutterstock (1310708m) Catherine Middleton and Prince William The wedding of Prince William and Catherine Middleton, Buckingham Palace, London, Britain - 29 Apr 2011](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195072958/HznjIEQKI.jpeg align="left")](https://ferrelux666.wordpress.com/the-wedding-of-prince-william-and-catherine-middleton-buckingham-palace-london-britain-29-apr-2011/)

Mandatory Credit: Photo by David Fisher/REX/Shutterstock (1310708m) Catherine Middleton and Prince William The wedding of Prince William and Catherine Middleton, Buckingham Palace, London, Britain – 29 Apr 2011

[![prince-harry-meghan-baby-details-m](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195074237/o3BZslJkQ.jpeg align="left")](https://ferrelux666.wordpress.com/prince-harry-meghan-baby-details-m/)

[![royal-wedding](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195075304/aJMjuYFGY.jpeg align="left")](https://ferrelux666.wordpress.com/2018/05/19/royal-wedding/royal-wedding-2/)

[![royal-wedding-2018-sitting-dress-comparison-kate-meghan-1526735395](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195076778/-zaxKNfPK.jpeg align="left")](https://ferrelux666.wordpress.com/royal-wedding-2018-sitting-dress-comparison-kate-meghan-1526735395/)

[![Royal-Wedding-Bouquet-Forever-Bridal-Wedding-Shows](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195077974/C2IuuasqO.jpeg align="left")](https://ferrelux666.wordpress.com/royal-wedding-bouquet-forever-bridal-wedding-shows/)

[![hbz-royal-wedding-comparisons-dress-1526845763](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195079252/eftdJkxmJ.jpeg align="left")](https://ferrelux666.wordpress.com/hbz-royal-wedding-comparisons-dress-1526845763/)

[![5296747_051219-cc-ap-royal-baby-feet-img](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195080546/_rF6WjQOc.jpeg align="left")](https://ferrelux666.wordpress.com/5296747_051219-cc-ap-royal-baby-feet-img/)

[![db1dc772d9164cc38b3ba2f0b33673de_18](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195081796/XlUx6DnJE.jpeg align="left")](https://ferrelux666.wordpress.com/db1dc772d9164cc38b3ba2f0b33673de_18/)

[![GettyImages-960052182.w700.h700](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195082977/Pnjo_4RuH.jpeg align="left")](https://ferrelux666.wordpress.com/gettyimages-960052182-w700-h700/)

[![gettyimages-1051970878](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195084112/GSaXbSgKm.jpeg align="left")](https://ferrelux666.wordpress.com/gettyimages-1051970878/)

[![1557409261005](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195085487/m3CvbnY3w.jpeg align="left")](https://ferrelux666.wordpress.com/1557409261005/)

[![9c7c6606-46a0-4e92-99e0-71bafb81a3f7-AFP_AFP_19Z0KB](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195086968/Ovp54qLfz.jpeg align="left")](https://ferrelux666.wordpress.com/9c7c6606-46a0-4e92-99e0-71bafb81a3f7-afp_afp_19z0kb/)

[![050919-celebrities-radio-host-meghan-markle-prince-harry-royal-baby-racist-tweet](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195088091/oGplq9Bt-.jpeg align="left")](https://ferrelux666.wordpress.com/050919-celebrities-radio-host-meghan-markle-prince-harry-royal-baby-racist-tweet/)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195089185/hjoVqUh-J.jpeg align="left")](https://ferrelux.com/adverts/)
