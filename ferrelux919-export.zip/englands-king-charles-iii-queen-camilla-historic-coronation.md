---
title: "\U0001F3F0 England’s King Charles III & Queen Camilla, Historic Coronation  \U0001F451"
date: '2023-05-06T10:25:55.276Z'
slug: englands-king-charles-iii-queen-camilla-historic-coronation
tags:
  - king-charles
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1683923286252/ff3e8ab2-2e8e-435a-ad67-734b8b0a9c7c.png
---
*Afferte Mihi Poculum Tea Et Temporii 🕰️ Bring Me A Cup Of Tea And The ‘Times’ (Queen Victoria)*

[**Thomas Morley ~ Now Is The Month Of Maying *(English Renaissance Composer)***](https://odysee.com/@nadaniente115a:4/thomas-morley-now-is-the-month-of-maying:8)

***My Wise Message To King Charles & Queen Camilla In 4 Kingdom Languages:  
Welsh, Irish, Scottish, English***

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683404554805/af3f1108-2068-4afd-9f9c-58dd8fb76767.jpeg align="center")

**W E L S H**  *(Bookman Old Style, Font) ~* ***Font May Not Show Exactly As Intended.***  
***The Foreign Language Translation May Not Be Fully Accurate As Meant***

Llongyfarchiadau ar ddod yn Frenin Charles y trydydd o Loegr. Dyma'ch Diwrnod Coroni, ac rydych chi'n edrych yn wych yn gwneud hanes i gael eich coroni fel y frenhines hynaf yn ein hamser milflwyddol blwyddyn 2023, 6ed o Fai. Gwybod pan ddaw'ch pen -blwydd yn 75 oed yn ddiweddarach eleni, y byddwch chi'n ei ddathlu y tro hwn fel brenin. Er gwaethaf beirniadaeth eraill, roeddwn bob amser yn meddwl mai eich genedigaeth oedd y cyntaf a anwyd i esgyn yr orsedd. Er nad oedd rhai amgylchiadau preifat yn ystod eich bywyd yn deg yn dda yn llygad y cyhoedd, cawsoch eich geni i sefyllfa benodol a oedd yn ei gwneud yn anodd ar brydiau arwain eich bywyd fel y dymunodd, ond gwnaethoch drin yr heriau hyn y gorau y gallech. Mae rhywun sy'n amau  eich gallu i reoli fel brenin, yn camgymryd y blynyddoedd o sesnin, meddwl a hyfforddiant y gwnaethoch chi barhau i ddal pŵer yn etifeddu’r ymerodraeth ac yn datrys rhai pethau. Rwy'n dymuno rheolydd teg i chi, a hefyd eich brenhines wrth eich ochr yn creu hanes gyda chi, hefyd yn edrych yn ysblennydd. Er i Camilla yr un modd ddioddef beirniadaeth, er clod iddi, fe wnaeth ei thrin yn dda ac mae wedi dod i mewn i'w gras brenhinol ei hun. Pa mor gyffrous oedd gweld eich bod yn cael eich anrhydeddu yn y fath fodd gan Eich mab Cyntaf-anedig William ac arwyddocâd hynny. A Kate, brenhines wrth aros yn edrych yn hyfryd yn ystod y seremoni; A'r plant, mor felys. Felly mae Charles & Camilla, Lloegr o'r newydd gyda'r ddau ohonoch ar y gorseddau i weld eich pobl trwy'r amseroedd anodd hyn. Bendith Duw.

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683404477594/1b851543-5931-4d5d-8df5-e2a1bef23a99.jpeg align="center")

**I R I S H  (Bodoni MT, Font) ~ *Designated Font May Not Show Exactly As Intended.***  
***The Foreign Language Translation May Not Be Fully Accurate As Meant***

Comhghairdeas as a bheith ina Rí Charles an tríú ceann de Shasana. Is é do lá corónaithe é, agus féachann tú go hiontach le stair a dhéanamh mar an monarc is sine inár mbliain mhílaoise 2023, 6 Bealtaine. Bíodh a fhios agat nuair a thagann do 75ú lá breithe thart níos déanaí i mbliana, go ndéanfaidh tú ceiliúradh air an uair seo mar Rí. In ainneoin an cháineadh a bhí ag daoine eile, shíl mé i gcónaí gurbh é do cheart breithe an chéad duine a rugadh chun dul suas an ríchathaoir. Cé nach raibh roinnt cúinsí príobháideacha le linn do shaoil  go maith i súile an phobail, rugadh tú i bpost ar leith a bhí deacair ag amanna do shaol a stiúradh mar a theastaigh uait, ach láimhseáil tú na dúshláin seo is fearr a d'fhéadfá. Tá duine éigin a bhfuil amhras ort faoi do chumas rialú mar Rí, ag cur botún ar na blianta a bhí ag blastanas, smaoinimh agus oiliúna a d'fhulaing tú anois chun cumhacht a bheith ag an Impireacht agus ag réiteach roinnt rudaí. Guím gach rath ort, agus freisin do bhanríon ag do thaobh ag déanamh staire leat, ag féachaint go hiontach freisin. Cé gur fhulaing Camilla mar an gcéanna, mar gheall ar a creidmheas, dhéileáil sí go maith léi agus tháinig sí isteach ina grásta ríoga féin. Cé chomh corraitheach a bhí sé go bhfaca tú onóir ar bhealach mar Sin Ag Do chéad Mhac William Agus an tábhacht a bhaineann leis sin. Agus d'fhéach Kate, banríon a bhí ag fanacht go hálainn le linn an tsearmanais; Agus na páistí, cé chomh milis. Mar sin, tá Charles & Camilla, Sasana nua leatsa ar an Thrones chun do dhaoine a fheiceáil trí na hamanna seo. Dia dhaoibh.

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683404513737/f46b9a48-f604-4105-949c-8a5b16f339b6.jpeg align="center")

**S C O T T I S H  (Bakersville Old Face, Font) ~ The *Designated Font May Not Show Exactly As Intended, And The Foreign Language Translation May Not Be Fully Accurate As Meant.***

Meal an naidheachd air a bhith na Rìgh Teàrlach an treas cuid de Shasainn. Is e seo an Latha a 'Chrùnaidh agad, agus tha thu a' coimhead air a bhith a 'dèanamh eachdraidh mhath a bhith air a chrùnadh mar am monarc as sine anns a' bhliadhna Mìle Bliadhna againn 2023, 6mh Cèitean. Fios a bhith agad nuair a thig an 75mh co-latha-breith timcheall air nas fhaide air adhart am-bliadhna, chomharraichidh tu e an turas seo mar Rìgh. A dh 'aindeoin càineadh dhaoine eile, bha mi an-còmhnaidh a' smaoineachadh gur e do-bhreith a bh 'aig do mhilleadh an toiseach gus a bhith a' dìreadh an rìgh-chathair. Ged nach robh cuid de shuidheachaidhean prìobhaideach rè do bheatha gu math ann an sùil phoblach, cha do rugadh tu e duilich aig amannan na dùbhlain sin a dh 'fhilleadh thu, ach dh' làimhseachadh thu na dùbhlain sin as fheàrr a b 'urrainn dhut. Tha cuideigin a 'cur teagamh a' chomas a bhith a 'riaghladh mar rìgh, a' dèanamh mearachd air bliadhnaichean ràitheachd, smaoineachadh agus trèanadh gus cumhachd a chumail a 'sealbhachadh cuid de rudan. Tha mi a 'guidhe dhut riaghladair math cothromach, agus cuideachd do Bhanrigh aig do thaobh a' dèanamh eachdraidh còmhla riut, cuideachd a 'coimhead eireachdail. Ged a dh 'fhuiling Campilla càineadh, chun chreideas aice, dh' làimhseachadh i gu math e agus thàinig i a-steach don ghràs rìoghail aige fhèin. Cho suathadh bha e a ' faicinn thu urram ann an leithid de dhòigh, le do chiad mhac a rugadh, William, agus cho cudromach sa bha sin. Agus tha Ceit, banrigh ann an feitheamh ri bhith a 'coimhead brèagha tron  deas-ghnàth; agus a 'chlann, cho milis. Mar sin tha Teàrlach & Camilla, Sasainn a 'fuireach còmhla riut le chèile air na h-amannan airson do shluagh fhaicinn tro na h-amannan a tha a' feuchainn. Gum beannaicheadh  Dia thu.

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683404580654/168af9c5-e58a-49ab-8c40-ea0dd2d2efc9.jpeg align="center")

**E N G L I S H  (Monotype Corsiva, Font) ~ *Font May Not Show Exactly As Intended.***  
***This is My Intended Message In The English Language***

Congratulations on becoming King Charles The Third of England. It’s your Coronation Day, and you look great making history to be crowned as the oldest Monarch in our millennial time year 2023, 6<sup>th</sup> of May. Know that when your 75<sup>th</sup> birthday comes around later this year, you’ll celebrate it this time as King. Despite the criticism of others, I always thought it was your birthright being the first born to ascend the throne. Although some private circumstances during your life did not fair well in the public eye, you were born into a particular position which made it difficult at times to lead your life as you wished, but you handled these challenges the best you could. Someone doubting your ability to rule as King, is mistaking the years of seasoning, thought and training you endured to now hold power inheriting the empire and sorting out some things. I wish you well Fair Ruler, and also your Queen at your side making history with you, also looking splendid. Although Camilla likewise suffered criticism, to her credit, she handled it well and has come into her own Royal Grace. How touching it was seeing you honored in such a manner by your first-born son **William** and the significance of that. And Kate, a Queen in waiting looked lovely during the ceremony; and the children, how sweet. So Charles & Camilla, England is anew with you both on The Thrones to see your People through these trying times. God Bless.

Signed ⚔️ Nobly,  
Lisa Angela Markland  
(Lhisa Ungelis Mrklon)  
Jamaican-Born, Currently  
Residing In The Former British Colony  
New York, United States Of America

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683405881932/dce446ea-d969-4a17-8e55-c1407d658a4b.png align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683406357289/7143cd65-ef67-4b46-bfd4-9468947fdfd3.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683503336017/5e69deb6-6745-4bcf-9659-685372110bc1.jpeg align="center")

**Queen Victoria, And The Declining Practice Of Slavery**  
[https://news.yahoo.com/complicated-history-queen-victorias-colonial-152949692.html?fr=sycsrp\_catchall](https://news.yahoo.com/complicated-history-queen-victorias-colonial-152949692.html?fr=sycsrp_catchall)

**Famous Quotes From Prince Charles & Camilla Parker Bowles**  
[https://quotes.thefamouspeople.com/charles-prince-of-wales-6361.php](https://quotes.thefamouspeople.com/charles-prince-of-wales-6361.php)    
[https://www.purewow.com/entertainment/camilla-parker-bowles-quotes](https://www.purewow.com/entertainment/camilla-parker-bowles-quotes)

**King Charles' Bank Note**  
[https://finance.yahoo.com/news/king-charles-iii-banknote-designs-122623843.html](https://finance.yahoo.com/news/king-charles-iii-banknote-designs-122623843.html)

**Some Links On Prince Charles**  
[https://www.theguardian.com/uk-news/2013/nov/13/prince-charles-timeline](https://www.theguardian.com/uk-news/2013/nov/13/prince-charles-timeline)   
[https://www.bbc.com/news/uk-wales-65458795](https://www.bbc.com/news/uk-wales-65458795)   
[https://www.mirror.co.uk/news/uk-news/prince-charles-64-is-the-longest-waiting-successor-1457279](https://www.mirror.co.uk/news/uk-news/prince-charles-64-is-the-longest-waiting-successor-1457279)

**Fun Links**  
[https://ew.com/books/prince-charles-coronation-books/](https://ew.com/books/prince-charles-coronation-books/)  
[https://www.usmagazine.com/celebrity-news/pictures/prince-charles-quotes-about-becoming-king-after-queen-elizabeths-death/](https://www.usmagazine.com/celebrity-news/pictures/prince-charles-quotes-about-becoming-king-after-queen-elizabeths-death/)

**Royal Family Tree**  
[https://britroyals.com/](https://britroyals.com/)  
[https://www.bbc.com/news/uk-23272491](https://www.bbc.com/news/uk-23272491)   
[https://www.bbc.com/news/topics/c77jz3md4qwt](https://www.bbc.com/news/topics/c77jz3md4qwt)  
[https://dianalegacy.com/royal-family-history-how-did-the-royal-family-start-accident-started-modern-royals/](https://dianalegacy.com/royal-family-history-how-did-the-royal-family-start-accident-started-modern-royals/)

**The Haters**  
[https://www.readersdigest.com.au/culture/11-reasons-why-some-brits-dont-want-prince-charles-to-be-king](https://www.readersdigest.com.au/culture/11-reasons-why-some-brits-dont-want-prince-charles-to-be-king)

[https://www.latimes.com/opinion/story/2023-05-04/king-charles-coronation-monarchy-defense-against-demagogues](https://www.latimes.com/opinion/story/2023-05-04/king-charles-coronation-monarchy-defense-against-demagogues)

[https://edition.cnn.com/2023/05/01/opinions/republic-protest-king-charles-coronation-smith/index.html](https://edition.cnn.com/2023/05/01/opinions/republic-protest-king-charles-coronation-smith/index.html)

[https://time.com/6212008/king-charles-iii-controversy-past/](https://time.com/6212008/king-charles-iii-controversy-past/)

[https://www.nbcnews.com/think/opinion/queen-elizabeth-king-charles-iii-end-monarchy-rcna47104](https://www.nbcnews.com/think/opinion/queen-elizabeth-king-charles-iii-end-monarchy-rcna47104)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1684383997539/6f27531a-483b-4fa8-a7b6-3dc96fd20414.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1685321083682/89940ac4-a64b-476d-a885-73826ffe722e.jpeg align="center")

**AND NOW THEIR STORY . . . . . . .**

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683509057669/9ebadb57-ae94-4558-b6e1-c49a020d7579.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683506085001/18285d1b-f42c-4be3-89e5-21c26dddc1d0.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683506108281/f24e7e87-754e-4910-94c8-5f516846b361.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683506411735/18d62092-1024-4a05-9a6a-9c2689b32223.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683506657242/e4a72881-df51-4183-a649-9516e76757c7.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1685320498102/451cb623-bce2-453c-9ec7-3634aa2dc779.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1685320521022/e623894a-7e8a-4fcc-a78f-44560b61ad13.png align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683506831184/3e7e9fb4-dde7-4460-aa80-b84f7509e555.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1686464516651/5c381c9a-e451-4723-951c-b2c32b13b1bc.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683743210052/dd5c4c2e-6550-43d3-83e4-3f75ea720feb.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683743241030/4da98b99-94de-4f08-a0b7-0327ec7d5e22.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1686463990522/461a844f-7e27-43b9-8548-8ff9ad144ba9.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683507140532/087483ae-ce48-4688-affe-a577a1b208f4.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683507347839/7989146f-d213-4cd4-8d08-2213d593a8f2.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683507724285/20a57e9c-57ff-4256-94e9-a7ccbd6a73a8.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683508409806/34733326-a199-4bd5-a856-78121e54118b.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683508239427/866a33d8-4087-42af-9ae8-ddd3a0a34464.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683508653222/9723199d-9fc6-4f57-8616-07ed8d46b16a.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683510284618/7b8a0412-73b8-4adc-a25e-9b722fd25df6.png align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683509663980/d5214af9-b92a-4101-8a1f-255ebdf654a5.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683510192437/bc797cb0-00b5-44ba-9ce4-2505c4710eeb.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683510214298/7e0e9cc7-8690-40fc-89fe-7691c77ecf4a.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683742682545/523fd5ea-0051-4d35-a33e-0cf2f9eb36dd.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683740978730/ba882598-7f10-4268-b945-e66b90fc871d.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683740910803/898012d1-6894-484d-b994-64eaada13f40.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683510233461/7c875fd9-188e-4c1e-91c6-8d852461a889.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704609944149/1a4573f8-c64e-4ccc-87d7-cd9c67830496.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683743532761/014f5ea2-1b62-4745-881d-5423fde89f62.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683923403669/b96ec49d-426e-4505-9482-81b60aed1b94.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704611381467/1b956863-1527-423c-9ba2-5cba9e60ea64.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704611718173/117d22a8-3d1a-48a8-b334-a98fe98a5e42.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704610439968/536c6b1d-eb57-4ab3-9e6a-fd1d2d25913b.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1686463212022/f965c04e-42d4-4e2a-bd89-2fec48fe7abc.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704610742233/5764a545-9765-42db-a74c-6a7b85f64bf2.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1685321547313/32ec8532-bf17-4d1c-be69-a0c676611cba.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683506683818/a0df3741-c8ab-4ac2-89d2-78329312e853.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683741452676/4dc71ad2-4714-400f-990e-21854b22e55d.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683511093878/c07ba02b-95c7-429b-9427-c6eaee219d89.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683742039525/02484857-b5d2-4f79-a2f1-33f46e1d9a53.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683742093832/d1a8d905-bdd8-42fa-9c36-2dd60363f187.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1683510881997/5959063d-87d3-454c-9e43-281ac77d710f.png align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1685320764914/326dc49e-45d0-4f28-9659-9396f7b3e577.webp align="center")
