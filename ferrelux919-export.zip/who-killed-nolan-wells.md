---
title: Who Killed Nolan Wells?
date: '2026-09-16T03:42:49.338Z'
slug: who-killed-nolan-wells
tags:
  - mississippi
coverImage: >-
  https://cdn.hashnode.com/uploads/covers/6269a04eaedfbdb0ce1a65f6/dc8741f8-351b-4f42-8a7d-1135b2411e72.jpg
---
Today is Tuesday September 15th 2026, and it's been over 2 months now since the death of Nolan Wells who was an 18 year old Student that went out to Horn Island, Mississippi on a boat with some friends to celebrate the 4th of July but never made it back alive.

. . .. Stay Tuned Till My Next Post . . .

Sign,  
Lhisa Mrklon

#202
