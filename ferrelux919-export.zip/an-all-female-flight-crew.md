---
title: "✈️ An All Female Flight Crew \U0001F6EC"
date: '2024-03-17T00:33:11.670Z'
slug: an-all-female-flight-crew
tags:
  - ethiopians
  - black-woman
  - hbcu
  - '167'
  - female
  - pilots
  - '2024'
  - womens-history-month
  - muslim
  - islamic
  - navy
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1711317375975/5eb49bd5-6e6e-401f-a35b-ec81d94ceb20.jpeg
---
Ego Sum Homo Qui Potest 🌔 I Am The Man Who Can *(Wonder Woman)*

🎶 [Jefferson Airplane 💊 White Rabbit](https://odysee.com/@HIPPIE:c/Jefferson-Airplane---White-Rabbit-\(Audio\):5)  
*It may not be the best choice, but this song encapsulates all 3 occasions*

***Happy St Patrick’s Day, Happy Easter, & Happy Women’s History Month.***

Although this kind of history has been made already by other Airlines or Military Air Forces in America or Foreign Countries, it has happened again in 2024 with United Airlines featuring an All Woman Aviation Team. This past Thursday’s United Airlines Flight from *Newark, NJ*  to *Sarasota, Fl*  was flown by a Black Woman, Captain Gabrielle Harding who graduated from an HBCU Pilot Program. Everyone involved in the crew right down to the baggage checking were women from diverse Nationalities.

**Sign,  
Lhisa Mrklon**  
**#167**

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1710834336898/e8408a43-5209-4187-9927-d7a6001d6c73.jpeg align="center")

**SOME LINKS ON THE DIFFERENT WOMEN IN AVIATION MAKING HISTORY**

[**https://abc13.com/newark-airport-women-female-flight-crew/14500074/**](https://abc13.com/newark-airport-women-female-flight-crew/14500074/)

[**https://www.msn.com/en-us/lifestyle/travel/all-women-crew-pilots-history-making-united-flight-during-womens-history-month/ar-BB1jvA7k**](https://www.msn.com/en-us/lifestyle/travel/all-women-crew-pilots-history-making-united-flight-during-womens-history-month/ar-BB1jvA7k)

[**https://www.npr.org/2022/08/22/1118744489/bessie-coleman-first-black-woman-pilot-honored-american-airlines-crew**](https://www.npr.org/2022/08/22/1118744489/bessie-coleman-first-black-woman-pilot-honored-american-airlines-crew)

[**https://www.navytimes.com/news/your-navy/2023/10/16/patrol-squadron-45-conducts-rare-all-female-p-8a-poseidon-flight/**](https://www.navytimes.com/news/your-navy/2023/10/16/patrol-squadron-45-conducts-rare-all-female-p-8a-poseidon-flight/)

[**https://www.voanews.com/a/africa\_all-female-ethiopian-flight-crew-aims-inspire/6185484.html**](https://www.voanews.com/a/africa_all-female-ethiopian-flight-crew-aims-inspire/6185484.html)

[**https://www.navcanada.ca/en/news/blog/all-women-controllers-direct-air-canadas-all-women-flight-crew-from-yyz-to-yeg.aspx**](https://www.navcanada.ca/en/news/blog/all-women-controllers-direct-air-canadas-all-women-flight-crew-from-yyz-to-yeg.aspx)

[**https://www.businessinsider.com/onboard-afghanistan-first-flight-with-all-female-crew-kam-air-2021-2**](https://www.businessinsider.com/onboard-afghanistan-first-flight-with-all-female-crew-kam-air-2021-2)

[**https://www.cntraveler.com/story/air-india-all-female-crew**](https://www.cntraveler.com/story/air-india-all-female-crew)

[**https://www.cnn.com/2022/08/20/us/american-airlines-honors-bessie-coleman/index.html**](https://www.cnn.com/2022/08/20/us/american-airlines-honors-bessie-coleman/index.html)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1711318056557/03e39a72-1f69-47d8-9e83-d7163035cde1.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1711318074381/32e8d860-2217-4abb-8cfc-060c450aca6f.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1711317678839/9bb84a8f-e183-49f9-81cd-d8166e734c7a.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1711317698208/a1798566-dce9-4844-b28f-daa475e11ad9.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1710636970023/5148c205-2535-44e2-8309-64eb81a02146.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1711318433642/45b18846-13e1-4764-8cdf-36f2cb6f4b35.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1711318454038/f194080e-e9fa-4970-a8a9-e931c8759c63.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1711318477165/ed0ee6fd-4baf-4dd9-bdb0-e19e84aa86fa.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1710836003415/544fcfb8-2235-4e2d-981c-e9cb8bcce2c0.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1711318826892/262bba66-abde-4dad-a2d2-926a3259f486.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1711318841236/af892c5b-d657-42dd-a76c-6276f4a29c83.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1711319112677/05d9fd8c-9581-48e2-93ad-2f21ee4163ce.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1711319134050/69726d05-a0d4-4164-8cc5-ba2328382604.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1711319710819/a2092c14-d3ad-4621-bc34-06a5baf4212b.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1711319735039/fc1b2919-b510-492e-a873-e95ce81cc651.gif align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1711319759514/22484c11-3d17-4fb4-8e26-a286a9e744df.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1711322015130/1aca2829-6798-4e33-be01-1134581e02c7.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1711324896079/a2d27001-19f1-4c54-9441-2a55000e506c.jpeg align="center")

**👉 I'LL ADD MORE PHOTOS. CHECK BACK SOON.**
