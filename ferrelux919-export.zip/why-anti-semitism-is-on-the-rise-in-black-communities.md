---
title: "Why Anti-Semitism Is On The Rise In Black Communities \U0001F3B3\U0001F3AF\U0001F54D"
date: '2020-08-15T00:41:03.000Z'
slug: why-anti-semitism-is-on-the-rise-in-black-communities
tags:
  - news
  - enterprise
  - resources
  - trump
  - jobs
  - education
  - business
  - employment
  - history
  - programs
  - money
  - media
  - war
  - germany
  - society
  - economy
  - school
  - rent
  - housing
  - wealth
  - welfare
  - america
  - commerce
  - indian
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672194007424/nVADCtsEm.jpeg
canonical: 'https://ferrelux666.wordpress.com/2020/08/14/black-nazis/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193980541/gw5XydTbY.jpeg align="left")](https://www.thecrimson.com/article/1992/2/12/jews-and-the-slave-trade-just/)

[**The Beatles – “Blackbird” (1968) From The White Album**](https://www.youtube.com/watch?v=Man4Xw8Xypo)

Studium Immane Lucri  💵  An Insatiable Desire For Money

**I wanted to run this story late last year, but decided to end 2019 positive. Then in Jan 2020 when attacks on Jews was still happening, just when I was looking to cover my take on it again, reports of Kobe Bryant’s death filled the airwaves. And again on a later occasion, the Corona-Virus took precedent in the news so I postponed it. So now during this small window of opportunity until something new happens, here’s my article.**

Jews are currently getting attacked consistently by Blacks now, in addition to other groups like  
Neo-Nazis that don’t like them also. Do you really want to know why it’s happening more NOW in Black communities? It’s because of certain activities that some Jewish controlled enterprise do that affects the very fiber of a Black Person’s quality of life WHY they hate you. Stop paying attention to the watered down version on your local news and use common sense. Why would another persecuted people be on the attack against the other group? Usually that happens when there’s a conflict of some sort. The media isn’t explaining it right and a person like David Duke can tell you why. If you or I were running these airwaves, you would see & hear all kinds of shit happening out here. The News sanitizers the real problem only reporting these anti-Semitic incidents as strange senseless attacks. A local School Principal out here in New York earlier in the year was terminated from his job when he correctly stated on Twitter something to the effect that these Black kids beating up Jews, doing the swastika graffiti, and hurling insults at them suffered from the housing discrimination, being put out of their homes, the neighborhood gentrification buyouts, etc. And I agree, the uptick of these attacks are happening for a reason. For educational purposes, if you privately went around and interviewed a wide spectrum of people about their experiences with Jews without persecution, you would most likely get a candid answer. You can do the same with Blacks. While history shows the persecution of Jews under Hitler and we are constantly reminded of it in film, shows, talks, etc, as time goes on and people are living their lives in today’s time, they are seeing a Gatekeeper who’s Jewish, deciding whether they get a job or not, or housing they are entitled to or other benefit playing God over their lives talking to & handling them in a dismissive condescending way. And if you are a Black person who stayed out of trouble, carry yourself well, got educated, are of use to society, did everything wonderful that was expected of you, yet you are still denied access into The Promised Land, while who they like or want, is admitted especially if they are another Jew as we readily see. Now, not all cases are like this. There are people that can report favorable experiences with Jews more than the negative ones, but what’s more prevalent for you? So what’s going on now in these disenfranchised communities, is a re-evaluation of the Jewish Community. It was slowly going on decades ago if you noticed with certain think tanks re-structuring Hitler as a hero for Germany. It started taking course with more favorable books being written of him. Now, in our time there is a more extreme development where a school of Black people are saying that Hitler was really Black and they have a depiction of him telling the world that the historical accounts are wrong and that to hide the truth, they got a White actor (Charlie Chaplin) to redo the videos portraying Hitler as White. And in their Caucasian revisionist history, changed the Negro photos of him into white-washed ones. So now disgruntled Blacks who secretly liked the White Hitler, can now embrace a black-version of him. Incidentally, you can find legitimate books about Blacks who served Hitler openly in military garb. It’s always important to dig and research real history and be careful with what you are being told. So what we are seeing, like in Germany, is growing anti-Semitic sentiment based off economic political power. Here’s the interesting thing, when you troll around both the Black & White “hate groups” you’ll notice some colorful characters to follow and both sides are saying the same damn thing. And in a board game where you’re also fighting 2 other opposing forces, it would be logical that the closest 2 put their differences aside and concentrate on eliminating a common threat. Famous battles & wars over Europe were won that way. But what keeps a Neo-Nazi from siding with their local Pro-Black person that they have similar values with, is a programming. Created by who though? Last time I checked, RACE never existed as a problem EVER in history going way back to antiquity. It’s a recent thing just happening debatably about 500 or 700 years ago.

In ancient times you were addressed by your TRIBE, coloring and features were not much of an issue. If you were dark-tone, they knew from what region you came and by your garb and tongue what Kingdom. And you weren’t hated for it. How you were treated was based on other things such as whether your people were at peace with another people or served the same common interest or god. The historical writings, paintings, monuments, sculptures, accurately depicted varied persons only referring to them by name or tribe, not a Black or White person. If you were a “Black” person from a tribe over-ran by Romans you could have still become SOMEBODY in your lifetime as opposed to how you’re treated now. We had numerous “Black Romans” freely functioning in every corner of Roman life, even becoming Emperors. Where do you see that in fulfillment here today? You’re constantly under surveillance and attack or being denied something for having a dark skin tone in every aspect of your life. And where did that all come from? Hmmm, from my longtime observations reading the part of history dating back to 1 A.D., there reportedly was a God-man to be King, who was born named “Jesus Christ” of a people referred to as Hebrews. Some say they were dark-skinned, but others including some African Scholars say they were not. Whatever the case, Romans ruled at the time, more specifically the 3rd Emperor Tiberius, was in power. Now “Blacks” don’t appear to have had any hard issues during that period, and this continued well after The Roman Empire. Do you know WHO were having problems? JEWS. They were persecuted & hated all throughout Europe accused of killing Jesus. The biblical text says he was crucified under the Romans after Governor Pontius Pilate, who found no fault with him, heard the case. The Jews at the time gave him over to The Romans and chose the release of another prisoner, far less noble named Barabbas instead. So for their role in causing Jesus’ death, noticeably Whites from the 1200s on into the late 1500s hated Jews. Now this is just my account to explain things. So to get out from under that, wouldn’t you need another people to demonize in your place? Some prominent Jews in financial power owning banks & merchant ships, could have conspired a better life for their people at the expense of another race by manipulating the ruling Whites at the time. And looking at the time period it all happened, you started seeing that fully play out in the 1600s with the systematic Enslavement of Africans. Suddenly the focus shifted off Jews to a new term, Nigger. And someone came up with that too. Nothing like it ever existed before. And I’m well aware of the other events that was happening in Europe at the time like The Rulership of The Moors who were Arab Muslim that contributed, but THE HATE was more focused on The Jew why they were eventually expelled from Spain along with The Moors, but The Jews were also expelled from other parts of Europe as well, while at the time it was only The Africans from varied tribes who suffered from The Slave Trade. Now you can offer up YOUR own explanation to explain what may have historically happened because it’s all speculation. The point is, TODAY, our current time is still dealing with the same sort of conflict between 2 or more very different groups of people who don’t belong together, packed in the same area, contending over access to resources to thrive. IT WON’T GO AWAY.

Lhisa,  
Your Historical Analyst

### Of All The People Who Ever Crossed You In Life, Did Most Of Them Happen To Be Jewish? 🤨😯 Scroll Down And Leave Your Reply Below.

[![Ferrelux Homepage_BlackHitler-Aug2020](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193981680/iM6PArd_I.jpeg align="left")](https://ferrelux666.wordpress.com/2020/12/24/goodbye-2020/ferrelux-homepage_blackhitler-aug2020/)

[![Minister Louis Farrakhan](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193983252/bAfbIUHXJ.jpeg align="left")](https://ferrelux666.wordpress.com/minister-louis-farrakhan/)

[![Swastika In Black](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193984427/dk32WdQjs.jpeg align="left")](https://ferrelux666.wordpress.com/swastika-in-black/)

[![Rotten Jewish Rat](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193985735/ePZH5xTXO.jpeg align="left")](https://ferrelux666.wordpress.com/rotten-jewish-rat/)

[![Hitler Without Mustache](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193986987/d_SEjCiN1.jpeg align="left")](https://ferrelux666.wordpress.com/hitler-without-mustache/)

[![Jews In Concentration Camp](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193988017/ysvxJeSOT.jpeg align="left")](https://ferrelux666.wordpress.com/jews-in-concentration-camp/)

[![Jesse Owens Getting Set](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193989083/UA3vA2b6N.jpeg align="left")](https://ferrelux666.wordpress.com/jesse-owens-getting-set/)

[![Jesse Owens Jumping Hurdles](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193990234/WL3qT945-.jpeg align="left")](https://ferrelux666.wordpress.com/jesse-owens-jumping-hurdles/)

[![Black Nazis 3](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193991539/vivesis2B.jpeg align="left")](https://ferrelux666.wordpress.com/black-nazis-3/)

[![HANDOUT - James Baldwin, center, fought in World War II, helping to liberate the Netherlands. His job in the Army battalion was to give the orders from the tank. They used an 81 MM mortar gun that fires long range.  We came in and freed them, Baldwin said. We liberated them. We ran the Germans out. We took 23 cities in three days. We were moving fast. Thats called liberation. He received a certificate of appreciation and gifts from the embassy of the Netherlands February 6, 2020. Baldwin, 95, served in the 784th Tank Battalion during the war. (Family photo)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193993180/eODGHX0-d.jpeg align="left")](https://ferrelux666.wordpress.com/black-liberators-in-the-netherlands/)

HANDOUT – James Baldwin, center, fought in World War II, helping to liberate the Netherlands. His job in the Army battalion was to give the orders from the tank. They used an 81 MM mortar gun that fires long range.  We came in and freed them, Baldwin said. We liberated them. We ran the Germans out. We took 23 cities in three days. We were moving fast. Thats called liberation. He received a certificate of appreciation and gifts from the embassy of the Netherlands February 6, 2020. Baldwin, 95, served in the 784th Tank Battalion during the war. (Family photo)

[![FILE PHOTO -- David Duke, former Republican member of the Louisiana House of Representatives and former Grand Wizard of the Knights of the Ku Klux Klan, speaks to journalists on a street in central Barcelona, November 24, 2007, after the suspension of an initially planned news conference on the Spanish version of his book "Jewish Supremacy" (Supremacismo Judio). REUTERS/Gustau Nacarino/File Photo - RTSJ8CH](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193994483/9vfvMt8nM.jpeg align="left")](https://ferrelux666.wordpress.com/duke-former-republican-member-of-the-louisiana-house-of-representatives-and-former-grand-wizard-of-the-knights-of-the-ku-klux-klan-speaks-to-journalists-on-a-street-in-central-barcelona/)

FILE PHOTO — David Duke, former Republican member of the Louisiana House of Representatives and former Grand Wizard of the Knights of the Ku Klux Klan, speaks to journalists on a street in central Barcelona, November 24, 2007, after the suspension of an initially planned news conference on the Spanish version of his book “Jewish Supremacy” (Supremacismo Judio). REUTERS/Gustau Nacarino/File Photo – RTSJ8CH

[![Hitler With Mustache](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193995671/ulIUPNh8C.jpeg align="left")](https://ferrelux666.wordpress.com/hitler-with-mustache/)

[![German News Paper About Jews](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193996905/4nnZsN5HS.jpeg align="left")](https://ferrelux666.wordpress.com/german-news-paper-about-jews/)

[![Anti-Jewish Poster](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193998414/QftmmXj1U.png align="left")](https://ferrelux666.wordpress.com/anti-jewish-poster/)

[![Black German Soldier](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193999593/V-2QXfrG_.jpeg align="left")](https://ferrelux666.wordpress.com/black-german-soldier/)

[![Black Hitler Imagery](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194001230/WIfCa8v08.png align="left")](https://ferrelux666.wordpress.com/black-hitler-imagery/)

[![Black Hitler](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194002830/A4gQZsTIu.jpeg align="left")](https://ferrelux666.wordpress.com/black-hitler/)

[![Concentration Camp Jews](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194004154/o04XcfD73.jpeg align="left")](https://ferrelux666.wordpress.com/concentration-camp-jews/)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194005976/AvBjb1yKk.png align="left")](https://globalacn.org/business-grants/?ref=Ferrelux)
