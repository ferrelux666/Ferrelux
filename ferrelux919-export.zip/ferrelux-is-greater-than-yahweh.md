---
title: "\U0001F319 Ferrelux Is Greater Than Yahweh ☀️"
date: '2023-11-02T01:05:01.563Z'
slug: ferrelux-is-greater-than-yahweh
tags:
  - '159'
  - yahweh
  - ferrelux
  - lhisa-mrklon
  - curse
  - brand-name
  - brand-identity
  - company
  - business
  - latin
  - hebrew
  - religion
  - judgement
  - god
  - israel
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1698887013122/a5d22c22-e9a0-4f9b-9e4f-4d72470db1dc.jpeg
---
**🎶** [**Mustapha By Queen**](https://soundcloud.com/queen-69312/mustapha-remastered-2011?utm_source=clipboard&utm_medium=text&utm_campaign=social_sharing) *(The Name* مصطفى *In Arabic Means Chosen)*  
[**The Lyrics**](https://songmeanings.com/songs/view/13175/) **&** [**Freddie Mercury’s Song In Context To Bohemian Rhapsody**](https://en.wikipedia.org/wiki/Mustapha_(song))

😈 In Novissimis Diebus Ego Facere Impius Vultus Bonum  
😊 In The Last Days, I Will Make Evil Fair-Seeming *(Satan)*  
*The Koran 15. 30-39, Quran Surah Al-Hijr Ayat 39*

**SEE BELOW IN BOLD ITALICS THE REST OF MY POST**

So I got your attention with the title and ofcourse this is a private joke between God and I, as I drove home the point in previous articles talking about my battle with Big Tech & Big Brother, exposing some stuff and covertly revealing the works and identity of an FBI Agent and his Cointelpro Team who’s responsible. And all of this cyber mischief relates to Jews in several ways because your resources are being used in connection to immoral activities and what **יהוה** (YHWH) views as an abomination. And I have an answer for this. You’re supposed to hold The Leaders among you accountable. Allowing yourselves to be misguided by someone of another nation to draw your blessings at risk to partake into their problem is foolish. That’s why it all led to an attack by your Enemies the other day and you didn’t see it coming because like Old Times in The Scriptures, when God is angry, His Power, blesses your enemies. And I’ll reveal more wisdom on this later but first, let me start this off with my partial predictions.

For privacy purposes, I had to make these divine interpretations abstract as to protect what I really mean due to Somebody stalking & trifling with me and my work. The futurecast pertains to several nations in accordance to divine prophecy related through me. The symbols used are deliberately not so obvious, which means the message could be for this country or other region, but before you dismiss it as charlatanry, realize that I’ve been consistent and right and had it not been for certain attacks against me, my clues would be far more apparent with specific commentary. So when something comes true, I’ll point that out at a later time, referencing this article, and it will all be eye-opening.

**There’ll Be 8 Divine Forecasts**

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1699477351706/3d07ab63-8e97-4396-b2c5-4fdfa3a66a3a.jpeg align="center")

**Me Describing What Has Happened So Far Using Prophetic Language**

*When The Eagle flew across the broad skies, a ship docked along a shore as a Crain looked on. The Seagulls of The North conspired with The Eagle to share land and grain through the generosity of The Crain, which angered the people of the Ice Kingdom for The Harvest of The Bear will not be bountiful. A White Knight then sets out from his people to venture onto the other land, and was met with a few Allies on his quest. A Valkyrie flew across the skies into unknown parts of a dark realm, then returned to strike at its Master only to fail. Vipers swam across the sea to take hold of a harvest of lambs which they carried away, and The Eagle took flight across the sea to try to save them.*

**My Prophecy Comes Below Its Respective Imagery**  
*The semi-colon & slash are consistent in relation to the specified symbols for the divine period*

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1699741166210/90f46a09-4b66-4efb-8e27-9b4f9a6c3392.png align="center")

👼🏼 🔢 🕧 ***My Prophetic Message To This Part Of The World*** 📅 😇 🔢  
: \\ : \\ : \\ : \\ : \\ : A New Nation Will Rise From The Old One With Its World Leader, But There Will Be An Overlooked One Who Is Ruling, Mounted On All Nations 🕗👩🏼‍🦰🐲📖

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1699748598233/95f3f14f-f28e-4492-b46a-97baf2f699f4.jpeg align="center")

👼🏼 🔢 🕧 ***My Prophetic Message To This Part Of The World*** 📅 😇 🔢  
: \\ : \\ : \\ : \\ : \\ : It's Not You Who Will Be Destroyed 🏜️🐫🌵⏳🩴🕊️✌🏼🌱🪔🥭⛺📜

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1699747725655/bf523e93-702e-44c6-82cc-fadd63439fac.jpeg align="center")

👼🏼 🔢 🕧 ***My Prophetic Message To This Part Of The World*** 📅 😇 🔢  
: \\ : \\ : \\ : \\ : \\ : The Kingdoms Within You Will Prosper 🕘 🛖 🌧️ 🏝️ 👹

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1699745284577/a86e5fd2-d426-48c3-9358-0ba83c454d74.jpeg align="center")

👼🏼 🔢 🕧 ***My Prophetic Message To This Part Of The World*** 📅 😇 🔢  
Though You Joined Their War Effort With Good Intentions, You’ll Eventually Pull Out Of It To Protect The Political Welfare Of Your People & Those Dependent On Your Rule  
🏰 🦄 🤵🏼 👰🏼 📚 🪵🪓🍀🏛️ 🏒 🤽🏼 📨 👖 🏇🏼

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1699744537646/8b7dfc86-ffc3-49da-81e0-7e54b9729047.jpeg align="center")

👼🏼 🔢 🕧 ***My Prophetic Message To This Part Of The World*** 📅 😇 🔢  
: \\ : \\ : \\ : \\ : \\ : Your Wisdom, Fortitude, Discipline & Training Will Pay Off As You Expand Your Empire Offshore Fairly Greeted By Foreign Nations Like Ancient Times  
🛕 👘 💹 😄 🐈 🏮 🀄 🧑🏻‍💻 🤳🏻 📱 🧧 🎬 🎥 📷 🎈

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1699743693958/0e349ea0-baf0-48fc-af53-1fcbd5c1b5b9.jpeg align="center")

👼🏼 🔢 🕧 ***My Prophetic Message To This Part Of The World*** 📅 😇 🔢  
: \\ : \\ : \\ : \\ : \\ : Your Country Will Eventually Get Involved Realizing You Too Can Claim Land Rights In That Region Due To Ancient Times 🕙 ⌛ 🐪 🥬 🌊 🔮 🥻

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1699742798785/952685c3-c36f-4d81-b532-83de0c734620.jpeg align="center")

👼🏼 🔢 🕧 ***My Prophetic Message To This Part Of The World*** 📅 😇 🔢  
: \\ : \\ : \\ : \\ : \\ : This Nation Will Symbolically Take On The Identity Of Another With Gilt  
🍒 💰 ✈️ 🛂 🛳️ 🚸 🌲 ⛑️ ☢️ 👷🏼‍♀️ ⛪ 🎖️ 🏆 🌭 🍔 🚅 ☮️

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1699741750619/80faa04b-8126-4d63-a59e-6f3d6b1e770c.jpeg align="center")

👼🏼 🔢 🕧 ***My Prophetic Message To This Part Of The World*** 📅 😇 🔢  
: \\ : \\ : \\ : \\ : \\ : You Will Endure And Triumph 🕛 ❄️ 🪆👩🏼‍💻 👨🏼‍🚀 🏅 🚀

*Though you might be able to guess which nation or region I’m talking about, you still don’t know when or how. The timing of these prophecies start right now until atleast 100 years from this date. I’m stating it that way because one nation spoken about here twice in context to another, is divinely scheduled to be destroyed at such and such a time, and in my vision I saw the year, but before then, their government will change with hope for the future sporting a new image that I also saw and know how it looks, but it will prove futile. What I’ve stated is still true and correct based on the course we are on divinely made known to me over 15 years ago, which I kept until now. From that time, I pondered how to coyly relate it and have been doing so through social media commentaries, blogging and other creative presentations. Due to the Big Brother & Big Tech attacks led by One in the FBI unqualified on these matters, I decided to impart what was unknown to them and The People in this abrupt manner, when I preferred a gentler approach. Now you must deal with it. Sometimes, minding your own business and letting something play out right on its own in the hands of Someone who knows better, is the best move. The so-called Illuminati Sorcerers you are dependent on to protect you, don’t have the insight or power to save you. They are as misguided as you. In your quest to protect a nation, your zeal got the best of you, misreading a situation and mistakenly turning on The One within your kingdom who knows, but offered guidance. In Biblical Times, Abraham tried to bargain with God to save a city (Sodom) he was about to destroy and his argument was going somewhere for a while because Abraham was who he was working through at the time why he entertained such a dialogue. Do you honestly think that HE will listen to you? Nevermind who on the planet HE or SATAN favors. You working against him or her is stupid. Keep doubting it and see what happens next. HE already told me years ago how I fit in concerning all this and I have not revealed too much about that yet. If anyone is curious about my interest in The Devil . . . . well I can’t hide certain things any longer because it will become apparent as time goes on. I’ve left overt and subtle clues through my work. I’ve left overt and subtle clues through my work. I’m scheduled to look exactly as I do now un-aging to play my part in God’s Script as it was meant, since Mankind has grossly mis-interpreted certain parts of The Holy Scriptures, to be revealed as it is supposed to be in real time.*

***So I’m posting the rest of the article today on November 17, 2023 for symbolic reasons as numerology plays a special role in what I do with this blog in general. It represents angel number 1117, and what that means going forward and you should be looking at the context of everything.***

**A Word On Palestine**

People are always going to fight for their Homeland no matter the size. It is their right. They began using sticks and stones and graduated to using more professional weapons.

**A Word On Anti-Semitism**

People hate you. It is the truth. You saw it. And why? Well, I’ve always been forth-coming in trying to articulate things from a unique perspective. And being Spiritually grown, I’m not inclined to respond to certain things as I’ve seen some of the more respected persons in our Communities have. The mask came off and they showed you what they truly think of you, yet prior to that, you mistook other people as The Anti-Semite when they were just being real with you. When the Aftermath of the attacks took off online, I went on **GAB** to see The Party unfold, as it was Anti-Semitism all day prior to that historic event, and the Racists there handled it better, even someone with a HAMAS account on there. There was not a Fiesta! And we know where the real Party was. It was on Twitter and everywhere else on YOUR political platforms. All that internal grievance came up to the surface unleashed on you. Anybody that ever felt wronged by Jews had something to say, especially in The Streets protesting for Palestine. Even your beloved Politicians held back sympathy for you. Throughout life, I’ve weighed unfairness directed at me from any group a certain way. It is true that sensitive areas of my quality of life had been negatively impacted more so by persons of faith and blood who were Jewish and I moved tactfully to handle the problem. The solutions I employ are effective and what goes around comes around. I also keep in mind the small percentage of positive experiences I’ve had from them why I haven’t digressed from my noble path to go do the **Black Hitler** thing. I also grew up watching many intelligent TV Shows and Films that had deep moral messages that were entertaining and not preachy. They also taught you how to recognize things and see through people. And I think when those programs in all its forms over the many years, *even now* got pulled from TV with no adequate replacement to interest the passions of people, it created a void for them to concentrate more on their real life grievances and problems, no longer with a symbol representing their struggles to learn from and suddenly when some event hits **Society** pertaining to your people, the **Monster** comes out.

**A Word On The FBI Guy**

So I introduced this Federal Agent to you **7** Articles back. After several years steadily writing these articles prior to moving to **Automattic’s Wordpress Hosting Site** in 2013 re-posting my old ones and continuing with the writing for nearly 10 years before leaving them due to their role in The Big Tech Attacks, with my last 2 articles in February 2023 being about 2 Black Athletes, PELE & FLO JO where the symbolism was waving goodbye as the end of my term on there onward to fairer treatment. Nobody goes on a platform to be harassed or taken advantaged of. No one starts a business so another group of people can hijack, pirate and prosper from their labor in a exploitative way and they have no right to. Government in part operates that way with some people. When you are a Federal Agent that’s not thoroughly vetted having his or her own problems, and given access to a person’s life with impunity to wreak havoc, the question becomes what’s the reason since you don’t legally have the justification? So the matter falls into categories for speculation like: **Race, Gender, Class, Age, Religion, Creed,** and other areas for prejudice. And I’ve been exposing and poking fun at this guy due to his wreckless Handler activities that impacted my life and the life of my family negatively and it’s unjustified. The more I learn about this man, the more ridiculous it seemed for The FBI to have assigned him to that uneventful **Dr Ali Muhammad** case over 12 years ago, and the more improper it was for Somebody to have chosen him as a Handler for me as if he’s qualified. That’s why the whole thing turned out that way from who’s Handling HIM. And I see some things I’m not saying and am inclined to view my experiences from other perspectives, but the vibe I’m on is more apt. So what does this have to do with The Jewish People? **Plenty,** just look at it. He lives in one of your prominent communities in New York when he’s not moving about The States to an Irish or English one. His **vibe** is all over your equipment moving amongst your people entreating you to partake in his iniquity due to a warped attraction towards me that has been going on for over 12 years. In Ancient Times when The Tribes of Israel profaned God by lusting after a Foreign God in any form HE saw which crossed the line to be considered Worship, his wrath came up to the surface against you that an atonement and Sacrifice was needed to correct that why you got **The Azazel Goat** to offer carrying off all the sins of The People. Perhaps now in **Our Present Day**, such a ritual might be in order except this time The Baphomet Goat among us is in the form of a MAN who can be found living in The Empire State dwelling by a Pearly River, but moves mysteriously through your towns from State to State and can be anywhere, for he has homes there and is protected by a Brittonic Mermaid he hides under, *however caught by your people,* he will be filled with the weight of SIN as you carry him off aloft to **The Bohemian Grove** beseeching GOD in your ceremony to see if He will find The Goat acceptable in His sight and Fit to appease His Anger ***unless*** your atonement might need to be addressing something **profane** happening in your land HE disagrees with. *Hmm,* I wonder what it is? And as for the Dude I’m talking about, I never expected anyone to be ***too*** attracted to my work stalking my activities across all Social Media and being a problem to me hanging on my every visual and word to find himself a part of it debuting on my **152<sup>nd</sup> Blog** entitled **The FBI: A National Security Threat**, and arguably going back 31 articles from that one to the **121<sup>st</sup>** **Blog** entitled **Avenatti’s Marvel Universe, DC** where if *The Culprit* I was alluding to was *him*, he could be considered Sinestro, on the bad side or on a the good side **Spider-Man**, but a separate character describing *his role* would be better except that I’m not trying to honor him. He’s also exposed again on my **153<sup>rd</sup> Blog** entitled, **Screen Actors Guild Strike In 2023**. So in addition to that exposure, he’s now written about here again **Blog 159** *this time* in dark humor.

**~ Lhisa 666**

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1699474992136/462f7688-df9b-4ecc-b58b-8ae8ce9ededf.jpeg align="center")
