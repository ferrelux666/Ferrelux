---
title: "3 Shows NOT Missed In 2019 \U0001F971\U0001F629\U0001F610"
date: '2019-11-07T19:20:51.000Z'
slug: 3-shows-not-missed-in-2019
tags:
  - play
  - network
  - myth
  - race
  - entertainment
  - crime
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672194669840/oqEfun9Q2.png
canonical: 'https://ferrelux666.wordpress.com/2019/11/07/cancelled2019/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194606920/ZZ2Uv31hL.png align="left")](https://www.ferrelux.us/)

\*\*[Shalamar ~ “A Night To Remember”](https://www.youtube.com/watch?v=x9IimLb3b2U)  
\*\*

Enim Vero Di Nos Quasi Pilas Homines Habent 🧜‍♂️ The Gods Use Mortals As Their Playthings

\*\*  
ONCE UPON A TIME\*\*  
First Aired: 10/23/2011  
Last Aired: 5/18/2018  
[https://en.wikipedia.org/wiki/Once\_Upon\_a\_Time\_(TV\_series)](https://en.wikipedia.org/wiki/Once_Upon_a_Time_(TV_series))  
[https://www.youtube.com/channel/UCHU33siD6FnDOOQEECDXn\_w](https://www.youtube.com/channel/UCHU33siD6FnDOOQEECDXn_w)

Okay. Like Many, I really liked the show when it first aired in….. and like many TV shows tend to do, it started to get stupid along the way with the Writers trying too hard to squeeze in too many different story plots with the different fairytale characters. My favorite Ones throughout the show were Rumpelstiltskin, Peter Pan, The Wicked Witch, The Evil Queen and her magic Mirror. They held my interest the most to keep watching the show, it was not the actual corny Good Guys the show revolved around. Somewhere along the line, Mirror’s character got a little too downplayed to where he completely disappeared without further storyline. Rumpel had all the answers and though a prisoner at times, he held the power. Peter Pan had an interesting back story being Rumpel’s Dad and we got to see Rumpel be outwitted at times, because “Pan never fails”, until the Writers messed up his story and he became this diminished character in Hades, which was stupid. It would have been interesting if instead they wrote where Pan was The Wicked Witch’s son, because that looked right. Instead we learn the Wicked Witch, Zelena was a bastard child of a love interest gone wrong and cast aside in another dimension, and that she’s the half-sister of the Evil Queen, Regina. Both Zelena & Regina’s characters should have remained as they were throughout the tale on The Dark Side with Rumpel and Pan, but instead this idea of soul-saving & redemption went so overboard that the show got insipid, and I mean boring to the point of multiple endings of the show until it FINALLY ENDED.

**SCANDAL**  
First Aired: 4/5/2012  
Last Aired: 4/19/2018  
[https://en.wikipedia.org/wiki/Scandal\_(TV\_series)](https://en.wikipedia.org/wiki/Scandal_(TV_series))  
[https://www.youtube.com/channel/UCObcpTKRMYgzOd4mgP6Cocw](https://www.youtube.com/channel/UCObcpTKRMYgzOd4mgP6Cocw)

One feature I actually liked about the show was the sound of a camera shot, play alongside the case of day. That was classic. It gave this modern show an iconic feel. It started off great, until the storyline got stupid. It became a dumb racial mistress Stereotype that isn’t really true. I don’t blame Black Men for dissing the show and it makes no sense why its Black Writer Shonda Rhimes would wallow in such an insipid storyline. In real life most successful Black Women don’t live that way. Unlike the main character Olivia Pope, many Black females would have kept dating, or continue their marriage with that educated and successful Black Ken doll. They wouldn’t be seeing some spoiled Ivy League White guy and have the relationship escalate socially into a tawdry mess. Most people of color when they date outside of their race for some reason, it’s THEM who break it off with that White person after configuring in their ethnic mind why they don’t want to deal with them and the situation anymore. And sometimes that works out well, other times it develops on the White person’s part into an emotional stalking event. Even I experienced that a couple times and thought, it was easier breaking up with the Black, Hispanic and Asian Dudes. They know when something is over so they don’t grow this weird emotional attachment to you. I’ve heard cases with some Black men complaining about breaking up with “Becky” and the drama behind it. Now “Sisters” aren’t going to waste time, the shit is over and they move on. So ‘Scandal’ was a TV show that didn’t make sense to Black Women that are Conscious. I also didn’t like the depiction of Millie, the First Lady, declining her to a “White Trash” status at times. The show was all over the place with trying to show all facets of the racial disparagement in America that it started to look weird. I mean really…. Were things that odd? There were better personal areas to attack like the hypocrisy of Black people. The only things I appreciated in the show were the strong current event topics, the government cover up stuff, the secret agent activities, the twist plot and impacting monologues. The only character I liked very much throughout the show was the “bad guy” Papa Pope. He was a Strong Black Man who was in charge, clever, stern when he needed to be, and when finally tried by the powers that be, he extricated himself from THEIR control and turned the tables on them. And ofcourse, the only person in my mind that made sense to expose the whole thing in the end at trial WAS HIM. And Oh, the only other character I really liked was Huck. I mean come on, he was a genius. Though he had some issues he was your standard hero, reliable and tough. And lastly, Cyrus. It would have helped if the Writers just wrote his character as a normal guy given his background rather than injecting a weird gay storyline that didn’t fit. Anyway, I liked how he operated in The Oval Office, the difficult decisions he had to make to protect the President, whom he saw like a son, and secure the welfare of the Country. Some elements of the show we could have done without along its run, but it did end in an okay fashion.

**QUANTICO**  
First Aired: 9/27/2015  
Last Aired: 8/3/2018  
[https://en.wikipedia.org/wiki/Quantico\_(TV\_series)](https://en.wikipedia.org/wiki/Quantico_(TV_series))  
[https://www.youtube.com/channel/UC0s97gAW4V941imZTFUebJA](https://www.youtube.com/channel/UC0s97gAW4V941imZTFUebJA)

This show should have BEEN Cancelled the prior season but it dragged on. The series started off great with all the FBI training stuff, but after their first few cases, things got sketchy. They lost their audience with a boring storyline in the follow up season. Though I tried watching to see where everything would lead, I eventually lost interest in it and clicked off to different channels. What made me come back was when they casted the actor Blair Underwood in it. When the show finally CAME ALIVE to me was in the very last season when someone got the bright idea to write in a new Super Villain, an Irishman named Conor Devlin. Now he was SOMETHING! He was on in the final 5-weeks of the show and I couldn’t wait to see him. He was exactly what the show needed from Season 2, an elusive re-occurring bad guy. I guess it was already too late for the Network to want to renew the show because they ended up killing his character, which I didn’t appreciate. Where could the show have gone had they kept it? Well…… since they already showed the training process, terrorist cases, the agent setup with Alex, who’s the main character of the show, & her being recruited by other secret agents for other cases, why not explore other issues with that kind of life. The show might have stretched on to a Season 6 instead of only 3 Seasons, because it should have been cancelled after the Second Season. There are Agents who turn Rogue for a reason and are living an interesting life, and that story should be told. Also, what about those FBI Agents who abuse their power in pursuit of a so-called criminal? There are stock pile cases of that. And what about real life corruption cases with the Feds? There were so many things they could have done including showing their failure at times. Cases don’t always work out well, and they could have shown another side of Law Enforcement where people, situations, & things could get mis-interpreted and they fuck up their case. That happens A LOT, which is why you only hear and see the successful cases they are proud of. A lot of the training shown is plausible, but certain things wouldn’t work, especially if they’re applying what would usually work with Caucasian Criminals on Ethnic Ones. There are real live cases where that shit don’t work. Ethnics look at things differently. And with the word Ethnic, don’t limit your thinking to just Hispanics, Blacks, Asians & Indians. Include some Jews, Irish, Greeks, Italians & the like where these crime cases are concerned because many of them I’ve viewed, had their Ethnic instinct about something correct, BUT went against it & got caught. One popular mob case was Donnie Brasco, the undercover cop still in hiding today. I’ve had the pleasure of viewing certain broadcasted criminal cases where Ethnics who knew better, “sensed something” followed their instincts and that Fed wasted his time. Now, I could go on & on about what the undercover agents are doing wrong out here. Many of them are bad actors or just too obvious. Then there are those cases where the Federal Agent messes up bad, real life cases the Quantico TV show could have depicted. Sometimes The Feds prosecute & incarcerate their own in high maximum security prisons specially designed to hold them. The Writers of that show should have explored all options moving forward, because I wouldn’t have had a problem writing episodes. Hollywood however, has their little prejudiced clique selection process, so it’s better just keeping your ideas & present them at a time when everything is right. So we went through most of 2019 not missing Quantico, especially with other TV shows on competing Networks having better content.

**L H I S A**

### Which One Of These 3 Shows Did You NOT Miss The Most? ‘Scandal’, ‘Quantico’, Or ‘Once Upon A Time’. Scroll Down And Leave Your Reply Below.

[![Ferrelux Homepage_NotMissedShows2019](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194609321/qKfICPz_l.png align="left")](https://ferrelux666.wordpress.com/ferrelux-homepage_notmissedshows2019/)

[![Quantico-Season-3-ABC-620x375](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194611055/96dDfNs7Z.jpeg align="left")](https://ferrelux666.wordpress.com/quantico-season-3-abc-620x375/)

[![untitled (3)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194612381/SNrouEbxg.png align="left")](https://ferrelux666.wordpress.com/untitled-3-7/)

[![image](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194613610/t94dhh8fK.jpeg align="left")](https://ferrelux666.wordpress.com/image-3/)

[![quantico-abc-tv-series-tv-promos](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194614866/9x7ZgcL-J.jpeg align="left")](https://ferrelux666.wordpress.com/quantico-abc-tv-series-tv-promos/)

[![untitled](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194616532/zBYROgjlw.png align="left")](https://ferrelux666.wordpress.com/untitled-15/)

[![untitled (5)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194619384/_GrLx2vfP.png align="left")](https://ferrelux666.wordpress.com/untitled-5-3/)

[![untitled (4)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194621236/ub3wlsavv.png align="left")](https://ferrelux666.wordpress.com/untitled-4-5/)

[![QUANTICO - "Run" -- A diverse group of recruits has arrived at the FBI Quantico Base for training. They are the best and the brightest, so it seems impossible that one of them is suspected of masterminding the biggest attack on New York City since 9/11. "Quantico" airs SUNDAY, SEPTEMBER 27 (10:00-11:00 p.m. ET) on the ABC Television Network. (ABC/Eric Liebowitz) PRIYANKA CHOPRA](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194622460/R60tp7zK8.jpeg align="left")](https://ferrelux666.wordpress.com/priyanka-chopra-2/)

QUANTICO – “Run” — A diverse group of recruits has arrived at the FBI Quantico Base for training. They are the best and the brightest, so it seems impossible that one of them is suspected of masterminding the biggest attack on New York City since 9/11. “Quantico” airs SUNDAY, SEPTEMBER 27 (10:00-11:00 p.m. ET) on the ABC Television Network. (ABC/Eric Liebowitz) PRIYANKA CHOPRA

[![145645_0549_-_h_2017](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194624200/PD42Q8z1b.jpeg align="left")](https://ferrelux666.wordpress.com/145645_0549_-_h_2017/)

[![ec188ac9d0c32526dd32a13d91d025f3](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194625503/tht929OJZ.jpeg align="left")](https://ferrelux666.wordpress.com/ec188ac9d0c32526dd32a13d91d025f3/)

[![Quantico-640x360](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194626755/DkRnZCGT_.jpeg align="left")](https://ferrelux666.wordpress.com/quantico-640x360/)

[![quantico1](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194627956/6FipmXkF7.jpeg align="left")](https://ferrelux666.wordpress.com/quantico1/)

[![Conor-Devlin](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194629496/X3hDiwwoR.png align="left")](https://ferrelux666.wordpress.com/conor-devlin/)

[![bf0d91dde7a0848f2185939c8cb29656](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194630682/m6T0iCY9X.jpeg align="left")](https://ferrelux666.wordpress.com/bf0d91dde7a0848f2185939c8cb29656/)

[![b308fbfd01b591f6c80cb77940c7](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194631815/TGesFTw0a.jpeg align="left")](https://ferrelux666.wordpress.com/b308fbfd01b591f6c80cb77940c7/)

[![Lydia_Hall](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194633690/AScEvEWpZ.png align="left")](https://ferrelux666.wordpress.com/lydia_hall/)

[![MV5BMTkxNTg3MTc0Ml5BMl5BanBnXkFtZTgwMzYxNDIyNTM@.V1](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194635042/PsRWE-wRO.jpeg align="left")](https://ferrelux666.wordpress.com/mv5bmtkxntg3mtc0ml5bml5banbnxkftztgwmzyxndiyntm-_v1_/)

[![QUANTICO - ABC's "Quantico" stars Priyanka Chopra as Alex Parrish. (ABC/Bob D'Amico)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194636256/qUOACEEEK.jpeg align="left")](https://ferrelux666.wordpress.com/priyanka-chopra/)

QUANTICO – ABC’s “Quantico” stars Priyanka Chopra as Alex Parrish. (ABC/Bob D’Amico)

[![28-Priyanka](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194637662/F6ayAxb9D2.jpeg align="left")](https://ferrelux666.wordpress.com/28-priyanka/)

[![22-quantico.w700.h700](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194639003/3h83gri5F.jpeg align="left")](https://ferrelux666.wordpress.com/22-quantico-w700-h700/)

[![giphy](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194640412/aFipAcEa8.gif align="left")](https://ferrelux666.wordpress.com/giphy/)

[![Zelena722](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194642159/gJeJJHp5e.jpeg align="left")](https://ferrelux666.wordpress.com/zelena722/)

[![Ultimate-Gladiator-806x806-2](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194644473/lkjMpSKJX.png align="left")](https://ferrelux666.wordpress.com/ultimate-gladiator-806x806-2/)

[![untitled](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194646074/zoG1Gr_4q.png align="left")](https://ferrelux666.wordpress.com/untitled-13/)

[![intro](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194647166/aExuSV5fe.jpeg align="left")](https://ferrelux666.wordpress.com/intro/)

[![joe-morton-810x960](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194648493/5Ybt7LsWh.jpeg align="left")](https://ferrelux666.wordpress.com/joe-morton-810x960/)

[![Papa-Pope](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194649711/yDrGfbLHb.jpeg align="left")](https://ferrelux666.wordpress.com/papa-pope/)

[![SCANDAL - "Seven Fifty-Two" - Secrets from Huck's life before Pope and Associates are revealed, Olivia and Fitz engage in an emotionally charged conversation, unaware of the fact that someone could be watching, and Olivia's team comes together to help one of their own. Meanwhile, Cyrus is becoming increasingly skeptical of Jake, and Mellie makes a decision that could bring down the White House, on "Scandal," THURSDAY, APRIL 25 (10:02-11:00 p.m., ET) on the ABC Television Network. (ABC/Ron Tom) KERRY WASHINGTON, GUILLERMO DIAZ](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194650989/wzRnSVArp.jpeg align="left")](https://ferrelux666.wordpress.com/kerry-washington-guillermo-diaz/)

SCANDAL – “Seven Fifty-Two” – Secrets from Huck’s life before Pope and Associates are revealed, Olivia and Fitz engage in an emotionally charged conversation, unaware of the fact that someone could be watching, and Olivia’s team comes together to help one of their own. Meanwhile, Cyrus is becoming increasingly skeptical of Jake, and Mellie makes a decision that could bring down the White House, on “Scandal,” THURSDAY, APRIL 25 (10:02-11:00 p.m., ET) on the ABC Television Network. (ABC/Ron Tom) KERRY WASHINGTON, GUILLERMO DIAZ

[![scandal-eli](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194652044/Zga6OSzEG.jpeg align="left")](https://ferrelux666.wordpress.com/scandal-eli/)

[![imagesW4AGH1W5](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194653325/KxldjX1k2.jpeg align="left")](https://ferrelux666.wordpress.com/imagesw4agh1w5/)

[![cb464f4880651bb5a1d83ac33821bb47](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194654399/OsOe2haGJ.jpeg align="left")](https://ferrelux666.wordpress.com/cb464f4880651bb5a1d83ac33821bb47/)

[![beauty-trends-blogs-daily-beauty-reporter-2013-10-03-Kerry-Washington-Scandal](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194655849/xtqTuSH53.jpeg align="left")](https://ferrelux666.wordpress.com/beauty-trends-blogs-daily-beauty-reporter-2013-10-03-kerry-washington-scandal/)

[![a15acd7dde9b4a5612c2c29ab35303db](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194657442/hPD5k2Qrv.jpeg align="left")](https://ferrelux666.wordpress.com/a15acd7dde9b4a5612c2c29ab35303db/)

[![SCANDAL - "Even the Devil Deserves a Second Chance" - While Fitz is focused on winning back the American people, he makes a shocking discovery. Meanwhile, OPA takes on a new client, but Olivia seems preoccupied keeping her own secrets, and Elizabeth North sets her sights on a new agenda, on "Scandal," THURSDAY, NOVEMBER 5 (9:00-10:00 p.m., ET) on the ABC Television Network. (ABC/Eric McCandless) GUILLERMO DIAZ](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194658746/Ei34yGaXD.jpeg align="left")](https://ferrelux666.wordpress.com/guillermo-diaz/)

SCANDAL – “Even the Devil Deserves a Second Chance” – While Fitz is focused on winning back the American people, he makes a shocking discovery. Meanwhile, OPA takes on a new client, but Olivia seems preoccupied keeping her own secrets, and Elizabeth North sets her sights on a new agenda, on “Scandal,” THURSDAY, NOVEMBER 5 (9:00-10:00 p.m., ET) on the ABC Television Network. (ABC/Eric McCandless) GUILLERMO DIAZ

[![20152F032F132F5f2FScandal1.f02c0.jpg2F950x534__filters3Aquality288029](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194659905/1w2mHVmz6.jpeg align="left")](https://ferrelux666.wordpress.com/20152f032f132f5f2fscandal1-f02c0-jpg2f950x534__filters3aquality288029/)

[![1200x627-Q80_f271c80228b5d6bb188ca371c06ab388](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194660868/uoO_y0Uci.jpeg align="left")](https://ferrelux666.wordpress.com/1200x627-q80_f271c80228b5d6bb188ca371c06ab388/)

[![411full](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194661828/ZCOefkBRN.jpeg align="left")](https://ferrelux666.wordpress.com/411full/)

[![6x04_-_Cyrus_Beene_01](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194662942/k1xRwCgkt.jpeg align="left")](https://ferrelux666.wordpress.com/6x04_-_cyrus_beene_01/)

[![6e0981c8b1fb4b873b198d179f02e44b](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194664620/j16K-_vNn.gif align="left")](https://ferrelux666.wordpress.com/6e0981c8b1fb4b873b198d179f02e44b/)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194666429/kO7TZ8vU4.jpeg align="left")](https://ferrelux.com/adverts/)
