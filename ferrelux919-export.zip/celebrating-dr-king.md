---
title: "\U0001F396Celebrating Dr King \U0001F4D6"
date: '2022-01-17T01:28:40.000Z'
slug: celebrating-dr-king
tags:
  - google
  - youtube
  - ranking
  - social-media
  - search-engine
  - freedom
  - usa
  - holiday
  - legacy
  - american
  - networks
  - united-states
  - america
  - online-platform
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672192165391/ef7VUFQzn.jpeg
canonical: 'https://ferrelux666.wordpress.com/2022/01/16/celebrating-dr-king/'
---
[![The Rev Dr King](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192139251/7SiQ8QCOf.gif align="left")](https://rumble.com/search/video?q=Martin%20Luther%20King%20Jr)

<iframe width="100%" height="100" src="https://w.soundcloud.com/player/?url=https%3A%2F%2Fapi.soundcloud.com%2Ftracks%2F256319748&auto_play=false&hide_related=false&visual=true&show_comments=true&show_user=true&show_reposts=false&color=ff5500"></iframe>

[U 2](https://soundcloud.com/u2) · [Pride (In The Name Of Love)](https://soundcloud.com/u2/pride-in-the-name-of-love-1)

\_\_  
So you’ll notice some changes to the site this New Year going forward. You know, there are other long-standing and developing websites out there you can use to peruse and feature additional material to your own work. It’s unfortunate that people make a habit of continuing to use Google products and services in exclusive ways, when it has gotten to the point of obvious corruption to really trust.\_\_

\*\*  
It’s important while living our daily lives to remember history, and how we got to be where we are now and the sacrifices it took.\*\*

[Joe Biden, Kamala Harris & Others Honoring Dr King’s Statue](https://utreon.com/v/3DHh28cTOyA)

**Here Are Some Links On His Legacy**

[**https://empirestateplaza.ny.gov/nyking**](https://empirestateplaza.ny.gov/nyking)  *Live Presentation, PBS, 1/17/22, 10am*

[**https://naacp.org/find-resources/history-explained/civil-rights-leaders/martin-luther-king-jr**](https://naacp.org/find-resources/history-explained/civil-rights-leaders/martin-luther-king-jr)

[**https://mlk50.civilrightsmuseum.org/timeline**](https://mlk50.civilrightsmuseum.org/timeline)

[**https://afro.com/dr-kings-legacy-and-our-struggle-for-the-soul-of-our-democracy/**](https://afro.com/dr-kings-legacy-and-our-struggle-for-the-soul-of-our-democracy/)

[**https://www.yahoo.com/lifestyle/open-closed-martin-luther-king-204815516.html?fr=sycsrp\_catchall**](https://www.yahoo.com/lifestyle/open-closed-martin-luther-king-204815516.html?fr=sycsrp_catchall)

[**https://www.nobelprize.org/prizes/peace/1964/king/biographical/**](https://www.nobelprize.org/prizes/peace/1964/king/biographical/)

[**https://www.biography.com/activist/martin-luther-king-jr**](https://www.biography.com/activist/martin-luther-king-jr)

\*\*\*\*Sign,\*\*\*\***Lhisa Mrklon**

**Is Dr King’s Dream Fulfilled In Our Time? Scroll Down And Leave Your Reply Below.**

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192140694/3ZvTy5NVm.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192142235/gGPGiTxk1.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192143480/xXv576Eyd.gif align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192144572/QTUqJRr5p.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192145889/Z2oUST2L_.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192147279/1kqMIJ8Wa.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192150733/pfS78j7i8.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192151823/CuTr2MA_J.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192152968/uLB_aqhlW.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192154166/xVLaZxL8d.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192155608/9EiUoH--R.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192157144/RlEuhgbYT.gif align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192158175/3Q0ozrk8r.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192159287/4OjwsOgmS.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192161059/CJxIzEJNY.jpeg align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192162620/c2kGCtMxp.jpeg align="left")](https://lightinthebox.tv2h87.net/c/3170166/898314/8199?prodsku=8709764&u=https%3A%2F%2Fwww.lightinthebox.com%2Fpz607-w-lcd-digital-screen-wireless-car-reversing-monitor-reversing-radar-kit-waterproof-360-monitoring-for-car_p8709764.html&intsrc=PUI2_7096)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192164002/gUy8wLr6a.jpeg align="left")](https://miniinthebox.8zwg.net/c/3170166/461413/8200?prodsku=5451432&u=https%3A%2F%2Fwww.miniinthebox.com%2Fnecklace-rhinestone-jewelry-men-s-18k-stamp-real-gold-plated-crown-lion-pendant-necklace-with-chain-29-5_p5451432.html%3Fcurrency%3DUSD&intsrc=PUI2_2952)

### Like this:

Like Loading...

### *Related*
