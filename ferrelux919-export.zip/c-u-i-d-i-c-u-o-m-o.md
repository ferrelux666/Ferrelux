---
title: "C U I D I  ❤\U0001F90D\U0001F499 C U O M O"
date: '2021-08-13T18:12:30.000Z'
slug: c-u-i-d-i-c-u-o-m-o
tags:
  - book
  - trump
  - scheme
  - office
  - women
  - policy
  - political
  - workplace
  - health-care
  - government
  - vote
  - covid-19
  - guns
  - power
  - vaccine
  - female
  - voting
  - aoc
  - new-york
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672208706003/fbca642b-9c3f-47c3-80d8-948613bed33c.jpeg
canonical: 'https://ferrelux666.wordpress.com/2021/08/13/cuidi-cuomo/'
---
[![Voters Stand By Cuomo](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192778458/2lbvFuFrG.jpeg align="left")](https://www.andrewcuomo.com/latest)

[**“My Way” ~ Frank Sinatra**](https://www.youtube.com/watch?v=w019MzRosmk)  
Est Tempus Ad Populum De Imperium Civitas Ut Adversor 🍎 It’s Time 4 The People Of The Empire State To Strike Back (Andrew Cuomo)

That’s my personal nickname for him. And by the way, why treat him like that? It could have been handled better. Why remove him from Power? What the hell do you think is going to be better? You might end up regretting that move because Ya’ll acting like none of you have any faults, when this sudden action is revealing your true nature. Before Cuomo can even exit Office, his Successor Kathy Hochul is already arrogantly strutting & squawking like some behind-the-scenes agenda was in suit for her to emerge, why a school of people that know better are not comfortable with this move. It’s a poor political strategy. When it backfires, that’ll learn ya. New York is now well on it’s way to becoming a RED STATE! The misguided agenda to use some females to go out there in public, making questionable accusations with intent to remove someone from Office is a wicked scheme. As Americans, we vote who we want into office. You don’t use vicious tactics disguised as morality to force someone out of office simply because you want **The Power** for yourselves. How dare you try to govern us in that way! I was comfortable with Andrew Cuomo. I didn’t agree with everything he said and did, but I knew that he was solid to keep in Office. And I liked his father Mario Cuomo. He remained in power until he got beat by the Republican contender George Pataki. Then ‘The People of New York’ realized that they should have kept Mario Cuomo. **NOW**, in a Millenial Time, a similar thing is happening again. This time instead of voting out a Politician, THEY ARE using a cheap political scandal to deprive an America Citizen of the proper Due Process Of Law, to institute a Candidate THEY can control until they find who they really want in there. When women allow themselves to be stupidly used like that without thought that maybe, **The Powers That Be,** have their own agenda and could really care less about YOU, it’s a tremendous loss. It means that you are just a convenient tool to use, and when something serious pops up that demands their respect of you, THEY will show exactly what they think of you, because you no longer serve a purpose. The way you should want to emerge as *‘The First Female Governor of New York’* is that you won fair and square in a political election. Not through #MeToo or #TimesUp. Those things actually hurt women and their respectability. As time goes on, they’ll see how. When Kathy Hochul was in the background, that is a perfectly great position to be in sometimes. People don’t notice you as much, and **\_***your work***\_**. They either know of you, or actually know enough. So your progress on something is protected, you’re not exposed in the same way for scrutiny or attack. NOW, with her out there in the open amidst these wolves she thinks she’s prepared to handle, might show itself to be premature. You want to come into a job the right way, or atleast respectable enough. You don’t want to get a job position by cut-throat, and think THESE PEOPLE will not fuck you over too. THEY WILL, because like they did Andrew Cuomo, they may already have their cards to play on you too. Politics is nasty. You do not have anybody’s true blessing, which brings me back to Andrew Cuomo, a seasoned politician with the guidance and upbringing the Cuomo heritage had to offer. So we trust that Brand. And he would know how rugged and dirty politics is to handle himself as he did through it. And **YOU PEOPLE**, orchestrating an embarrassment for him is shameful. And you know what, you stooped to such a degenerate level simply because **you could not beat him** the right way in an Election. Now what the hell do you think New Yorkers who know better is going to do? You think they will go to the polls and vote to keep Kathy Hochul? There are already some discrepancies circulating out there about her. You know what is most likely to happen? With the Republican Candidates running for Governor, one might be a viable prospect to elect instead. Now that a Democratic Strongman Leader like Andrew Cuomo got abruptly, and rudely removed from his Post by his own democratic party plotting against him, a Republican Strategist can work further in ensuring that New York turns RED. They certainly could not do it before while Cuomo was still there, because he was too strong. He had a way of seeing certain things and although ‘We The People’ didn’t always agree, we knew we could protest and fight and argue on some points for change, while on other topics, he did exactly what we expected. He is someone ‘The People’ knows and can reason with and playfully fight for something we want. Any mistakes or mis-judgments comes with the job, and he can’t entirely be blamed for it. We live in a Government, so others are involved in these decisions as well. In recent times, regarding certain areas of politics, I thought that New York would do better being a **Red State**, but I always respected Governor Cuomo as a political Strongman holding the state Democratic, and I was figuring in my mind when The Election came around again, would The State furnish a Republican that might beat him. And then months back, Republican Rudy Giuliani’s son Andrew Giuliani emerged. So now two well-known and trusted political brands might contend, **Cuomo Vs Giuliani**, and I was so looking forward to an interesting battle that now I, and other New Yorkers are robbed from this showdown, just because questionable political hashtags like #MeToo and #TimesUp, have more political power as tools for usurpation in America than they would in long-standing, and more stable governments around the world where something as silly as that is put in check and kept in its place. An Old School Politician who lived through **The Times** and knowing so much, and seeing the changes, would want to ask ‘The People’ who know better, ‘Are You Loyal?’ because you will need to be, if you are trying to preserve something you hold valuable, before you get run over by your enemies. It’s logical to pay attention to what is going on in **Our Time** and how it might affect you. So thank you Andrew Cuomo for your beneficial work over the years serving **The People of New York**. The presence of your governing struck fear into a lot of people who knew damn well that they couldn’t just do something politically sneaky and expect that to fly with you. So your Political Party got infiltrated and manipulated I guess, and I bet you saw it happening all around you, as you tried tactfully dealing with it. And despite what The Press says, your name is no disgrace. What is disgraceful is where politics is NOW. I’ll miss you. And going forward, you’ll be free from having to sit in Office and deal with that whole political nonsense each day, as the rest of them still trapped in it, might eventually turn on each other. Thank you for *caring* for the people of New York, Cuidi Cuomo  💜  \*\*EXCELSIOR!  
\*\*

Sign,  
Lhisa Mrklon

**Were These Sexual Harassment Allegations Suddenly Cropping Up Against Andrew Cuomo Designed To Hurt Him Politically Going Forward? Scroll Down And Leave Your Reply Below.**

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192780050/uhRCKQeIA.png align="left")](https://www.usgrants.org/sign-up?affiliate=134980)

[VISIT THE NEW YORK 9/11 MEMORIAL MUSEUM](https://www.tiqets.com/en/new-york-attractions-c260932/tickets-for-9-11-memorial-museum-p974440/?partner=ferrelux&tq_campaign=New%20York)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192782600/UQ5JnxchN.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192784512/B7ilbGXb9.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192786114/SLIsDHtew.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192787684/fNs3_T1ZA.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192788934/9-ZvHI3F-.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192790247/RfzqrUdMM.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192792784/L5lhQNlcJ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192794981/tFyskFkIu.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192796255/UWFwehn2M.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192797415/RPNyRKePF.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192798966/YTbL-qqHp.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192800487/UXybTWTWa.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192802405/lmiwvZFNu.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192804100/9q-MzTNgK.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192805689/fdGOdbW3D.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192807224/0kcFboM9b.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192808949/t6m7XsMPI.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192810726/Cejb4sqy9.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192812525/tranm57bb.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192813747/im7cItKn6.jpeg align="left")
