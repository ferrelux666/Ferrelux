---
title: "\U0001F304 Haiti's Scorpion Unit \U0001F41A"
date: '2023-03-15T06:36:05.400Z'
slug: haitis-scorpion-unit
tags:
  - haiti-scorpion-unit
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1678861866844/77b1c829-c7d0-4050-87e0-345dc1c3aa42.jpeg
---
*O Venite Shango Et Oya, Defende Nobis 🪓 Oh Come Forth Shango & Oya, Defend Us*

[Bob Marley - Could You Be Loved (Instrumental)](https://odysee.com/@Lucifer666:f/Bob-Marley_Audio-Image_Beloved:5)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1679352232518/7faccdb4-4494-45e1-84c7-d3a37e623dd4.jpeg align="center")](https://visithaiti.com/)

**🤍 O Haitians, lo how they turn you back as soon as they see your glistening Black skin appear on their shores. There is no love for you in this land. A few centuries back you dared to take up arms against your Slavers on that Island and you WON, and to this day, they never forgave you for inspiring the Slave Uprisings that took place here in America and elsewhere. So when they hear of you or see you, THAT comes to mind. Keeping you sacked in crippling poverty and enabling a global agenda against you centuries after to impair your economic development and ability to strengthen your independence as a free people is what’s going on. They don’t like any of Us. And know that here in America, and elsewhere, “Blacks” in general are personally experiencing a tragic poetic form of your plight in our daily lives being turned away from prospects or obstructed from prospering in life. So I implore you to think about your situation collectively and invoke your power. See below my goodwill message videos in 4 languages. Peace.**  ❤️ *Oh Haitianos, he aquí cómo te dan la espalda tan pronto como ven tu piel negra y reluciente aparecer en sus costas. No hay amor por ti en esta tierra. Hace unos siglos, os atrevisteis a tomar las armas contra vuestros esclavistas en esa Isla y GANASTEIS, y hasta el día de hoy, nunca os perdonaron por inspirar los Levantamientos de Esclavos que tuvieron lugar aquí en Estados Unidos y en otros lugares. E ntonces, cuando escuchan de ti o te ven, ESO viene a la mente. Lo que está sucediendo es mantenerlos despedidos en una pobreza paralizante y permitir que una agenda global en su contra siglos después perjudique su desarrollo económico y su capacidad para fortalecer su independencia como pueblo libre. No les gusta ninguno de nosotros. Y sepan que aquí en Estados Unidos, y en otros lugares, los "negros" en general están experimentando personalmente una forma trágica y poética de su difícil situación en nuestra vida diaria, que se aleja de las perspectivas o se les impide prosperar en la vida. Así que les imploro que piensen en su situación colectivamente e invoquen su poder. Vea a continuación mis videos de mensajes de buena voluntad en 4 idiomas. Paz. 💙* Ô Haïtiens, voyez comme ils vous refoulent dès qu'ils voient votre peau noire luisante apparaître sur leurs rivages. Il n'y a pas d'amour pour toi sur cette terre. Il y a quelques siècles, vous avez osé prendre les armes contre vos Esclavagistes sur cette île et vous avez GAGNÉ, et à ce jour, ils ne vous ont jamais pardonné d'avoir inspiré les Soulèvements d'esclaves qui ont eu lieu ici en Amérique et ailleurs. Alors quand ils entendent parler de vous ou vous voient, CELA leur vient à l'esprit. Vous maintenir dans une pauvreté paralysante et permettre un programme mondial contre vous des siècles plus tard pour nuire à votre développement économique et à votre capacité à renforcer votre indépendance en tant que peuple libre, c'est ce qui se passe. Ils n'aiment aucun d'entre nous. Et sachez qu'ici en Amérique et ailleurs, les “Noirs” en général vivent personnellement une forme poétique tragique de votre sort dans notre vie quotidienne, étant détournés des perspectives ou empêchés de prospérer dans la vie. Je vous implore donc de réfléchir collectivement à votre situation et d'invoquer votre pouvoir. Voir ci-dessous mes vidéos de messages de bonne volonté en 4 langues. Paix. *💛* ***O Ayisyen, gade ki jan yo fè nou tounen le pli vit ke yo wè po Nwa briyan ou parèt sou rivaj yo. Pa gen lanmou pou ou nan peyi sa a. Kèk syèk dèyè ou te oze pran zam kont esklav ou yo sou zile sa a epi ou GENYEN, e jiska jodi a, yo pa janm padone ou paske yo te enspire Soulèvman Esklav yo ki te fèt isit la nan Amerik ak lòt kote. Se konsa, lè yo tande pale de ou oswa wè ou, sa vin nan tèt ou. Kenbe ou sache nan povrete enfim epi pèmèt yon ajanda mondyal kont ou plizyè syèk apre yo anpeche devlopman ekonomik ou ak kapasite pou ranfòse endepandans ou kòm yon pèp lib se sa k ap pase. Yo pa renmen okenn nan nou. Epi konnen ke isit la nan Amerik, ak lòt kote, "Nwa" an jeneral yo pèsonèlman fè eksperyans yon fòm powetik trajik nan sitiyasyon ou nan lavi chak jou nou yo te vire do bay kandida oswa obstrue nan pwospere nan lavi. Se konsa, mwen sipliye w pou w reflechi sou sitiyasyon w ansanm epi envoke pouvwa w. Gade anba a videyo mesaj bon volonte mwen nan 4 lang. Lapè. 💚***  
  
[**VIDEO: HAITI'S SCORPION UNIT (CREOLE)**](https://odysee.com/@Lucifer666:f/Haiti's-Scorpion-Unit-Creole-Version:5)  
[**VIDEO: HAITI'S SCORPION UNIT (FRENCH)**](https://odysee.com/@Lucifer666:f/Haiti's-Scorpion-Unit-French-Version:5)  
[**VIDEO: HAITI'S SCORPION UNIT (SPANISH)**](https://odysee.com/@Lucifer666:f/Haiti%27s-Scorpion-Unit-Spanish-Version:0)  
[**VIDEO: HAITI'S SCORPION UNIT (ENGLISH)**](https://odysee.com/@Lucifer666:f/Haiti's-Scorpion-Unit-English-Version:5)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1679362892880/9776eb37-3e97-418a-bc13-5e144b059996.jpeg align="center")

**ASSIST HAITI**  
[https://ht.usembassy.gov/](https://ht.usembassy.gov/)  
[https://www.haiti.org/](https://www.haiti.org/)

**The Memphis Scorpion Unit & The Death Of Tyre Nichols**  
[**https://www.bbc.com/news/world-us-canada-64442756?\_hsenc=p2ANqtz--qxGWhCKxGvJyyX0B09wJxX6PqjK6urtfcod4SvaGlEkRTEaQU6C3LEX4UiBGy8qIsjLBY**](https://www.bbc.com/news/world-us-canada-64442756?_hsenc=p2ANqtz--qxGWhCKxGvJyyX0B09wJxX6PqjK6urtfcod4SvaGlEkRTEaQU6C3LEX4UiBGy8qIsjLBY)

**The Scorpion Unit, In America (Now De-Activated)**  
[https://abcnews.go.com/US/scorpion-unit-memphis-police-task-force-center-tyre/story?id=96720313](https://abcnews.go.com/US/scorpion-unit-memphis-police-task-force-center-tyre/story?id=96720313)

**The NYPD In Haiti**  
[https://www.nbcnewyork.com/news/local/nypd-officers-training-police-port-au-prince-haiti-earthquake-devastation-violence/1021929/](https://www.nbcnewyork.com/news/local/nypd-officers-training-police-port-au-prince-haiti-earthquake-devastation-violence/1021929/)

[https://www.cbsnews.com/newyork/news/nypd-receiving-award-for-haiti-training-assistance/](https://www.cbsnews.com/newyork/news/nypd-receiving-award-for-haiti-training-assistance/)

**The Gangs Controlling Haiti**  
[**https://www.theguardian.com/global-development/2021/jul/19/guns-gangs-and-bad-aid-haitis-crisis-reaches-full-throttle**](https://www.theguardian.com/global-development/2021/jul/19/guns-gangs-and-bad-aid-haitis-crisis-reaches-full-throttle)

[https://news.un.org/en/story/2022/10/1129777](https://news.un.org/en/story/2022/10/1129777)

**The United Nations & Haiti**  
[https://abcnews.go.com/International/wireStory/warns-gangs-consuming-haiti-despite-police-97893840](https://abcnews.go.com/International/wireStory/warns-gangs-consuming-haiti-despite-police-97893840)

**Some Info About Haiti**  
[**https://www.factretriever.com/haiti-facts**](https://www.factretriever.com/haiti-facts)

**Biden & The Haitians**  
[**https://www.spokesman.com/stories/2023/mar/13/with-bidens-visit-to-canada-us-will-seek-commitmen/**](https://www.spokesman.com/stories/2023/mar/13/with-bidens-visit-to-canada-us-will-seek-commitmen/)

**The Clintons & The Haitians**  
[https://www.bbc.com/news/election-us-2016-37826098](https://www.bbc.com/news/election-us-2016-37826098)

[https://slate.com/news-and-politics/2016/09/the-truth-about-the-clintons-and-haiti.html](https://slate.com/news-and-politics/2016/09/the-truth-about-the-clintons-and-haiti.html)

**Haiti & Jamaica**  
[**https://en.wikipedia.org/wiki/Haiti%E2%80%93Jamaica\_relations**](https://en.wikipedia.org/wiki/Haiti%E2%80%93Jamaica_relations)

**Toussaint L’Ouverture**  
[**https://en.wikipedia.org/wiki/Toussaint\_Louverture**](https://en.wikipedia.org/wiki/Toussaint_Louverture)

**Jean-Jacques Dessalines**  
[**https://en.wikipedia.org/wiki/Jean-Jacques\_Dessalines**](https://en.wikipedia.org/wiki/Jean-Jacques_Dessalines)

**What Happened To Haiti Financially A Couple Decades After**  
[https://www.npr.org/sections/money/2021/10/05/1042518732/-the-greatest-heist-in-history-how-haiti-was-forced-to-pay-reparations-for-freed](https://www.npr.org/sections/money/2021/10/05/1042518732/-the-greatest-heist-in-history-how-haiti-was-forced-to-pay-reparations-for-freed)

**Sign,**  
**Lhisa Mrklon,**  
**Orisha 666**

***A Black Man, Toussaint L’Overature rose against The French Emperor Napoleon, trying to liberate his enslaved people with some success until he was captured and held in a French prison, then subsequently executed. His Lieutenant, another Black Man, Jean-Jacques Dessalines, rose in his place to lead The Slave Uprising and he succeeded in freeing Our People, defeating Napoleon and declaring himself The First Emperor of Haiti.***

**So Haiti, Are You Ready For Another Revolution?**

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1679255369270/ba179900-ab0b-448d-9ade-c973426a7e1e.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1679255391400/394d05ee-125b-4041-8f92-f61715b5f25f.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1679255421349/24a82b14-4062-4883-85fb-1c65617d83fb.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1679255443255/4e2f2e21-402c-4350-a0c4-23403612a3cd.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1680394272913/93d1d091-b98d-4473-b4d7-cc80e0d95c0f.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1680394307608/7a4fae54-512b-4630-849e-c46265016839.jpeg align="center")
