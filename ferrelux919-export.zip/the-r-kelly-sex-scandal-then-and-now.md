---
title: "The R. Kelly Sex Scandal Then & Now\U0001F3B5\U0001F39E"
date: '2019-08-12T19:38:40.000Z'
slug: the-r-kelly-sex-scandal-then-and-now
tags:
  - trial
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672194847110/irRlHR0YT.jpeg
canonical: 'https://ferrelux666.wordpress.com/2019/08/12/rkelly/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194811966/xQM88TbFz.png align="left")](https://www.ferrelux.us/)

  
[R. Kelly ~ ‘My Story’](https://myspace.com/rkelly/music/song/my-story-93790443-105298577)

*Mendacem Memorex Esse Oportet 🎱  A Liar Needs A Good Memory*

So what brings me to talking about his case at this time is this might be it? Going all the way back to the 90s, this mega R&B star has been accused of dating under-aged girls, but nobody really cared much at the time until the ‘Me Too’ & ‘Times Up’ movement. Like many, I really like his music, hit after hit after hit. Somewhere in our minds we know about or have heard some shit about his lifestyle, but who in that Industry doesn’t have some similar shit. In the dingy circles where these people hangout or have an ear to, knew R. Kelly is shit, so…. YOU dealing with him, should know better. There’s no secret here. At the time when girl group Destiny’s Child was active, Beyoncé’s Mom & Dad heard some shit & didn’t want their daughter or any of the girls dealing with him so they went about their career another way, however, some parents didn’t have a problem with their teenagers seeing Robert Kelly, as we hear in some of these cases. We know that he married deceased R&B Princess Aaliyah, at age 14, when some doctoring of the paperwork was necessary for the marriage to happen & her Mother didn’t have a problem with him. Aaliyah’s beauty, dress, dance, & music is still remembered & celebrated to this day. Many young ladies wanted to be successful in R&B Hip-Hop just like her & hitting on R. Kelly was a way to get there. Just singing a duet with him, or being a leading lady in his video would be significant, BUT somewhere along the line messing with him, he just didn’t see an Aaliyah in them, and they didn’t get a successful music career, but what they did get was a Caretaker they’re claiming took advantage of them in cruel demeaning ways. Well hold up,…….you’re seen freely arriving & leaving his house, all smiles, spending his money, all up on the camera and now you’re saying he humiliated you, but you went back. Could it be with all the White Women in the news accusing all kinds of popular men of sexual assault in their cases, you felt you could do the same against a musically defenseless Black Man whose career was stunted by his Baby Mama who still holds great poisonous anger towards him & can’t stop talking about him. Well, R. Kelly is not a Saint, but by his own account & those who know, he himself had been deceived or fucked over by women too, some of them he took back & the hateful squabble continues. So there are 2-sides to this story and ofcourse the truth. The accusations would work well if everything was static black & white, there are too many shades of grey here. The parents knew the teens were living under his luxury roof rent free, and they hoped that their child would make it in the big time. So I’m thinking, why not charge the parents for negligence, child endangerment? I bet they’ll drop the charges against R. Kelly if the case was twisted back on them. Who’s lying? Who’s telling the truth? The Law is not a game, they can’t keep making concessions for people being melodramatic. At the time way back about 20 years ago when the accusations were fresh, a Judge dismissed the charges and R. Kelly went free. Now 20 years later, because of some Director’s scathing depiction of him in the docu-series ‘Surviving R.Kelly’, it rehashed old spiteful feelings and to reclaim the lady honor you so cheaply gave away, it was a last ditch attempt to dig into this Nigger again with further embellishments to the story. Now I’m not absolving R. Kelly of anything, but many of you have guys in your neighborhood fucking around with you in ways that are no different that some of you live with, that you ain’t doing shit about. Wouldn’t it have been better to remain a chaste woman living off nickels & dimes from the grit of your brow and wood chuck your ass to success on your own terms? Now had Mister R. Kelly just put you in a song, secured a TV show for you, or brokered some other deal, I bet what you claimed he did bad to you, wouldn’t matter much because you hit the big time. That’s really what I fault him for, he couldn’t or wouldn’t deliver. That whole sex scandal would have went away had somebody not mailed former Stormy Daniels, attorney Michael Avenatti an old sex tape featuring what appears to be singer R. Kelly having sex with a 14-year old. That too brought steam back on old accusations. Fortunately for him though, Avenatti himself got into a legal bundle of trouble with charges of extortion from Sneaker giant Nike, and he had to leave the R. Kelly case. The troubles for the singer should have ended there when he got bailed out of jail both times, but some new women popped up later with new charges. Maybe the psyche of R. Kelly is not what others may think. Does he like trolling around young women in their teens? He could easily get quality women in their 20s and beyond. Maybe something else is going on with his person. He makes very beautiful music that suggest the feminine character in these songs are grown women. The explicit adult-content shows he knows he is an adult male painting a picture & telling a story in these songs. So what I care about is his person. Who is he, how did he develop? What happened to him? He himself is being objectified in the media. What makes him respond to women a certain way? What type of woman evokes a better reaction out of him? Rather than tear down a person this whole time, decades long, someone should have intervened or helped. Now an entire music catalog is at risk. Sony Music, after too much public protest, even Demonstrators marching around their building for weeks, dropped R. Kelly from their label. He can’t support anyone or pay restitutions to anybody if your legal actions against him dried up the funds. You were living off him before though. I hope every last detail on the case gets out because fair is fair. If he is in fact guilty of some terrible things, then okay.

[R. KELLY CASE UPDATES](https://www.google.com/search?source=hp&ei=lbxRXYGfIob65gLzjYKIBA&q=r.+kelly+case+update&oq=r.+kelly+case+update&gs_l=psy-ab.3...81328.88472..89683...2.0..1.2644.9065.5j10j4j1j2j9-2......0....1..gws-wiz.....6..0i308i154j0i131j0j0i22i30.0ISIBVWZfIA&ved=0ahUKEwjBvcSeh_7jAhUGvVkKHfOGAEEQ4dUDCAs&uact=5)

Lhisa

### Should The Justice System Be Trying To Prosecute R. Kelly NOW, Decades Later Using Hearsay, Faulty Testimony, & Other Questionable Evidence? Scroll Down And Leave Your Reply Below.

[![1_cy8kzMmLDmPYbMyDUq-aYg](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194813335/9jQTWEYr1.jpeg align="left")](https://ferrelux666.wordpress.com/1_cy8kzmmldmpybmyduq-ayg/)

[![rkelly](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194814574/XR3pgYDN5.jpeg align="left")](https://ferrelux666.wordpress.com/rkelly/)

[![190102-zimmerman-rkelly-tease_ldtroi](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194815780/4smIboISY.jpeg align="left")](https://ferrelux666.wordpress.com/190102-zimmerman-rkelly-tease_ldtroi/)

[![r._kelly-getty-h_2019](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194817232/qWhEWU4ga.jpeg align="left")](https://ferrelux666.wordpress.com/r-_kelly-getty-h_2019/)

[![aaaliyah](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194818424/6FjqL9xeO.jpeg align="left")](https://ferrelux666.wordpress.com/aaaliyah/)

[![RKelly_AW0724](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194819484/jAsyFQ3jg.jpeg align="left")](https://ferrelux666.wordpress.com/rkelly_aw0724/)

[![c2fdfd48-5f21-48dd-88db-4f20dab30550](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194820555/Nov58oFUA.jpeg align="left")](https://ferrelux666.wordpress.com/c2fdfd48-5f21-48dd-88db-4f20dab30550/)

[![RKellyandLadyGagaat2013AmericanMusicAwards.jpg_29441870_ver1.0_640_360](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194821870/mWJ1XJvfD.jpeg align="left")](https://ferrelux666.wordpress.com/rkellyandladygagaat2013americanmusicawards-jpg_29441870_ver1-0_640_360/)

[![image](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194823361/Whe3KHlbW.jpeg align="left")](https://ferrelux666.wordpress.com/image-2/)

[![kelly+avenatti+pic+2](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194824544/sdwuuJXLP.jpeg align="left")](https://ferrelux666.wordpress.com/kellyavenattipic2/)

[![R-Kelly-and-Aaliyah](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194825865/CtrLGIt9Y.jpeg align="left")](https://ferrelux666.wordpress.com/r-kelly-and-aaliyah/)

[![CHICAGO, ILLINOIS - JUNE 06: Singer R. Kelly leaves the Leighton Criminal Courthouse on June 06, 2019 in Chicago, Illinois. The singer appeared in front of a judge to face new charges of criminal sexual abuse. (Photo by Nuccio DiNuzzo/Getty Images)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194827121/mGKxabR4L.jpeg align="left")](https://ferrelux666.wordpress.com/r-kelly-appears-in-court-after-prosecutors-add-additional-felony-charges/)

CHICAGO, ILLINOIS – JUNE 06: Singer R. Kelly leaves the Leighton Criminal Courthouse on June 06, 2019 in Chicago, Illinois. The singer appeared in front of a judge to face new charges of criminal sexual abuse. (Photo by Nuccio DiNuzzo/Getty Images)

[![r-kelly-1532369173](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194828294/cBT8DGjxk.jpeg align="left")](https://ferrelux666.wordpress.com/r-kelly-1532369173/)

[![rkelly1250](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194829829/cRNQAqLzX.jpeg align="left")](https://ferrelux666.wordpress.com/rkelly1250/)

[![r-kelly-750x](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194831320/PEG1pfdWo.jpeg align="left")](https://ferrelux666.wordpress.com/r-kelly-750x/)

[![People](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194832483/t2Iyzek8X.jpeg align="left")](https://ferrelux666.wordpress.com/people-2/)

[![Mandatory Credit: Photo by Suzanne Cordeiro/REX/Shutterstock (8468023k) R. Kelly R. Kelly in concert at Bass Concert Hall, Austin, USA - 03 Mar 2017](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194834163/HKpeZJzTA.jpeg align="left")](https://ferrelux666.wordpress.com/r-kelly-in-concert-at-bass-concert-hall-austin-usa-03-mar-2017/)

Mandatory Credit: Photo by Suzanne Cordeiro/REX/Shutterstock (8468023k) R. Kelly R. Kelly in concert at Bass Concert Hall, Austin, USA – 03 Mar 2017

[![Surviving-R.-Kelly-1-520x444](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194835738/a4LWjgnQn.png align="left")](https://ferrelux666.wordpress.com/surviving-r-kelly-1-520x444/)

[![r-kelly-prison](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194836980/ie3eXp-dT.jpeg align="left")](https://ferrelux666.wordpress.com/r-kelly-prison/)

[![rkellyteacher_cc](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194837966/Q5Z3jFUkQ.jpeg align="left")](https://ferrelux666.wordpress.com/rkellyteacher_cc/)

[![untitled (2)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194839588/o4BJNkPyX.png align="left")](https://ferrelux666.wordpress.com/untitled-2-3/)

[![untitled (3)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194841245/dVD-69WLP.png align="left")](https://ferrelux666.wordpress.com/untitled-3-5/)

[![1545024258939862015](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194843093/lYNuTsTY4.png align="left")](https://ferrelux666.wordpress.com/news/attachment/1545024258939862015/)

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/eyrcaHoKcS0?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/f7Hqmh2FTIE?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/uAXxkNaRkp8?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/GIQn8pab8Vc?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194845493/99bQpOBAn.png align="left")](https://ferrelux.com/adverts/)
