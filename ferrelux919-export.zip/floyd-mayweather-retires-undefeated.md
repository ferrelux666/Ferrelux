---
title: "\U0001F6CEFloyd Mayweather Retires Undefeated\U0001F310"
date: '2017-09-15T22:00:55.000Z'
slug: floyd-mayweather-retires-undefeated
tags:
  - sports
  - entertainment
  - boxing
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195734411/JWVE2JEk-.png
canonical: 'https://ferrelux666.wordpress.com/2017/09/15/floyd-mayweather/'
---
**  
A Victor Semper Vincit ⭐ A Winner Always Wins**

\*\*  
‘Oh it Won’t Last beyond 2 rounds’, REALLY McGregor? Where’s the ‘beautiful skull’ you wanted to add to your (Warlord) Collection, Hmmm? I knew he would lose. Floyd “Money” Mayweather fought his last fight successfully as I expected, like the champion he is with that handsome face & build. I love watching him in action.\*\* **And now I have to find another new favorite boxer to cheer on. Past ones have been: Hector “Macho” Camacho, Oscar De La Hoya, Julio Cesar Chavez, Evander Holyfield, Mike Tyson, Larry Holmes, Marvelous Marvin Hagler, Sugar Ray Leonard, Ray Mancini, & Muhammad Ali. I ‘ve also been following Manny Pacquiao, who also lost to Mayweather in a previous fight. So what now for Mayweather?**

[Mayweather 50-0 Boxing Record](https://www.sbnation.com/2017/8/27/16210396/mayweather-retires-mcgregor)  
[Put Up Or Shut Up Conor Mcgregor](https://www.theguardian.com/sport/2017/aug/27/floyd-mayweather-conor-mcgregor-boxing-fight-report)

\*\*  
The Hype Before The Fight  
\*\*

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/3JCalZgGwNs?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

A Run Down On The Fight

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/yd0dxVe8cmM?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

**Here’s McGregor Explaining His Lost. AGAIN! even if Floyd changed up his style & started beating you, You should have been prepared for game.**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/2hYVO33HbJE?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

**Why Some People Don’t Like Him (The Attitude???) This Behavior shouldn’t Be Unusual In Competition.**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/Y78dnLtq1Dk?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

\*\*More On McGregor’s Personal Life  
\*\*

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/bnzmdnrtcj4?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

\*\*And The Conflict Hype Between Them Was The Draw. Conor McGregor (29) really needed the win to take out such a Veteran boxing champion Floyd Mayweather (40), but a champion will always be a champion no matter WHAT you say, Trash Talker. Like the man said after every fight in most cases, ‘I going to beat who ever they put in front of me’. And  
you proved yourself a WINNER!  
\*\*

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/x1SHes13tjI?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

**Now Let’s Hear From The Champ!**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/xi2zRubDwbY?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195717165/huZPEOw0F.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195718591/B8zWl3O1r.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195719835/fTHuZLnwT.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195721152/wbgtK2NuL.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195722436/clkNJ4YnE.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195723912/n41ISRvYs.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195725332/KNTXQOSoA.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195727058/llHK9uQqI.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195728782/1hhc8WARQ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195729914/f4eM-CTaS.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195731414/XVo2RR_bs.png align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195732732/dIey4P6BA.png align="left")](https://ferrelux.com/adverts/)
