---
title: "I, Tonya (2017 Film) \U0001F469\U0001F3FC\U0001F3C5⛸"
date: '2018-05-05T17:18:07.000Z'
slug: i-tonya-2017-film
tags:
  - music
  - model
  - hair
  - usa
  - sports
  - trial
  - international
  - ice
  - entertainment
  - rock
  - olympics
  - america
  - investigation
  - trophy
  - portland
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195502674/jmnA6tQpk.png
canonical: 'https://ferrelux666.wordpress.com/2018/05/05/i-tonya/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195479679/J3exTWOm0.png align="left")](https://www.ferrelux.us/)

**I, Tonya……..now on Dancing With The Stars (DWTS). The 2017 Movie, ‘I Tonya’ was great & the subject matter is relatable played by award-winning actresses Margot Robbie (Tonya) & Allison Janney (The Mother). Looking back at the time period of this story, I was in my graduating year in High School & Nancy Kerrigan was the skater almost everyone was rooting for….., but side opinions count. Some people liked Tonya & her hardship all the way to The Olympics representing America as well. It was fucked up what happened to her career. There are people that can relate to her story. Not everyone fits a mold for certain industries. Does this mean that you CAN’T compete? She was breaking a lot of rules. She didn’t let poverty get in the way, nor having the standard Ice Princess look or breeding hamper her chance at success & fame. And for THAT, she was punished. She was a victim of prejudice amongst HER OWN people. They loved Nancy Kerrigan. The dark-haired beauty could do no wrong. She had the judges in her favor even if she made a mistake on the ice, as long as it was not too bad, her marks were still high. Oh well…..you poor blond bitch, we don’t care about your scrapper way of getting here to our ivy league sport, you don’t belong & we don’t like you, so we’re gonna score you a little bit lower even though you were the ONLY American Woman to land the Triple Axel in 1991 in our International sport. THAT was the general attitude that poor child had to deal with even though she had A RIGHT to be there representing not only The U.S.A, but the downtrodden & disenfranchised rest of us. THEN IT ALL WENT WRONG ONE FATEFUL DAY. The asshole/loser she married to get away from her loud-mouth & funny, but abusive mother, couldn’t leave the skating politics alone & conspired with his friend to have a cohort go to where Nancy Kerrigan was practicing & whack her on the knee, where she famously screamed out, “WHY!” It injured her ability to do well in general, in an effort for Tonya to win Olympic gold ofcourse. There are those despite the old news reports & trial in the mid to late 90s, & now the current movie 23 years later partly told from Tonya’s perspective, who still doubt her innocence. The case was federally investigated & Tonya got banned professionally from the sport & competing nationally & internationally. So now for the first time ever in public, we’re seeing her at 47 years old (still able to land a triple axel while ice-skating privately) on the TV show ‘Dancing With The Stars’ competing for the Mirabal trophy along other respected athletes. But going back to that tragic event from the past, arguably the attack on Nancy Kerrigan was not necessary at all, since Tonya WAS the better skater if you look back at the old footage. The real problem here was the skating committee/judges who discriminated against her for being poor & rock n’ roll. She liked skating to heavy metal music, she looked like a hard rock chic in her outfits & I was into that stuff too & thought at the time watching her on TV, how refreshing to see someone different out there on the ice. Nancy Kerrigan was nice skating to the classical/contemporary themes, but she looked too much like the cookie-cut standard model with how she was carefully packaged. And the people in charge of the whole thing who could have made a difference, were too ignorant & blind to that. THEY are the real ones responsible, because had Tonya been treated more fairly,…..none of it would have happened.**

**More on the film……..**  
[https://en.wikipedia.org/wiki/I,\_Tonya](https://en.wikipedia.org/wiki/I,_Tonya)  
[https://www.nytimes.com/2017/12/06/movies/i-tonya-review-margot-robbie.html  
](https://www.nytimes.com/2017/12/06/movies/i-tonya-review-margot-robbie.html)[https://www.imdb.com/title/tt5580036/awards](https://www.imdb.com/title/tt5580036/awards)

**~ Lhisa Mrklon**

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195481257/3R26C56r_.jpeg align="left")](https://ferrelux.com/adverts/)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195482977/7tXuvpqdj.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195484732/seZ4kyRO4.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195486459/SERW_IY0g.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195488427/HniVPrTAZ.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195489946/D2AeOKrcr.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195491429/Uf9oESP1A.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195492973/9NG3oVIp0.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195494785/2qnzhxPS2.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195496644/n1CDzVWuQ.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195498156/9jV0FojsW.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195500125/nhhqIKn_9.png align="left")
