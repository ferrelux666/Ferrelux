---
title: "Ex-VP, Joe Biden’s Mistake Not To Assume Power Then \U0001F6CE☁\U0001F3E2"
date: '2019-07-02T22:48:05.000Z'
slug: ex-vp-joe-bidens-mistake-not-to-assume-power-then
tags:
  - trump
  - government
  - race
  - urban
  - politics
  - election
  - america
  - biden
  - russia
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672194958377/x4PERV5gwo.jpeg
canonical: 'https://ferrelux666.wordpress.com/2019/07/02/biden/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194936765/yn2qLoejF.jpeg align="left")](https://www.ferrelux.us/)

[Rick Derringer ~ ‘Real American’](https://myspace.com/rickderringer/music/song/real-american-95420540-106302647?play=1)

*Seditio Civium Hostium Est Occasio*  😡 *Sedition of the Citizens is an Opportunity for the Enemy*

OMG, why run now? So my criticism goes all the way back to when Barack Obama ran for Presidency in 2010 and chose then Senator, Joe Biden as his Vice President. At the time, my instincts found that choice questionable. I was expecting someone that made more sense, and not Hillary Clinton or Bernie Sanders. And since people were celebrating it as a successful ticket, I kept my fingers crossed and hoped no problem came of it. Race-Readers were seeing Obama’s move in choosing Biden as a cover, since it would calm down racial tensions if they saw a white male there with him. Somewhere in my head I didn’t think he needed him. Now look, about 6-8 years towards the end of the Obama Administration, I’m seeing my suspicions about Biden were right. The time to run for President was right under Barack to win the succession of power. That’s how it’s done. Only somebody better at the time could beat you. When I saw this ridiculous campaign going along to setup Hillary as the 2016 Candidate, THAT was questionable. It wasn’t necessary. She was there before. That was a problem for many Voters. And before you say, the Russians would have made Trump win anyway, entertain this, were they interfering before? When they saw a circus in your politics and thought about it, THAT was an opportunity to fuck with it. Had the system went the way it should, Russian interference wouldn’t have happened. I blame Joe Biden for all that went wrong and still, with our politics now. His excuse at the time was his dead son, personal/familial issues and so on. Hmmm……. In ancient times if you were Caesar, a Greek Ruler, Pharoah, Asian Emperor, or other Leader, and you were dealing with treachery all around you and death of those close to you, you got your act together and fight back and maintain your kingdom. So I’m thinking the real reason here is to separate himself from Obama and his policies, especially when he went a few weeks ago to tell his ‘friend’ publicly to not endorse him so he can win it on his own. I knew this guy was suspect and to this day many people are still absorbing his bullshit. So now, he expects to win against other capable Democrats, and succeed over an already sitting President. Why this puts him where he was before Obama in the wee political past when he lost running on his own. His best chance was a VP ascending to the corporate throne right after Obama like the Republicans did in the past, but that little mistake showed me how dumb Democrats are, because you had the helm and you let feminism and other stupidness get in the way of something practical. That’s why you see the rattiness and teamwork of Republicans winning seats in the Judiciary branch, and the Senate, and watch them recover the House of Representatives again, because they are not playing with ya’ll. YES, there are problems with them ‘handling’ Trump from the get go, BUT they’re in power now. Do you really think they are just going to give that up? All they have to do, is deal with a Motherfucker, and quickly work to re-instate Republican policies and derail/dismantle Democratic values. WHY??? WELL, somebody name Joe Biden could have stopped it, but failed to do a critical move at the time that would have kept all this shit we’re seeing right now at bay. Had Russia seen a normalcy, an interest in pimping a Candidate would not have been there. Now the Ex-Vice President, so-called forerunner, is openly being attacked, disrespected by fellow Democrats and they have a right to. He got in it with Cory Booker and Kamala Harris over the race thing both times in recent debates. Hmmm, is a circus happening again? I don’t blame Trump behaving the way he is. He’s doing the right Republican move. Oh, I’m up here as President of the United States of America. See me make a trip overseas talking to Dignitaries, other World Leaders and so on. Who are you? I’m not worried! He can keep doing that. If you Democrats don’t get it together, you’re gonna lose.

Lhisa,  
Agent of Fortune

### Should Barack Obama Had Chosen Joe Biden To Be His VP In the First Place? Scroll Down And Leave Your Reply Below.

[![_95445823_hi038828658](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194938272/w1iCXbR5W.jpeg align="left")](https://ferrelux666.wordpress.com/_95445823_hi038828658/)

[![858753532.0](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194939664/XXx8IKZ8u.jpeg align="left")](https://ferrelux666.wordpress.com/858753532-0/)

[![2019_0628-joe-biden-1200x800](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194940897/jnepkdMpg.jpeg align="left")](https://ferrelux666.wordpress.com/2019_0628-joe-biden-1200x800/)

[![85](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194941827/bJLYOpFWx.jpeg align="left")](https://ferrelux666.wordpress.com/85/)

[![1_i4me0lP-oEIeThpaYtKwFQ](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194942958/GygNzVrJr.jpeg align="left")](https://ferrelux666.wordpress.com/1_i4me0lp-oeiethpaytkwfq/)

[![01-trump-flag.w1200.h1200](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194944245/ZaT9e5AP9.jpeg align="left")](https://ferrelux666.wordpress.com/01-trump-flag-w1200-h1200/)

[![cory-booker](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194945451/6fz8FAKBg.jpeg align="left")](https://ferrelux666.wordpress.com/cory-booker/)

[![flickr-klobuchar-hillary-rally-oct-2016](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194946660/9W6jZ91r0.jpeg align="left")](https://ferrelux666.wordpress.com/flickr-klobuchar-hillary-rally-oct-2016/)

[![hickenlooper-close](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194947702/7iNao0rVm.jpeg align="left")](https://ferrelux666.wordpress.com/hickenlooper-close/)

[![GettyImages_954798126.0](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194948766/eU9F3qqq1.jpeg align="left")](https://ferrelux666.wordpress.com/gettyimages_954798126-0/)

[![Michelle-Obama-Purple-Suit-2019](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194949888/dYy8VDTFr.jpeg align="left")](https://ferrelux666.wordpress.com/michelle-obama-purple-suit-2019/)

[![MBaqSY2M](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194951187/v2rV_1BDt.jpeg align="left")](https://ferrelux666.wordpress.com/mbaqsy2m/)

[![527303762.jpg.0](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194952327/mm2cPxA_K.jpeg align="left")](https://ferrelux666.wordpress.com/527303762-jpg-0/)

[![trumpshutdownraises](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194953468/3A1UWkSipU.jpeg align="left")](https://ferrelux666.wordpress.com/trumpshutdownraises/)

[![Ferrelux Homepage_Biden-July2019](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194954769/P6_6XEnmU.png align="left")](https://ferrelux666.wordpress.com/ferrelux-homepage_biden-july2019/)

[![2695ab3b5b91d0d3b6c380.62883974-AR_1_-512](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194955883/n7jcSDfULK.jpeg align="left")](https://ferrelux666.wordpress.com/news/2695ab3b5b91d0d3b6c380-62883974-ar_1_-512/)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194957056/VXbh7TAIA.jpeg align="left")](https://ferrelux.com/adverts/)
