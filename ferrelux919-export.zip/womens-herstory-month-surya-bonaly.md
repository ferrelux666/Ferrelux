---
title: Women's Herstory Month ⛸️ Surya Bonaly
date: '2025-03-22T02:53:18.937Z'
slug: womens-herstory-month-surya-bonaly
tags:
  - ice-skater
  - figure-skating
  - olympiad
  - march
  - '2025'
  - black-women-empowerment
  - france
  - sports
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1742611885450/d5099ad6-631a-459e-8e30-3e8fb65059b0.webp
---
Phrase Coming Soon

🎵 [**O Fortuna & Fortuna Plango Vulnera (Carl Orff’s Carmina Burana)**](https://www.youtube.com/watch?v=AP_CSQgBPpQ) **🎶**

***These 2 songs are among my favorite Opera tracks and I chose them here because visually in my mind, they would be great for a Gymnast or Figure Skater to use in telling a dramatic story, and ofcourse in occult context for my purposes here, someone name Surya Bonaly fits the musical concept as it talks about godly things where Fortune is concerned, dancing between doom and happiness. Surya signifies a Hindu Sun God who is powerful and a Bonaly is derived from a Scottish Gaelic terms meaning, the pool at the bottom of a shallow place. So you see the imagery here, and there’s more. Her middle names are Varuna and Claudine, well, Varuna is a Hindu Deity of The Cosmic Ocean, and Claudine is derived from the Roman Emperor Claudius, where the word means lame or crippled due to his condition but he was an effective enough Ruler and not really depicted as so. So the imagery here is a Fallen and hurt Deity who once ruled over Something. And there’s more, her being at the Olympics in Nagano, Japan is significant as a NAGA in African, Asian & East Indian Cultures refers to Powerful Inter-Dimensional Serpent Beings among Us. So when you see me set up these articles a certain way, ha ha, there is more to it reading the next one forward or previous to the present one to gain the sense of it. . . . . . . Look, I know when I posted this Surya Bonaly article, Ya’ll failed to get the symbolism at first with all that time to figure it out, otherwise you would have related to it WHY I have to explain it now. And ofcourse there is an overall theme of Air & Water playing out as a subtext in these articles. I don’t mean to toot my own Horn BUT I knew this went above your heads. This is why you leave Occult stuff like this to Masters like Myself to come up with rich content like this. I do it better than you ahmm, so-called Enlightened Ones, ha ha ha.***

So for 2025, the Phenomenal Female being showcased is an under-rated **French Olympic Ice Skater** named **Surya Bonaly**. A most deserving and accomplished young Woman. I followed her athletic progress many years back in her heyday, as a Black Skater out there on The Ice being disrespected by a nasty All-White set of Judges which prejudices extending to their own Fair-Skinned Skaters who did not fit a certain Profile to score too high at the time, even though they skated well like we saw they did to **Tonya Harding** since they favored the other American, **Nancy Kerrigan** and Others. Well Surya had a nice upbringing though she was a young African Girl who was adopted by her White French Mother. The racism in that Sport was noticeable and to some degree still is, many years later. She never got her Props or Flowers when it mattered from that Committee. She proved Her Black Self to be the only One in ALL OLYMPIC HISTORY to have the ability to skate that well throughout her career at such feats. NO ONE, male or female was able to beat her highly technical moves to this day. You see Black People are not supposed to do that well. ICE SPORTS and the like are supposed to be an area where White People excelled, which made it all the more interesting.

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1743483883790/e2726d56-34bb-4944-b499-8ca25c2728a0.jpeg align="center")](https://medium.com/@blueknightgirl75/queens-of-the-ice-surya-bonaly-dde35b4c350e)

Hey Folks, it’s **Monday March 31<sup>st</sup> 2025**, and Women’s Herstory Month for me this year will extend into part of April before returning back to particular discussions as I am keeping abreast of all those global topics and am currently reserving my perceptions of such issues till it’s time for me to furnish my opinions. Also, I’ve been awfully busy these past weeks with my Personal Life, including working on behind-the-scenes technical stuff surrounding appendages I seek to add to my websites with thorough testing for scalability to improve what I currently offer in The Marketplace as well as perusing possible alternatives for The Community as certain features I desire are not yet forthcoming on my current Platform to enable additional functionality for engagement, which I made suggestions for. I also have been submitting for Gigs, and going out on Productions where The Acting Side of my Life is concerned to be visible in these taped footage, appearing on very Popular Shows to be recognizable in some scenes, surprising those of you in the know, who happen to notice watching and wondering if that’s me, and you know where to find some of that material. I now have some down time to continue with this since its original post 10 days ago. So here goes . . .

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1743485863893/27cdb0c5-459a-4aca-ae5c-1831ad1d85ca.jpeg align="center")](https://www.olympics.com/en/athletes/surya-bonaly)

So Surya was incredible on Ice. Her Power, Her Strength, Tenacity, and Endurance. The way she moved was electrifying. Majestic. Truly an inspiration to young Black Figure Skaters. And ofcourse this came with prejudice among certain Judges more finding fault with her skin-tone than any real flaw in her technique to be scoring her low in favor of Whiter-Skinned Skaters, but she remained in The Sport showing up in future Olympics. Now we all saw it. She was the better Skater. Let’s be real. The only one among them who mastered doing a Back Flip, though the move was considered too dangerous for Skaters to do and was banned. What it came down to was her proving that since whatever hand gestures, grace and so forth she made further improvements on and it still didn’t matter, she vigorously went to show that she did not care anymore after cussing at them showing her indignation and ofcourse this raw move was much appreciated by her Fans. The Judges needed to be told off. So she began incorporating these high-level death defying stunts, performing them so effortlessly across The Ice showing that she can outdo any Caucasian or Asian Skater out there since it came down to that. None of them could compete. She was exciting to look at with the bold fashion. The Soul of Africa, dominating. It became more about letting Our Presence be known in such a carefully racist Sport where The World saw that even skating on Ice by European Standards, we excelled.

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1744707104681/bad749f3-599b-416f-9e4f-60b811e80d52.jpeg align="center")](https://www.oneyoungworld.com/counsellors/surya-bonaly)

Finally, today is **Tuesday April 15th 2025**, and it had been fifteen days since my last post and like I stated earlier in that section, in addition to all that, I am still working on my own stuff and can present a re-vamped [Ferrelux Marketplace](https://ferrelux.biz/) **&** [Lhisa Boutique](https://lhisa.biz/) for your perusal. I also worked on a new podcast video to present later. I’m just trying to wrap this article up right now, and why sometimes pieces like this get interrupted sometimes like this when I fully intended to run a special feature as you’ll notice in some prior articles is that I am heavily being targeted and censored by some Forces who would look at a lovely innocent work like this and insanely bug out. And what I am simply revealing are my own thoughts. My perspectives on certain topics tend to pan out. While Some are inspired by this, Others are either jealous or fearful, which brings me back to this topic about **Surya Bonaly** as in such cases I tend to eventually incorporate these problems into my writings as my Audience following over the many years and knowing certain things can tell. I pick particular things to showcase and talk about at times as they also fit into my crisis. I can relate to this young lady as I did growing up years ago under less pressure. Being The Sole Black out there noticeably accomplishing something, but is being held back by The System, to the point where it looks like what it looks like, racism and in some cases sexism, classism, and agism. These concerns still affected me and many others like me moving forward but despite that, we shined through. She was an example of that back then fighting back by proving her unmatched skill and strength in The Sport, being a Black Queen. **The Silver Medals** she won should have been **Gold Ones**. The ones Judging these Athletes had a bigoted perception in their heads about who should be doing that Sport, how he or she should look, their breeding and so on that even affected their own White Person at the time, namely Tonya Harding who might not have realized that she too was in the same discriminatory category as Surya. They liked Nancy Kerrigan and Christina Yamaguchi and others. And they were great Skaters, but a Sporting Competition should be fair though. When you are being ignored and disrespected like that by that Industry, Millions see it and they they also see what THEY are trying to hide or downplay concerning that person. So it becomes political. France did not send some White Girl out there. As “racist” as France and other Countries are said to be in comparison to America, there are certain giveaways that suggest otherwise. I even experienced that in some cases growing up, being exposed to other Foreign Groups that were said to be Bigots, only to meet persons among them along the way in life who treated me rather well. And back to her case, when viewing some of the below videos, and other ones you might come across, you’ll notice which Judge of these Foreign Countries graded her a little higher than the Others. Notice how the so-called lesser racist and diverse Countries graded her. And so one might argue, that they have their favorites and scoring her low has more to do with wanting this other person to win, but that’s not fair though. Giving them 7, 8, 9, or 10 is favorable even when they did not execute their routine that well in some cases. No matter how beautifully Surya skated, she got 4, 5, and barely scoring a solid 6. That’s Rude. They would not have done that to a White Girl barely proficient at Skating. So to prove something, Surya learned how to do a back flip while skating on ice, landing on both legs ofcourse as that was an expected standard. The move was first done in The **Olympics** back in **1976** by a White Male Figure Skater, name **Terry Kubicka**. Since then such a daring and life threatening skill was deemed not necessary to be required to do for The Sport and therefor banned. When you’re in competition and see the writing on the wall, it’s not about winning anymore, but more about unprecedented showmanship. Like, what can I do to forever place a stamp on history about my greatness. And there it was, not just landing a death-defying backflip so many times landing safely on the 2 legs but going further to show that she could also do it, landing from that momentum on one leg and was the only Skater in her time to have done that. So in 2024, nearly 50 years, The Olympics are now making it legal again to work a backflip into a figure skating routine for points. Surely a difficult maneuver like that should get you a 10 if you are White doing it, especially. Surya mastered it back then and the Judges acted like it was not impressive when we all clearly saw it was. Other Male Skaters who did the move in recent years were, [**Adam Siao Him Fa**](https://www.youtube.com/watch?v=_R7Cq2Nz8x0) (France) in March 2024 & [**Ilia Malinin**](https://www.youtube.com/watch?v=idD2z48_iQY) (USA) in October 2024, but let’s head back to the past, specifically in 1992 where there was a guy name [Scott Hamilton](https://www.youtube.com/watch?v=Uj5RAbbzrAg) (USA) who had a lot of energy and regularly worked a backflip into his figure skating routines, sometimes doing it twice within the same Program, as Surya did.

❄️ **Her light skating back in 1991.**

%[https://www.youtube.com/watch?v=6FiJF-gDaDE] 

❄️ **This is her Figure Skating back in 1991**

%[https://www.youtube.com/watch?v=6e_X0aFLWCg] 

❄️ **This was her back in 1992 with the one early fall, but skated beautifully otherwise. (see below)**

%[https://www.youtube.com/watch?v=lrqZQsVCIXQ] 

❄️ **Here she is at that same Albertville Olympics, doing the one stunning back flip. (see below)**

%[https://www.youtube.com/watch?v=8io08qHg1MU] 

❄️ **Here she is in 1993**

%[https://www.youtube.com/watch?v=KaCaOQwAZuY] 

❄️ **And Another**

%[https://www.youtube.com/watch?v=quCIaKEbmAU] 

**❄️ Here she is in 1994, even with the slight mistake, she quickly recovered and finished her complex routine yet The Commentators like casting doubt though her skill on the ice is Masterful.**

%[https://www.youtube.com/watch?v=fexLmuu4mlI] 

❄️ **In the this one below, she skated even better and got the credit she deserved but remember throughout this competition this young lady got robbed of the Gold Medals she truly deserved at the time due to them favoring other Skaters.**

%[https://www.youtube.com/watch?v=AOkGmPdIAO8] 

Sign,  
Lhisa Mrklon  
#183
