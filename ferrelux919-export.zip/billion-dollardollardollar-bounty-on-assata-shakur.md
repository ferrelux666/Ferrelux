---
title: "\U0001F626 Billion $$$ Bounty On Assata Shakur \U0001F632"
date: '2013-05-29T08:35:36.000Z'
slug: billion-dollardollardollar-bounty-on-assata-shakur
tags:
  - hate
  - escape
  - human-rights
  - black
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672196139094/iRSQ_JkG9.jpeg
canonical: 'https://ferrelux666.wordpress.com/2013/05/29/assata-shakur/'
---
![Assata Shakur Art](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196133511/eSl18fSB9.png align="left")

**This is disgraceful. Hunting down a poor defenseless Black female for a crime she was proven to obviously not have committed. After reading into the facts of the case she was tried for, I concluded that Zayd most likely is the one who fired the shot that killed the officer since he was being aggressive. It would make sense if he ended up dead, right? And Sundiata Acoli should have been released a long time ago, but they value the life of that racist cop so much who had no right stopping them on that highway unless he was sent to harass them most likely, which is a common practice being that they were freedom fighters why they have him serving a double sentence in a way since Assata escaped. I also question her safety in Cuba now since Castro being advanced in years & sick, is about to expire & his brother may change the regime to more American friendly policies. When Jay-Z & Beyonce, being so close to the Obama headed over there, that made me wonder. I vaguely remember some article I saw about Assata either secretly meeting with Obama without threat of arrest on behalf of petitioning to free her friend Sundiata Acoli or her handlers/supporters doing this. Well, given the turn of events, it never worked out favorably. Sundiata may have his earliest parole hearing (again) shortened from 10 years to 3 now, BUT New Jersey cops continue to keep up their hate against Assata, blindly insisting on her being a culprit in the death of their comrade when it was proven she had already been shot in the arm from behind by the dead cops partner. What the FBI did now was create a situation escalating this old case to inspire some misguided desperate soul to attempt to inform leading to her capture since several folks out there must know who she is & where she is. I sincerely hope that the good nature in people wins out.**

**~ Lhisa**

[![Assata Shakur In Custody](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196135408/fhOMvvKHT.jpeg align="left")](https://ferrelux666.wordpress.com/assata-shakur-in-custody/)

[![Assata Shakur, Mural](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196136510/YhA4UOdc-.jpeg align="left")](https://ferrelux666.wordpress.com/assata-shakur-mural/)

[![Assata Shakur, Braids](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196137783/gSHrIkbV_.jpeg align="left")](https://ferrelux666.wordpress.com/assata-shakur-braids/)

**READ ARTICLES**  
***Sign Petition*** – [https://www.change.org/petitio…nted-terrorists-list](https://www.change.org/petitio...nted-terrorists-list)  
[http://blackademics.org/2009/0…adite-assata-shakur/](http://blackademics.org/2009/0...adite-assata-shakur/)  
[http://portside.org/2013-05-15…erning-assata-shakur](http://portside.org/2013-05-15...erning-assata-shakur)  
[http://www.globalresearch.ca/o…of-terrorism/5334405](http://www.globalresearch.ca/o...of-terrorism/5334405)  
[http://www.assatashakur.org/cleaver\_k.htm](http://www.assatashakur.org/cleaver_k.htm)  
[http://www.afrocubaweb.com/assata.htm](http://www.afrocubaweb.com/assata.htm)  
[http://www.sundiataacoli.org/](http://www.sundiataacoli.org/)  
[http://kersplebedeb.com/posts/…age-73-ten-year-hit/](http://kersplebedeb.com/posts/...age-73-ten-year-hit/)  
[http://prisonradio.wordpress.c…up-for-parole-again/](http://prisonradio.wordpress.c...up-for-parole-again/)
