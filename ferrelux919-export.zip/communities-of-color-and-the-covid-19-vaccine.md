---
title: "Communities Of Color & The Covid-19 Vaccine \U0001F912\U0001F927\U0001F637"
date: '2021-02-22T02:07:14.000Z'
slug: communities-of-color-and-the-covid-19-vaccine
tags:
  - experiment
  - community
  - light
  - money
  - health
  - magic
  - government
  - energy
  - hospital
  - pandemic
  - covid-19
  - race
  - coronavirus
  - crime
  - american
  - politics
  - vaccine
  - cdc
  - genetics
  - biden
  - commercial
  - black
  - city
  - population
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672193347997/P60Q3fCfy.jpeg
canonical: 'https://ferrelux666.wordpress.com/2021/02/21/covid19-vaccine/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193319726/qBEufIrc9.jpeg align="left")](https://www.bethewaie.org/film/real-magic-of-melanin/#:~:text=The%20REAL%20Magic%20of%20Melanin%20is%20the%20benefits,All%20Black%20people%20have%20an%20abundance%20of%20melanin.)

\*\*  
[Ray Charles – “I Don’t Need No Doctor”](https://www.youtube.com/watch?v=ViMzB8rWsOQ)  
[W.A.S.P – “I Don’t Need No Doctor”](https://www.youtube.com/watch?v=_JIWzrRMoQY)  
\*\*

Vivere Populi Mei 🚑 Live On, My People

President Joe Biden made a slip up the other day, people have been teasing him about when he said that Blacks in rural areas don’t know how to use the computer to get on the internet to know where the vaccination cites are. Hmm, that came out wrong. We know how to use computers Joe and it’s not just the rural areas. The real problem here is the lack of convenient access to numerous, affordable and adequate internet service providers in our towns & cities mainly due to a racist agenda to keep certain Communities of Color impoverished from competing with fully sourced White ones, despite the educated persons here with their available talents, the cultural resources, and general commercial & political interest in these communities. So The American Government has been pushing this interest for Black people to receive the Corona Virus Vaccine as if they really care about us. Truth be told, no Conscious thinking Black person knowing and studying our history really trusts The System, especially when it appears to be specifically targeting us. We don’t know what’s in the drug or what your true intention is. It might be a drug designed to interfere with our divine melanin benefits. Or, it might be a medicine meant to induce gay behavior you’re trying to get people across the globe to take since The Democratic Party promotes a gay lifestyle. What do you care if Black People die? Go vaccinate your own. If there’s really a disease out there, then as a race of Caucasoid people that can easily be bred out of existence over time if you’re not careful, you should want to vaccinate your own first, right? I’m not concerned too much that vaccines aren’t reaching Black people. Do you know that as a dark-skinned people, we’ve survived through the eons of years on the planet some of the most deadliest diseases known to Man? Many astute Doctors & Scientist will argue that a man-made substance introduced to an otherwise healthy body can interfere with its natural ability to maintain itself. This is no different from a person of any race who has been operating normally without an illness, then all of a sudden he/she was conned into getting a Flu shot, and their system got out of whack with the person falling ill because of it. Also some of the side-effects in many medications are more dangerous than the illness itself. Some news sources out there have even reported some people already dying from that Covid-19 vaccine. The Human Body, equipped with the natural minerals & nutrients it requires to fend off illnesses coupled with a vigorous spirit, sound mind, & adequate rest is all it needs. I’ve not had a problem throughout all this pandemic. And I still see many of the same Niggers around me in my neighborhood moving about just fine. I don’t know what millions of dead Colored people dying from Covid-19 you’re talking about. Also, a lot of this has to do with mind over matter. Our genetics as a Primordial people is more than equipped to deal with any germ or virus on its own. We don’t need you.

Lhisa,  
The Ever Living Goddess

### Do You Trust Getting The Covid-19 Vaccine? Scroll Down And Leave Your Reply Below.

[![Ferrelux Homepage_Blacks & Covid-19](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193321330/72reRLaaX.jpeg align="left")](https://ferrelux666.wordpress.com/ferrelux-homepage_blacks-covid-19/)

[![Random Masked Persons, Coronavirus In Communities Of Color](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193322825/ZvatZbYwp.jpeg align="left")](https://ferrelux666.wordpress.com/random-masked-persons-coronavirus-in-communities-of-color/)

[![NYC Vaccine For All Campaign](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193324811/4q0Pyl07v.png align="left")](https://ferrelux666.wordpress.com/nyc-vaccine-for-all-campaign/)

[![NY Covid-19 Vaccine Campaign](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193326484/HcxujvJfS.png align="left")](https://ferrelux666.wordpress.com/ny-covid-19-vaccine-campaign/)

[![Masked People Living In Communities Of Color](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193327859/1t2yrSWQ0.jpeg align="left")](https://ferrelux666.wordpress.com/masked-people-living-in-communities-of-color/)

[![Featured Women Holding Black Power Fist Papers](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193329072/1Su8tteE4.jpeg align="left")](https://ferrelux666.wordpress.com/featured-women-holding-black-power-fist-papers/)

[![Covid-19 Vaccine Racial Disparity](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193330413/uUDmVpfs4.jpeg align="left")](https://ferrelux666.wordpress.com/news/covid-19-vaccine-racial-disparity/)

[![COVID-19 Update art](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193331707/avrAqn6R_.jpeg align="left")](https://ferrelux666.wordpress.com/covid-19-update-art/)

[![Coronavirus Covid-19 DNA Art](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193333335/XfH2f9iO-.png align="left")](https://ferrelux666.wordpress.com/coronavirus-covid-19-dna-art/)

[![Coronavirus COVID-19 Cell Art](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193334991/Lmtdd1NnA.jpeg align="left")](https://ferrelux666.wordpress.com/coronavirus-covid-19-cell-art/)

[![Corona Virus Food Line In Brooklyn](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193336405/yHeE5Gg_jx.jpeg align="left")](https://ferrelux666.wordpress.com/corona-virus-food-line-in-brooklyn/)

[![U.S. President-elect Joe Biden adjusts his face mask as he speaks about his plan to administer coronavirus disease (COVID-19) vaccines to the U.S. population during a news conference at Biden's transition headquarters in Wilmington, Delaware, U.S., January 15, 2021. REUTERS/Kevin Lamarque TPX IMAGES OF THE DAY](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193338214/gobkUKZRG.jpeg align="left")](https://ferrelux666.wordpress.com/u-s-president-elect-joe-biden-speaks-about-plans-to-vaccinate-the-u-s-population-during-news-conference-in-wilmington-delaware/)

U.S. President-elect Joe Biden adjusts his face mask as he speaks about his plan to administer coronavirus disease (COVID-19) vaccines to the U.S. population during a news conference at Biden’s transition headquarters in Wilmington, Delaware, U.S., January 15, 2021. REUTERS/Kevin Lamarque TPX IMAGES OF THE DAY

[![Biden, Masked Up, Out & About](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193339563/OvoMoerW2.jpeg align="left")](https://ferrelux666.wordpress.com/biden-masked-up-out-about/)

[![Biden With Some Executive Orders To Sign](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193340848/6_c3Zwd_T.jpeg align="left")](https://ferrelux666.wordpress.com/biden-with-some-executive-orders-to-sign/)

[![Biden Masked And Signing Executive Orders](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193342378/2VJ9w0STX.jpeg align="left")](https://ferrelux666.wordpress.com/biden-masked-and-signing-executive-orders/)

[![Democratic U.S. presidential candidate and former Vice President Joe Biden and his wife Jill visit the War Memorial Plaza during Memorial Day, amid the outbreak of the coronavirus disease (COVID-19), in New Castle, Delaware, U.S. May 25, 2020. REUTERS/Carlos Barria](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193343855/pQ_-FCbbD.jpeg align="left")](https://ferrelux666.wordpress.com/joe-biden-visits-new-castle-delaware-during-memorial-day/)

Democratic U.S. presidential candidate and former Vice President Joe Biden and his wife Jill visit the War Memorial Plaza during Memorial Day, amid the outbreak of the coronavirus disease (COVID-19), in New Castle, Delaware, U.S. May 25, 2020. REUTERS/Carlos Barria

[![A George Floyd Vigil](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193345178/Qfxlrr9NC.jpeg align="left")](https://ferrelux666.wordpress.com/a-george-floyd-vigil/)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193346405/-Wpl3eCF3.jpeg align="left")](https://www.discovercars.com/?a_aid=Ferrelux)
