---
title: "\U0001F5FBCelebrating Black Achievement\U0001F3F4"
date: '2022-02-07T00:28:24.000Z'
slug: celebrating-black-achievement
tags:
  - communities
  - business
  - youtube
  - gmail
  - women
  - kids
  - society
  - usa
  - government
  - politics
  - children
  - united-states
  - god
  - america
  - google-workspace
  - morality
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672192090879/u2CQyJh1L.jpeg
canonical: 'https://ferrelux666.wordpress.com/2022/02/06/black-history-2022/'
---
[![Colin Powell, Inspiration](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192052224/ggThwovFD.png align="left")](https://rumble.com/search/video?q=Black%20History%20Month)

[![Desmond Tutu, On Jews  Arabs](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192054568/ntsX5t0I8.jpeg align="left")](https://rumble.com/search/video?q=Black%20History%20Month)

  

[![A Young And Promising Sydney Protier](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192055781/tTJj936-t.png align="left")](https://rumble.com/search/video?q=Black%20History%20Month)

<iframe width="100%" height="100" src="https://w.soundcloud.com/player/?url=https%3A%2F%2Fapi.soundcloud.com%2Ftracks%2F18509022&auto_play=false&hide_related=false&visual=true&show_comments=true&show_user=true&show_reposts=false&color=ff5500"></iframe>

[co0lk1d DimGhim](https://soundcloud.com/co0lk1d) · [Dizzy Gillespie – Rich сool](https://soundcloud.com/co0lk1d/dizzy-gillespie-rich-ool)

Semper Habebat Facultatem Dicere No, Ut Quam Vocavi Meae Offa ♟ I always had the ability to say no, that’s how I called my own shots (Sidney Poitier)

*Let me first preface by saying that my Black Struggle continues against some forces working against my operation. One of them is Google/Youtube, who despite the pending lawsuits in 36 states, they’re still engaged in monopolous activities targeting certain people and/or businesses, especially if you have Conservative views. This also particularly hurts Blacks who are not aligned with their agenda. Are you using Google products where all of a sudden you notice a few strange things happening whether you are on Youtube or using Gmail? Well, you are being watched and interfered with by some unscrupulous people who work for them behind the scenes. I would think if you are a savvy tech giant, you could stop so-called foreign powers hijacking your site, but what gives it away that it is ALL YOU, is your behavior. I caution people to stop re-directing your audience to them and look at some other services offering a competitive service or product. If you are a professional company, you don’t engage in dishonest services, by singling out somebody or company with the purpose of marginalizing them in your search engine all of a sudden, using old cache files, and daily cyber manipulations. If the person or company was unpopular, you certainly wouldn’t be moved on a daily bases to try to injure them especially when he or she did absolutely nothing to you. My views and ad campaigns still remain unchanged, and like any other American, I have the inalienable Constitutional Right to the pursuit of Happiness.*

For this year’s Black History Month, in context of what’s going on now in society, let’s take on a couple of current event topics that the general public is complaining about to examine some of the issues as to why that it. You hear Bill O’Reilly, Tucker, Judge Jeanine Pirro, Laura Ingraham, Tomi Lahren and others complaining about the societal conditions with the crime and homelessness. Well, it was not like that before, even under The Democrat Rule of Yester-years. So why is it happening now? Well over the process of time due to unfair policies and prejudice, something like this would develop. There are no opportunities anymore. I remembered growing up where there was always some program or funding for Scholars or other talented people to get involved in that was based of grades, skill or merit which you were entitled to. So you applied, and your life was on a fast-track to success. The dumber kids in life also had something in those days. If they were less gifted, they were still buffered within that safe environment amongst the better ones and seeing them as an example to thrive towards. That barely exists anymore. With the social promotion of lower-class values, and parading them in front of everybody, why would you need to learn to read & write properly or speak correctly? Dropping the standards is a regular thing now. It leaves people with far less to strive for if they can just let their life fall by the wayside due to a lack of opportunity to turn their situation around. If you are promoting Stripper Sally into the upper echelons of Society where she can easily gain access to quality of life spaces once reserved for The Dignified, then something is wrong. You don’t see the Jacqueline Kennedy Onassis types anymore, we’re now seeing Stormy Daniels and others. A proper Gentleman can’t even thrive as much in Today’s time, due to the thug-life mentality being coddled by society as the new way to progress. Remember the time way back, when we saw Mobsters, how well dressed they were and articulate compared to the hoodlums of now. Well, we lost something. So this breakdown over a period of time would lead to Crackheads in the streets in Brentwood and other coveted places to live, because the values changed. Even the disenfranchised loose women back in the day, was still classier than Today’s Broads, just watch the old movies. Given an opportunity, she bettered herself. These handout programs tailored for dope-fiends and other unsavory types isn’t helping their mindset. Why get off drugs, when you’re rewarded more for being on it? Why practice chastity when being promiscuous gets the doors of society open to you? You now have flagrant same-sex couples advertising their way of life. You’ll soon see another drop in sanity when they start demanding a law to drop the legal age of sexual consent to 13 so they can gain legal  access to having sex with kids. At this rate, it’ll be all over soon and mankind will need to be reset by The Creator, and start again.

**Another topic to explore is** The Black Struggle Itself and where that is now locally in your neighborhoods. Why has the term **“Woke”** suddenly appeared in the lexicon of the current affairs. Well, if those Journalists were smart instead of blindly going along with it, then they would have done some research which led to small populations of Black Commentators on Youtube who were exclusively discussing Black Issues amongst their Peers and the term “Woke” came from an old phrase, **‘Are You Woke?’** which meant, are you awake, and cognoscente of the racial issues affecting you as a Black Person in Society. So how did it get out into White Society, being mis-used. Well you all should know this already, nothing has changed since the **1960s** on the tactics involved by The Government spying on Black Communities, and mi-interpreting stuff or hijacking their vernacular. Now I have more to say on this topic in the future, but for now, let me briefly state that when things are handled better, certain issues don’t find their way up in places they don’t belong.

**\_***Now let’s take a look at 3 individuals who recently passed away with legacies to remember.***\_**

**Desmond Tutu, Arch Bishop**

Back in the day, I grew up watching this man speak on the apartheid issues in South Africa. The footage of pain, suffering, poverty and bigotry were extreme. He was always there with Winnie and Nelson Mandela pleading and fighting The Government for change. He is surely one of the pillars who valiantly fought The System and he will not be forgotten.

[https://www.facebook.com/bbcnews/videos/1352932208501476](https://www.facebook.com/bbcnews/videos/1352932208501476)

[https://rumble.com/search/video?q=Desmond%20Tutu](https://rumble.com/search/video?q=Desmond%20Tutu)

**Sidney Poitier, Actor**

‘To Sir With Love’, is right. He was a Gentleman with profound intellect and wisdom, representing our people well, taking on movie roles which showed insight into The Black Struggle, and the triumph through it all. He will surely be missed.

[https://www.mtpr.org/2022-01-13/sidney-poitier-actor-activist-and-trailblazing-heartthrob](https://www.mtpr.org/2022-01-13/sidney-poitier-actor-activist-and-trailblazing-heartthrob)

[https://www.facebook.com/attn/videos/sidney-poitier/231756022497157/](https://www.facebook.com/attn/videos/sidney-poitier/231756022497157/)

**General Colin Powell**

This man was exemplary. I’m also proud of his achievement. Sometimes when things seem bleak in your road in life, with sketchy chances for opportunity, one can look at his triumph as a Black Man through that, and how he carried himself to reach such a status of dignity and honor.  
Rest In Peace, Soldier!

[https://www.facebook.com/13abc/videos/live-colin-powell-funeral/996083844285886/](https://www.facebook.com/13abc/videos/live-colin-powell-funeral/996083844285886/)

**Sign,**  
**Lhisa Mrklon**

**Is Your Quality Of Life As A Black Person Better Off Now Than It Was 30 Years Ago? Scroll Down And Leave Your Reply Below.**

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192057388/IMwwaQPBv.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192059148/rSDGm7Rlz.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192060709/30CKdirKT.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192061990/AOM3qi0Zi.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192063549/_WRkPaRkW.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192064836/9fdL6q3pj.jpeg align="left")

Major General Colin L. Powell, USA (uncovered)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192066220/IeIA-uuUQ.jpeg align="left")

General Colin Powell, (USA), (uncovered).

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192067952/SEF8oDV71.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192069680/mSOqeN2m5.jpeg align="left")

General Colin Powell

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192071382/IUglxkEGJ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192072649/YMnSyMC07.jpeg align="left")

Generated by IJG JPEG Library

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192074314/eE_LiwO22.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192075684/b7HFjDJCw.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192076850/HqHT2iGPo.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192078315/_5QNPyNmu.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192079606/wXtFxHaAy.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192080912/UXQAqxhq8.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192082463/6swJD-XCz.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192083614/6j4j7q2BQ.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192085573/VdayIgjFa.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192087207/VRsgeSDm2.png align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192088781/QDCXA6JNA.jpeg align="left")](https://lightinthebox.tv2h87.net/c/3170166/805530/8199?prodsku=8538559&u=https%3A%2F%2Fwww.lightinthebox.com%2Fwomen-s-2-piece-splice-tracksuit-jogging-suit-street-casual-long-sleeve-2pcs-winter-breathable-moisture-wicking-sweat-out-fitness-gym-workout-running-_p8538559.html%3Fcurrency%3DUSD&intsrc=PUI2_5801)

### Like this:

Like Loading...

### *Related*
