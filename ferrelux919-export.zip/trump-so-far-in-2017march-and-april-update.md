---
title: "Trump So Far in 2017\U0001F9D0March & April Update"
date: '2017-03-27T22:12:32.000Z'
slug: trump-so-far-in-2017march-and-april-update
tags:
  - trump
  - president
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195913918/5mwXfFtQ-B.png
canonical: 'https://ferrelux666.wordpress.com/2017/03/27/trump-2017/'
---
![Trump's 2016 Speech](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195907977/6w4ZQ7y0C.jpeg align="left")

**WOW, how presidential this speech was. There must really be 2 different Donald Trumps.**  
**This explains why he stopped tweeting for almost 2 weeks to prepare for this.**  
**If only his image in general could remain so pristine & favorable for the rest of his reign, but**  
**we know better. He’s been in office only since Jan 20th 2017, but with the everyday stress**  
\*\*of it, seems longer than that.  
\*\*

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/CFYXgyjg44g?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

**The President thinks he’s a King that what he decrees has to be followed across the land, well….this is how New York will deal with Trump’s unfair Executive Orders…….**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/hQ3qDauQ45c?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

**Now, to distract from the U.S. Government investigation of Donald Trump’s Administration for Election fraud, Trump threw up a claim that former President  
Barack Obama tapped Trump Tower & illegally surveilled him. Well, that wouldn’t be  
odd of any government, but he had no proof to make it stick. Trump knows that  
his legitimacy for being the President is under question so a diversion tactic may  
by invoking Obama & accusing him of something might make it go away, well……**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/HXJwo6VOG2A?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

\*\*BUT……his supporters disagree to prove there was a wiretap.  
\*\*

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/yEAMsB8IJFk?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

**And……here’s further news on that showing some evidence……**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/V3V5UJ_Akdw?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

\*\*  
Despite that, t\*\*\*\*he Trump-Russia probe thing goes on. If the hacking led to him being in power, then what?\*\* **Are they REALLY going to remove him from power, after all that HARD work to get the** **Republican party back in control of almost everything. Come on, if The Law really wanted** **they could have done so on less while Trump was running before the victory. I’m sure if** **he was “Black”, they would have.**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/rNsoyiEnDmo?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/CFYXgyjg44g?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195909797/o_Wxdx9Xm.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195911905/cehRVTHyQ.png align="left")
