---
title: "The Death of George Floyd Sparks Civil Unrest Nationwide \U0001F3F4‍☠️\U0001F9EF\U0001F525"
date: '2020-06-06T21:31:52.000Z'
slug: the-death-of-george-floyd-sparks-civil-unrest-nationwide
tags:
  - traffic
  - trump
  - service
  - society
  - strategy
  - hospital
  - world
  - global
  - covid-19
  - crime
  - peace
  - america
  - funeral
  - death
  - justice
  - fire
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672194133653/acP2Zep5D.jpeg
canonical: 'https://ferrelux666.wordpress.com/2020/06/06/george-floyd/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194101707/2kjUUs2Pc.jpeg align="left")](https://www.ferrelux.us/)

[**Burnin’ & Lootin’ – Bob Marley & The Wailers (1973)**](https://www.youtube.com/watch?v=za01QWLXisQ)

*Alius Homo Nigrum Quia Ratio Non Moriatur* 😢 *Another Black Man Dies For No Reason*

Well, what did you expect? In a previous article a few weeks ago, I said they should not have shut the cities down across the country and think that was smart, due to the novel Corona-Virus. There were big potential problems with that because prior years, on that same list of deadly diseases, ranked more serious killers like Cancer, Pneumonia, Malaria & other types of Flu, ABOVE the Corona-Virus and so many people died from the Flu, yet there was no shutdown. People went about their lives untethered. Yes there was the mention on the News after the fact, but people didn’t notice. Now, when you DISRUPT people’s lives telling them to stay home, wash your hands, you can’t go back to work, I’m closing your bars & restaurants, you can’t go to the theatre, oh and you can’t hang out here,  
NOW WAIT A MINUTE, what’s going on here? Anyone who doubted the existence of this deadly mystery disease had a right to. WHY, well do you still see unsavory types out there with their wayward lives moving about just fine with no mask, when they should be dead by now if there was a really a killer germ? In the beginning, things were spooky for a while & people were on their best behavior to the point where there was no case of racial incidences on the airwaves at all. It was almost too good to be true. I noticed it and said nothing and I wondered if others noticed it as well. Because I thought opening your mouth & talking about it might jinx it, but maybe somebody blabbered. Even under the ‘stay home’, and ‘we’re in this together’ Covid-19 Edict, a Black Life was still subject to Police Brutality, on or off duty. We heard about the racial shooting of Ahmaud Arbery by racist hicks in a truck, but that didn’t upset people yet to the breaking point. George Floyd in Minneapolis, with a cops knee pinned into his neck for about 8 minutes while he was already hopelessly subdued saying he could not breathe, harkened back to the New York incident with Eric Garner, killed by an illegal cop choke hold. All 3 Men, like many others died a senseless death for no valid reason in comparison to a typical Caucasian Criminal doing the worse lawless acts who are not treated that way. So now when you add OUTRAGE on top of the social restraint people had to endure these past couple months, you get an angry outburst from certain people in the population who WOULD respond like this under that pressure. I blame The Government. Trump was right to not want to shutdown a damn thing because he knew it would mess up everything, just deal with the sickness. Now, all this racial shit could have been avoided. Let me tell you where everything went wrong. When they said the virus got loose in China, it was hitting mostly Europe after, then the narrative changed, and the media kept reporting how it was killing disenfranchised Blacks in our American neighborhoods. Mind you, Hispanics & other Ethnics groups live in these same Communities suffering, but the media kept mis-reporting info focusing on Black People and then it triggered an interest in the most unstable racists in their hate group to mobilize thinking it’s their time to attack. Mind you, things were pacified before. And now the headlines are talking about racial injustice over the slaying of these 2 Black Men. Now, what did I say about keeping your mouth shut? I also blame The Media. Frequent Instigative Reporting also caused this problem. Now the Country is scrambling to appease People out of control tearing down America, and you out there throwing smoke bombs at your own Citizens. These recent racial problems have happened before, and you would get the typical Civil Rights protest, but nothing like this happened in a long time. This kind of onslaught against the cities across the nation, the burning & the looting, harkens back to a time way back with Blacks fighting for liberty under restrictive bigoted conditions globally. Now, whoever ‘The Powers That Be’ are, they’re trying to attack your American way of life in general by undermining the Constitution over time, and trying to take away certain freedoms, and such, they’re the same Ones using Social Psychosis, and other manipulative tools that would work on those less inclined to resist, because they aren’t fully informed or smart enough to recognize game. Now I told Y’all this was coming, keep reading my shit. At the time when Donald J. Trump came into power, there were some Conspiracy Theories out there saying he will be the last American President, alluding to a new government taking over after him. Now, that theory might be true. The year 2020 should have been a nice year. We had a mild winter, people should be out there enjoying the Spring, Summer, & Fall, not wearing a fucking mask and meeting curfew. I’m bracing myself for the next bullshit they’re gonna come with. This is all planned. Don’t let these people manipulate and control your life. You already have enough problems to deal with. HOW DARE THEY! Be vigilant, and remain very much in control of your own mind, body & spirit and understand what’s happening around you. I wouldn’t be surprised if a Foreign Power already took over this Country and is just playing games with us, while the transition is happening to finalize it. Mind you, you’re not supposed to be aware of The Takeover. Now the way the Government is acting, something IS wrong. And we’re in an undecided place right now. This is scary because historically it can lead to several things: 1) The expulsion of a people, 2) The massacre of some, 3) A new religion & way of life you don’t agree with, forced on The Ones who remain here under a new Leader & currency. It all doesn’t have to be BAD though, but let’s not be naïve. What they’re doing now is conforming you. A peaceful protest hijacked by racists, foreign enemies, or psy-ops should tell you. This sort of stuff have happened before under other changing governments around the world. And now America is trying to hide a secret she’s too ashamed to tell.

[George Floyd Funeral](https://www.youtube.com/results?search_query=George+Floyd+Funeral)

[George Floyd Protesters](https://www.youtube.com/results?search_query=George+Floyd+Protesters)

Lhisa,  
Your Political Informer

### Was Our Government Right To Shutdown All The Economically Flourishing Cities Across The Continental U.S. Due To Covid-19? Scroll Down And Leave Your Reply Below.

[![Ferrelux Homepage_George-Floyd June2020](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194103051/RQCQCwnhC.jpeg align="left")](https://ferrelux666.wordpress.com/2020/12/24/goodbye-2020/ferrelux-homepage_george-floyd-june2020/)

[![Peaceful Protest](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194104503/IJtDDKT7J.jpeg align="left")](https://ferrelux666.wordpress.com/peaceful-protest/)

[![Minneapolis Burning](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194105957/tURSgYvDN.png align="left")](https://ferrelux666.wordpress.com/minneapolis-burning/)

[![Smoke Bomb Cops In Riot Gear](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194107270/0rfJwivYg.jpeg align="left")](https://ferrelux666.wordpress.com/smoke-bomb-cops-in-riot-gear/)

[![Women Protesting on Bench](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194108267/D8tpKojyV.jpeg align="left")](https://ferrelux666.wordpress.com/women-protesting-on-bench/)

[![Women Protesters Chanting](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194109802/BMB7TyBlq.png align="left")](https://ferrelux666.wordpress.com/women-protesters-chanting/)

[![Washington-HoustonGeorgeFloydProtest](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194111348/JG8mVse5q.jpeg align="left")](https://ferrelux666.wordpress.com/washington-houstongeorgefloydprotest/)

[![Protesters Kneeling](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194113261/YcuNrcd3i.jpeg align="left")](https://ferrelux666.wordpress.com/protesters-kneeling/)

[![Protester, I Still Can't Breathe Mask](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194114385/puvXP6ix1.jpeg align="left")](https://ferrelux666.wordpress.com/protester-i-still-cant-breathe-mask/)

[![Soccer Players Taking A Knee](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194115583/xEcuWkozR.jpeg align="left")](https://ferrelux666.wordpress.com/soccer-players-taking-a-knee/)

[![Player Protesting, Justice For George Floyd](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194117109/L-AW8CXTk.jpeg align="left")](https://ferrelux666.wordpress.com/player-protesting-justice-for-george-floyd/)

[![Boxer Floyd Mayweather In Support of George Floyd](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194118127/ipQHrgqfX.jpeg align="left")](https://ferrelux666.wordpress.com/boxer-floyd-mayweather-in-support-of-george-floyd/)

[![George Floyd Mural 2020](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194119085/Chh-uxuU2.jpeg align="left")](https://ferrelux666.wordpress.com/george-floyd-mural-2020/)

[![A Protesting Fist in the Midst of Smoke](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194120071/dJecir9n0.jpeg align="left")](https://ferrelux666.wordpress.com/a-protesting-fist-in-the-midst-of-smoke/)

[![George Floyd Painting](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194121036/LWBS5xWKm.jpeg align="left")](https://ferrelux666.wordpress.com/george-floyd-painting/)

[![George Floyd's Family](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194122218/Qz4EQrHy_.jpeg align="left")](https://ferrelux666.wordpress.com/george-floyds-family/)

[![Justice For George Floyd](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194123587/1e2rpr8q1.jpeg align="left")](https://ferrelux666.wordpress.com/justice-for-george-floyd/)

[![German Soccer Player Protesting](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194124650/2pGwKlfek.jpeg align="left")](https://ferrelux666.wordpress.com/german-soccer-player-protesting/)

[![Cops Trying To Keep The Peace 2020](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194126041/ykINsZcPK.png align="left")](https://ferrelux666.wordpress.com/cops-trying-to-keep-the-peace-2020/)

[![George Floyd 2020](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194127770/TKa7MPeDD.jpeg align="left")](https://ferrelux666.wordpress.com/george-floyd-2020/)

[![George Floyd Casket](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194129429/HEM7WX47B.png align="left")](https://ferrelux666.wordpress.com/george-floyd-casket/)

[![Angry Protesters Burn Down Property](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194130790/s8brb7-mh.png align="left")](https://ferrelux666.wordpress.com/angry-protesters-burn-down-property/)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194131894/3uOStk36y.png align="left")](https://voropro.com/training/get-your-real-estate-license/invite/2654/)
