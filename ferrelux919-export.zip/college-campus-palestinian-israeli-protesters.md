---
title: "College Campus \U0001F92C Palestinian & Israeli Protesters"
date: '2024-05-02T01:10:43.652Z'
slug: college-campus-palestinian-israeli-protesters
tags:
  - covenant
  - jerusalem
  - protesters
  - '2024'
  - palestine
  - israel
  - college
  - jewish
  - muslim
  - middle-east
  - god
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1715314033653/66c45d40-a5f7-4321-a384-d253035acb55.jpeg
---
*Certe Cito Venio* ✝️ *Surely I Am Coming Quickly (Jesus Christ)*

🎶 [**Matisyahu ~ King Without A Crown**](https://www.youtube.com/watch?v=dsFpUW48Tnc)

**🏫 Sponsor:** [Support Ferrelux's Reporting By Buying A Home Lifestyle Product Here](http://go.novica.com/oq2ByE)

📝 **Social Justice:** [https://uscpr.org/campaigns/](https://uscpr.org/campaigns/)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1715330687597/3d438040-f9a5-47ba-9f33-6c1e8e53720e.jpeg align="center")

**Friday May 10th 2024 UPDATE**  
👉 Let me add something which dawned on me because I always knew what I am sharing with you on the links below. If you wish to be heard, O Palestinians, stop  
calling It Palestine and perhaps rename It-***ISHMAEL***\-to properly conflict with-***ISRAEL***.

[https://www.jewishvirtuallibrary.org/origin-of-quot-palestine-quot](https://www.jewishvirtuallibrary.org/origin-of-quot-palestine-quot)

[https://www.thejewishstar.com/stories/heres-how-the-palestinians-got-their-name,22410](https://www.thejewishstar.com/stories/heres-how-the-palestinians-got-their-name,22410)

[https://www.biblegateway.com/resources/encyclopedia-of-the-bible/Ishmael](https://www.biblegateway.com/resources/encyclopedia-of-the-bible/Ishmael)

[https://myislam.org/prophet-ishmael/](https://myislam.org/prophet-ishmael/)

☪️☪️☪️☪️☪️☪️☪️☪️☪️☪️☪️☪️☪️☪️☪️☪️☪️☪️☪️☪️☪️☪️☪️☪️☪️☪️☪️☪️☪️

[**Men's Black Alpaca Jacket**](http://go.novica.com/xkxRLx)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1724028575651/dfccf889-cfc1-4136-add6-8881a2178a3c.png align="center")](https://go.novica.com/xkxRLx)

🕋🕋🕋🕋🕋🕋🕋🕋🕋🕋🕋🕋🕋🕋🕋🕋🕋🕋🕋🕋🕋🕋🕋🕋🕋🕋🕋🕋🕋

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1715327790089/79c36db2-7380-4fc8-8f72-4e59d9243eba.jpeg align="center")

When this issue popped off due to the war last year, I saw the heat in these people as it affected well-known Politicians and other persons who took the mask off and ceased to be Hypocrites. It was shocking and hurtful to those who did not expect it. Such truth was not surprising to me as it tapered back a while due to some backlash. None of it is gone by the way, just hidden again. I don’t condemn them because it is important to understand what’s going on. I’ve been following it.

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1714956156487/e0c35a6a-3488-417c-9dd5-3b152a328476.jpeg align="center")](https://www.history.com/topics/holidays/cinco-de-mayo)

So now it’s **Sunday May 5<sup>th</sup> 2024**, Happy Cinco De Mayo. As this Society struggles to normalize It’s Economy with these Holidays where the enthusiasm is still lackluster, contending with another potential global war swamps our near future prospects as a Nation.

*Before I continue writing on this topic. Take a look at my short video below I uploaded yesterday.*

**📽️**[**https://ferrelux.substack.com/p/campus-protesters-arabs-vs-jews**](https://ferrelux.substack.com/p/campus-protesters-arabs-vs-jews)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1715315428043/2cea0c59-52d3-4d94-b32b-6d602461359a.jpeg align="center")

It’s now **Thursday May 9, 2024** and I’ll go into some stuff that not a lot of people are saying out loud. And I am not referring to Jewish People that this does not apply to, but to the Ones it stringently does practicing these moves. A lot of people far and wide are venting their own distrust and disgust of Jews based off general stereotypical perceptions in some cases, while others are more acting out due to some bad experience. There is no delicate way to present some of the validity of that. There probably is a genuine interest in the nation of Palestine and Its people, but the energy out there is more personal and directed at your Community as being The Body solely responsible for impairing an area of their lives. Interview some of them if you dare. Hope you get an honest answer. The animist is relatable. So how do you deal with it? Targeting and harassing these people isn’t going to stop the sentiment. There is right and wrong here on both sides. You can’t deny that. Without circumspect I can go deeper, but perhaps another time for it might be too painful for you to bear now. You even lash out at a smattering of truth. It’s a sign of weakness. Know that people will react to the things you do that are improper where justified, but why must you exercise this notion that you are above blame? You God is known to side with Your Enemy at times why they flourish. Oh Israel, what have you done to cause your circumstance as it is now for your People settled across the 4 Corners Of The World? I already highlighted a good some of it in previous recent articles. It all ties together and We are in a new Time now. **The Game** is different but the wrath of either God remains the same. The answer lies not in the conquest of your present critics or Enemies, but in The Submission to Your God as His Work is happening all around you if you care to see it. I’m well aware of His Presence and the moves He’s making not to bother add to it. I’ll chastise you another time.

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1724032772754/ccc29197-336a-44ed-8df2-0c5d494f461c.png align="center")](https://go.novica.com/KjRWqe)

**Sign,**  
**Lhisa Mrklon**  
**The Enlightened One**

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1715326863033/dd311c0a-c604-44b2-8551-8023906f5c9d.jpeg align="center")

👁️ ☪️ 🕋 🕌 ⏳ 🕍 📜 📖 ⌛ 🏜️ 🐫 ✡️ 👀

**🤔 Rabbi Yisroel Dovid Weiss Speaks On Why He & Other Jews Support Palestine**

**🎥**[**https://www.youtube.com/results?search\_query=Rabbi+Yisroel+Dovid+Weiss**](https://www.youtube.com/results?search_query=Rabbi+Yisroel+Dovid+Weiss)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1715315880955/e16fe96d-d597-4611-bd5b-9300ebed21fd.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1715315902838/bc8184bb-6986-4a42-bef8-54f0b69573c6.png align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1715315925638/954dc944-5ab0-47cf-b86c-c904675d9a5f.png align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1715316230916/265540ff-45d4-4eb4-8d41-5978db3b19ed.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1715316249259/515648c1-647b-4c0a-a64a-719eb672bac0.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1715316711338/b96aa383-0d77-4ccc-8af1-c1c3127fb1db.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1715317466047/131427d9-8b5d-4274-95fe-029ae38ece25.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1715317483601/5a08a94a-cb23-47f9-acba-2a7558a6a7fa.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1715317498466/c0341fe7-7379-4f0c-bdd7-88eced55a444.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1715317771343/1ea15b71-9d6d-4f0c-a47a-6dc06766b25c.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1715317791010/1cc124c2-2c31-4fbf-8097-ba6ccefd7c21.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1715326055395/3d24a35e-ac07-4e8b-90d1-3082538321c7.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1715560856522/49366292-2144-4a63-85ee-69a805b4eeaa.jpeg align="center")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1715561527453/2b0fd68e-0344-49d2-afb4-6a0235397b65.webp align="center")](https://ferrelux.com/mothers-day-royal-photo-mishap)

✝️✝️✝️✝️✝️✝️✝️✝️✝️✝️✝️✝️✝️✝️✝️✝️✝️✝️✝️✝️✝️✝️✝️✝️✝️✝️✝️✝️✝️

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1723425245002/db0b72a2-ac0d-4a4c-8cbe-d555e754dc48.jpeg align="center")](https://www.stacksocial.com/sales/refurbished-hp-elitebook-840-g5-i5-8350u-16gb-256gb-ssd-14-windows-10-pro?aid=a-1af3pey3)

#170
