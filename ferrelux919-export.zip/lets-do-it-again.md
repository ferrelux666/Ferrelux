---
title: "Let’s Do It Again \U0001F38A✨\U0001F9E8"
date: '2019-01-11T19:44:39.000Z'
slug: lets-do-it-again
tags:
  - blogging
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195262683/IwXRwf848.png
canonical: 'https://ferrelux666.wordpress.com/2019/01/11/newyear2019/'
---
![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195258987/ZMawrtYky.png align="left")

**Again, welcome to 2019. Thanks for supporting me & my blogs. Last year was a dark one if you were paying attention to all the weirdness & deaths.**

**And this year’s blogs may be a carryover from past headlines as they tend to repeat, BUT my interest is in taking on relevant topics at certain times**

**why a few of my blogs on some issues tend to appear at odd times after the fact; well…….it’s because I tend to pick up on some things people miss.**

**What do YOU expect for 2019…………………………………………………………….**

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195260349/WCWkAvMi5.png align="left")](https://ferrelux.com/adverts/)
