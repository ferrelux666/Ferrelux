---
title: "\U0001F6A4 North Korean Small Town River Boat \U0001F3E6"
date: '2023-10-02T17:28:59.777Z'
slug: north-korean-small-town-river-boat
tags:
  - korea
  - bob-menendez
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1697607934681/27fc24d3-bb79-4fc6-83c9-bbb09c780c0d.jpeg
---
🎵 [Lathan Warlick's Rap Over Jason Aldean's *"Try That In A Small Town"*](https://rumble.com/v3684xk-man-added-to-jason-aldeans-try-that-in-a-small-town.html)

I decided to lump 4 unrelated topics into one using that title for this article since I sometimes save certain issues for purposes like this to picture in your mind. And ofcourse the passenger on that boat headed to a small town in North Korea, would be Senator Bob Menendez, *ha ha ha.*

**😃 STAY TUNED FOR MY COMMENTARY ON THE LAST TOPIC LEFT. CHECK OUT THE REST OF THE INFORMATION I DROPPED CONCLUDING THAT FBI ARTICLE**  
**WHEN YOU SCROLL DOWN TO 'THE SCAM' SECTION. I WAITED THE 99 DAYS SINCE PUBLICATION AS A TRIBUTE TO AGENT 99 IN THE TV SHOW, GET SMART.**  
[https://ferrelux.com/the-fbi-a-national-security-threat](https://ferrelux.com/the-fbi-a-national-security-threat)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1696451632192/8270ec9e-a095-4fd1-adb6-c6b76cc0f9ae.jpeg align="center")

**New Jersey Senator Robert Menendez Brought Up On Charges**

Now his situation was going well *UNTIL* . . .  
I attribute his problems to someone being careless. As we watch that unfold in real time, take note of the things happening around his case so if *‘American Greed’* decides to get on it, you can properly distinguish the episode. In The Press Conference, he gave plausible explanations. It would be interesting to see if and how he gets out of it. So now his ties to Cuba is involved. He may have went too far grossing money. Someone he hired could have let him down. If his operation was running so well all this time, what went wrong? And was it illegal to be taking away his gold? It may just be a matter of suspected personal enrichment limited to the Affairs of his Office and Jurisdiction, but someone handling the case in The Justice System may be looking too deep beyond that.

[https://www.cnn.com/2023/09/22/politics/bob-menendez-charges/index.html](https://www.cnn.com/2023/09/22/politics/bob-menendez-charges/index.html)

[https://apnews.com/article/bob-menendez-profile-indictment-corruption-0407745502680965e7ed230745ffa520](https://apnews.com/article/bob-menendez-profile-indictment-corruption-0407745502680965e7ed230745ffa520)

[https://www.politico.com/news/2023/10/04/nadine-menendez-car-accident-00119903](https://www.politico.com/news/2023/10/04/nadine-menendez-car-accident-00119903)

👉 **Update:  The Charges On NJ Senator Bob Menendez Connects Him With Doing Favors For Egypt.**  
[https://www.theguardian.com/us-news/2023/oct/12/senator-bob-menendez-charged-foreign-agent-egypt](https://www.theguardian.com/us-news/2023/oct/12/senator-bob-menendez-charged-foreign-agent-egypt)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1696451661394/25cfc269-5eaa-4250-83e2-abbc262ba112.jpeg align="center")](https://www.dailymotion.com/video/x8mqoua)

**The Capture Of Black Soldier Travis King, Who Went AWOL Into North Korea**

The prevailing perception of this Dude is that he’s Crazy, which comes off as dismissive. He’s complaining about racial bias he experienced in The Military and depending on The Unit you’re a part of or where you’re stationed and your Commanding Officer and Colleagues, that’s true. For my brief time in **The United States Military**, throughout the process my experience was positive. The topic of race came up with other people. Where you come from and what you believe factors in too. A Military Base is generally ran better than a Civilian Town or City. It’s very clean, orderly, friendly, and much safer. And you start seeing some other critical differences from **Civilian Life**. There should be less problems due to the rules you have to follow, and your ability to rise in rank more definite. It’s uncertain as to what Travis King’s problems were. There are numerous factors that play into why a person would do something. How far in **The Service** is he? You’re supposed to be able to determine at The **Boot Camp** Level whether being in The Military is right for you or not, given what you’re exposed to for roughly 6 to 12 weeks. And you should be aware of some things prior to signing up. If he was Crazy *THEN,* it should have been determined before entry into **The Armed Forces**. Had I continued in The Service, I would have probably found myself actively involved serving as a **Judge Advocate General** (JAG), and I’m imagining being a JAG Officer assigned to his case, I’m seeing some Lines of Defense already having privately studied different **Areas of Law**. I’m excited to see how his case is handled. That Poor Dude. So now I’ll take time to give a quick shout out to that old long running TV Show back in the day called **JAG**. You can still see it on TV depending on what channels you watch, but you can certainly catch it on certain Streaming Services and Youtube. I’ve seen that shit several times, and it’s quite inspiring and informative. In fact for Halloween 2022, I was going to do another fictional tale concerning a group of particular people around a certain case quite similar to the 70+ page story I wrote in October 2021, but that didn’t get a chance to happen due to **Avenatti** losing his Case against Stormy Daniels though **the hope** for his victory was there. So I’m set back on that one. Many of the characters in [***Avenatti’s Marvel Universe, DC***](https://ferrelux.com/avenattis-marvel-universe-dc)  were to be re-casted in *my version* of **JAG** with ofcourse **him** winning again *and how* based off the style of that show and I have the entire idea in my head still. And **WHO’S** arguably having **The JAG Experience** right now in New York is one of my characters, **TRUMP**. He’s also representing a **David Vs Goliath** Battle, *like I Am,* and I didn’t want to say it much then during the thick of my own problems in 2022 dealing with malicious Cyber Attacks from that **Big Tech Giant Google** empowered by BIG BROTHER reading my work in late 2021, to play into their power struggle, but I definitely felt it. And that theme won’t go away. It’s affecting a lot of other people telling the truth, and or trying to earn a living in creative independent ways. And that troubled American Soldier Travis King, now in U.S. Custody, is going to need to find a way to win a gigantic case that the military is forging against him. And I’m inclined to conspiracy theories concerning covert operations since the last publicized American Black Person on **Axis Territory** was Olympian Basketball Star Brittney Griner politically rescued from a Russian jail. In the case of Travis King, while in North Korea, he could have planned his escape better by getting some paperwork started dis-engaging himself from The U.S. and applying for **Asylum** there or somewhere in the region. If he had some military secrets to share, I guess he could have negotiated something in his favor with them instead of being *“expelled”* from North Korea. So this shows how spontaneous and unprepared he was fleeing from something. Any other move would have been within his rights or considered treason. We’ll see what happens. Incidentally, I’ve been looking at that side of The World to relocate to as well since I can fit in just about anywhere shapeshifting and acclimating myself to the culture. As a Black Person living in America or places like it, one only needs to be amongst Communities representing certain places on The Globe to learn *where* to go.

[**https://www.dailymotion.com/video/x8n9pvk**](https://www.dailymotion.com/video/x8n9pvk) ***The White House, Karine Jean-Pierre***  
[**https://www.dailymotion.com/video/x8od4va**](https://www.dailymotion.com/video/x8od4va)  ***One India News***

[https://www.theguardian.com/world/2023/jul/18/us-citizen-crosses-border-from-south-korea-into-north-korea](https://www.theguardian.com/world/2023/jul/18/us-citizen-crosses-border-from-south-korea-into-north-korea)

[https://abcnews.go.com/International/wireStory/analysis-north-korean-standards-pvt-travis-kings-release-103554064](https://abcnews.go.com/International/wireStory/analysis-north-korean-standards-pvt-travis-kings-release-103554064)

[https://www.cnn.com/2023/09/27/asia/north-korea-travis-king-expel-intl/index.html](https://www.cnn.com/2023/09/27/asia/north-korea-travis-king-expel-intl/index.html)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1697181445454/d69bcf0f-7674-401a-b4ab-be123ec56477.png align="center")](https://rumble.com/v30xakm-watch-jason-aldeans-cancelled-try-that-in-a-small-town-music-video.html)

**The Song, ‘Try That In A Small Town’**

I heard it and was not offended. I know what he means. I’ve lived in Small Towns in The United States for a time, but preferred The City. The people offended by it, mainly some prominent Democratic Celebrities are sensitive to the slightest sound of anything that remotely can be associated with racism, much to the point where it comes off ridiculous. I’m not a big fan of Country Music, but I get the vibe and message and his song is aligned with that. Now, stuff that shouldn’t be happening **has happened** in Small Towns before, just check The Crime Reports. What happened with Antifa, Black Lives Matter, The Proud Boys, The KKK, And Others, marching through your Streets tend to pop off in in Cities where the density of social issues live and we have many ethnic urban songs past, present & future on those topics that became hits, to be making a case over that Country Man’s tune.

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1697608014180/570a86f1-6e98-4010-b8bc-292b4180f921.jpeg align="center")

**The Montgomery, Alabama River Front Brawl** 

It was disgraceful. The conflict was a result of some drunk Rednecks who parked their boat along the route where an Official Boat was on its way to dock and The African-American Deckhand politely asked them to move and they didn’t want to. So the White Guy struck him first and that poor Black Guy fought back, and then the fight was on with a White Posse jumping on him and later some other Blacks ran into the fight protecting him since it was racial. I agree. You don’t need to take disrespect from anybody. The man was just doing his job. Of course The Authorities came by breaking up the fight and taking some of them into custody. I lived in The South for a good while and can report that I personally had no true biased incidents, but I have heard some things. The legacy of Slavery & Jim Crow exists in some folks still, and sometimes administering a good old fashion beat down, can solve that.  

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1696458709692/d1c990e3-8c8e-4c99-b409-c841075f32e6.gif align="center")](https://www.goarmy.com/careers-and-jobs/specialty-careers/law.html)

**Sign,  
Lisa Markland, JAG Corps  
First Lieutenant, U.S Navy**  
[**https://www.jag.navy.mil**](https://www.jag.navy.mil)

***(Surely, I Jest ⚓ Lhisa Mrklon)***
