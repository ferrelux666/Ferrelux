---
title: "Mandela Centennial & Winnie’s Death (2018) \U0001F30D\U0001F622"
date: '2018-09-27T18:47:30.000Z'
slug: mandela-centennial-and-winnies-death-2018
tags:
  - fear
  - history
  - freedom
  - political
  - failure
  - united-states
  - america
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195342927/-pgUYpWJG.png
canonical: 'https://ferrelux666.wordpress.com/2018/09/27/mandela-centennial-2018/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195337700/-cfR8dVKD.png align="left")](https://www.ferrelux.us/)

*Pro Libertate Patriae* 🖤 *For The Liberty Of My Country*

**Amandla Awethu! Power to the People! As the year winds down, we remember the lives of freedom fighters Nelson Mandela, who would have turned 100 years old July 18th 2018 & his beloved Winnie Mandela who died on April 2 this year at age 81. The struggle still goes on. When you are the real majority of the people on the globe & the real minority are those oppressing you. When racism and greed fuel a global political agenda. When the Oppressed themselves in some parts fail to recognize it affecting their lives & mobilize to stop it. We look back to see the triumph of a man who was sent to the lowest depths of his life, only to rise like a phoenix to the top. How genocide & apartheid strived to keep him & his people down. The inhumane & wickedness of it all. This still goes on everyday in the United States of America. And what keeps it alive is hate, greed & apathy; a continual problem nobody is correcting politically except for infrequent times when it suits them. When it looks like we’re finally moving forward with change, society as a whole digress back to that old comfortable phase. Why? Well, human nature. The innate ugliness of fear & contempt won’t disappear. And so we live with it pretending that we’re better today when just yesterday, you had no problem disrespecting another or denying them their basic rights. We don’t like each other, really. We only pretend we do, but some of us know better, while exercising the aptitude to improve.**

**~ Lhisa Ungelis Mrklon**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/XkHjrKDrhjg?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

**SOME LINKS**  
[http://freedomforever100.com/](http://freedomforever100.com/)  
[https://www.nelsonmandela.org/nelson-mandela-100](https://www.nelsonmandela.org/nelson-mandela-100)  
[https://en.wikipedia.org/wiki/Nelson\_Mandela](https://en.wikipedia.org/wiki/Nelson_Mandela)  
[https://www.britannica.com/biography/Nelson-Mandela](https://www.britannica.com/biography/Nelson-Mandela)  
[https://en.wikipedia.org/wiki/Winnie\_Madikizela-Mandela](https://en.wikipedia.org/wiki/Winnie_Madikizela-Mandela)  
[https://www.cnn.com/2018/04/02/africa/winnie-mandela-south-africa-intl/index.html](https://www.cnn.com/2018/04/02/africa/winnie-mandela-south-africa-intl/index.html)  
[https://www.aljazeera.com/news/2018/04/south-africa-winnie-mandela-180402161736297.html](https://www.aljazeera.com/news/2018/04/south-africa-winnie-mandela-180402161736297.html)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195339466/FhEGIyKt-.png align="left")](https://www.ferrelux.biz/2019/11/gucci-unisex-sync-rubber-black-46mm.html)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195341123/HwU4PEpZO.jpeg align="left")](https://ferrelux.com/adverts/)
