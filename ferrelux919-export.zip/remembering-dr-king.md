---
title: "\U0001F393Remembering Dr King\U0001F396️"
date: '2017-01-17T20:44:03.000Z'
slug: remembering-dr-king
tags:
  - history
  - speech
  - human-rights
  - america
  - president
  - black
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672196039029/xf9a8VSpe.jpeg
canonical: 'https://ferrelux666.wordpress.com/2017/01/17/remembering-dr-king/'
---
[![Dr King's Extraordinary Life](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196035640/H9ns4FhPW.jpeg align="left")](https://thekingcenter.org/about-tkc/martin-luther-king-jr/)

**The Legacy Of This Man Lives On Despite The Cruel Hatred That Still Exists In The World.**

**See The Series Of Videos  
**[**https://www.dailymotion.com/search/Rev%20Dr%20Martin%20Luther%20King%20Jr./videos**](https://www.dailymotion.com/search/Rev%20Dr%20Martin%20Luther%20King%20Jr./videos)

**~ Lhisa Mrklon**

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196037047/UAHFonOR7.jpeg align="left")
