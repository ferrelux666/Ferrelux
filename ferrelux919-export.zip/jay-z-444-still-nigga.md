---
title: "Jay-Z 4:44 Still Nigga \U0001F3B1\U0001F3B3"
date: '2017-07-18T22:37:01.000Z'
slug: jay-z-444-still-nigga
tags:
  - president
  - black
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195815965/blebF7m7C.jpeg
canonical: 'https://ferrelux666.wordpress.com/2017/07/18/still-nigga/'
---
[![Jay-Z In Suit And Bow Tie](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195807600/HL41IQfeb.jpeg align="left")](https://tidal.com/browse/artist/7804)

Libertas Inestimabilis Res Est ♠️ Freedom Is A Possession Of Profound Value

\*\*  
You’ve seen the mysterious 4:44 ads everywhere before the release of the album at the end of June on TIDAL. You can read More about it here ~ [Jay-Z 4:44 Album](https://en.wikipedia.org/wiki/4:44_(album))\*\*  
**Like many other “Black” people, I’m feeling the song ‘The Story of O.J’ because the message is** **so true. The subject matter of the song applies to O.J. too & is a more roundabout title to use** **to draw folks into discussion, than, ‘still nigga’ which, is the catch phrase throughout the song** **driving the point home. And WHY…well, the eerie child-like voice croons, because ‘my skin is black’. The sad fact is many “Blacks” still suffer from getting this fact, especially when you look** **at cases having to do with popular Celebrities getting in trouble with the system. Now you know** **what it is. No matter what your accomplishments are, it is all rigged against you. But yet the** **“White” counterpart with the same, similar or worse offense is not attacked in like manner or** **even exposed the same way. Access to opportunities & resources is not the same for you** **“Black” people or any other group that isn’t “White” since they control & manipulate the wealth** **globally until that changes. Why is it that some “Blacks” forget this simple fact, well….the delusion that you are also included. If you do this, or get that, & be a good little Black person** **you can access this reward. Well, many have done that & many of them are nowhere. The truth** **is even if you tried, the roadblocks are there & many of our people are in a state of suspended** **animation. So much competence & potential but deliberately kept behind from making it even** **though you are better. What should sadden you is how used our people are. So what if you** **represented the country at the Olympics & won the nation gold, you get to go back home to racist America watch an NBC commercial featuring your win, then placing a subliminal racist ad** **about some mud make-up product, or monkey image in the one commercial that plays all the time on their station just after YOU Black athlete. And I could go on & on because no matter** **how decent you are, it is what it is, the prevailing societal projection, my Nobel Peace Prize Winner.**

**~ STILL NIGGA**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/RM7lw0Ovzq0?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195809191/SviADmyT4.jpeg align="left")

NEW YORK, NY – MAY 16: Jay-Z performs during TIDAL X: Jay-Z B-sides in NYC on May 16, 2015 in New York City. (Photo by Theo Wargo/Getty Images for Live Nation)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195810743/AC1KtzSZF.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195812040/ihPBD2Ara.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195814370/Akscn3Nmz.png align="left")
