---
title: ☣️President Joe Biden’s RED Speech☢️
date: '2022-09-08T00:59:40.000Z'
slug: president-joe-bidens-red-speech
tags:
  - atomic
  - trump
  - doj
  - state
  - speech
  - germany
  - usa
  - government
  - union
  - einstein
  - florida
  - politics
  - debate
  - olympics
  - currency
  - america
  - biden
  - pennsylvania
  - nuclear
  - washington
  - military
  - islam
  - raid
  - middle-east
  - president
  - fascist
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672191641793/qRaH_XzD4.jpeg
canonical: 'https://ferrelux666.wordpress.com/2022/09/07/red-biden/'
---
[![Biden's Inauguration Day Speech](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191617536/cbx91rQhT.jpeg align="left")](https://rumble.com/v1idd9x-is-biden-a-dictator-ep.-1844-the-dan-bongino-show.html)

<iframe width="100%" height="100" src="https://w.soundcloud.com/player/?url=https%3A%2F%2Fapi.soundcloud.com%2Ftracks%2F245788107&auto_play=false&hide_related=false&visual=true&show_comments=true&show_user=true&show_reposts=false&color=ff5500"></iframe>

[Salvador E. Ruano](https://soundcloud.com/salvador-e-ruano) · [I Am The Law](https://soundcloud.com/salvador-e-ruano/i-am-the-law)

I chose this heavy metal track by ANTHRAX in humor because it sums up how some on the right might be feeling about Biden’s current flare in use of the DOJ against MAGA.  And a line from the chorus goes,  
\_\_“. . . . . I Am The Law, you won’t fuck around no more. . . . .”

\_\_

\_\_**Divide Et Vincere 😡 Divide And Conquer**  
\_\_

**\_*Some People*\_** **are really trying to stop this publication from coming through if you have been following my issues since this year, but we the brave people will press on. Now parking The Trump Case a side for a moment, let’s take a look at Biden.**

So Potus 46 graced us with another side of himself, showcasing versatility. Now many of you don’t like it, especially on The Right, but check it, Ya’ll been hating on Old Joe, so what did you expect? And I appreciate the ominous background. This is a time now where we are going to see some more tremendous changes in our government, and WHOever is Controlling It is just trying to show you, so brace yourselves. The Fascism or whatever you want to call it is real. Some of you have called it Satanic, Third Reich, etc. **\_*Ahmm Look,*\_** I use to have these kinds of debates with people who touted The American System of Government as being the best, and it turns out that one of my predictions I gave decades ago in High School and College may be coming true. I just didn’t expect it to unravel like this though. At the time, I had other speculations as to how it might come about. I expected this same style of government to go on as is until . . . . .**\_*well,*\_** I guess it sort have happened already. The elements are certainly there, but it’s sad though. At the time, after listening to those people debating me many years back about how unbreakable our system is, I let them win the argument because you have to remember that back then, we were still living in a hopeful time when you believed in all that stuff, The American Dream and so on. So fast forward to NOW, **\_*what went wrong?*\_** Well, a drop in our policies all across the board. And I mean EVERYTHING,. . . . . . . the foregoing of Standards, the lack of Opportunities, The Weak Economy, Declining Infrastructure, the breakdown of Morals, the collapse of Trust, and so forth. We use to have **Propaganda** working for us. The Movies were all about The American Spirit and how Great we are. At least we were still able to prove that at The Olympics but what about the rest of it? The value of The American Dollar is plummeting compared to The Great British Pound, and The Euro. Didn’t Obama take out Muammar Qaddafi over this same thing in a way. I know a lot of Pro-Blacks in certain online Communities didn’t like what he did, but it was over the idea of Qaddafi possibly trying to unify the whole Arab Region under One Currency which would subvert the dominance of The U.S. Dollar. And though in the beginning stages of his presidency, people here did not trust or like Obama for going over there showing The Muslim Leader a traditional gesture of respect due to political reasons, but when it came time to show where his loyalty was, he sent out some soldiers to execute a few prominent perceived foreign enemies in Arabia. So their plans were abruptly halted, but about 2 decades later now, what’s to stop any of it from happening now especially where Afghanistan is concerned? With a “Weak” Leader in Office as Ya’ll put it, just about everybody is taking step of poor Joe, that it’s no wonder why Somebody dressed The Capitol Stage up so dramatically to give a darker and more evil side of Joe for all to see and take seriously. We already know that if Trump were in Office, what he might do. We almost all agree that these people out here on The World Stage popping off with stuff would not have tried that had Trump still been in Office. So Old Joe needs some kind of re-vamping if he is to go on Representing us. People need to be put back in their place. And the only thing holding us together right now is the **Nuclear Arms Secrets**. Our Nation got this knowledge according to history, from The Jewish Scientist Albert Einstein when he fled Hitler’s Germany for refuge here. And I’m not too sure in these news reports if The Feds actually recovered any of this military information from their raid of Mar-A-Lago as proof of treason. Even if the secrets were still kept in it’s sanctuary under lock and key where The Government is supposed to  have it, it does not guarantee that another nation would not somehow birth or already have in their ranks someone like Einstein who is even more gifted to grace **\_*them*\_**. Though demoralized and defeated in other ways, the reason why America is still here as “The World Leader” is because that one military bastion still has not been conquered yet.

Sign,  
Lhisa Mrklon  
Your Special Historical Master

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191618701/xpvuyTWW-.jpeg align="left")](https://lightinthebox.tv2h87.net/c/3170166/763593/8199?prodsku=8071469&u=https%3A%2F%2Fwww.lightinthebox.com%2Ffr%2Frobe-de-soiree-luxueux-etincelant-fiancailles-robe-ceremonie-robe-bretelles-fines-sans-manches-longueur-sol-satin-avec-paillette-robe-pan-volant-2020_p8071469.html&intsrc=PUI2_5462)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191620210/gpoZYH29O.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191621976/230wZ8WTt.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191623481/6ceOWsK2d.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191625286/GjoIUC9Q5.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191627508/BJPl9JdmV.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191629056/sl7QTPI-f.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191630824/BAnN7AYCh.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191632515/CZjwqQuPG.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191633882/Tfg6RhFrD.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191635112/LdeKRHRM6.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191636301/bKRIsLB9C.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191637614/mia8iMC6t.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191639276/dBMkHynqcz.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1677692681628/42ac7cbc-4174-4246-aa56-225b0f1617ab.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1677692711768/2dbc79da-efe0-4dcf-bb80-fe38eaaba9ce.jpeg align="center")

### Like this:

Like Loading...

### *Related*
