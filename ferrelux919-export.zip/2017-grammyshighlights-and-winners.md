---
title: "2017 Grammys\U0001F4C0Highlights & Winners"
date: '2017-03-05T17:37:43.000Z'
slug: 2017-grammyshighlights-and-winners
tags:
  - music
  - show
  - beyonce
  - celebrity
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195954714/HyD2D6TEW.jpeg
canonical: 'https://ferrelux666.wordpress.com/2017/03/05/grammys2017/'
---
[![Beyonce 2017 Grammys](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195947101/vl5cHwbHW.jpeg align="left")](https://www.cnn.com/2017/02/12/entertainment/grammys-winners-list/index.html)

This past 2017 Grammy awards turned out great with the performances,  
but was not without a glitch. At the end, it was nice that a big winner, Adele  
complimented Beyoncé’ album ‘Lemonade’ & how it inspired her & that  
she should have won best album of the year.  
[https://www.grammy.com/](https://www.grammy.com/)

Ofcourse, you may not agree with the winning recipient & one would have  
to wonder if it is really based on politics or sales.  
You can catch a list of all the winners & nominees here……  
[https://www.grammy.com/nominees](https://www.grammy.com/nominees)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195948635/eykvXHJyG.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195949981/GxLsiNXne.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195951567/5xPnSJb8M.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195952840/iul1dzlnC.jpeg align="left")
