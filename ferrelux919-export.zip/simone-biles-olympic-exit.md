---
title: "Simone Biles’ \U0001F947\U0001F948\U0001F949 Olympic Exit?"
date: '2021-07-31T01:50:49.000Z'
slug: simone-biles-olympic-exit
tags:
  - uber
  - fear
  - runner
  - games
  - mindset
  - team
  - women
  - mental
  - health
  - kids
  - german
  - magic
  - society
  - japan
  - usa
  - competition
  - sports
  - japanese
  - world
  - international
  - entertainment
  - politics
  - olympics
  - australia
  - arena
  - protest
  - running
  - america
  - russia
  - silver
  - mexico
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672208833412/059b992d-6d94-4ada-80b5-d3aa9303688f.jpeg
canonical: 'https://ferrelux666.wordpress.com/2021/07/30/simone-biles/'
---
[![Simone Biles, Glammed Up](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192821958/0DO-2emHj.jpeg align="left")](https://www.dailymotion.com/search/Simone%20Biles/videos)

\*\*[The Olympic Theme By Leo Arnaud “Bugler’s Dream”](https://www.youtube.com/watch?v=q9gL33ze4RE)  
Vos Poteris Deprensus Ut Etiam Adsequitur In Te 👏🏾👏👏🏾👏👏🏾👏👏🏾👏👏🏾👏  
You Can’t Get Too Caught Up In Yourself  *(Simone Biles)*  
\*\*

So Gymnast Simone Biles decided to withdraw herself from the Olympic competition to focus more on her personal well-being, and that move has further propelled a questionable political agenda. Some are failing to see it, but it was quietly happening for some time, and now they want to attach mental illness to it. There’s an attack on Black Female sports figures. They’re looking for every reason to get you out of the competition whether you self-disqualify like the case of runner Sha’Carri Richardson with the dope thing, or you take yourself out by claiming injury, or other personal reason impedes your win like Naomi Osaka. They’re even citing over-masculinize female track & field runners for disqualification even though they are naturally born women who just pump a lot of weights. Many of them being affected in the sweep are Black Women runners known to win races. Now if I was a White Girl growing up somewhere training for The Olympics, I would rather be in there competing with Black Girls because it would force me to bring my game up. You don’t want to travel The World competing with weaklings in your race, walking around with a gold medal you won too easy. In the 1968 Olympics held in Mexico, with the two Black American track & field Stars, Tommie Smith & John Carlos standing on the podium barefoot with their gold and bronze medals, raising their Black Power Fist in civil protest in that iconic pose, along with them was that White Australian Gentleman Peter Norman also wearing a social justice badge in protest, and his silver medal as a testament to his skill to be up there being honored with them. I have more on that story [**here**](https://ferrelux.com/2019/09/09/olympics1968/). Now, when Hitler attended The Olympics held in Germany in 1936, he expected his Ubermensch (German Superman) to win, but Jesse Owens, our Black USA Superstar won, and do you know why? Well, the heat of the racist political atmosphere weighed so heavily on this poor soul that he was running for ALL Black People, and proved that **he was The Greatest**. You know who else was The Greatest? Muhammad Ali. Now, in our time, this issue still exists in just about every competition when you’re Black, and it’s a shame that these Black athletes even bother to represent a country that treats their people like shit. Many have a lot to say about Simone Biles’ decision, some positive, and others insulting. And what I have to offer is an alternate perspective. **Now Simone, it’s all the same thing. You won gold medals before, and you are the only one capable of those historic gymnast moves you did not too long ago so fearlessly within your same physical capacity. Anyone deliberately getting you to doubt yourself or distracting your discipline away is not truly with you or care about the team. When Greats like LeBron James, Stephen Curry, Kevin Durant, and others had to carry the weight of their team and be** **\_***The One***\_** **scoring the gold while injured, it was their destiny, and you were poised to do the same,** **even after being shaken from something racist directed at you in the media or in the locker room like Gymnast John Orozco.** Simone Biles has already been anointed with the title ‘Greatest Of All Time’ doing gymnastic moves named after her, and accomplishing these historic things under less pressure, and in a more supportive environment. So what we’re seeing with her right now, with what they’re calling a mental health issue and parading in the media targeting other Black athletes is completely unfair and racial. What it really is from a Black standpoint, is dealing with the pressure. A young White female doing anything be it sports, or whatever, is not confronted with the same racial issues or tension to strive and obtain something. Just growing up myself being involved with academics, sports, fine arts, etc. in competitive ways, sometimes I was the only Black there or one of the few Blacks in something, and I knew I was representing my people. This is not unusual for conscious thinking People Of Color even if they’re Hispanic, Asian, or other. You know damn well that you’re this Colored person there and you’re competing with these White People, and you become highly aware of yourself there representing your race. Now if the situation was turned around and some White Male or Female entered into a heavily dominated Colored Competition, be it entertainment or sports or whatever, you better believe that those dark ethnics **notice you** and are wondering what the hell is he or she doing here. And you know what White boy or girl? You better bring it. You better be just as good or better representing your people bringing some kind of honor so they can be proud of you back home, because you had a right to be there and you won, or came close to. And I’m proud to say that in my case back in the day, being the only Black from my District submitting for things and winning, and coming up on people’s radar, made me even more aware of race, social status, and politics early in my life. And I made sure I looked nice in my outfit, spoke properly, carried myself well, and did the right things. It also helps when you have parentage or other Mentor educating you about race & prejudice, and giving you the pep talks you need to hear, to see yourself through it. That’s why some of the stuff I say sometimes against people coming at me, is all a part of an intellectual arsenal I use in dealing with bigotry. Your repertoire of defense needs to be developed no matter what race or culture you are when you’re out there, because you’ll run into some racialism. If I was a White person dealing with a Black Prejudice person barking at me, I would know what to say also. And sometimes what pops out of my mouth or what I type back to somebody might sound racist, but hey, you started it first, and biting back at you is just a game to me. Now I say all this just to make a point. With Simone Biles’ situation, we’ve seen something like that before concerning Gabby Douglass, another dynamic Black Female Gymnast who was dealing with race issues behind the scenes. They were both surrounded by White Trainers in a White World who along with other Caretakers, failed to protect them from sexual molestation at the hands of an approved Doctor as I described [**here**](https://ferrelux.com/2018/07/21/raping-olympic-kids/), but they were also unequipped to mentally and emotionally reach those young Black Women in the right encouraging way. Now if both Gabby and Simone had Kobe Bryant or some other Black Big Brother or Sister continuously talking to them, **like how we know to**, those young ladies would have had a similar message told, that was reinforced in me at a young age, and they would be seeing that White World and themselves in it through a different lens. This is true for Hispanics, Asians, Indians, Arabs, etc. Such encouragement is very important. It protects you from pressure and feeling the weight of the world on your shoulders. Instead, you would be realizing that your ethnic ass got up somewhere because you are that good, and you are the only one there, and you know what, you are competent enough to beat those people and win that prize. And somewhere in your head along with the other things you’re telling yourself, you’d know that **you are The Greatest**.

\*\*\*\*Sign,  
\*\*\*\***Lhisa MrklonAlways A Top Contender\_\_\_\_And Sometimes Champion\_\_\_\_Competing In Certain Things**

### Should Simone Biles Have Competed In The 2020 Tokyo Olympics? Scroll Down And Leave Your Reply Below.

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192824224/sioVl9Vzh.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192826156/Q0-TqOwiv.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192827714/VQuq3e6on.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192829005/yVhW6nhv7.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192830295/TLVDQpLJ9.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192832571/TRtCI6Isg.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192834385/DVPAjihaL.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192835729/iKtwee8wq.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192836916/daxq81ger.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192838166/XwpP-zqWN.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192839556/N99e4-xuX.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192841222/9JVbEJF4F.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192842693/7-XwLTzzS.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192844106/RZ1nGDOY4.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192845545/fENUVS8tD.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192847112/0GWW3zl3l.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192848837/hxyb3Wqsd.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192850703/TomT9KT8R.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192852315/0oYhuvihO.png align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192854183/8GBd7bAk6.png align="left")](https://ferrelux.com/adverts/)
