---
title: "\U0001F3AACharlottesville’s Confederacy\U0001F3C1"
date: '2017-08-18T17:10:20.000Z'
slug: charlottesvilles-confederacy
tags:
  - general
  - trump
  - hate
  - america
  - death
  - movement
  - new-york
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195768095/O10Dam3tU.jpeg
canonical: 'https://ferrelux666.wordpress.com/2017/08/18/charlottesvilles-confederacy/'
---
[![n-REVOLUTION-FIST-628x314](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195757338/NvWuglyp0.jpeg align="left")](https://www.dailymotion.com/search/The%20Black%20Panthers%201960s/videos)

**Odium Est Deformitas Animae 👺 Hate Is An Ugliness Of The Soul**

**The White Supremacists raised their ugly head again, this time in a Charlottesville, Virginia march that took place Saturday August 12th 2017. Obviously a rally like this coming to a town near you in front of Black people, wouldn’t end peacefully. The person behind this White Nationalist nonsense was Jason Kessler. You can read more about him here  
(** [**https://www.splcenter.org/fighting-hate/extremist-files/individual/jason-Kessler**](https://www.splcenter.org/fighting-hate/extremist-files/individual/jason-kessler) **)**

**Now, bright people THINK before they act. Once again their White Power thing backfired. Let’s look at the last time something happened, when there was talk about removing The confederate flag from government places, monuments, stores etc. Society was s-l-o-w-l-y moving towards that idea until the ‘Alt-Right’ kept pushing their luck. A Brave Black Activist, Bree Newsome, climbed a flagpole in front of the Statehouse in Columbia, S.C. on June 27th 2015 & this event was seen live on TV, moving the hearts of Black People everywhere. Here’s a woman who took action, while closet racists White Officials were sitting around legally deciding if it was racist to keep the flag displayed on government property. Eventually they decided to remove it due to ALL the media attention, really.  
(** [**https://splinternews.com/bree-newsome-a-year-after-charleston-we-still-need-to-1793857618**](https://splinternews.com/bree-newsome-a-year-after-charleston-we-still-need-to-1793857618) **)**

**The ‘Alt-Right’ attracted the counter-march of the ‘Black Lives Matter’ movement. And racist ass David Duke just had to be there supporting the ‘Unite The Alt-Right’ Movement, to no avail because the backlash came when one of their own racists, James Alex Fields, Jr., wound up driving his car into a crowd of protesters in attempt to kill Black people, but only succeeded in injuring a portion of the crowd and ultimately ending the life of an innocent young White Woman, named Heather Heyer, whose death was felt by The Nation. She became the cause celebre for the individual State leaders like Gov. Andrew Cuomo from New York & others, to answer the injustice by REMOVING the racist statues of Confederate Army Generals Robert Edward Lee & Thomas Jonathan “Stonewall” Jackson from government places, etc. about the city & making VERY public statements about racism & that ugly incident in Charlottesville.**

**NOW,…….had the racist idiots just kept their behind shut, & move on with life, they still would have had the cities around America populated with their racist stuff still. No one was noticing or paying attention to that shit around them because it was historical stuff reminding people of how far we came from the past. But when you keep tickling hatred, reminiscing about some racist past time period, THE PEOPLE react by doing away with the last remnants. Now their bigot world is getting smaller & smaller & smaller…………………….**

**MUAHAHAHAHAHA!!!**

**Some Articles On The Incident**  
**(**[**http://www.aljazeera.com/news/2017/08/charlottesville-attack-170813081045115.html**](http://www.aljazeera.com/news/2017/08/charlottesville-attack-170813081045115.html)**)**

**(**[**http://www.foxnews.com/us/2017/08/17/jason-kessler-charlottesville-rally-organizer-says-  
hes-in-hiding.html**](http://www.foxnews.com/us/2017/08/17/jason-kessler-charlottesville-rally-organizer-says-hes-in-hiding.html)**)**

**Sign,**  
**Lhisa**

### Do You Agree With The Perceived Racist Statues Being Removed? Scroll Down And Leave Your Reply Below.

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195758983/QY6zdYMss.jpeg align="left")

CHARLOTTESVILLE,VA-AUG11:Chanting White lives matter! You will not replace us! and Jews will not replace us! several hundred white nationalists and white supremacists carrying torches marched in a parade through the University of Virginia campus last night. Beginning a little after 9:30 p.m., the march lasted 15 to 20 minutes before ending in skirmishing when the marchers were met by a small group of counterprotesters at the base of a statue of Thomas Jefferson, the universitys founder. (Photo by Evelyn Hockstein/For The Washington Post via Getty Images)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195760596/sOQxGRaX-.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195762230/r0TXBtyyV.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195763774/JxEEvTc2r.jpeg align="left")

Two young black men pass Klan marchers in downtown Salisbury, N.C., August 1964. The Ku Klux Klan was active in North Carolina, and Sturkey covered many of their demonstrations.

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195766627/P2xbMTQV6.png align="left")](https://ferrelux.com/adverts/)
