---
title: "The Raptors Win (2019)\U0001F341\U0001F3C0\U0001F309"
date: '2019-06-21T23:29:11.000Z'
slug: the-raptors-win-2019
tags:
  - game
  - toronto
  - score
  - sports
  - entertainment
  - american
  - basketball
  - california
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672194990222/fDjHPiFNd.png
canonical: 'https://ferrelux666.wordpress.com/2019/06/21/raptors/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194965565/FDNfFRGUD.jpeg align="left")](https://www.ferrelux.us/)

[Kurtis Blow ~ ‘Basketball’](https://myspace.com/kurtisblow3/music/song/basketball-67753-108886709?play=1)

*Optimis Optimus* 🐍 *The Best Of The Best*

‘Let’s go Raptors!’ as the chant goes. When people were expecting Golden State Warriors to win from before the game even started, I predicted The Raptors, and I was right……I was right. My Reptilians should have won in game 5 in their home stadium in Canada, but made the callous mistake of not using a play in their favor instead, and The Warriors caught up the score and won by 1 point. I got nervous! My boys still won in game 6 of course. It was a great set of games. OMG! The best of the best players going at it point after point. If Kevin Durant (The Warriors) didn’t get injured again and played in game 6, we would have see a game 7. Remember in game 5, Durant, scored 11 points in the space of 12 minutes for the Warriors while playing injured against the wishes of his Doctors. The omens were in the favor of the Raptors though, especially with that movie, ‘Godzilla’ out. I’m proud of both teams. The Golden State Warriors have nothing to be ashamed of. They did everything in their power to retain their title championship with the typical cheating, trying to pull a fast one, and just playing nasty, but The Toronto Raptors were prepared for it. The Warriors, even at the last minute when the Raptors won, they called a technicality hoping the player didn’t make the shot in the basket again, but he did, and re-won for the team. So Canada now holds the Basketball Titleship and plans on retaining it for a long time.

\*\*Sign,  
Lhisa 666  
\*\*

SOME LINKS  
[https://en.wikipedia.org/wiki/Kevin\_Durant](https://en.wikipedia.org/wiki/Kevin_Durant)  
[https://en.wikipedia.org/wiki/Stephen\_Curry](https://en.wikipedia.org/wiki/Stephen_Curry)  
[https://en.wikipedia.org/wiki/Toronto\_Raptors](https://en.wikipedia.org/wiki/Toronto_Raptors)  
[https://www.nba.com/raptors/](https://www.nba.com/raptors/)

[![untitled](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194967300/2FpkTDb4G.png align="left")](https://ferrelux666.wordpress.com/untitled-10/)

[![Ferrelux Homepage_RaptorsVsWarriors_6-21-2019](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194968693/jbsFcf84b.png align="left")](https://ferrelux666.wordpress.com/ferrelux-homepage_raptorsvswarriors_6-21-2019/)

[![UNW2ENPARFDL7AXGBHIMKAQIYI](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194970112/zFVuCZj0I.jpeg align="left")](https://ferrelux666.wordpress.com/unw2enparfdl7axgbhimkaqiyi/)

[![warriors_header](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194971429/4D5cr6z09.jpeg align="left")](https://ferrelux666.wordpress.com/warriors_header/)

[![Why_the_Raptors_are_gonna_win.0](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194972681/knUMNqs2y.jpeg align="left")](https://ferrelux666.wordpress.com/why_the_raptors_are_gonna_win-0/)

[![the-raptors-win-and-canada-learns-to-swagger__499401_](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194974303/5pXuER0nB.jpeg align="left")](https://ferrelux666.wordpress.com/the-raptors-win-and-canada-learns-to-swagger__499401_/)

[![RaptorsFronts-4-1024x576](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194975615/ZQsqk_RRK.jpeg align="left")](https://ferrelux666.wordpress.com/raptorsfronts-4-1024x576/)

[![NBA-finals](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194976960/DEFOGw_u1.jpeg align="left")](https://ferrelux666.wordpress.com/nba-finals/)

[![lebron-james--35f7b9e4528a584a](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194978563/c1S3LVDVi.jpeg align="left")](https://ferrelux666.wordpress.com/lebron-james-35f7b9e4528a584a/)

[![OAKLAND, CA - DECEMBER 25: LeBron James #23 of the Cleveland Cavaliers looks on as he walks off the court against the Golden State Warriors during their NBA basketball game at ORACLE Arena on December 25, 2015 in Oakland, California. NOTE TO USER: User expressly acknowledges and agrees that, by downloading and or using this photograph, User is consenting to the terms and conditions of the Getty Images License Agreement. (Photo by Thearon W. Henderson/Getty Images)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194979896/VI3VjOzgR.jpeg align="left")](https://ferrelux666.wordpress.com/cleveland-cavaliers-v-golden-state-warriors/)

OAKLAND, CA – DECEMBER 25: LeBron James #23 of the Cleveland Cavaliers looks on as he walks off the court against the Golden State Warriors during their NBA basketball game at ORACLE Arena on December 25, 2015 in Oakland, California. NOTE TO USER: User expressly acknowledges and agrees that, by downloading and or using this photograph, User is consenting to the terms and conditions of the Getty Images License Agreement. (Photo by Thearon W. Henderson/Getty Images)

[![970199346.jpg.0](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194981317/DM080_iGe.jpeg align="left")](https://ferrelux666.wordpress.com/970199346-jpg-0/)

[![3-Reasons-the-Raptors-can-dethrone-the-Warriors](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194982590/MpGfGEamc.jpeg align="left")](https://ferrelux666.wordpress.com/3-reasons-the-raptors-can-dethrone-the-warriors/)

[![5d03b7476fc9201ebf6f89b4-750-375](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194984288/1Gdl7hSDPR.jpeg align="left")](https://ferrelux666.wordpress.com/5d03b7476fc9201ebf6f89b4-750-375/)

[![1200px-Toronto_Raptors_logo.svg](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194985896/ZUAbxz7Km.png align="left")](https://ferrelux666.wordpress.com/1200px-toronto_raptors_logo-svg/)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194987272/bCgCFVizn.png align="left")](https://ferrelux.com/adverts/)
