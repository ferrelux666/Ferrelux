---
title: "\U0001F4A5Texas Church Shooting 2017❌"
date: '2017-11-13T19:29:21.000Z'
slug: texas-church-shooting-2017
tags:
  - culture
  - guns
  - texas
  - united-states
  - america
  - death
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195669934/WZodVF1Pt.png
canonical: 'https://ferrelux666.wordpress.com/2017/11/13/texas-church-shooting/'
---
[![Texas Church Shooting Victims](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195662034/xQ8lFeCtd.jpeg align="left")](https://www.dailymotion.com/video/x67ztr7)

**Faber Est Suae Ouisque Fortunae 😠 Each Man IS The Smith Of his Own Fortune** *(Appius Claudius Caecus)*

\*\*  
Oh it has happened again. Somebody crazy was able to obtain a rifle under the nose of the governing authorities and took out his aggression on innocent people. When are they going to get it together in identifying these cases before they happen? The problem is the gun culture. From its conception, America has always been about your guns. From your Prairie family, to the Cowboys at the Saloon, to your modern day Gangsters. Guns are a thing. So while you are addressing community safety, you’ll need to address the culture of gun ownership too with the people who have it in their blood to shoot.\*\*

**Here’s some footage on it…**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/Lu2vRl0FzZY?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/6IcibfHTJg0?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/WbVGexuuzyg?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/xzZk_FabF-E?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/vIgCK4u7vWo?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195664000/71Sv5r1Mq.png align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195666059/YewPEti2z.png align="left")](https://ferrelux.com/adverts/)
