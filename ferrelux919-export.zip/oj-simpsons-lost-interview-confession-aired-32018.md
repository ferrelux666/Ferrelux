---
title: "OJ Simpson’s Lost Interview Confession (Aired 3/2018) \U0001F910\U0001F61F"
date: '2018-12-14T19:10:36.000Z'
slug: oj-simpsons-lost-interview-confession-aired-32018
tags:
  - trump
  - celebrity
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195284022/X21nspjrU.jpeg
canonical: 'https://ferrelux666.wordpress.com/2018/12/14/oj/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195280019/82zMtRlPl.png align="left")](https://www.ferrelux.us/)

**What is one of the most memorable moments that stands out in 2018. Well…………………….’If I did it, this is how I would do it’ O.J said in reference to a book he wrote back in September 2007 with such title based on his ‘fiction’ of committing the murder of his ex-wife Nicole Brown Simpson & her friend Ron Goldman. Around that time too, Trump was NOT president, he was still doing ‘Celebrity Apprentice’ when OJ was marketing his book & Trump wanted him on the show in 2008 & public outcry squashed that. Since then, we don’t expect to hear any new shocking info about a dead story concerning OJ, UNTIL…….channel 7 aired a 2016 special in favor of The Goldman Family showing OJ’s guilt while he was being interviewed & interrogated by police etc. It was a convincing piece because if you were on team OJ, it made you doubt his innocence, but you also got to see the pain of the Goldman’s & the hate as some of the commentaries against OJ was racial. He however, kept his responses to script with nonchalant gestures that showed callous indifference. So as time went on, we don’t expect to see anymore of this. I mean what more can you milk out of it. WELL… as it turns out, HE DID IT, atleast in the latest version of things. What you can get out of it is that somewhere over the many years guilt got a hold of him to be still thinking & talking about it with such anger. They had already broke up, nothing further should have come from them, but yet the murder happened. Many have speculated that the murder may have been related to drug activity because of drug use with Faye Resnick over unpaid drugs, or a homeless person was responsible for randomly targeting them, & so forth. One detective went as far as to say it was OJ’s deranged son, Jason Simpson and OJ was just covering up the murder to protect him. That theory still holds water when you wonder who the ‘other guy’ OJ says he was with. Some thought it was Al Cowlings, but he was ruled out as a suspect by police. Some people still believe that the way the crime scene looked, there were 2 people involved. If OJ had an alter-ego as some think he’s referring to in the video, then I guess IT got out to make the crime scene seem like 2 people were there, but whoever the mystery person is, still remains at large. The theory that it could be his son Jason, has not been disproven, especially when we know he was upset with Nicole for cancelling dinner reservations in favor of Ron Goldman’s restaurant. OJ’s son was very close to Nicole & some say perhaps too close. Others have suggested that Nicole was ‘too loose’. Well, if that were so, her murder should never had happened, just move on, leave her alone. Instead of looking to justify the killing, it would make more sense to disprove OJ as the killer, as some still believe he is innocent despite his hypothetical admission, BUT we have no further clues to date other than speculations.**

**SOME LINKS ON OJ’s SON BEING THE KILLER**  
[OJ’s Son Jason Killed Nicole](https://blacksportsonline.com/2016/04/5-reasons-why-its-likely-ojs-son-jason-killed-nicole-ron-goldman/)  
[Jason Simpson Saw The Murder Of Nicole Brown](https://radaronline.com/exclusives/2018/04/thomas-scotto-claimed-oj-simpson-son-jason-simpson-saw-nicole-brown-simpson-murdered/)

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/PWJjkvSSm_A?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/GPmG5TMAaGA?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/5_hqAJ26OF0?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/kCwMARo94QY?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

**SOME MORE LINKS  
**[**OJ’s Book: If I Did It**](https://en.wikipedia.org/wiki/If_I_Did_It)

[Back When Trump Wanted OJ On Celebrity Apprentice](https://money.cnn.com/2016/10/12/media/donald-trump-oj-simpson/index.html)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195281309/cvk2zw1hT.png align="left")](https://www.ferrelux.biz/)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195282724/cmkpXm0U1.jpeg align="left")](https://ferrelux.com/adverts/)
