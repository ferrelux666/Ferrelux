---
title: "2017 \U0001F63D\U0001F63BValentines"
date: '2017-02-06T21:24:28.000Z'
slug: 2017-valentines
tags:
  - love
  - heart
  - passion
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195980284/NYPTakFmt.png
canonical: 'https://ferrelux666.wordpress.com/2017/02/06/valentines2017/'
---
![celtic-knot-triquetra-heart-nordic-symbols-mens-slimfit-longsleeve-shirt](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195973709/8iwjWywIv.jpeg align="left")

**Here are 3 videos I gathered to get you in the mood.**

**Playful Competition………**  
[http://www.youtube.com/watch?v=2fW5Z2z6pXM](http://www.youtube.com/watch?v=2fW5Z2z6pXM)

**Strange Passion: Ares & Xena**  
[http://www.youtube.com/watch?v=T3503AHyPCc](http://www.youtube.com/watch?v=T3503AHyPCc)

\*\*You Gotta Love This Guy  
\*\*[http://www.youtube.com/watch?v=dox5G0lmZNA](http://www.youtube.com/watch?v=dox5G0lmZNA)

**Sign,**  
**Lhisa**

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195974922/LcnxKkx_K.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195977364/_vzCcg3IO.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195978612/gCSgjSd6a.jpeg align="left")
