---
title: "Christmas 2017 \U0001F389\U0001F381\U0001F384"
date: '2017-12-22T18:13:20.000Z'
slug: christmas-2017
tags:
  - music
  - performance
  - apollo
  - entertainment
  - christmas
  - celebrity
  - xmas
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195641841/SeF4C1AKU.png
canonical: 'https://ferrelux666.wordpress.com/2017/12/22/christmas-2017/'
---
[![merry-christmas-happy-new-year-2017-decoration](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195635660/YvfclQffU.jpeg align="left")](https://www.dailymotion.com/video/x6c477k)

**Pax Vobiscum 🧡 Peace Be With All Of You**

**HAPPY HOLIDAY’S Y’ALL**

**Highlighting special performances this year from both Steve Harvey’s Apollo Christmas Special & Taraji P. Henson’s White Hot Holidays.**

**Here’s DMX’s Performance…………….**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/wvWGR9G_hVc?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

**And 5th Harmony…………………………**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/AIIy8Fuj6Tg?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

**CIARA…………………………………………………**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/bw_ob5GFi6I?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

**FERGIE………………………………………….**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/tQQ_VsRTc20?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

**FERGIE & JUSSIE SMOLLET……………..**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/58l2WSapzxY?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

**The Melisizwe Brothers at the Apollo………**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/3xRwXEZyMzw?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195637460/oOtBh8D8_.png align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195639044/idIkZZkmw.png align="left")](https://globalacn.org/business-grants/?ref=Ferrelux)
