---
title: "\U0001F9712022 Start Off Topics & Updates\U0001F623"
date: '2022-01-24T06:33:44.000Z'
slug: 2022-start-off-topics-and-updates
tags:
  - news
  - announcements
  - trump
  - google-maps
  - google
  - business
  - public
  - doj
  - gmail
  - services
  - women
  - update
  - war
  - products
  - adword
  - uncategorized
  - crime
  - politics
  - google-ads
  - child
  - korea
  - ukraine
  - topics
  - children
  - biden
  - russia
  - fraud
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672192131764/R5HV9W73Q.jpeg
canonical: 'https://ferrelux666.wordpress.com/2022/01/24/2022-topic-updates/'
---
[![Negative news headline](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192098146/rUQ3U0IPl.jpeg align="left")](https://rumble.com/search/video?q=Russian%20%26%20Ukraine)

<iframe width="100%" height="100" src="https://w.soundcloud.com/player/?url=https%3A%2F%2Fapi.soundcloud.com%2Ftracks%2F251343373&auto_play=false&hide_related=false&visual=true&show_comments=true&show_user=true&show_reposts=false&color=ff5500"></iframe>

[John Lennon](https://soundcloud.com/john-lennon-official) · [Imagine (Remastered 2010)](https://soundcloud.com/john-lennon-official/imagine-2010-remaster)

**Bellum Venit 🚀 War Is Coming**

**Google Ads, Maps, Business Listing**

Notice the sidebar image & link. I’ll keep you posted on that as we move on. For now, do your own due diligence on the several cases out there against them, and why. It might affect **\_***YOU***\_** also, and your bad experience with Google’s products & services might also be significant.

**Russia Invading Ukraine**

The world is bracing for this impending attack at a time where things are already difficult.

**South Korea Wanting Taiwan Back**

When stuff like this takes off, and a pending war strategy looks like it will work, then another nation only naturally would wish to try the same thing in the future.

**Trump & His Kids In Trouble**

Well, you know how it goes. The attacks keep coming until you win.

\*\*\*\*Matt Gaetz, U.S Representative For Florida

---

You all should know that he was able to prove the allegations were false. He was really the target of an extortion plot, however much of the public didn’t seem to care about his redemption. Now a new scandal is brewing, but it’s much of the same stuff from last year again.

**Andrew Cuomo, Ex-Governor Of New York**

I was glad when I heard that he won. They dropped that sexual harassment case against him due to insufficient evidence to keep pursuing him, however, they’re looking to get him on the public funds he allegedly used to write his book. And poor Chris Cuomo forced to testify. He shouldn’t have gotten fired by CNN and replaced by Jesse Watters, but right now he’s bigger than them though.

**The Queen’s Last Jubilee?**

Her Majesty of England is dealing with so much at 96 years old. Send out your good thoughts and good vibes.

**Prince Andrew In Trouble**

You know, back in regal times you had Courtesans who tended to the sexual needs of Royals, and if you were favored, you had it made for life unless you played yourself. In today’s time, that lifestyle is best enjoyed by The Common Man. It can be argued that those females trying to hold him accountable isn’t realizing that their life could have been more tragic than it was. I mean, unlike some other homeless females out there on drugs, turning tricks in the streets with low or no pay and the possibility of abuse and death, they got a chance to meet a High Society Lady name Ghislane Maxwell who took them off the streets and into the lap of luxury, living the life and can continue to do so under certain conditions that they apparently agreed to. And at no time in those many happy photos do we see pain or reservation expressed in their face or eyes. That many years later, they can now come out of the wood-works and make extra-ordinary claims, and gain and gain and gain from it, eventually causing the death of Jeffrey Epstein & the imprisonment of Ghislaine Maxwell, as well as the embarrassment and practical dethroning of a Prince. All formerly respectable people who provided, and seemingly handled them with care. Now, they couldn’t have done that with a Pimp, or a Thug, or a Dirty Cop.

**Justice For The Female Olympians**

Larry Nassar, the Doctor who raped U.S Gymnasts for decades, will spend the rest of his life behind bars. A $380 Million Settlement for the Survivors was reached.  
[https://nypost.com/2021/12/13/larry-nassar-victims-to-receive-380m-in-sex-abuse-settlement/](https://nypost.com/2021/12/13/larry-nassar-victims-to-receive-380m-in-sex-abuse-settlement/)

[https://www.cnn.com/2021/12/13/us/larry-nassar-gymnastics-settlement/index.html](https://www.cnn.com/2021/12/13/us/larry-nassar-gymnastics-settlement/index.html)

[https://www.the-sun.com/news/3667124/where-is-larry-nassar-now/](https://www.the-sun.com/news/3667124/where-is-larry-nassar-now/)

[https://www.cnn.com/2021/07/29/us/larry-nassar-court-payments-motion/index.html](https://www.cnn.com/2021/07/29/us/larry-nassar-court-payments-motion/index.html)

**Some Notable Deaths**

So we recently lost Comedian Louie Anderson, and Rocker Meatloaf, Fashion Designer Andre Leon Talley, Actor Sidney Poitier, and a few others, and the year just started.

**Sign,**  
**Lhisa Mrklon**

**Should America Care Too Much About Russia’s Impending Invasion Of The Ukraine, When The European Union Cares More About Their Oil Agreement With Russia. Scroll Down And Leave Your Reply Below.**

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192100292/Q6IhZFaO7.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192102078/wBYLmY5bD.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192103615/AUawXu7Pu.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192105377/bxKnOSwb8.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192106809/tw5NXd67Y.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192108142/sM_iUsYMC.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192109361/w-1OCk7Xo.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192110665/ccLbRwTYK.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192112097/T6HsceMCV.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192113711/v2EF5hlZZ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192115170/step6XTtS.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192116672/kNUjpk5x7.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192118121/DdcCWdkFt.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192119933/nV9UuoCFv.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192121784/l7TvBOFvT.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192123034/_0wCOdQl9.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192124334/G0L0OEH11.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192125926/cTKhJkagO.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192127217/6rDeUZv7w.jpeg align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192128876/YoqTxu8hP.jpeg align="left")](https://lightinthebox.tv2h87.net/c/3170166/898314/8199?prodsku=7875205&u=https%3A%2F%2Fwww.lightinthebox.com%2Fneon-light-el-wire-for-automotive-car-interior-decoration-flexible-car-interior-lighting-led-strip-garland-wire-rope-tube-line-neon-light-with_p7875205.html&intsrc=PUI2_7096)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192130297/iQM1Q5JRq.jpeg align="left")](https://miniinthebox.8zwg.net/c/3170166/461413/8200?prodsku=6621873&u=https%3A%2F%2Fwww.miniinthebox.com%2Fsmart-bracelet-heart-rate-monitor-pedometers-call-reminder-message-reminder-pedometer-fitness-tracker-activity-tracker-sleep-tracker_p6621873.html%3Fcurrency%3DUSD&intsrc=PUI2_2952)

### Like this:

Like Loading...

### *Related*
