---
title: "Avengers: Endgame (2019) (Review/Spoiler) ☄\U0001F300"
date: '2019-06-06T20:18:46.000Z'
slug: avengers-endgame-2019-reviewithspoiler
tags:
  - review
  - movie
  - comics
  - thanos
  - avengers
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195025902/_qwfiEDBo.png
canonical: 'https://ferrelux666.wordpress.com/2019/06/06/endgame/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194996977/dqQgg3znT.jpeg align="left")](https://www.ferrelux.us/)

[Led Zeppelin’s ~ ‘Battle of Evermore’](https://myspace.com/ledled.zeppelin/music/song/the-battle-of-evermore-108904686-122891937?play=1)

*Ferrum Homo, Vindex Quis Moritur*  ☣  *Iron Man, The Avenger Who Dies*

Awh Man! I’ve got huge spoilers here. I believe I waited long enough to really say what I want, so if you didn’t see the film by now, turn away. Let me start by honoring the late great Stan Lee, who we still see a cameo appearance of in the film. His mind was so great in coming up with these Marvel characters. Okay so, personally, I preferred the first part of this 2-part movie; ‘Avengers: Infinity War’ was way better. For me, ‘Avengers: Endgame’ turned out to be what I hoped not to happen. When you set up a mythic problem because you outthought yourself, it becomes a monumental challenge to rethink something plausible. What do I mean, well……. they had setup a big conundrum where Thanos got all the Infinity Stones and now had the kind of power that would make him unstoppable. So we’re thinking about scenarios that might work to defeat him, and after I saw this film, I liked other peoples’ ideas better including my own. While people were busy thinking The Avengers were the only ones that could stop him, I was considering other notable heroes in The Marvel Universe. It would be an entirely different movie if you involved the X-Men, Fantastic Four, etc. since what Thanos did would affect them as well. Of course, there is a mystery being in The Universe people forgot about called The Beyonder, that would have seen the whole thing coming and could single-handedly stop it or just make an event of it using the noblest heroes, him already knowing how it would all end. Plus, I thought as much that the Writers, would need to scale down the might of Thanks’ character in a way so they can defeat him. None of it came off believable to me. The movie came off like how you would expect a corny good guy come-back. If you have all that power, I don’t think you would want to give it up. We are led to believe that Thanos had to destroy the stones to so that he saves himself from being destroyed by them, plus by destroying them, he and all he did prior is inevitable. Well, what’s wrong with this is that he absorbed the jolt of power originally being a Demi-god and was fine using it many times well into the film that our heroes have a way of clocking the last time he used the stones and can pinpoint where in the galaxy he is. So we see a humble looking Thanos living his hobbit-like life until The Avengers crash into him and Thor finally does what he failed to do the first time, aiming for his head. Big deal! Later we see the Mighty Thor being a potbelly, beer drinking couch potato bum. Thanos should not have ended like that. He’s supposed to be on his throne chillin’, but this is good guy must win nonsense when the first time around when it mattered they failed miserably. When the film opened with Iron Man and the camera focused too long on him, all up in his face with the emotional shots, I said to myself, ‘oh no, are you really going to make this about him’. Well, in the first film, Thanos tried to kill him successfully until Doctor Strange gave up his Infinity Stone to save his life. Now you can debate in your mind at what point with which stone or stones Thanos had at any given point of both movies, but for me, while watching the film, and thinking of the movie days after, I still have problems with it. THANOS, SHOULD NOT HAVE LOST! He had all the information to stop them at any point. He would have to voluntarily give up his power for the greater good, and we know that wouldn’t make sense for him. So as I watched this bullshit, I cringed. A quirk of fate, makes it possible for Antman, who was trapped in a storage unit, to escape and come up with the idea of going back in time the way he does, using quark nano-technology. So the Incredible Hulk uses his scientific brain to put together a time machine. Iron Man, who already has a new married family life he does not want to lose, eventually falls sway to the rest of the team to try to stop Thanos in the past. And we are to believe that they are able to do what the greatest scientific minds have been unable to do by precisely creating a time machine on such short notice to end up at precise moments in history and return to the present time safely. Well, even if they were such geniuses, Thanos, being able to see all future scenarios as well, would have seen that coming. The Writers only allowed a little mistake in there where no matter how smart the superheroes were, they neglected to think that a super android was dangerous to send back into the past because anything could go wrong. Nebula got captured and Thanos learned about the time stamp events from the future. Right there, the whole thing should have got shut down with just the couple stones he had, but here, he’s thinking like someone without the power playing games. This allowed Gamora and the future Nebula to teamup. We see a lot of female heroic action until Captain Marvel got punched in her face by Thanos. So to cut a long story short, the one move to save them all was Iron Man offering his life in that epic battle. He got the gauntlet off Thanos and did his own Infinity snap bringing back Black Panther (Ebombeh!), and other previously dead heroes. Then he used the power to get rid of Thanos and his dark legions. Listen man, Thanos did the decimation snap better. Like the Infinity Stones he so-called destroyed, the nano-particles are still in the universe, so you can’t completely eradicate evil. Then we see the funeral of Iron Man, his mortal body being destroyed by the power, and a briefcase filing away of the time machine technology. Ofcouse, Captain America was going to use it to have a romantic life with Agent Carter, why not, it was his only chance. And he gave away his super-action name to a Black guy to be the new Captain America. Hmmm, I would have preferred he had his own super identity. Iron Man didn’t have to die. This idea is coming from a concept of a sacrificed hero, well, it was possible to have done the whole thing where no one needed to die. The movie could have been done better. I remember the reaction the first time around at the end of Part 1 with movie-goers being sad and awe-struck at the end but in wonder and excitement to see Part 2. Now that we got the cookie-cut good-guy ending, the intrigue doesn’t feel the same. It was lacking something; that once and for all tone. If by any chance, I would like to see Thanos and Friends resurrect. Let’s have a proper battle. One with an outcome we can all agree with.

Lhisa Mrklon,  
Emissary of Fate

[![Ferrelux Homepage_AvengersEndgame6-2019](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194998172/zu6Uk0N0D.png align="left")](https://ferrelux666.wordpress.com/ferrelux-homepage_avengersendgame6-2019/)

[![untitled (3)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194999715/FtmIwER6Q.png align="left")](https://ferrelux666.wordpress.com/untitled-3-2/)

[![untitled](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195002066/iVncH0xAm.png align="left")](https://ferrelux666.wordpress.com/untitled-9/)

[![nrave3kiwyeambtdtkqv](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195003364/6pq8-wcV8.jpeg align="left")](https://ferrelux666.wordpress.com/nrave3kiwyeambtdtkqv/)

[![Nebula-EndgameProfile](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195004683/A8twuerIS.jpeg align="left")](https://ferrelux666.wordpress.com/nebula-endgameprofile/)

[![mv5bzme5otriyjutyzaznc00mwy3ltkyy2mtmgy0zmq3mtuzzmi0xkeyxkfqcgdeqxvynzk3nduzntc.v1_sx1777_cr001777935_al](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195006086/p1ViRoAtI.jpeg align="left")](https://ferrelux666.wordpress.com/mv5bzme5otriyjutyzaznc00mwy3ltkyy2mtmgy0zmq3mtuzzmi0xkeyxkfqcgdeqxvynzk3nduzntc-_v1_sx1777_cr001777935_al_/)

[![untitled (2)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195007642/zzSmSvLRG.png align="left")](https://ferrelux666.wordpress.com/untitled-2-2/)

[![thanos_avengers__endgame_by_barongraphics_dd6imfg-pre](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195008883/H-HhbIaSj.jpeg align="left")](https://ferrelux666.wordpress.com/thanos_avengers__endgame_by_barongraphics_dd6imfg-pre/)

[![online_char_avengehonor_series_nebula_v1_lg_1](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195010449/ZeUKctGkr.jpeg align="left")](https://ferrelux666.wordpress.com/online_char_avengehonor_series_nebula_v1_lg_1/)

[![ironman-spiderman-homecoming-poster-frontpage-700x354](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195011675/u5XHxZDmz.jpeg align="left")](https://ferrelux666.wordpress.com/ironman-spiderman-homecoming-poster-frontpage-700x354/)

[![https___hypebeast.com_image_2019_02_avengers-endgame-costume-leak-orville-redenbacher-1](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195012995/OwDZNzoWr.jpeg align="left")](https://ferrelux666.wordpress.com/https___hypebeast-com_image_2019_02_avengers-endgame-costume-leak-orville-redenbacher-1/)

[![Avengers-Endgame-Thanos-Warning-Josh-Brolin](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195014205/YSb-Cdt2c.jpeg align="left")](https://ferrelux666.wordpress.com/avengers-endgame-thanos-warning-josh-brolin/)

[![a_main](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195015470/fu4qG9DCf.jpeg align="left")](https://ferrelux666.wordpress.com/a_main/)

[![17258_avengers_endgame_-_thanos](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195016943/irO_L3Kxg.jpeg align="left")](https://ferrelux666.wordpress.com/17258_avengers_endgame_-_thanos/)

[![185903-01](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195018421/2gQUCMvI-.jpeg align="left")](https://ferrelux666.wordpress.com/185903-01/)

[![551541](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195019896/UzN_wgEhY.jpeg align="left")](https://ferrelux666.wordpress.com/551541/)

[![1522872239-aif18](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195021792/tfxjyiobJ6.png align="left")](https://ferrelux666.wordpress.com/1522872239-aif18/)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195023877/qNozcGmhU.jpeg align="left")](https://ferrelux.com/adverts/)
