---
title: "\U0001F30A Aquaman & The Lost Kingdom (Review)"
date: '2024-02-08T18:29:43.294Z'
slug: aquaman-the-lost-kingdom-review
tags:
  - fbi-agent
  - avenatti
  - black-manta
  - ocean-master
  - aquaman-2
  - movies
  - amber-heard
  - february
  - '2024'
  - leap-year
  - marvel
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1707907521902/9dd54e7a-745b-47b4-8a79-919b8a5ed57d.jpeg
---
**🚢 Pone Duas Naves In Mari Aperto, Sine Vento Aut Fluctus, Et Denique, Illi Venite Simul ⚓ Put Two Ships In The Open Sea, Without Wind Or Tide, And, At Last, They Will Come Together 🛳️**\*(Aquaman / but originally Jules Verne)\* 🔱

**🎶**[**Black Manta Theme By Rupert Gregson-Williams**](https://www.youtube.com/watch?v=RNjKGFTap-A)

If you haven’t seen the film yet, there are spoilers, so go see it before it leaves Theaters. I waited till February to do this story so it matched up for **Valentines Day**, plus my topics last year was already in a sequence I did not want to ruin. This **Aquaman 2** follow-up movie released Friday December 22, 2023 was great, it would have been even better in my mind had 2 things occurred. **One,** Aquaman has a son, Baby Arthur, who’s genetically stronger with Atlantean Blood at about 75% compared to his Father who was only half-blood. Sorry, that’s the way I was looking at it. So I expected to see that little Atlantean Baby use his power to protect himself, his parents or grandparents somewhere in the story since The Writers showed how in touch he was with his powers, but that didn’t happen. **Two,** when the Demonic King Kordax of Necrus got up out of his chains free now from Aquaman’s blood, it was a moment towards the end of the film where it should have come more alive with a climactic battle between HIM, Aquaman and Orm, but they ended what should have been a promising battle with Aqua Man, like David & Goliath, throwing his Trident at him destroying The Black Trident at the same time. It was too soon. The only other thing is, **Three,** is Black Manta really gone? As Aquaman extended his hand to try to save him, he opted to fall to his death, honoring his dead father whom Aquaman killed.

%[https://odysee.com/@Ferrelux666:f/Aquaman-And-The-Lost-Kingdom-Lhisa-Movie-Review:f] 

So now today is Sunday **February 11, 2024**. I posted my short film review video yesterday on **Odysee**. And to continue with this, they did a great job hopping about the globe to different scenic locations to film this movie and the quality of work that went into making it is clear to see. As the adventure unfolds, we learn about ancient Atlantean technology unknown to the current Atlanteans, and usage of **The Orichalcum** at that time, which nearly destroyed their empire then, but is now sought after by Black Manta to empower his technology. Another important thing that happened in the storyline is how Aquaman realized that he needed his brother Orm to help him defeat Black Manta *and later on* Kordax. Aquaman hatched up a plan to break Orm out of his prison. Now when we first see Orm in the film, he looked very different from the way we met him in the first Aquaman movie in all his glory as **Ocean Master**. In this one, he was gaunt looking with long blond hair and matching facial hair. His Captors tormented him and gave him just enough water to survive each day. Aquaman was wearing an invisibility suit when he rescued him. As they fled, they had to also escape some creatures giving chase. They finally end up at a beach where a weak Orm dramatically crawls his way inch by inch into the sea where his Atlantean Body & Soul is immediately replenished for battle, and he rises to the occasion defending himself from a bad guy. He and Aquaman fled some more to another location where Aquaman eventually delivers their Mother’s message of love and concern to him at an odd time. Ofcourse there were contention between the two along the way, but they certainly worked well together caring for one another;s safety. Everyone in Atlantis eventually learned about **The Black Trident**, it’s power, and the story about **King Kordax** and **Necrus**. There were originally Seven Kingdoms of Atlantis till King Kordax began warring with his brother **King Atlan**, who was the **True Ruler of Atlantis** at the time, the bloodline from which Arthur came from. Back then, Kordax tapped into some very dark magic turning himself and his people into demonic entities. He eventually lost that war when Atlan used his own powerful light magic sealing Kordax and the people of Necrus, in a spell forged by his own good Atlantean blood for evermore, which can only be broken by someone in the same bloodline. And so Black Manta and his Minions went to Aquaman’s home on the surface to capture his baby son to sacrifice. Black Manta first came in contact with The Black Trident when he ventured on a path in the ocean and discovered the lost city of Necrus. As he touched the two pieces of the Trident, bringing them together, he got a cosmic charge and came into contact with the demonic Kordax energy intimating thoughts and visions to him. ***And this is also a pivotal moment of the film where we see Black Manta portrayed in a future glory achieving his aims, triumphantly arching his body, holding his Trident atop of his conquest.*** And so began his journey to take vengeance on Aqua Man with his new found power being stronger and smarter to where **Dr. Shin** notices and covertly tries to stop Black Manta who at one point threatens him, but the shrewd Dr. Shin navigates himself well, even pinpointing coordinates to Aquaman’s team so they can save him and Baby Arthur. Notice I’m not giving away **ALL** the details as there are cute moments if you saw the film then you know already, but for those of you who don’t know certain things yet, can still be surprised when you see the movie. I’ll say this, the baby got rescued and Kordax got free through Aquaman’s own blood when he was fighting and a trickle of it fell onto the ceremonial stone. The magic happened and we see Kordax come alive again breaking the chains, rising from his throne. I must say that here, while the fight was going on and Orm touched the Trident a second time, since the first time was earlier in the adventure where he was the one with the knowledge enlightening his fellow Atlanteans. This time, he got tempted by Kordax telling him how he can BE The Ruler Of Atlantis and Orm was getting possessed until Aquaman got into his mind reminding him of the love he has for him as a brother and the love that their mother has for them, and the purity of that feeling and thought in Orm brought about the desire to help Aquaman instead. So rather than getting into a further battle where Kordax could possible win, Aquaman from where he stood, used his Trident and threw it directly at Kordax, destroying his Trident and him at the same time which seemed farfetched to me, because a more believable battle leading up to that would have been better. And somewhere along the battle, the rest of The Atlantean Army showed up trying to destroy **Devil’s Island** and Black Manta was hanging on for his life. When Aqua Man this time around tried to extend a saving hand to him, which he failed to offer his Father, Manta, David Kane opted to fall to his death. So anyway, after the victory they all went home. Aquaman decided to let the surface world ***KNOW*** about Atlantis and that it exists and present themselves at a United Nations Conference. And why not, the signs of their existence were there. And ofcourse closing the film with his Moniker, **I’m Aquaman**. I did stay beyond the rolling credits to see if Black Manta somehow survived, but what they showed was Orm carrying on discovering how to live on The Surface World while he’s at a restaurant paying for his meal with what appears to be an Atlantian Gold Coin. ***Ha Ha***. Well before, King Arthur, King Nereus and the Others on The Adventure decided to secretly let Orm go and not return him to his prison sentence due to his dedicated assistance in helping them save Atlantis. **And I like Orm.** I like many of the characters in the DC Comics World. So where will the franchise go from here? Will there be an **Aquaman 3**, if so, what will happen in THAT sequel?

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1707906459100/9cbac45b-5a04-4d87-a6ff-e5a6109f84e3.jpeg align="center")

So now it’s Wednesday **February 14, 2024** and for those of you checking, *YES*, you know damn straight I would go there. You see the parallels already, The Dr Strange Movie, Namor, Black Panther 2, Aquaman 2, who else? Those following the subtext and all I’ve been doing *know*. It’s good though. It’s nice to see my ideas appreciated. I must bring this topic up because it applies, especially with all of what I’ve been revealing. For those who are failing to see it in context must read a 70+ page story I wrote on here about somebody in comic book form entitled: *Avenatti’s Marvel Universe, DC* and maybe you’ll get it. On **X**, the site formerly known as Twitter, one of the things you’ll notice if you failed to at the time a couple years ago is how people who Support **Michael Avenatti** still use symbols having to do with **The Sea**. It certainly was not happening before. And that brings me to a point to explain why. Remember a few years back when people were using the term **Icarus** in relation to Michael Avenatti when he made a simple comment describing his experience about his oncoming downfall, you know flying too close to the sun as a metaphor to his ambitions? Well the image stuck in noticeable ways and I did not think he should be defined by that and as time went on during his trials, I got to thinking that he needs a new image. And so I began thinking about him, his ways and who he reminded me of, and then it dawned on me. I’m getting **Prince Namor** vibes. And I like The Marvel Universe with **Storm** and the other characters. So that’s 2. And I began thinking about another person who was around Avenatti at the time of his troubles, and realized *hmm,* this guy reminds me of **The Silver Surfer**, and golly gee, he surfs in real life. And then the light bulb over my head went on shining even brighter. For Holloween 2021, I should do a story talking about Avenatti’s Case in a way and somehow figuring how to Cast everybody else in it. Now I didn’t think doing that shit would be a problem and it wasn’t, it only became an issue leading into 2022 when, yeah that narcissistic FBI Agent I exposed in 2023 stalking me, popped up working feverishly behind-the-scenes ongoing reacting to my story, but not in the way one would think, but more like a jealous rage energy. You see, that literal work in all its ***light, beauty and hope,*** sparked an ugly ruthless attack from The One in our Kingdom who was not mentioned in the tale at all, but apparently somehow is responsible for what I was trying to cunningly explain. The problem though was by itself the story was cute and subject to interpretation. It only makes further conspiratorial sense if you were a Prosecutor or something having access to reading the private emails where certain things were discussed. **That** with the story NOW makes greater sense. It took me a while to figure who specifically was harassing me in that manner because I had better suspects in mind. The point is the **magic** of my story not only brought a Culprit forward, the only one in The Kingdom, who acted a fool over it, *but before that,* it **magically** erased the idea of Icarus. People were now seeing that whole Atlantean thing I was trying to present around Avenatti’s image instead, that I began seeing marine life emojis of people ***feeling that*** when they commented about him online. They were no longer thinking Icarus. It was noticeable to anyone paying attention and it had put a smile on my face. It was a Work of Love. One of my best that came from the purest place. I felt compelled to do it. And there is more I can say, which might get out at a later time, *but for now,* know that when you vibrate off a higher frequency and are acting on truth and love in the face of adversity, sometimes what lurks out at you from The Shadows is a wretched punitive soul, offended at your wisdom, dedication, compassion, and the possibility that what you have to offer may actually change the tide, so this enemy relentlessly faces off against you even after the fact, mercilessly trying to destroy you when you were only righteously trying to save a poor soul from further injustice which **FATE** in her mercy made possible.

**Sign,**  
**Lhisa Mrklon 🧜🏽‍♀️**  
**Aqua-Woman 🔱  
The Black Manta Atlantean**  
**#164**

<sup>💧🐢🦞🐳🪸🦑🪼🦭🐙</sup>**<sup>🐟🦐🐚🐠🐡🦈🦀💦</sup>**

**King Orm, Ocean Master Tribute From The First Aquaman Movie**  
[**https://www.youtube.com/watch?v=oEQPbTA0RrY**](https://www.youtube.com/watch?v=oEQPbTA0RrY)

**More Info About Orm Marius, Ocean Master**  
[**https://dc.fandom.com/wiki/Orm\_Marius\_(Prime\_Earth)**](https://dc.fandom.com/wiki/Orm_Marius_\(Prime_Earth\))

**You Just Gotta Love Black Manta**  
[**https://www.youtube.com/watch?v=7Ov2VhtRfHA**  
**https://www.youtube.com/watch?v=CpBIykvgm5**](https://www.youtube.com/watch?v=7Ov2VhtRfHA)[**Y**  
**https://www.dailymotion.com/video/x8qksp9**](https://www.youtube.com/watch?v=CpBIykvgm5Y)[  
**https://www.dailymotion.com/video/x8o3gi**](https://www.dailymotion.com/video/x8qksp9)[**6**  
**https://injustice.fandom.com/wiki/Black\_**](https://www.dailymotion.com/video/x8o3gi6)[**Manta/Quotes**  
](https://injustice.fandom.com/wiki/Black_Manta/Quotes)

**SOME CLIPS**  
[https://www.ign.com/videos/aquaman-and-the-lost-kingdom-official-trailer](https://www.ign.com/videos/aquaman-and-the-lost-kingdom-official-trailer)

[https://www.dailymotion.com/search/Black%20manta%20Theme%20Aqua%20Man%20%26%20The%20Lost%20Kingdom/videos](https://www.dailymotion.com/search/Black%20manta%20Theme%20Aqua%20Man%20%26%20The%20Lost%20Kingdom/videos)

**SOME LINKS**  
[https://en.wikipedia.org/wiki/Aquaman\_and\_the\_Lost\_Kingdom](https://en.wikipedia.org/wiki/Aquaman_and_the_Lost_Kingdom)

[https://dcextendeduniverse.fando](https://www.dailymotion.com/search/Black%20manta%20Theme%20Aqua%20Man%20%26%20The%20Lost%20Kingdom/videos)[m.com/wiki/Aquaman\_and\_the\_Lost\_Kingdom](https://dcextendeduniverse.fandom.com/wiki/Aquaman_and_the_Lost_Kingdom)

[https://www.looper.com/1477722/ending-aquaman-and-the-lost-kingdom-explained/](https://www.looper.com/1477722/ending-aquaman-and-the-lost-kingdom-explained/)

[https://www.usatoday.com/story/entertainment/movies/2023/12/23/aquaman-lost-kingdom-ending-spoilers-credit-scene/71957342007/](https://www.usatoday.com/story/entertainment/movies/2023/12/23/aquaman-lost-kingdom-ending-spoilers-credit-scene/71957342007/)

[https://nerdist.com/article/aquaman-and-the-lost-kingdom-everything-we-know/](https://nerdist.com/article/aquaman-and-the-lost-kingdom-everything-we-know/)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1707448575106/07d422cc-ecac-49a5-a458-95473367ca36.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1707616532739/e26e3260-5bab-4365-a7d6-c4b7abe86d44.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1707618869213/0979465a-6a26-45d3-ae9b-86eb3e7475d1.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1707692061095/a56ee375-9370-49ec-b162-ced76d3c13cd.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1707692080657/335de62d-30b2-43c1-8215-0e11559995e9.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1707778370022/dc899a1b-0b91-4828-a940-60c7068a88b5.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1707778624480/a6a859ae-346b-42e4-8dae-4ecbb1098bb9.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1707778934815/65fc8b24-5527-4564-abda-8deee1aeecfc.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1708031015581/fca2acf7-9b28-4acf-8fe7-dcbaba9c9f20.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1708031033977/3f1c4187-c603-4359-bab5-4fcbea4fd2a8.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1708031061351/93a2f394-9e56-4736-92d8-ce8901142bd6.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1707691715228/57084ef0-7bdd-47ba-b439-7e50787b38d6.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1708031519967/4d5e70d8-879a-4058-b5e1-119b4cd1dcce.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1708032099119/be36e5d3-9501-4734-b067-08cad27fb3fd.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1708032122113/d29c8148-299b-4f85-b4fb-cb65a57af8be.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1708032370937/3d414a3a-415c-438c-88d5-cd0ef1e79b4d.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1707616462964/1b651527-3a57-4719-ba8f-16b43adbc3d1.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1708031694733/8cf9e3e1-2d69-4327-b742-1e2341081bc3.webp align="center")
