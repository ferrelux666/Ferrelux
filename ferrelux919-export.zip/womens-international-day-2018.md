---
title: "☀Women’s International Day 2018\U0001F31E"
date: '2018-03-18T17:48:48.000Z'
slug: womens-international-day-2018
tags:
  - news
  - rights
  - women
  - grow
  - kids
  - international
  - uncategorized
  - politics
  - men
  - parents
  - children
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195531256/WQkecYjSH.png
canonical: 'https://ferrelux666.wordpress.com/2018/03/18/womens-day-2018/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195522257/jUtarKFml.jpeg align="left")](https://www.ferrelux.us/)

\*\*Inanna, Regina Caeli 🌙 Inanna, Queen Of Heaven

The struggle for respect, peace & equality for women all over the world continues this month, and everyday as we March on for our rights.\*\*

\*\*Here Are Some Highlights………  
\*\*

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/sXCnHvQzoOU?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/g4a2eAYIyRg?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/D0dI6McraBM?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/CbSaBZBsbAY?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/wdw8KNmr2pc?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195523358/IjTMbcda0.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195524933/S9h52BY8O.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195526420/QRhJgunM4.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195527701/pooRiwtId.png align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195529250/glIV9ML3R.jpeg align="left")](https://ferrelux.com/adverts/)
