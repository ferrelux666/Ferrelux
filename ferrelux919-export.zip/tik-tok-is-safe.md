---
title: "\U0001F4F1 Tik Tok Is Safe \U0001F409"
date: '2023-04-01T06:36:28.883Z'
slug: tik-tok-is-safe
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1680330376297/d2c5c29b-7165-4f7c-9d64-b532034442eb.webp
---
**A Dies Consilio Factum At Aurora 🐼 A Day Of Planning Is Done At Dawn**  
***(Chinese Proverb)***

**一日之计在于晨。  
Yī rì zhī jì zài yú chén.  
A day's planning is done at dawn.**

[**Big Trouble In Little China (Main Theme)**](https://odysee.com/@Lucifer666:f/Big-Trouble-In-Little-China-Main-Theme:2)

**This Easter, I’m Bestowing My Blessings To You Asia 🐇 And That’s No April Fools'.  
zhè gè fùhuó jié，wǒ jiàng zhùfú nǐmen yàzhōu，zhè bù shì yúrénjié.  
这个复活节，我将祝福你们亚洲，这不是愚人节。**

[**VIDEO: TIK TOK IS SAFE (CHINESE)**](https://odysee.com/@Ferrelux:7/Tik-Tok-Is-Safe-Chinese-Version:c)  
[**VIDEO: TIK TOK IS SAFE (JAPANESE)**](https://odysee.com/@Ferrelux:7/Tik-Tok-Is-Safe-Japanese-Version:c)  
[**VIDEO: TIK TOK IS SAFE (KOREAN)**](https://odysee.com/@Ferrelux:7/Tik-Tok-Is-Safe-Korean-Version:4)  
[**VIDEO: TIK TOK IS SAFE (ENGLISH)**](https://odysee.com/@Ferrelux:7/Tik-Tok-Is-Safe-English-Version:d)

I’ve never had a problem with it. What’s great about that App is that you can get on there and peruse a slew of entertaining videos and enjoy them. Social media as it was meant to be, accessible and engaging without any behind-the-scenes weirdness involved. I can’t say the same about comparable American Big Tech Apps which over the years I’ve noticed some serious invasive issues which are worse than what they are complaining about China. I personally can report ongoing cyberstalking and attacks that are underserved and are coming from an obvious source. I can’t say that about ANY Chinese or other Asian, Russian, British or European-owned Companies whose services I’ve used. I’m treated with respect. Unlike Americans, they engage Business Partners and/or Customers with greater honor. I’m still having problems with rabid American Big Tech Corps on basic stuff that should have been resolved that same day, and not leading into a legal proceeding. So I can’t agree with The Congressional Court System here harassing **Tik Tok**, when like every day you can read or hear about some case against Facebook or Google creating injury or harm with the misuse of Section 230. When you once enjoyed using a platform that has become a Monopoly over the years, that the Staff there can use their adjoining access to other Web Services controlled by them to interfere with **YOU** personally wreaking havoc into your life because of their discriminatory practices, then a line has been crossed. It’s a pity that they fail to use that technology in a way that prevents or solves crimes instead of harassing somebody, reading privileged emails and interfering in legal cases. Also, The Chinese, and Other Intelligentsia of The World, are more apt in realizing who to follow, target and prosecute, where I see Americans are struggling with that.

**SIGN,  
:LHISA:**

**Did You Trick Anyone Yet This April’s Fool? 🐰 And How Is Your Easter?**

**2023 Chinese Year Of The Rabbit**  
[https://studycli.org/chinese-zodiac/year-of-the-rabbit/](https://studycli.org/chinese-zodiac/year-of-the-rabbit/)

**April Fools Day In China**  
[https://www.chinahighlights.com/festivals/april-fool-day.htm](https://www.chinahighlights.com/festivals/april-fool-day.htm)

**2 Famous Chinese Business Men In America**  
[https://en.wikipedia.org/wiki/Desmond\_Shum](https://en.wikipedia.org/wiki/Desmond_Shum)   
[https://en.wikipedia.org/wiki/Guo\_Wengui](https://en.wikipedia.org/wiki/Guo_Wengui)

**Tik Tok, The Ceo, Bytedance, etc.**  
[https://en.wikipedia.org/wiki/Singapore](https://en.wikipedia.org/wiki/Singapore)

[https://en.wikipedia.org/wiki/Shou\_Zi\_Chew  
https://en.wikipedia.org/wiki/ByteDance](https://en.wikipedia.org/wiki/Shou_Zi_Chew%EF%BF%BChttps://en.wikipedia.org/wiki/ByteDance)    
[https://en.wikipedia.org/wiki/TikTok](https://en.wikipedia.org/wiki/TikTok)

[https://www.pbs.org/newshour/politics/watch-live-tiktok-ceo-testifies-before-house-committee-over-security-concerns-connection-to-china](https://www.pbs.org/newshour/politics/watch-live-tiktok-ceo-testifies-before-house-committee-over-security-concerns-connection-to-china)

[https://www.theverge.com/2023/3/24/23654732/tiktok-hearing-shou-zi-chew-failed-defense-congress-ban](https://www.theverge.com/2023/3/24/23654732/tiktok-hearing-shou-zi-chew-failed-defense-congress-ban)

[https://www.theguardian.com/technology/live/2023/mar/23/tiktok-ceo-hearing-ban-congress-live-updates](https://www.theguardian.com/technology/live/2023/mar/23/tiktok-ceo-hearing-ban-congress-live-updates)

[https://people.com/human-interest/tiktok-ban-hearing-biggest-bombshells/](https://people.com/human-interest/tiktok-ban-hearing-biggest-bombshells/)

**Google Lawsuits**  
[https://en.wikipedia.org/wiki/Gonzalez\_v.\_Google\_LLC](https://en.wikipedia.org/wiki/Gonzalez_v._Google_LLC)   
[https://en.wikipedia.org/wiki/Google\_LLC\_v.\_Oracle\_America,\_Inc.  
https://en.wikipedia.org/wiki/Google\_litigation](https://en.wikipedia.org/wiki/Google_LLC_v._Oracle_America,_Inc.%EF%BF%BChttps://en.wikipedia.org/wiki/Google_litigation)

**Facebook Lawsuits**  
[https://en.wikipedia.org/wiki/Lawsuits\_involving\_Meta\_Platforms](https://en.wikipedia.org/wiki/Lawsuits_involving_Meta_Platforms)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1680330888366/76d9bba1-27d1-493c-8b52-02323c592972.jpeg align="center")](https://www.nationalgeographic.com/travel/article/the-fascinating-history-behind-the-popular-waving-lucky-cat)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1687196775823/49cfcd75-e0d0-4a15-b562-5fecc93a18f4.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1687197243430/47d7d7cf-4ceb-4839-8242-a147456b6a9d.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1687196807111/cb3beb69-796c-4781-a18d-20dcd6d11822.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1687197278426/ecabc7ea-3c97-4f13-bf57-07a124ae5aab.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1687196831746/336aeb15-d345-439c-ac64-388e9be3e335.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1687196857073/eefedd92-066b-419d-9b0f-a01d0ccba120.jpeg align="center")
