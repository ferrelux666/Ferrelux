---
title: "The Kanye West \U0001F621 Jimmy Kimmel Feud"
date: '2013-10-13T20:06:59.000Z'
slug: the-kanye-west-jimmy-kimmel-feud
tags:
  - entertainment
  - comedian
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672196098292/fGZ-xlu0W.jpeg
canonical: 'https://ferrelux666.wordpress.com/2013/10/13/kanye-kimmel-feud/'
---
[![Comedian Jimmy Kimmel Vs Rapper Kanye West](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196092030/Yql8Olfx5.jpeg align="left")](https://www.businessinsider.com/kanye-west-on-jimmy-kimmel-after-feud-2013-10)

**If you saw the special, because Jimmy gave him the whole show for this reconcile & cancelled the guests he had & guess what one of their names were? Some musical group with the word Monkeys in their title. REALLY, this goes to show that my perceptions of Jimmy Kimmel over the years is dead on. He is racist. He likes making racial jokes using terms like mud, monkey, or other derogatory associations denoting Black People because it is SOOOOO consistent in American media in general.**

[**www.huffingtonpost.com/2013/10/09/kanye-west-to-jimmy-kimmel\_n\_4074879.html**](http://www.huffingtonpost.com/2013/10/09/kanye-west-to-jimmy-kimmel_n_4074879.html)

\*\*[www.nydailynews.com/entertainment/gossip/kanye-west-finds-bromance-jimmy-kimmel-live-article-1.1481391](http://www.nydailynews.com/entertainment/gossip/kanye-west-finds-bromance-jimmy-kimmel-live-article-1.1481391)  
\*\*

**~ Lhisa Mrklon**

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196093491/vMV-85Al_.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196094894/pZWlcpuZV.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196096368/WdFf4UW-u.jpeg align="left")
