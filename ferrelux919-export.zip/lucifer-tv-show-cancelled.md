---
title: "Lucifer TV Show Cancelled \U0001F4C9⌛\U0001F5D1"
date: '2018-08-30T17:35:55.000Z'
slug: lucifer-tv-show-cancelled
tags:
  - netflix
  - face
  - california
  - religious
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195353118/2tW7vO8rX.png
canonical: 'https://ferrelux666.wordpress.com/2018/08/30/lucifer-show-cancelled/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195350342/uyWjKcWxt.png align="left")](https://www.ferrelux.us/)

**Oh My God! I’m GLAD they cancelled that shit! REALLY! It had NOTHING to do with the REAL Lucifer/Satan, and by nothing, I mean authenticity. When the Christians learned about this show being created to put on TV & protested, their hysteria was off why The Fox Network would disregard them & still put it on TV, but they were right in a way; it’s misleading. Now some lay-person not knowing The Bible, & only having loose concepts about The Devil can be easily misguided by the show. I was watching the shit because of the subject matter being The god himself & was appalled at the callous way his intricate story was being handled. There are some fans of the show still complaining but can now see Season 4 on Netlix since they approved it, but it is nowhere on mainstream TV anymore & they can’t seem to get it. It’s not an accurate portrayal of The Devil, other works of fiction in the past were WAY better. It wasn’t stupid, gay, or off topic. Even though those satanic works current, decades past, & centuries old, depicted a fabrication of Lucifer, it was still believable enough to embrace as truth. Now this show, failed to do that miserably. In my younger days, hanging out at my favorite comic places in the city, I came across the Lucifer comic, read a few & I didn’t like it. I still feel the same way many years later. Even with some of the changes the Producers made with some of the characters & storyline for TV, it still felt WHACK! The whole thing would have been better had the show just been about a normal guy; take out the whole dimensional thing about Heaven & Hell and a fallen angel. The screenplay would have read better like a normal show about him, his life and the pursuit of a girl. Why invoke a Lucifer concept over that & complex it with God and a strange host of characters harassing him. Was that necessary? Other TV shows are able to survive currently with simpler storylines. And what made it worse was The Gay Agenda. Did they really have to make the character bi-sexual? How crazy? You’re talking about a biblical character that your show borrowed from scriptures, & you must impose gay stuff on it. The only time you see gay activity in the bible concerning angels was when Lot invited 2 handsome strangers into his home that God sent on a mission, who were angels that he protected from the men of the village who wanted them for sex. And God ultimately destroyed their cities, Sodom & Gomorrah, only saving Lot & his 2 daughters. Now that story is not for someone to go twist & morph into a morbid concept to impose on divine creatures, trying to see THEM gay. How sick! And I’m not thrilled about the guy chosen to play Lucifer. He’s goofy looking at times when he turns his head here, and there, he looks common & only at rare times he actually looks attractive. I appreciate that they didn’t make him blond like the comic. Now that Devil face they made for him looked dumb. The circle of people they had around him made no sense either. So the idea was the King of Hell, no longer wants his God-given job & he escapes responsibilities to live on Earth in the city of Los Angeles, as a rich playboy. How unoriginal. Then we see a character falling off the rails at times needing a shrink to help him sort his life out. Really! A divine being with an infinite scope of reality would not need a lower being’s help in telling him what to do. The writers spent a lot of time trying to trivialize a serious religious subject into a stupid comedy in a most irresponsible way. Now I get the idea that the work was NOT based on the reality of SATAN, but why even bother using a word like LUCIFER for your book or TV show? When you make a grand SPLASH like that, people expect better. Now those who liked the show I notice are the Millenials, persons that are not religious & those who don’t know better retweeting, up on Youtube endorsing the shit, & so forth. People like myself that favor Satan in his correct light weren’t seeing the show as a great thing. It didn’t accomplish anything. The most you got was me maybe retweeting a concept concerning the show, like #SaveLucifer (not the show), BUT his significance & value, and some of the poster artwork were cool too. All the original writers of the comic had to do was invent a brand new concept for their fabricated character & call him something different. Now, the cast of friends, a therapist & cops. Is it likely that he would end up with those types of people around him regularly? It would surprise you what he might actually end up doing living on the Earth. When you have a misconception of who people are, this often happens. If they had a show writing Jesus in a certain unflattering way, like the Christians, that would upset me too. Stay true to the theology. There are hateful perceptions out there with people trying to see him gay, perverting his relationship with Disciples. When you keep watching a show to see where it goes, the level of insanity becomes apparent to you. No proper direction, morals, or agenda to make it have a subtenant meaning.**

**SOME LINKS ON THE COMICS**  
[https://www.vertigocomics.com/characters/lucifer](https://www.vertigocomics.com/characters/lucifer)  
[https://en.wikipedia.org/wiki/The\_Sandman\_(Vertigo)](https://en.wikipedia.org/wiki/The_Sandman_(Vertigo))  
[https://www.vertigocomics.com/characters/the-sandman](https://www.vertigocomics.com/characters/the-sandman)  
[https://en.wikipedia.org/wiki/Lucifer\_(DC\_Comics)](https://en.wikipedia.org/wiki/Lucifer_(DC_Comics))  
[https://en.wikipedia.org/wiki/Lucifer\_(TV\_series)](https://en.wikipedia.org/wiki/Lucifer_(TV_series))  
[https://www.fox.com/lucifer/](https://www.fox.com/lucifer/)

**THE REAL LUCIFER / SATAN**

[https://en.wikipedia.org/wiki/Lucifer](https://en.wikipedia.org/wiki/Lucifer)  
[https://en.wikipedia.org/wiki/Fallen\_angel](https://en.wikipedia.org/wiki/Fallen_angel)  
[https://en.wikipedia.org/wiki/Satan](https://en.wikipedia.org/wiki/Satan)  
[http://thehumornation.com/13-interesting-facts-devil-lucifer/](http://thehumornation.com/13-interesting-facts-devil-lucifer/)  
[https://en.wikipedia.org/wiki/Demon](https://en.wikipedia.org/wiki/Demon)  
[https://www.deliriumsrealm.com/demons/](https://www.deliriumsrealm.com/demons/)

**~ Lhisa Ungelis Mrklon**

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195351517/BFul19vLYc.jpeg align="left")](https://ferrelux.com/adverts/)
