---
title: "\U0001F9E1Amber Heard Johnny’s Depposition⚓"
date: '2022-05-23T03:48:00.000Z'
slug: amber-heard-johnnys-depposition
tags:
  - google
  - tv
  - movies
  - relationships
  - love
  - caribbean
  - trial
  - atlantis
  - marriage
  - men
  - mermaid
  - female
  - hollywood
  - myths
  - amber-heard
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672191917651/eHGpcgbbI.png
canonical: 'https://ferrelux666.wordpress.com/2022/05/22/amber-heard-johnnys-depposition/'
---
[![Amber Heard And Johnny Depp](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191871796/9MEuw15h7.jpeg)](https://rumble.com/search/video?q=Johnny%20Depp)

<iframe width="100%" height="100" src="https://w.soundcloud.com/player/?url=https%3A%2F%2Fapi.soundcloud.com%2Ftracks%2F96706269&amp;auto_play=false&amp;hide_related=false&amp;visual=true&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;color=ff5500"></iframe>

[callum’mixbreed!#](https://soundcloud.com/usher-junior) · [Usher U Remind Me BBC Radio 1 Live Lounge 2012](https://soundcloud.com/usher-junior/usher-u-remind-me-bbc-radio-1)

I chose this song as to allude if Johnny Depp were to move on with dating another, what he might say should the girl look like Amber, ha, ha ha ~ [The Lyrics To Usher’s “U Remind Me”](https://genius.com/Usher-u-remind-me-lyrics)  
  

_Omnia, Quae Sunt, Non Pulchra In Amore Et Bellum 💔 All Things Are Not Fair In Love & War_  
  

**__I am watching the development of other topics in the general news I’ll cover soon, but for now, I decided to run below this Amber Heard vs. Johnny Depp story. And my publication here is still undergoing attacks by Google/Facebook who don’t like thoughtful and creative people like me, so they think their covert cyber attacks go unnoticed when it all leads right back to them and their Cohorts. It would be wise for the general public to seek out alternative platforms not co-dependant on Facebook, Google and Other Big Tech Companies since they have no respect for people. Don’t ignore the many negative complaints you keep seeing and hearing about them singling out and harassing certain people and their work. It’s just a matter of time before they start fucking around with you too, especially if there is something unique about you and your activities.__**

Now you know I had to be cute with the title, right, with the way my mind works. So anyway, to who it interests if Ya’ll been watching this spectacle, it might yet be another orchestrated distraction for The Public to pay more attention to in lieu of a real political affair happening privately elsewhere. You should be ever so vigilant to look at news outside of Hollywood in the political atmosphere where something being __decided__ by the wrong people may impact your freedom. These people are Actors commissioned to entertain you. Notice how much more of them are in the news now with some issue, since the pandemic. Don’t let The System control your innate common sense, but while we’re at it, let’s look at this shit. The conflict between the two is odd. On the one hand they look like just another Hollywood hookup, but doing a second take, you think, wait, aren’t they mismatched? Just from a movie standpoint, Johnny Depp is Jack Sparrow the Pirate of the Caribbean, and Amber Heard is Mera, the Atlantian Princess romantically linked to Aquaman. And in another story that might work, but on the real, come on. So you see the problem here 😉😆 And this is not even funny in a real life sense because both their careers took a hit over this concerning their iconic roles in their respective movie franchises. What’s happening with them in this public trial is NOT a good look. Many women are feeding into defending Johnny Depp. And notice his body language too throughout all this. He is subdued like an abused male and women feel sorry for him. And maybe he was a victim of domestic violence at the hands of Amber Heard, but people are forgetting way back in the news when we use to hear Johnny Depp’s name regularly linked to women he was abusive towards in his romantic relationships. So I guess he met his match. Look at him cower. He could just be acting though. Every now and then we see glints of him showing sexist male antics in Court when Amber is on The Stand giving testimony or answering questions. A lot of women don’t believe her and think she’s acting and making false claims. Well, so much for the #MeToo #BelieveWomen stuff. You see how one seemingly frivolous case can swing the pendulum back. Notice not a lot of men seem to care too much about that case. It’s stupid. You hear them talking about other things that matter. And the case is still going on with the tell-tale nonsense, though it should have been long wrapped up.

Sign,  
Lhisa Mrklon

**How Did YOU View The Depp vs Heard Defamation Case? 😦😕 Scroll Down And Leave Your Reply.**

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191874247/7kEYJ9iTu.png)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191876075/7goRv9VXM.jpeg)![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191877541/cYAhksP3h.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191878879/0ctkvN-Fy.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191880244/h2DlYWggL.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191881883/devL_d1rZ.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191883684/nE54aONgx.jpeg)![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191885206/6P-x70av6.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191886510/5JhVqxSZ-.jpeg)![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191887990/F7sKfimbF.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191889501/gSkIWw6M8.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191890806/mPmmKLiPS.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191892395/hLBVYwje0.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191893845/1xicHeNRR.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191895268/Gzbyl6Fz2s.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191896835/pLneM9LxW.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191898282/uxF-saP-F.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191899797/jmZlamAS8.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191902059/hvCoDgsZj.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191903554/6mjYPwisk.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191905269/x4_bjDn7S.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191907170/ID1oL8DNlx.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191908648/IqihYfykr.png)![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191910303/FkIapbEf8.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191911810/bgK8ReDSK.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191913099/le6zD4Hr9.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191914483/WxtpcLAUn.jpeg)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191915624/RpR9tJBzM.jpeg)](https://lightinthebox.tv2h87.net/c/3170166/898314/8199?prodsku=7190943&u=https%3A%2F%2Fwww.lightinthebox.com%2Fmen-s-vest-v-neck-polyester-black-navy-blue-wine-l-xl-xxl_p7190943.html&intsrc=PUI2_7096)

### Share this:

*   [Twitter](https://ferrelux666.wordpress.com/2022/05/22/amber-heard-johnnys-depposition/?share=twitter)
*   [Reddit](https://ferrelux666.wordpress.com/2022/05/22/amber-heard-johnnys-depposition/?share=reddit)
*   [Pinterest](https://ferrelux666.wordpress.com/2022/05/22/amber-heard-johnnys-depposition/?share=pinterest)
*   [Tumblr](https://ferrelux666.wordpress.com/2022/05/22/amber-heard-johnnys-depposition/?share=tumblr)
*   [LinkedIn](https://ferrelux666.wordpress.com/2022/05/22/amber-heard-johnnys-depposition/?share=linkedin)
*   [Email](mailto:?subject=%5BShared%20Post%5D%20%F0%9F%A7%A1Amber%20Heard%20Johnny%27s%20Depposition%E2%9A%93&body=https%3A%2F%2Fferrelux666.wordpress.com%2F2022%2F05%2F22%2Famber-heard-johnnys-depposition%2F&share=email)
*   [More](https://ferrelux666.wordpress.com/#)

*   [Telegram](https://ferrelux666.wordpress.com/2022/05/22/amber-heard-johnnys-depposition/?share=telegram)
*   [Print](https://ferrelux666.wordpress.com/2022/05/22/amber-heard-johnnys-depposition/#print)
*   [Skype](https://ferrelux666.wordpress.com/2022/05/22/amber-heard-johnnys-depposition/?share=skype)

### Like this:

Like Loading...

### _Related_
