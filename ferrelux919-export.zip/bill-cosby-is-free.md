---
title: "Bill Cosby Is Free ⚖\U0001F48A\U0001F3A5"
date: '2021-07-15T21:00:24.000Z'
slug: bill-cosby-is-free
tags:
  - books
  - free
  - community
  - women
  - attorney
  - trial
  - party
  - lawyers
  - drugs
  - celebrity
  - fraud
  - hollywood
  - taxpayers
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672208935857/22a4e0ee-f16a-45fe-98f7-0e0e336b91d7.jpeg
canonical: 'https://ferrelux666.wordpress.com/2021/07/15/bill-cosby/'
---
[![Cosby Conviction Overturned](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192865964/dFMesbOX5.jpeg align="left")](https://www.pbs.org/newshour/arts/why-bill-cosbys-conviction-was-overturned)

\*\*[Fat Albert Rap Scene From The Movie](https://www.youtube.com/watch?v=8lWAQ-0kF14)  
\*\*  
Ut Succedant, Desiderio Debet Esse Maior Tuo Timor Deficiendi 🤩 In Order To succeed, Your Desire For Success Should Be Greater Than Your Fear Of Failure *(Bill Cosby)*

Still in certain circles there’s talk about Bill Cosby. His Haters ofcourse very disappointed he got released from prison with his conviction overturned and he can never be tried again on that. And on the other side, ofcourse his many Fans elated that he’s now free. I was one of the people that did not have a problem with this. I was following his case and saw no real merit with the accusations at the time it began. And when they kept coming and coming and coming, with a presentation of woman after woman after woman, I knew then that this was some shit that’s not going away. These people are really trying to convict him BAD. What the fuck is this and what did you do Bill? They’re all kinds of theories out there as to the true reason, but I won’t spend time discussing it. I had my own perspective as to why which you can read [here](https://ferrelux.com/2018/11/14/cosby/). During the course of him fighting his cases, things took a turn for the worse when The Justice System decided to renege on their own judicial process by moving to unseal an old case he had just to try to convict him. That showed me how unjust the system was to try to use some thing he said in that case just to win a conviction decades later. How about properly vetting The Accusers first before wasting Tax Payers time and money. Now I’m not saying that Bill Cosby is completely innocent of any wrongdoing, but this whole thing is about something else. They’ve been after this man for many years. Whatever power move or activity he was doing in Hollywood, or about to do that offended some powerful people to retaliate, well, they got around to setting him up. Whoever jumped on the bandwagon was on it to see them tear down Cosby, but many of us value his legacy and moved to try to preserve that. This issue he went through, had little or nothing to do with justice. People are going to believe what they want without requiring any evidence or proof that he drugged and raped women while others contend that there may have been some sexual interludes, but these recreational drug use & sexcapades was a thing at the time, and he wasn’t the only Celebrity having wild parties and doing it, yet he was targeted all of a sudden out of the blue. So anyway, while being old, legally blind and behind bars, they were trying to get him use to the prison life and to do some things they wanted, including taking courses to get out on early parole and register as a Sex Offender, but he refused to buckle under their pressure, preferring to serve the 10-years instead. He kept being difficult and maintaining his not guilty plea until his release after 3-years. His Attorneys kept fighting that shit till they won. And not only them, all this time people who are his Fans that value the rich legacy, all had something to say and post. And now all kinds of stuff about his case is getting out to the public. I appreciate the team he had behind him. A community of people who see through corrupt stuff, don’t let go of their people. My favorite version of Bill Cosby was his work before **The Cosby Show**. The teaching he was doing educating the public about racism and prejudice. People forget that. And he came from a time where he can talk about that candidly. I care more about those videos than the comedic stuff. He began mellowing out and becoming more mainstream with the cartoon **Fat Albert**, his stupid comedy routines, and ofcourse **The Cosby Show**, and the timing of his release couldn’t be more perfect in the midst of this so-called “Woke Culture” & “Critical Race Theory”, to which anybody truly curious about those things to learn why and how these issues popped up into the mainstream now, should be asking all the right questions that I’ll be so happy to answer, because there **\_***is***\_** usually a hidden story behind these things.  😎 🤐 😡 🤬 😏 😜

[Tom Mesereau, Speaking On Bill Cosby](https://www.youtube.com/watch?v=CVBpXtV4K4I)  
[Marc Lamont Hill & Judge Joe Brown](https://www.youtube.com/watch?v=6nBDNsNSga4)  
[Dr Boyce Watkins & Bill Cosby’s Spokesperson Andrew Wyatt](https://www.youtube.com/watch?v=8p5VYNn-KQI&list=PLvjq047Nl4L9R7udlINjS-QcXpS3pf71B&index=2)

[Bill Cosby 1968 Interview](https://www.youtube.com/watch?v=rvXy9WUhnE4)  
[Dick Cavett Show Interview](https://www.youtube.com/watch?v=OI5qwB2b43w)

[Some Info On Bill Cosby  
](https://www.billcosby.com/)[Popular Bill Cosby Quotes](https://www.brainyquote.com/authors/bill-cosby-quotes)   
[Bill Cosby’s Background](https://en.wikipedia.org/wiki/Bill_Cosby)

Sign,  
Lhisa Mrklon

**Do You Believe Bill Cosby Actually Hurt Those Women? Scroll Down And Leave Your Reply Below.**

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192867503/G5nseAknU.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192869150/hcicdjAtm.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192870463/d_Qw4o5fL.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192871963/mF0J_BRPp.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192873596/Rt0iq6CH9.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192875367/sbmy85rAR.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192876568/b6LwfcPHv.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192878011/7hxhp4_j2.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192879647/jeDIZ1X-c.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192881494/FPgXHSn9Y.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192882796/fXQ-kIKaB.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192884573/y3hlgBk4P.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192886327/tMAcvZRxL.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192887572/3xlHTG-sk.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192888952/SSFusIN_l.jpeg align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192890726/D29AnFQgo.png align="left")](https://www.usgrants.org/sign-up?affiliate=134980)
