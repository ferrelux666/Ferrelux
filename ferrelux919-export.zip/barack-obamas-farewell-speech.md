---
title: "⚓Barack Obama’s Farewell Speech\U0001F9ED"
date: '2017-01-11T20:12:03.000Z'
slug: barack-obamas-farewell-speech
tags:
  - speech
  - president
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672196049400/vkYiGAIWC.jpeg
canonical: 'https://ferrelux666.wordpress.com/2017/01/11/farewell-obama/'
---
![112012-politics-inauguration-guide-barack-obama-waving-smiling](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196046525/L-2N_h-Mu.png align="left")

What A Lovely President.  
His Presence On The Stage Of World History Had A Enchanting Air To it.  
When I Got Up In The Morning, I Knew The Country Was Secure With Him At The Helm.  
Goodbye Barack, I Will Sincerely Miss Your Presidency……

\*\*[His Full Televised Speech](https://www.dailymotion.com/video/x583ioc)  
\*\*

**~ Lhisa Mrklon**

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196048147/hsnvv6LEE.jpeg align="left")
