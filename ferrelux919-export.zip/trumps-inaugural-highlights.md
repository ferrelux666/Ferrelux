---
title: "\U0001F61FTrump’s Inaugural Highlight’s\U0001F913"
date: '2017-01-23T22:10:39.000Z'
slug: trumps-inaugural-highlights
tags:
  - trump
  - people
  - government
  - party
  - president
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672196018655/GGzAMPH_U.jpeg
canonical: 'https://ferrelux666.wordpress.com/2017/01/23/trump-inaugural-highlights/'
---
[![Trump Being Sworn In As President, 45](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196003580/YmdnrOV72.jpeg align="left")](https://www.cbsnews.com/news/donald-trump-inauguration-protest-damages-downtown-washington/)

**Here He Is, Mr. America! Check Out These Videos.**

**First, the PRE-Inaugural**  
[http://www.youtube.com/watch?v=CtqNfsrKPj8](http://www.youtube.com/watch?v=CtqNfsrKPj8)

**Split Shots on the Attendance Turnout for Trump vs Obama**  
[http://www.youtube.com/watch?v=FTXFGvH5\_B8](http://www.youtube.com/watch?v=FTXFGvH5_B8)

**Celebrities Who Didn’t Attend & Had Something to say**  
[https://www.youtube.com/watch?v=DBl-NTx4XdU](https://www.youtube.com/watch?v=DBl-NTx4XdU)

**Performers Who Declined Trump’s Invitation**  
[http://www.youtube.com/watch?v=yuMm5Y8-4B4](http://www.youtube.com/watch?v=yuMm5Y8-4B4)

**Those who secretly voted for him**  
[https://www.youtube.com/watch?v=RrL72ynzzHM](https://www.youtube.com/watch?v=RrL72ynzzHM)  
\*\*  
Trump had problems attracting a HUGE crowd on the common level & at the very top. He did however draw the Bikers out….\*\*  
[http://www.youtube.com/watch?v=cSwMz4eBTns](http://www.youtube.com/watch?v=cSwMz4eBTns)  
\*\*  
Oh & his inaugural speech (notice the hand jestures) ……\*\*  
[http://www.youtube.com/watch?v=IgRyZvIPFw8](http://www.youtube.com/watch?v=IgRyZvIPFw8)

**Speculation’s on Trump’s relations with Russia**  
[http://www.youtube.com/watch?v=PV0SJo8Z0Cw](http://www.youtube.com/watch?v=PV0SJo8Z0Cw)

**Trump’s Questionable Cabinet…..**  
[http://www.youtube.com/watch?v=TxPO8dSJu74](http://www.youtube.com/watch?v=TxPO8dSJu74)

**Sign,**  
**Lhisa**

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196005247/KdY_-85vqv.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196006540/7oZ86VKiT.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196007993/L95gNr3k3-.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196009386/G_hFfXBkim.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196010592/V5dHwV2Cw.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196012137/absq60-r-.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196013505/9whXFWv_8.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196014832/cH6_eAJbt.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196016117/_Ue1Jvr01.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196017349/60BdWVeuP.jpeg align="left")
