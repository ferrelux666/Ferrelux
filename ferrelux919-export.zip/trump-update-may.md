---
title: "Trump Update: May \U0001F480\U0001F54D"
date: '2017-05-23T21:49:15.000Z'
slug: trump-update-may
tags:
  - trump
  - attack
  - concert
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195861932/AWB4KYlEu.jpeg
canonical: 'https://ferrelux666.wordpress.com/2017/05/23/trump-update/'
---
[![01-trump-flag.w1200.h1200](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195857650/pA1AnXd_6.jpeg align="left")](https://www.thesun.co.uk/news/3621403/donald-trump-makes-history-on-israel-trip-as-first-sitting-us-president-to-visit-jerusalems-fiercely-contested-western-wall/)

Trump making news again. You know every few days there’s something on him even if you’re trying to ignore him. This time, his recent trip to Israel & other parts. He made history as the first U.S. President to recognize Jerusalem & touch the Western Wall in his visit.  
[Article on Trump’s recent visit to Jerusalem](http://www.jpost.com/Israel-News/Bennett-calls-on-Trump-to-make-history-recognize-Jerusalem-493627)

**Him & Melania in a wreath laying ceremony.**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/f5lRSusVQDo?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

**Him finally leaving………………………….**

[https://www.youtube.com/watch?v=C3gb7MBXoo4](https://www.youtube.com/watch?v=C3gb7MBXoo4)  
**But the news of the Manchester Terrorist attacks marred the beauty of a peaceful week.**

[http://www.youtube.com/watch?v=y8cCYZSTBEk](http://www.youtube.com/watch?v=y8cCYZSTBEk)  
**More on that attack, which ISIS claimed responsibility for……………**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/zK-kcuELKfM?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195858997/Y9wTXFCI8.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195860346/yJ9L_ably.jpeg align="left")
