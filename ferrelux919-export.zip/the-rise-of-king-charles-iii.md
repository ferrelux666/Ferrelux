---
title: "\U0001F4DC The Rise Of King Charles III \U0001F570️"
date: '2022-09-20T03:56:27.000Z'
slug: the-rise-of-king-charles-iii
tags:
  - uk
  - uncategorized
  - scotland
  - kate-middleton
  - meghan-markle
  - death
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672191610297/6bJ12PJLu.jpeg
canonical: 'https://ferrelux666.wordpress.com/2022/09/19/king-charles-the-third/'
---
[![Grieving King Charles III](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191579699/YC_ESRB-A.jpeg align="left")](https://www.bbc.com/news/uk-62952004)

<iframe width="100%" height="100" src="https://w.soundcloud.com/player/?url=https%3A%2F%2Fapi.soundcloud.com%2Ftracks%2F1344542908&auto_play=false&hide_related=false&visual=true&show_comments=true&show_user=true&show_reposts=false&color=ff5500"></iframe>

[God Save the King](https://soundcloud.com/godsavetheking-music) · [God Save the King](https://soundcloud.com/godsavetheking-music/god-save-the-king)

**Vivat Rex 👑 Long Live The King**

When I last reported on The Royal Family a couple months back, it concerned The Queen’s Platinum Jubilee, and prior to that, last year, The Death Of Prince Philip. And I knew due to the loss of her beloved husband, who was her strength and stay, and given her advanced age, the time of her death drew nearer. And now, here it is. The Funeral Procession of England’s Late Queen Elizabeth, whom reigned 70+ years over The United Kingdom, went well. Everyone was dressed beautifully. Unlike some sources out here, I would not remark against the garments of the guests. Meghan And Harry paid their respects, but Commentators were informing The Press that they might still release their latest work trashing The Monarchy. I did notice the stern composure of Kate as she passed Meghan at times. The Sussexes have little to nothing to inherit after their scandals as Others gained staying true to the Crown. When you have “a place” in Society, and fail to honor it, . . . **\_***well.***\_** What came of this moment was Prince Charles finally ascending to The Throne at a historic 73 years old, with his Queen Consort Camilla. In the past, many have remarked negatively to whether he was ready. Well, he handled himself in a dignified manner. He addressed The Public with a proper speech and definitely sounded Kingly, and we see him carrying out his Duties. And this is not a joyous moment. He and the rest of The Kingdom is grieving a beloved deceased Queen. The Pageantry in the streets was respectful. The remaining legacy of her Era, lives on in her Children. And to the Ones with vitriolic comments concerning Colonialism and The British Empire, **\_***I hear you,***\_** but focusing your wroth against that poor Old Lady as The Symbol of It, is misguided. Yes she inherited It, but It was already a fallen and broken system, later partly re-constructed to fit the times and It is still changing. She is not responsible for what happened in The 1600s. Her Collective Work during her Lifetime reflects charity, implementing and promoting humane practices globally through various Organizations with the other Royals Commissioned to do so. One famous Royal at the time noted extensively for her duties to The Crown was the late great **Diana, Princess Of Wales**. And the further work needed to be done to reverse the damaging effects of Imperialism on Our People in our Realms, is best administered by Us. Looking to **The Crown** for that, shows that you still haven’t realized something. Maybe taking a history book might help. YOU already won. The slave uprising, boycotting, and all the fighting our Ancestors did proves that. And what of the Old Empire? They have been reduced to a Society. So please draw your claw back and let them grieve for a dear family member who just died. Rest In Peace, . . . Elizabeth.

[King Charles III Addressing His People](https://rumble.com/v1je3bu-september-9-2022.html)  
[Remembering Queen Elizabeth II](https://odysee.com/@GoldenAgeGeek:9/remembering-hm-queen-elizabeth-ii:a)  
[Videos Of The Royal Funeral](https://www.cnn.com/videos/world/2022/09/19/moments-from-queen-elizabeth-funeral-lon-orig.cnn)  
[More Press Coverage On The Subject](https://rumble.com/search/video?q=Queen%20Elizabeth%20Funeral)  
[More Opinions, Controversial, And Bizarre Stuff](https://www.brighteon.com/new-search?query=Queen%20Elizabeth%20Funeral&page=1&uploaded=all)  
[And Even More Conspiracy, Reptilian Stuff](https://utreon.com/search?q=Queen%2BElizabeth%2BFuneral)

Sign,  
Lhisa Mrklon  
Queen Of ***MY*** Realms

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191581008/PXH_bt4td.jpeg align="left")](https://lightinthebox.tv2h87.net/c/3170166/898314/8199?prodsku=4403785&u=https%3A%2F%2Fwww.lightinthebox.com%2Fwomen-s-chain-bracelet-alloy-cubic-zirconia_p4403785.html&intsrc=PUI2_7096)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191582367/aj6QS5jQn.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191583818/hEj_0tQF6.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191585040/DlaXSPivB.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191586417/9XaVuY91f.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191588172/EM5UEZ2IZ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191590056/z7mILis0U.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191591597/5TuIIZXV3.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191593140/V8jze8uZR.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191594704/YgOQXjXcK.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191595995/mspM_kBx2.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191597517/8hc-0nn-W.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191598869/6GeapLOjU.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191600046/9Ci9U7was.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191601669/d7I3bPg5d.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191603895/Jjw96foWk.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191606039/ztF8WwA2N.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191608412/J-p2E7ZOB.jpeg align="left")

### Like this:

Like Loading...

### *Related*
