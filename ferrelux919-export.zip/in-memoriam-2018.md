---
title: "In Memoriam 2018 \U0001F33B\U0001F480"
date: '2018-12-23T19:29:09.000Z'
slug: in-memoriam-2018
tags:
  - life
  - living
  - celebrity
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195273325/-02xmWJhj.png
canonical: 'https://ferrelux666.wordpress.com/2018/12/23/deaths2018/'
---
**  
Merry Christmas Everybody & Have a Blessed New Year in 2019.**  
We remember 2018 with the deaths of the following………………………….

Anthony Bourdain  
Kate Spade  
Joseph Jackson  
Nelson Mandela  
Winnie Mandela  
Barbara Bush  
Aretha Franklin  
George Herbert Walker Bush  
Stephen Hawkins  
Burt Reynolds  
Nancy Wilson  
Roy Hargrove  
Steve Ditko  
Lovebug Starski  
Neil Simon  
Penny Marshall

AND THE LIST GOES ON………………………….  
[http://www.legacy.com/news/galleries/celebrity-deaths/gallery/2018-celebrity-deaths](http://www.legacy.com/news/galleries/celebrity-deaths/gallery/2018-celebrity-deaths)  
[https://en.wikipedia.org/wiki/Deaths\_in\_2018](https://en.wikipedia.org/wiki/Deaths_in_2018)

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/qunK91Qhdgc?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195271251/IriWa1JGO.png align="left")](https://ferrelux.com/adverts/)
