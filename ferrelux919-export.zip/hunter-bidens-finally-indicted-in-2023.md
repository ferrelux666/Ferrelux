---
title: "⚖️ Hunter Biden’s Finally Indicted In 2023 \U0001F3DB️"
date: '2023-09-18T01:37:07.170Z'
slug: hunter-bidens-finally-indicted-in-2023
tags:
  - hunter-biden
  - '2023'
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1695238171337/7dfe7008-5d49-4a3e-a5c0-a90c9ed52801.jpeg
---
**Experiri Effugere Eam 🤔 Try To Escape It**

[**Iron Maiden - Virus (Visions Of The Beast) 1996**](https://www.dailymotion.com/video/x2apa5i)  
🎵 I chose this track as a fun play encompassing The Hunter Biden Psychedelic Experience, as it has a message: . . . *There’s an evil virus threatening Mankind, . . . the two-faced elite . . . a menace to society . . . Superficially smiling a shake of the hand, As soon as the back is turned, treachery is planned . . . And every time you think you're safe, And when you go to turn away, You know they're sharpening all their papers knives . . . They want to sink the ship and leave. All in your mind, all in your head, try to relate it. All in your mind, all in your head,* ***try to escape it*** *. . .*  
*The Rats in The Cellar, You know WHO You Are . . .* 🦉 [*The Rest Of The Lyrics*](https://www.lyrics.com/lyric/24869408/Iron+Maiden/Virus)

👉 **Прокрутіть Галерею, Щоб Знайти Українську Версію Цієї Статті**  
**Scroll Pass The Gallery For The Ukrainian Version Of This Article**

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1695153994623/aa8cac93-2bf3-4186-aa5e-da2150d9e95c.jpeg align="center")

I know a lot of Republicans are happy to see this after putting all those hours of work into bringing this guy down and his Father, Joe Biden. It’s like I said late last year in [my article](https://ferrelux.com/hunter-bidens-laptop) before this calamity hit. With all that shit on him, ***the way to escape it*** was running for President. He could have really cleaned himself up out of that quagmire, put himself together, do a modeling shoot, start carrying himself right for The People to start seeing him as President material. And back then, *he had little time to do it,* and it’s virtually impossible now. He’s got some nice recent photos out there that will be featured in The Gallery below of him looking Presidential. He could have gotten out of that bullshit completely had he rocked the idea of a run, *test the waters* and see. For a long time before the indictment, he was treated really well in The Democratic Press with nobody really caring about the allegations. That shit was working for him. He could have used his drug image as a tool also to reach out into certain communities like a pseudo rock star appealing to an alternative street crowd, but no, what he wanted to do was lose. The son destined for Presidency was **Beau Biden** with his impeccable record. And now that he’s no longer here, the son with the slightly lesser credentials can only be so bold to honor his brother and father in such noble manner by attempting the impossible. No one would ever think it, but what else are you going to do? You might not have the entire polished ivy-league road map your brother had for President, but you sure make up for it being a Scrapper, able to shrewdly present yourself with your Lawyer mind finagling international deals at the highest levels. What else are you able to do? Maybe in the eyes of Somebody else if not Joe Biden, you might be ***The Apprentice.*** The person among the other possible Democratic Candidates to set up against The Republican One. The Justice System wasn’t that serious about clipping you or your father before until NOW. All of a sudden your sweet deal collapsed. *What changed?* They’re no longer supporting your family in politics. They’re trying to do an Al Capone on Ya. Oh we can’t get him on these serious charges so we’ll use the firearm thing instead. Look Man, this is a time for Hunter to think back to his drug phase and draw some wisdom from that like he’s Buddha, because he’s going to need some enlightenment. REALITY is what you make it. So you walk around in a haze believing this is not real right now. All those charges don’t exist and they can’t break me. *That technique works.* And when you slip out of THAT reality, you’ll be enlightened like a god in the current one with the answer. So what Hunter needs to be thinking about is what **game** The Justice System might be playing with him looking at his case. He successfully ESCAPED other possible charges concerning being paid millions for Influence Peddling with Ukraine & China, that the only thing they came up with is 3 charges concerning his Firearms. *Hmm.* Your name is HUNTER, right? Well, in The Woods, where you are, you just infiltrated The Headquarters of The Deep State and obtained certain government secrets to aid a competing faction of our Union to save The American People, and you evaded the capture of those shadowy Federal Agents out to get you. And you lost the radio signal from The Cabin so you can’t get a sense of the terrain now from Your Father who had set up a Fort there with top technology connected to a Satellite, and he’s worried about you. So now, these G-Men have a greater advantage hunting you and they know it, because they were responsible for jamming the frequency. And while you’re out there with your gear and low munitions, being a skilled Hunter, but slightly injured, you’re on your way out of The Woods, until you notice an all too familiar trap you just spotted. You stop, and see how well hidden 3 Firearms are wedged up triangularly in different trees and you can tell that if you move this way or that, you’ll trip off something and be shot. You’re use to escaping one trap like that at a time, NOT 3 at the same time, and since that route is the best route out of your problem rather than turning back to fight The Feds gaining on you and armed to the teeth, ***how will you escape?***

Sign,  
Lhisa Mrklon  
*Your Story Teller*

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1695001730097/cfaee0db-c9f6-43cd-a346-b75742a8f1a3.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1695149332761/e48b6379-5a35-4593-888a-30194dfa0409.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1695236566165/cc49841b-8eb9-468d-9fc6-745391bcf169.png align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1695239780494/aa3b851d-90fa-41f8-a7f5-2034e55de1e1.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1695149391968/180111de-13cc-479e-a63a-e2c432e3bd19.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1695148988325/3bd2bfaa-f8c5-45c0-b830-68addb937ff5.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1695149012511/64d2a0a3-f217-4379-916e-fbb9a92d1a6d.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1695239814031/d4bfeaeb-76b5-432e-bcd1-352daae1a200.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1695148463245/79e830ee-0711-47e5-acf4-9150913b7788.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1695239513048/50556b6d-02b5-4d85-8c97-4be5eeaa50b6.png align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1695238084341/86d898ea-f4b8-4882-965c-cb60e94eefff.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1695148220191/47b3fd91-e25c-4cc8-9a33-aec353ce720d.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1695148288346/44205c62-fda4-4c1a-8edc-902c5be2b04a.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1695148311102/15aadd27-368d-4e20-a113-d4b8266174a6.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1695148542175/5a7c87e7-ca5f-4003-9fce-8996f0b30afe.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1695237690645/478fd2cb-30b6-4ddd-9c9c-037e793f151d.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1695239490070/c7ff86ee-02ab-4cc4-ac68-4ebf797c8829.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1695242515257/3ea6b4e2-4e69-4ea5-8bba-d4c1ea40814b.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1695241119220/1f405596-5117-4e34-a9ef-103f02f11bb8.jpeg align="center")

**UKRAINIAN TRANSLATION  💸  ПЕРЕКЛАД УКРАЇНСЬКОЮ МОВОЮ**

**Хантеру Байдену остаточно пред'являть звинувачення в 2023 році**

Я знаю, що багато республіканців із задоволенням бачать це після того, як витратили стільки годин роботи на повалення цього хлопця та його батька Джо Байдена. Все так, як я говорив в кінці минулого року в своїй статті, ще до того, як сталося це лихо. З усім цим лайном на ньому, єдиним способом уникнути цього було балотуватися в президенти. Він міг би дійсно виплутатися з цієї трясовини, взяти себе в руки, знятися в модельній фотосесії, почати вести себе правильно, щоб люди почали бачити в ньому підходящого президента. І тоді у нього було мало часу, щоб зробити це, а зараз це практично неможливо. У нього є кілька приємних останніх фотографій, на яких він виглядає як президент, які будуть представлені в галереї нижче. Він міг би повністю виплутатися з цього лайна, якби відмовився від ідеї пробігтися, промацати грунт і подивитися. Довгий час, до обвинувачення, до нього дуже добре ставилися в демократичній пресі, і ніхто насправді не піклувався про звинувачення. Це лайно працювало на нього. Він міг би використовувати свій імідж наркомана також як інструмент для привернення уваги до певних спільнот, подібно до псевдо-рок-зірки, що апелює до альтернативної вуличної натовпу, але немає, чого він хотів, так це програти. Сином, якому судилося стати президентом, був Бо Байден з його бездоганним послужним списком. І тепер, коли його тут більше немає, син з трохи меншими повноваженнями може бути настільки сміливим, щоб вшанувати пам'ять свого брата і батька таким благородним чином, зробивши спробу неможливого. Ніхто ніколи б так не подумав, але що ще ти будеш робити? Можливо, у вас немає всієї відточеної "дорожньої карти Ліги плюща", яку мав ваш брат на посаді президента, але ви, безсумнівно, компенсуєте це тим, що ви скраппер, здатний проникливо представити себе з розумом юриста, який укладає міжнародні угоди на найвищому рівні. Що ще ви вмієте робити? Можливо, в очах когось іншого, якщо не Джо Байдена, ви можете бути студентом. Людина з числа інших можливих кандидатів від Демократичної партії, якого можна протиставити республіканцеві. До цього часу судова система не сприймала так серйозно, щоб заарештувати вас або вашого батька. Раптом ваша вигідна угода розвалилася. Що змінилося? Вони більше не підтримують вашу сім'ю в політиці. Вони намагаються зобразити з тебе Аль Капоне. О, ми не можемо пред'явити йому таких серйозних звинувачень, тому замість цього використаємо вогнепальну зброю. Подивіться, чоловіче, зараз саме час Хантеру згадати про свою наркотичну фазу і взяти з неї трохи мудрості, ніби він Будда, бо йому знадобиться якесь просвітлення. Реальність-це те, якою ви її робите. Отже, ти ходиш як в тумані, вірячи, що прямо зараз це нереально. Усіх цих звинувачень не існує, і вони не можуть мене зламати. Ця техніка працює. І коли ви вислизнете з цієї реальності, ви будете просвітлені, як бог в поточній, і отримаєте відповідь. Отже, про що Хантеру потрібно подумати, так це про те, в яку гру може грати з ним система правосуддя, розглядаючи його справу. Він успішно уникнув інших можливих звинувачень у тому, що йому заплатили мільйони за торгівлю впливом з Україною та Китаєм, і єдине, що вони висунули, - це 3 звинувачення, що стосуються його вогнепальної зброї. Хмм. Тебе звуть ХАНТЕР, правда? Що ж, у лісі, де ви знаходитесь, ви щойно проникли в штаб-квартиру глибокої держави і отримали певні урядові таємниці, щоб допомогти суперницькій фракції Нашого Союзу врятувати американський народ, і ви уникли захоплення тих тіньових федеральних агентів, які полювали на вас. І ви втратили радіосигнал з хатини, тому тепер ви не можете отримати уявлення про місцевість від свого батька, який побудував там форт, використовуючи новітні технології, підключені до супутника, і він турбується про вас. Отже, тепер ці гангстери мають більше переваг у полюванні на Вас, і вони це знають, тому що вони відповідали за глушіння частоти. І поки ви там зі своїм спорядженням і невеликою кількістю боєприпасів, будучи досвідченим мисливцем, але злегка пораненим, ви виходите з лісу, поки не помічаєте занадто знайому пастку, яку тільки що помітили. Ви зупиняєтесь і бачите, як добре приховані 3 одиниці вогнепальної зброї, розташовані трикутником на різних деревах, і ви можете сказати, що якщо ви рухаєтесь в той чи інший бік, ви спіткнетесь про щось і будете застрелені. Ви звикли уникати однієї подібної пастки за раз, а не трьох одночасно, і оскільки цей маршрут-найкращий спосіб вирішити вашу проблему, а не повертати назад, щоб боротися з федералами, які наздоганяють Вас і озброєні до зубів, як ви будете тікати?  
  
Знак,  
Ліза Мрклон  
Ваш оповідач
