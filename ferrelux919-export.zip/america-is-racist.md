---
title: "America IS Racist \U0001F3B3\U0001F3AF\U0001F3B1"
date: '2021-05-13T17:09:27.000Z'
slug: america-is-racist
tags:
  - cargo
  - history
  - banking
  - hair
  - usa
  - corporate
  - metaphysics
  - skin
  - urban
  - america
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672193099471/7dEkXi6E4.png
canonical: 'https://ferrelux666.wordpress.com/2021/05/13/amerikkka/'
---
[![Racism And The Justice System](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193064448/vMiPoJ-sy.png align="left")](https://www.history.com/topics/slavery/life-aboard-a-slave-ship-video#:~:text=From%20approximately%201525%20to%201866%2C%2012.5%20million%20Africans,FACT%20CHECK%3A%20We%20strive%20for%20accuracy%20and%20fairness.)

\*\*[“Promised Land” – Kanye West, w/ Malik Yusef & Adam Levine](https://www.youtube.com/watch?v=gnwoYZoUCp8)   
Dispergatur Populus Quadrum Terrae 🐑 A People Scattered To The Four Corners Of The Earth  
\*\*

So The Leaders of this Country began a political campaign stating that America is not racist, when a Citizen or Immigrant needn’t look too far to discover how racist this nation really is. Now ya’ll got pimped slapped on that topic the other day by our greatest Scholars. Did you forget how it all began a little over 400 years ago? That there were some Natives here your Ancestors massacred and then took over the land, and while doing all that they also enslaved another people from across the sea, transporting them here to work as slaves under brutal conditions. And when those slaves revolted and won, you set up some Jim Crow Laws segregating **your** people from ours, all the while going around in mobs lynching Blacks. And when the Civil Rights Movement came in overturning that, you still kept vestiges of it that are blatantly seen Today in Corporate America, The Banking System, Landlord-ism, and The Police to name the more critical everyday ones. And The Nation is still smitten with that mental illness of oppressing a wooly-haired people with a very dark skin-tone. And you’re being so oblivious to the other types of people here who are really more of a threat to you, strategically plotting a mass take-over. And I won’t get into some of the hurtful things right now which our people struggle with psychologically & emotionally from generation to generation because all that stuff has already come out in some of my takes on certain social issues, and will continue to as I take on more of these political topics. A lot of what I would discuss is already out there in some form that other opinionated people had put out educating you. And Ya’ll should look in the mirror and be ashamed of yourselves. And to my Oppressed People, you shouldn’t be powerless to the hateful whims that another people subjects you to. Your genetic **skin-tone** has metaphysical value which was known to only a few in ancient times and The knowledge of accessing it was deliberately cut-off from you. You only need to look at the cryptic examples that some of our Ancient Ancestors left behind in depictions & carvings to realize some things, why another people oppressing you over it should strike you as odd. **What is it?** What can you do that they can’t? Their ancestors knew, and some how along the course of history the real reason got lost even to them as to why they needed to oppress you. And when you **discover** that secret, oh god, it will change EVERYTHING.

Sign,  
LHISA 666

### Will The Centuries Old Systematic Racism In America, Practiced Across The World Ever Go Away? Scroll Down And Leave Your Reply Below.

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193066697/OHe-8cZrg.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193068357/vIBfcp9k65.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193069608/A16S_V5Jq.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193070914/aHNCEfKc7.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193072377/sUQGlezXp.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193073738/yvFE5QNcV.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193074793/1sdKlKHC6.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193076136/NxWp6uuwr.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193077748/Yk2S2iex7.jpeg align="left")

Policemen arrest black suspects in a Detroit street on July 25, 1967 during riots that erupted in Detroit following a police operation. / AFP PHOTO / AFP FILES / – (Photo credit should read -/AFP via Getty Images)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193079382/GqGTS4-Zr.jpeg align="left")

CHARLOTTESVILLE,VA-AUG11:Chanting White lives matter! You will not replace us! and Jews will not replace us! several hundred white nationalists and white supremacists carrying torches marched in a parade through the University of Virginia campus last night. Beginning a little after 9:30 p.m., the march lasted 15 to 20 minutes before ending in skirmishing when the marchers were met by a small group of counterprotesters at the base of a statue of Thomas Jefferson, the universitys founder. (Photo by Evelyn Hockstein/For The Washington Post via Getty Images)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193081001/iqkwrHV1_.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193082430/IHA-4AfyO.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193083972/GxE8mcw_o.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193085433/IXNJErfta.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193086658/rb3rHasHM.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193088023/qVOcPVszR.jpeg align="left")

Two young black men pass Klan marchers in downtown Salisbury, N.C., August 1964. The Ku Klux Klan was active in North Carolina, and Sturkey covered many of their demonstrations.

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193089341/wNI6tdstF.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193090844/Lot1zt0pF.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193092060/Xl6rl2Bm2.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193093380/YDWB-khtA.jpeg align="left")

SHOP ITEMS ON SALE  

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193095222/xQlmgCltg.jpeg align="left")](https://miniinthebox.8zwg.net/c/3170166/461413/8200?prodsku=5344310&u=https%3A%2F%2Fwww.miniinthebox.com%2Fcosplay-costumes-movie-tv-theme-costumes-movie-cosplay-white-black-patchwork-dress-halloween-female-polyester_p5344310.html%3Fcurrency%3DUSD&intsrc=PUI2_2952)
