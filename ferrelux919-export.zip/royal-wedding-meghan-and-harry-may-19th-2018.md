---
title: "Royal Wedding: Meghan & Harry (May 19th 2018) \U0001F48C\U0001F495\U0001F492"
date: '2018-05-19T16:42:50.000Z'
slug: royal-wedding-meghan-and-harry-may-19th-2018
tags:
  - canada
  - africa
  - love
  - american
  - queen
  - suits
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195472204/wLOwFzmzT.jpeg
canonical: 'https://ferrelux666.wordpress.com/2018/05/19/royal-wedding/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195461024/zVoiN_B3k.jpeg align="left")](https://www.ferrelux.us/)

Fide Et Amor 💞 Faithfully And Lovingly

**It’s official. THEY ARE MARRIED. I woke up 5am today to watch the whole thing LIVE our time since England is 5 hours ahead of us, as the American news broadcasters covered the event.**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/vn2rSYxjqaI?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

**SEE EVEN MORE HERE………..**  
[Her Life Before Prince Harry](https://www.youtube.com/watch?v=7evf93RWu70&spfreload=5)  
[Their Love Story](https://www.youtube.com/watch?v=1TtWUk4EXs8)

**~ Lhisa Mrklon**

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195462140/sKaXyp8Br.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195463311/Uu5Xt8m8s.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195464916/6005B5ZS-.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195466198/8jchhZI-E.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195467686/zwvpenJIF.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195469256/6i1qhpCmq.png align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195470915/tqiyA9LWu.jpeg align="left")](https://ferrelux.com/adverts/)
