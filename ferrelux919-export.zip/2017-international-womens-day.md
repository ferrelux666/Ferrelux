---
title: "\U0001F6BA2017 International Women’s Day\U0001F98B"
date: '2017-03-19T18:06:54.000Z'
slug: 2017-international-womens-day
tags:
  - conference
  - rights
  - women
  - health
  - pay
  - global
  - opportunities
  - economics
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195929181/qJBXcKSZI.png
canonical: 'https://ferrelux666.wordpress.com/2017/03/19/international-womens-day/'
---
![693964439sj00035-women-s-ma](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195920939/4EH5Exaot.jpeg align="left")

**The struggle for Women’s Rights still continues in 2017 all over the world, for**  
**respect, leadership, equal pay, education, and so on…………**

**Here’s the message from, Phumzile Mlambo-Ngcuka, the Executive Director of the United Nations**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/3Vees04UeOE?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

**Here’s Former First Lady, Michelle Obama’s message from 2016**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/FIN1F0TyadM?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&start=3&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195923607/NqiNBrA3O.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195925412/b_21QLL6b.jpeg align="left")
