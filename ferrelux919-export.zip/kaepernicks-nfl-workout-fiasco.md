---
title: "Kaepernick’s NFL Workout Fiasco \U0001F39F⚽\U0001F3C6"
date: '2020-01-10T19:53:15.000Z'
slug: kaepernicks-nfl-workout-fiasco
tags:
  - news
  - community
  - issues
  - fitness
  - sports
  - corporate
  - controversial
  - olympics
  - soccer
  - football
  - protest
  - wrestling
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672194489715/eB8Ajo03P.png
canonical: 'https://ferrelux666.wordpress.com/2020/01/10/workout/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194456788/yfnBCT8lJ.png align="left")](https://www.ferrelux.us/)

[**Eric B & Rakim ~ “I Ain’t No Joke”**](https://www.youtube.com/watch?v=2TN-kDEKxF0)

*Audemus Jura Nostra Defendere 🤾🏽‍♀️ 🤾🏾‍♂️ We Dare To Defend Our Rights*

It was a disaster for the NFL, not him. So here’s what happened since we last left off with Kap. While the NFL tries to repair its image back to the heydays by getting 2 top Hispanic Singers, Shakira & J.Lo to sign on as performers despite other top performers who’re mainly Black refusing to because of the whole ‘side with Kap’ thing, to attempt to resolve it, they reach out to Colin Kaepernick. The NFL wanted the Workout to be held in a controlled environment of their choosing where the media will learn what they chose to disclose, but being a Conscious Brother, Kap wanted the venue to be more public so the people can see what’s going on. They should have never reached out to him! If there are still some grievances, that was a mistake. It wasn’t negotiated properly. I’m with Kap. After hearing the shit, he was right. At first, listening to the news account, the real info didn’t get out right why it sounded like Kap was a no show until the cameras got on him to explain what happened. It was a set up! A Black Idiot ESPN Commentator, Stephen Smith, always had something negative to say about Kaepernick, and he jumped on it the day before the Workout saying to Kap through the camera & pointing his finger, “You better show up.” Well he did, but the event created more problems than solutions. Had they just left Kap alone, it would have been better. What’s really going on here is that they don’t want him back. It’s like Fuck You Kap, you first took a knee on August 14th 2016, then got others to take it with you & ruined our brand, you sued, we paid you, now move the fuck on, get lost, go play with another league, but the public agrees with you that you should have your job back with us since we’re a GIANT football league here in the United States, having not worked in 3 years & you want to play ball. And he proved he was still fit & ready to play at the Workout. To be fair here, this whole conflict could have been avoided from the very beginning had some legally thinking person, left him the fuck alone. You see him there taking the knee refusing to recite the National anthem, just make a quick positive press remark about it and play ball. The NFL later on letting their blood boil, creating a big stink around it due to mounting political pressure from Trump, caused it to escalate to a valid movement. Ignore his Black Ass, get your press people on a side note to articulate some encouraging social change argument to explain his protest on YOUR football field and protect your brand. Nobody would have cared much had they kept everything else about the game, merchandise, & the half-time show. And stop focusing the cameras on him too much, it’s fodder for a trouble-making press person. The problem would have went away with the right grace & tactic. Is the NFL responsible for police brutality? No, but Kap used their platform to make a point. Was that fair to them? No, but it happened. So now we’re here. Their response could have been better. Addressing the issue in a sensitive manner since a lot of their players, about 90% are Black, would have been smart. A carefully worded ad playing on the airwaves supporting the political consciousness of your players would have softened any Right-Wing aggression coming against it to understand, though the games are meant to bring people together, we should strive to continue to repair the problems that divide us. The NFL missed an opportunity to be a proponent for change, when back in the 1980s ya’ll would have dealt with the topic wiser like the WWF, (now the WWE) & G.L.O.W (the original Gorgeous Ladies of Wrestling). They had all kinds of diverse wrestlers & were smart to recognize their power in presenting forward thinking THEN on socio-political topics. If you couldn’t do that, then simply funding certain philanthropic projects in poor communities to help improve their daily lives would have been looked on as heartwarming since many of your players came out of there. But instead, after a number of days, the leaders of the NFL decided to attack Kap. Oh shut him up, remove him and let’s play ball, and life will carry on as usual, but a topic like Police Brutality can’t be removed from the table like that. You have a bunch of ‘Niggers’ playing ball for your league earning trillions of dollars for you and you can’t just dismiss their right to take a stand on a relevant topic. There was ample time for somebody to have delicately handle issues like that. I agree it shouldn’t be the elephant in the room when you take your family out to have a good time, but Kap was the player it emotionally affected the most to take a knee and NOT salute the flag, and no one in the administrative level was apparently equipped to discuss a proper method in dealing with it. Most problems can be diffused with the right person managing it. The NFL thought that person was Jay-Z but he drew criticism for some remarks that it’s time Kap move on from taking a knee and NOW some people are blaming Jay-Z for pushing the whole Workout event hoping it would turn out well, but simply offering him his rightful place back into the NFL would have wiser. So the ball is still in Kaepernick’s court. The NFL has not made any new motion towards Kaepernick since then. We’ll see if the Superbowl does well this year with the performances, since its last great success was with Lady Gaga before the Kaepernick controversy, and if ever their struggle with him gets resolved the right way. Anyway, you can enjoy more of Colin Kaepernick since the Workout incident now that sports gear giant NIKE released a new sneaker in honor of him.

[https://kaepernick.nofyme.com/?vst=kaepernick&redirect=true](https://kaepernick.nofyme.com/?vst=kaepernick&redirect=true)  
[https://twitter.com/kaepernick7](https://twitter.com/kaepernick7)

L H I S A,  
666

**Was Kap Buggin’ Or Was He Right Going Off On The NFL Like That? Scroll Down And Leave Your Reply Below.**

[![Ferrelux Homepage_KaepernickWorkout](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194458271/wkhLAqHLt.png align="left")](https://ferrelux666.wordpress.com/2020/12/24/goodbye-2020/ferrelux-homepage_kaepernickworkout/)

[![KAEPERNICK_OS](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194459748/8nPc4u1SZ.jpeg align="left")](https://ferrelux666.wordpress.com/kaepernick_os/)

[![maxresdefault](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194461112/yeHcaTZRo.jpeg align="left")](https://ferrelux666.wordpress.com/maxresdefault-10/)

[![untitled (4)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194462675/YstnHrN1b.png align="left")](https://ferrelux666.wordpress.com/untitled-4-6/)

[![untitled (5)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194464160/IpCQO0GFis.png align="left")](https://ferrelux666.wordpress.com/untitled-5-5/)

[![WireAP_dd81afb027c94c3dbae2181763d8d3bd_16x9_992](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194465451/43-YGOd-z.jpeg align="left")](https://ferrelux666.wordpress.com/wireap_dd81afb027c94c3dbae2181763d8d3bd_16x9_992/)

[![colin-kapernick-nike-air-force-1-low](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194466796/Y0PJHtEic.jpeg align="left")](https://ferrelux666.wordpress.com/colin-kapernick-nike-air-force-1-low/)

[![imrs](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194468048/yYEGg8cjg.jpeg align="left")](https://ferrelux666.wordpress.com/imrs/)

[![Jay-Z-Colin-Kaepernick-Statement-1574114604-e1574114708425-650x366](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194469298/0b1_8ABWG.jpeg align="left")](https://ferrelux666.wordpress.com/jay-z-colin-kaepernick-statement-1574114604-e1574114708425-650x366/)

[![JAY-Z-Kaepernick-NFL-Workout](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194470655/ktoGXVuM-.jpeg align="left")](https://ferrelux666.wordpress.com/jay-z-kaepernick-nfl-workout/)

[![kaepcollection](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194471803/bBwWCV-dc.jpeg align="left")](https://ferrelux666.wordpress.com/kaepcollection/)

[![Colin-Kaepernick-thejasminebrand](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194473793/DHXgLOFu_.png align="left")](https://ferrelux666.wordpress.com/colin-kaepernick-thejasminebrand/)

[![arrives at the ESPN's BODY at ESPY's Pre-Party at Lure on July 15, 2014 in Hollywood, California.](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194475200/u4z_GSBwG.jpeg align="left")](https://ferrelux666.wordpress.com/colin-kaepernick/)

arrives at the ESPN’s BODY at ESPY’s Pre-Party at Lure on July 15, 2014 in Hollywood, California.

[![c9e32548-0d9b-4229-b49c-2c70ddfcd176](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194476733/E8XtGDc-y.jpeg align="left")](https://ferrelux666.wordpress.com/c9e32548-0d9b-4229-b49c-2c70ddfcd176/)

[![a934f65e9567fa5b1c60f4532b130002](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194478044/5zFaNPMUP.jpeg align="left")](https://ferrelux666.wordpress.com/a934f65e9567fa5b1c60f4532b130002/)

[![a53ff6ad81474356684bfb07f8077d44](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194479167/ZZuTLVfXm.jpeg align="left")](https://ferrelux666.wordpress.com/a53ff6ad81474356684bfb07f8077d44/)

[![960x0](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194480418/upmIkBJRI.jpeg align="left")](https://ferrelux666.wordpress.com/960x0-2/)

[![544f8c8d10615b07dee250a03976cc6c](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194481805/PZ_PU81oH.jpeg align="left")](https://ferrelux666.wordpress.com/544f8c8d10615b07dee250a03976cc6c/)

[![6a3e9935b0314641af58192dd372abf8_md](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194483326/tB_qU_byq.jpeg align="left")](https://ferrelux666.wordpress.com/6a3e9935b0314641af58192dd372abf8_md/)

[![5dd2d15d3afd374b7d227765](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194484639/pqHHegZ1C.jpeg align="left")](https://ferrelux666.wordpress.com/5dd2d15d3afd374b7d227765/)

[![3fc6b450ddf85be5b349c24345f9af14_md](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194485957/w2x4UXf77.jpeg align="left")](https://ferrelux666.wordpress.com/3fc6b450ddf85be5b349c24345f9af14_md/)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194487467/7Qxugl7Ju.png align="left")](https://ferrelux.com/adverts/)
