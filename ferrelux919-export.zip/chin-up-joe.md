---
title: "Chin Up, Joe! ⛅\U0001F4F0\U0001F37A"
date: '2021-02-10T00:58:07.000Z'
slug: chin-up-joe
tags:
  - interview
  - trump
  - tv
  - vp
  - politics
  - pennsylvania
  - joe-biden
  - president
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672193525871/ZsFXqSJhZ.jpeg
canonical: 'https://ferrelux666.wordpress.com/2021/02/09/chin-up-joe/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193510202/tsJhA0Ly0.jpeg align="left")](https://www.cbs.com/shows/video/7Q_6kpadhxRmaH0gx4PnaVuemSGPHtW1/)

  
\*\*  
Pater Patriae 🤴🏻 Father Of His Country (Emperor Augustus)\*\*

[USA State Song: Pennsylvania](https://www.youtube.com/watch?v=WDiSCTlHl5Q)

Hey Potus 46, as I saw you being interviewed recently on TV and you teared up again remembering your beloved deceased son Beau Biden, I felt hurt with you. Now I’ve been hard & sarcastic with you in past articles about your running for The Presidency, but you showed everyone your fortitude in coming through and winning. You don’t need to explain yourself to anyone. I bet his soul is proudly looking over you. Now, you got a lot of enemies in the media actively propagating negative stuff about you without discretion almost every single day, seeing you as a weak leader. Now their energy is quite different from mine. You see when I “attack” you and your Administration or the Democratic Party in general, though tough at times, it’s done humorously with an agenda in mine. The criticism is designed to help you see something. And I’ve artfully engaged the past Administration likewise. I actually think it’s sad that your haters all decided to go that way using your age against you. I also liked pointing that out, but I still can see that young vigorous Senator in you, why I make certain antagonist commentary to draw him out. You’re a bit too civil these days, you need to be lashing back. Do you realize WHO you are? You accomplished something they did not expect. They’re thinking, oh this feeble old man, let’s get him emotional and doubting himself, and so forth till we chase him out of power. Now, remember young Senator Joe? How he was? How he was behaving even if he did not always say or do the politically correct things? That Dude would know how to aggressively handle The Media like Trump. You see you’re too wise now, too proper. You don’t need to take shit from anybody. I disagree with some of your policies, but damn I’m not out here like them mercilessly attacking it. The hostility towards you is everywhere. You’re a Democrat! Think about young Joe. You might even age backwards before our very eyes. Give ‘em something to really talk about. They still can’t believe YOU got to that position, and at any given moment some liberal idea may spark inside your head, and they’re afraid that your old shaky fingers may sign off on some policy they ain’t gonna like, and you got your Black Female VP & other Enforcers behind it. You peacekeeping, trying to formally engage dissident Republicans in your global dream is a nice gesture but they already see the writing on the wall. They ain’t with you. Stop all that diplomatic stuff with them. You’re in a war right now. They can’t believe YOU got the highly coveted Reins of Power from Trump **\_***and can really do some things***\_**. But remember, I’m still here observing & critiquing everything as I mirthfully watch this game unfold. **YOU** are now The Leader of the Free World at 1600 Plantation Avenue. Not bad for a humble kid from Scranton, Pennsylvania.

Sign,  
Lhisa Mrklon

### Are You Surprised That Joe Biden Won The Presidency? Scroll Down And Leave Your Reply Below.

[![Ferrelux Homepage_Chin Up Joe](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193511762/q1cD41wCV.jpeg align="left")](https://ferrelux666.wordpress.com/ferrelux-homepage_chin-up-joe/)

[![There's Joe](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193513580/uf-gyvs7D.jpeg align="left")](https://ferrelux666.wordpress.com/theres-joe/)

[![Joe Biden With Son Hunter](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193514929/-Cs-LkC4D.jpeg align="left")](https://ferrelux666.wordpress.com/joe-biden-with-son-hunter/)

[![NEW YORK, NY - SEPTEMBER 26: Vice President of the United States Joe Biden attends 2015 Global Citizen Festival to end extreme poverty by 2030 in Central Park on September 26, 2015 in New York City. (Photo by Michael Kovac/FilmMagic)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193516329/hXVAu0gOZ.jpeg align="left")](https://ferrelux666.wordpress.com/2015-global-citizen-festival/)

NEW YORK, NY – SEPTEMBER 26: Vice President of the United States Joe Biden attends 2015 Global Citizen Festival to end extreme poverty by 2030 in Central Park on September 26, 2015 in New York City. (Photo by Michael Kovac/FilmMagic)

[![Hunter Biden And His Dad](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193517686/HFav9dqco.jpeg align="left")](https://ferrelux666.wordpress.com/hunter-biden-and-his-dad/)

[![Biden & Son](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193518857/ovmVBSNgS.jpeg align="left")](https://ferrelux666.wordpress.com/biden-son/)

[![Hunter Biden & Father Joe](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193520144/Dfc_FLBQB.jpeg align="left")](https://ferrelux666.wordpress.com/hunter-biden-father-joe/)

[![Here's Joe](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193521441/PX0O0KZOs.jpeg align="left")](https://ferrelux666.wordpress.com/heres-joe/)

[![Vice President Joe Biden gestures after donning a pair of sunglasses as he delivers the Class Day Address at Yale University, Sunday, May 17, 2015, in New Haven, Conn. Biden urged graduating students to question the judgment of others, but not their motives to build consensus. (AP Photo/Jessica Hill)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193522720/hfYixg_yi.jpeg align="left")](https://ferrelux666.wordpress.com/news/cool-joe/)

Vice President Joe Biden gestures after donning a pair of sunglasses as he delivers the Class Day Address at Yale University, Sunday, May 17, 2015, in New Haven, Conn. Biden urged graduating students to question the judgment of others, but not their motives to build consensus. (AP Photo/Jessica Hill)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193524076/iQ07WWfq3.jpeg align="left")](https://www.discovercars.com/?a_aid=Ferrelux)
