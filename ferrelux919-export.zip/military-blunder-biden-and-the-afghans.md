---
title: "\U0001F5FDMilitary Blunder: Biden & The Afghans\U0001F985"
date: '2021-08-29T23:33:55.000Z'
slug: military-blunder-biden-and-the-afghans
tags:
  - technology
  - trump
  - communities
  - culture
  - india
  - women
  - modern
  - threat
  - kids
  - policy
  - war
  - society
  - europe
  - usa
  - girls
  - africa
  - school
  - covid-19
  - race
  - coronavirus
  - crime
  - iran
  - guns
  - escape
  - politics
  - vaccine
  - god
  - america
  - faith
  - military
  - joe-biden
  - middle-east
  - flight
  - president
  - city
  - desert
  - population
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672208588638/24a8fa89-02d6-4e52-bc77-3b9615ed9924.jpeg
canonical: 'https://ferrelux666.wordpress.com/2021/08/29/afghans/'
---
[![Joe Biden and the Afghanistan War](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192698472/8hpw89DOg.jpeg align="left")](https://www.dailymotion.com/search/Biden%20and%20Afghanistan/videos)

\*\*[GI JOE THEME SONGS (ALL INTROS, 7min & 21 sec)](https://www.youtube.com/watch?v=iENz3Lv5uA4)  
No Dedere, No Fugere ✈ No Surrender, No Retreat  
\*\*

My Revised Lyrics:  He’ll fight for freedom wherever there’s trouble GI Joe is there. GI Joe, a Real American Hero, GI Joe is there. It’s GI Joe against ISIS & The Taliban, fighting to save the day. He’ll never give up, he’s always there, fighting for freedom over land & air. GI Joe, a Real American hero, GI Joe is there. **GI Joe is the code name of America’s daring, highly trained special mission force. It’s purpose is to defend human freedoms against Arab Muslim Extremists, a group of ruthless nomadic terrorists determined to rule the world.** He’ll never give up, he’ll stay till the fight’s won, G.I Joe will dare. GI Joe, a Real American Hero. **GI JOE!**

**Yo Joe!** Whatever happened to that? America retreating from its everlasting war in Afghanistan, is a fully loaded topic all over the media. And President Joseph Robinette Biden, The Head of Our Military, **G**overnment **I**nspector **Joe** himself, called for it, which also resulted in the airlifts of multitudes of people from there fleeing The Taliban, being transported here in **Our Homeland**. We don’t know if terrorists are among them, and they are also un-vaccinated refugees. Ol’ Joe said that he will not continue to risk the lives of American Soldiers, if the Afghanistan People are unwilling to fight for themselves. He has a point, but the economic and democratic global vested interest in securing that area, to be there for decades fighting for a foothold over there was crucial. What should have happened way back was America taking over Iraq & Iran imperial style, and doing the same with Afghanistan to ensure future protection of its empire. Leaving that region and all its wealth under Islamic control, expecting them to fall in line with western values was dumb. And its arguable that when Barack Obama won The Oval Office as President, an uptick in extremist activity ensued due to them mis-reading that as a sign attesting to their right as Muslims to remain in power, especially when he went over there and bowed to a Sultan. I like Barack Obama, but certain moves no matter how polite can be mis-construed. So now, dealing with the same extremist problems, this time with Afghanistan, mostly Republicans are calling for Biden’s resignation and it was happening before this event a couple weeks ago when he co-signed off his friend Andrew Cuomo to step down as Governor over unproven allegations. Now look, when you set a precedent over canceling somebody over nonsense, **\_***it can affect you too***\_**, especially when what you are doing is more questionable, and provable. There’s so much to unpack here, and where do I start? First off, a mighty nation like America should NEVER be fleeing combat. Second, you let some debased Arab thugs beat you in battle. YOU have the weapons and technology. You are the more advanced culture. THEY should be submitting to YOU! There was a TV Show on The History Channel I loved watching called **Military Blunders**, exploring why and how some army lost a critical battle. That’s very important to decipher in this situation because Ya’ll should have conquered the place and setup a proper government and society. Now, let’s take a look at how things were many years back. Do you remember a time when you were in school, and a lot of the kids around looked like you and me, speaking the same language, dressed alike, enjoyed similar things, and so forth. Well, in the same school there was only a small population of students from East Indian or Arab Descent, and the person was either traditional or modernized. He or she never got in your way, or was involved in any activity designed to interfere or impair your right to be an American. And this continued for decades until now, where if you’re paying attention, depending on where you live in **Our Kingdom**, an increasing population of Arab Muslims are openly targeting, or interfering with non-Arab/Muslim persons in your city. And I have pointed this out a few times before exposing their cowardly activities in these refugee cities living among Black & Hispanic Communities, trying to take it over, and spread to your community. Some of their activities include trying to study particular persons, their life and family, and so forth. It particularly offends ME because I have ZERO interest in them. Like any other depraved weirdo, you only need to be a person they have an interest in to attract their unwanted attention. And they lack discretion too coming up on you in their monkey-ish attempt to convert and incorporate you into their ways. If you’re clearly someone from another race, culture, creed, and so on, it’s ignorant for them to be in your face like that, trying to be a part of your life, especially if you’re a person that likes eating pork, and are very much into your heathen beliefs and practices. The reason why America lost it’s longest war to date, in Afghanistan is because Ya’ll abandoned common sense. What happened to the foreign policies we had several decades back? When I’d turn on the TV as a young lady in Middle School, I saw news broadcasts about some poverty stricken people over there in The Middle East throwing stones at each other and talking badly about Jews and Israel. And it continued like that until foreign policies changed, to include them into our society. Why were they educated in any way on how to build modern weaponry, and trained in how to use them in combat? **They were Primitives before.** In Ancient Times, did you ever see The Sumerians, Greeks, Persians, or Romans, work against themselves by going to a people they saw as a threat and train them on how to use THEIR technology so that they can better defeat them? So in our day, we saw how in a time of Covid-19, some Arabs dressed in their traditional religious robes had strapped on them tactical gear, and carried their automatic firearm, wearing no mask, and were able to take over massive territory, defeating an advanced Western Military Army who were better equipped. **HOW!** I’m going to have to take you down memory lane, historic style. Before America became **America**, guess who was your enemy in Europe? ARABS! And many of them were Muslim too. They were either very dark-skinned or lighter complected. Except that in the common language over there, these advanced nomadic people were called MOORS, and guess who the slaves were? It was YOU, **White Man**. They moved into your territories all across Europe and set up their rules governing you for about 600 years. One treaty with England read where the Sultan demanded that 100 of the White Women in the town, to be given up to him regularly, at such and such a time as part of the bargaining to leave The Ruling Class as Figure Heads in power. So that White King & Queen and their Staff were only ruling puppets. And over time, dealing with that invasion, Europe **SOMEHOW** got their act together and overpowered **The Moors** and got them out of Europe. And as more time passed, The European Leaders at the time, among other things, wanted to protect their homelands from ever experiencing such a threat like that happening again. And you know what resulted? Some plotting that eventually led to **The Trans-Atlantic Slave Trade** after Colonial Occupation in Africa. But **YOU** weren’t any better, infact you did worse. You went extensively overboard attacking, robbing, raping and dehumanizing dark-skinned people that were not even Moorish or cared to be, cruelly transporting them to The Americas and elsewhere, and brutally enslaving them for about 400 years erasing their mother tongue and lineage to their ancestral past and homeland. So let’s go back for a minute to my previous point. **HOW** exactly did Europe defeat **The Moors** & expelled them and **Jews** out of Europe? That part of history is not fully explained well. The Moors at the time had the advanced society and the most powerful Navy, while Europeans were still learning art, science & math. And from that time, till now, nothing much has changed ideologically. When it comes to Muslims across The Globe, unlike debating Christians, they hold to the same core values, ignorant or not. It is debatable as to whether the Muslim religion is valid since some say it was created by Catholics. Whatever the case is, Christians need to decide whether Islam should be considered a part of the Monotheistic Belief In **God**, since they do not accept Jesus as his One Begotten Son, who died to pay an eternal price on behalf of Mankind’s sins, atleast Luciferians/Satanists honest with themselves understand that and don’t dispute it. Also, many Jews do not see Jesus as **God** nor recognize him as **The Son of God**. So my answer to you is, IDEOLOGY certainly played a major role back then **WHY** after being conquered, and occupied by Moors, **SPAIN** was not impressed by the farming, the aqueducts, the marketplaces, the public baths or other advancements that The nomadic Islamic “Black Africans” brought there, but were hellbent on getting them & Jews out of Spain, and somehow they succeeded. What you need to study is what **the tactic** was, because they accomplished defeating **the mass of them** in record time driving them out of Europe and recapturing lost territories, and this was at a time when OUR technology did not exist. So fast forward NOW to our time, when The United States Of America went over there and setup programs in schools talking to Afghani kids about same-gender marriages and pronouns, Ya’ll lost your mind. You looked stupid pushing that gay stuff on Muslims who have a long-standing tradition of Islam, and they believe in that. **Muslims far and wide over the globe are unified**, and are masters at extensively reproducing at 4 to 12 times the rate, populating, studying weaknesses in your system, strategizing, infiltrating cultures, corrupting unsuspecting people to join them, getting their people employed in your justice and political system, buying up franchises, tearing down western iconography and replacing it with god awful muslim ones in your neighborhood, and taking over places, and spreading their ways and religion all over the place in boarish ways. That’s why when America retreated, **all day that day**, where I live, there was what sounded like a celebration. And you know what, when September 11th 2001 happened, there were rare reports that leaked where some oppressed people identifying with that attack celebrated also. I remember the media laughing at Trump years back claiming he didn’t know what he was talking about, but I knew, and anybody else who was paying attention to the fallout over the whole thing knows. Anytime America gets their ass kicked, there’s usually a population here, identifying with it and laughing because they feel oppressed and see that as a win, but I caution you Black Folk, **Islam** is not the way. **And You should know better**. Arabs were your original Slave Traders, and Jews were historically involved in the process too. And when The White Man entered Africa, he got involved in the racquet, fiercely fighting Arabs for control over African Slaves. The only mistake The White Man made was not completing the job by getting rid of The Muslim Arab Threat then. That’s why centuries later, they are still **HERE** studying you, infiltrating and fighting you. They are **The Enemy** you left behind hundreds of years ago, who keeps coming back and being a thorn in your side. **Now you know what you must do!**

Sign,  
Lhisa Mrklon  
Your Oracle

### Should Joe Have brought The War-torn Afghani People Into The U.S.? Scroll Down And Leave Your Reply Below.

[![Ferrelux Homepage_Biden & Afghanistan](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192700156/bbIt8Bwae.jpeg align="left")](https://ferrelux666.wordpress.com/ferrelux-homepage_biden-afghanistan/)

[![Hundreds of people gather near a U.S. Air Force C-17 transport plane at a perimeter at the international airport in Kabul, Afghanistan, Monday, Aug. 16, 2021. On Monday, the U.S. military and officials focus was on KabulÕs airport, where thousands of Afghans trapped by the sudden Taliban takeover rushed the tarmac and clung to U.S. military planes deployed to fly out staffers of the U.S. Embassy, which shut down Sunday, and others. (AP Photo/Shekib Rahmani)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192701443/alysgarXD.jpeg align="left")](https://ferrelux666.wordpress.com/aptopix-afghanistan-2/)

Hundreds of people gather near a U.S. Air Force C-17 transport plane at a perimeter at the international airport in Kabul, Afghanistan, Monday, Aug. 16, 2021. On Monday, the U.S. military and officials focus was on KabulÕs airport, where thousands of Afghans trapped by the sudden Taliban takeover rushed the tarmac and clung to U.S. military planes deployed to fly out staffers of the U.S. Embassy, which shut down Sunday, and others. (AP Photo/Shekib Rahmani)

[![Afghan Refugees In Plane](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192702886/ehlPLvcMW.jpeg align="left")](https://ferrelux666.wordpress.com/afghan-refugees-in-plane-2/)

[![Afghanistan War Zone](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192704266/fc-5Ic46w.jpeg align="left")](https://ferrelux666.wordpress.com/afghanistan-war-zone-2/)

[![Afghani Taliban](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192705417/Kdp6uSK1_.jpeg align="left")](https://ferrelux666.wordpress.com/afghani-taliban-2/)

[![Afghan Special Forces](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192706748/x6H_g_-L7.jpeg align="left")](https://ferrelux666.wordpress.com/afghan-special-forces-2/)

[![African In Shackles](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192707847/pZaoaMoW-.jpeg align="left")](https://ferrelux666.wordpress.com/african-in-shackles-2/)

[![The Arab slave trade was the intersection of slavery and trade in the Arab world, mainly in Western Asia, North Africa, East Africa, India and Europe. Some historians assert that as many as 17 million people were sold into slavery on the coast of the Indian Ocean, the Middle East, and North Africa, and approximately 5 million African slaves were transported by Muslim slave traders via Red Sea, Indian Ocean, and Sahara desert to other parts of the world between 1500 and 1900. Africa illustrated by William. R. Smith; illustrated by the most eminent artists, 1889 (cropped and cleaned).](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192709329/VAOOrkr1wH.jpeg align="left")](https://ferrelux666.wordpress.com/arab-slave-trade-killing-exhausted-slaves-19th-century-2/)

The Arab slave trade was the intersection of slavery and trade in the Arab world, mainly in Western Asia, North Africa, East Africa, India and Europe. Some historians assert that as many as 17 million people were sold into slavery on the coast of the Indian Ocean, the Middle East, and North Africa, and approximately 5 million African slaves were transported by Muslim slave traders via Red Sea, Indian Ocean, and Sahara desert to other parts of the world between 1500 and 1900. Africa illustrated by William. R. Smith; illustrated by the most eminent artists, 1889 (cropped and cleaned).

[![Arabs And Slavery](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192710564/3PgnbsNGS.jpeg align="left")](https://ferrelux666.wordpress.com/arabs-and-slavery-2/)

[![Arabic Slave Trade](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192712067/Tdzf_6Jer.jpeg align="left")](https://ferrelux666.wordpress.com/arabic-slave-trade-2/)

[![Afghan National Army Special Forces](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192713575/MlbPh81E_.jpeg align="left")](https://ferrelux666.wordpress.com/afghan-national-army-special-forces-2/)

[![cropped-biden-and-afghanistan.jpg](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192714912/h0_ZW9dX5.jpeg align="left")](https://ferrelux666.wordpress.com/cropped-biden-and-afghanistan-jpg/)

[![White Women Sex Slaves](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192716097/BrwjskLf6.jpeg align="left")](https://ferrelux666.wordpress.com/white-women-sex-slaves/)

[![White Slavery In Barbary States](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192717409/bfHTCnWHc.jpeg align="left")](https://ferrelux666.wordpress.com/white-slavery-in-barbary-states/)

[![White Slave Traders](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192718419/VrUyaSupy.jpeg align="left")](https://ferrelux666.wordpress.com/white-slave-traders/)

[![White Slave Crusades](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192719450/lHIqYx_bH.jpeg align="left")](https://ferrelux666.wordpress.com/white-slave-crusades/)

[![The Jewish White Slave Trade](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192721810/B8lMMSyMB.jpeg align="left")](https://ferrelux666.wordpress.com/the-jewish-white-slave-trade/)

[![USA Slave Trade](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192722844/3QVxeV3Xo.jpeg align="left")](https://ferrelux666.wordpress.com/usa-slave-trade/)

[![Slavery In The Arab World](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192724044/ZI2ttdCoK.jpeg align="left")](https://ferrelux666.wordpress.com/slavery-in-the-arab-world/)

[![Slaves In The White House](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192725321/SNSe05tdW.jpeg align="left")](https://ferrelux666.wordpress.com/slaves-in-the-white-house/)

[![Taliban militants from a group led by Mullah Manan Niazi that has itself joined Mullah Rasool's splinter group 'The High Council of Islamic Emirate of Afghanistan' which split from the Taliban after the death of Mullah Omar.](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192726500/HwldAkTRI.jpeg align="left")](https://ferrelux666.wordpress.com/afghanisatn-apres-laccord-de-paix-entre-les-talibans-et-les-americains-et-le-gouvernemnt-afghan/)

Taliban militants from a group led by Mullah Manan Niazi that has itself joined Mullah Rasool’s splinter group ‘The High Council of Islamic Emirate of Afghanistan’ which split from the Taliban after the death of Mullah Omar.

[![Taliban Gunman](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192727561/OD9RJOrY2.jpeg align="left")](https://ferrelux666.wordpress.com/taliban-gunman/)

[![Taliban Soldiers](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192728716/m8yKfWlkE.jpeg align="left")](https://ferrelux666.wordpress.com/taliban-soldiers/)

[![The Taliban Soldiers](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192730165/RdRSAUib5.jpeg align="left")](https://ferrelux666.wordpress.com/the-taliban-soldiers/)

[![FILE PHOTO: A U.S. soldier from the 3rd Cavalry Regiment walks with the unit's Afghan interpreter before a mission near forward operating base Gamberi in the Laghman province of Afghanistan December 11, 2014. REUTERS/Lucas Jackson/File Photo](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192731518/xAMlO1pVs.jpeg align="left")](https://ferrelux666.wordpress.com/file-photo-u-s-soldier-from-the-3rd-cavalry-regiment-walks-with-the-units-afghan-interpreter-before-a-mission-near-forward-operating-base-gamberi-in-the-laghman-province-of-afghanistan/)

FILE PHOTO: A U.S. soldier from the 3rd Cavalry Regiment walks with the unit’s Afghan interpreter before a mission near forward operating base Gamberi in the Laghman province of Afghanistan December 11, 2014. REUTERS/Lucas Jackson/File Photo

[![U.S. Troops Withdraw](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192732633/NegvdCyuI.jpeg align="left")](https://ferrelux666.wordpress.com/u-s-troops-withdraw/)

[![U.S. War Chopper](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192733722/jIJoRVOPU.jpeg align="left")](https://ferrelux666.wordpress.com/u-s-war-chopper/)

[![Poverty In Afghanistan](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192734905/W_04KyKmL.jpeg align="left")](https://ferrelux666.wordpress.com/poverty-in-afghanistan/)

[![Seeking Allah, Finding Jesus](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192736352/6e2pLcGWU.jpeg align="left")](https://ferrelux666.wordpress.com/seeking-allah-finding-jesus/)

[![No To Sharia Laws](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192737361/AJPM29mJg.jpeg align="left")](https://ferrelux666.wordpress.com/no-to-sharia-laws/)

[![No More Mosques](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192738402/DB60hBEHQ.jpeg align="left")](https://ferrelux666.wordpress.com/no-more-mosques/)

[![No Islam To Islamic Mosques](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192739702/E4Vryc2oz.png align="left")](https://ferrelux666.wordpress.com/no-islam-to-islamic-mosques/)

[![Slave Ship Cargo](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192741097/IyljQZPxu.jpeg align="left")](https://ferrelux666.wordpress.com/slave-ship-cargo/)

[![No God But One](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192742335/bMLgt6nt4.jpeg align="left")](https://ferrelux666.wordpress.com/no-god-but-one/)

[![New Zealand White Slaves](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192743853/tUFr_MpZF.jpeg align="left")](https://ferrelux666.wordpress.com/new-zealand-white-slaves/)

[![Negro Cargo](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192745236/5WzosmJz2.jpeg align="left")](https://ferrelux666.wordpress.com/negro-cargo/)

[![Lady Liberty Under Attack By Islam](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192746449/6K0p7Q8-IB.jpeg align="left")](https://ferrelux666.wordpress.com/lady-liberty-under-attack-by-islam/)

[![Kick Islam Out of America](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192747864/p1q9m3OyP.jpeg align="left")](https://ferrelux666.wordpress.com/kick-islam-out-of-america/)

[![Joe Biden And The Mission](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192749048/Ndgj_7aDY.jpeg align="left")](https://ferrelux666.wordpress.com/joe-biden-and-the-mission/)

[![Joe Biden and the Afghanistan War](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192750217/grbSns5s8.jpeg align="left")](https://ferrelux666.wordpress.com/joe-biden-and-the-afghanistan-war/)

[![Joe Biden And Our Soldiers](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192751635/PyVtOGq8M.jpeg align="left")](https://ferrelux666.wordpress.com/joe-biden-and-our-soldiers/)

[![Jews And Slave Trade](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192752778/AMjVaC9bA.jpeg align="left")](https://ferrelux666.wordpress.com/jews-and-slave-trade/)

[![Jewish Slavers](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192754118/wXPM8MhFK.jpeg align="left")](https://ferrelux666.wordpress.com/jewish-slavers/)

[![Jewish Autonomy In Slave Society](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192755872/ijXP7KLdU.jpeg align="left")](https://ferrelux666.wordpress.com/jewish-autonomy-in-slave-society/)

[![Islam, Not A Religion Of Peace](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192757287/svQiQg_pB.jpeg align="left")](https://ferrelux666.wordpress.com/islam-not-a-religion-of-peace/)

[![From Slave Cabins to the White House](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192758322/kXQwh3Xj9.jpeg align="left")](https://ferrelux666.wordpress.com/from-slave-cabins-to-the-white-house/)

[![Fall of the Congo Arabs](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192759472/lpDJlJyX1.jpeg align="left")](https://ferrelux666.wordpress.com/fall-of-the-congo-arabs/)

[![Europeans In Black Face Imitating Moors](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192760761/dcRPKm6JL.jpeg align="left")](https://ferrelux666.wordpress.com/europeans-in-black-face-imitating-moors/)

[![U.S. Soldiers overlook the Eastern Region of Afghanistan during Operation Sentinel Freedom from a UH-60 BlackHawk on Nov. 30, 2019. U.S. Army Reserve photo by Spc. Jeffery Harris)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192762282/AOsNkjO0O.jpeg align="left")](https://ferrelux666.wordpress.com/east-afghanistan/)

U.S. Soldiers overlook the Eastern Region of Afghanistan during Operation Sentinel Freedom from a UH-60 BlackHawk on Nov. 30, 2019. U.S. Army Reserve photo by Spc. Jeffery Harris)

[![Cargo of Negroes](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192763311/f6mwdEqL1.jpeg align="left")](https://ferrelux666.wordpress.com/cargo-of-negroes/)

[![Armed Taliban](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192764401/pKQNOBVuQ.jpeg align="left")](https://ferrelux666.wordpress.com/armed-taliban/)

[![Britain White Slaves In America](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192765561/8UUuQlJQe.jpeg align="left")](https://ferrelux666.wordpress.com/britain-white-slaves-in-america/)

[![Black-Faced Europeans Imitating The Moors](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192766693/lBMlnSkdQ.jpeg align="left")](https://ferrelux666.wordpress.com/black-faced-europeans-imitating-the-moors/)

[![USGrantsOrg](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192768067/EL79elgtm.png align="left")](https://www.usgrants.org/sign-up?affiliate=134980)

### Like this:

Like Loading...

### *Related*
