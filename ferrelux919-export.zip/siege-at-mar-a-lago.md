---
title: ⛵ Siege At Mar A Lago ⛳
date: '2022-08-17T06:37:59.000Z'
slug: siege-at-mar-a-lago
tags:
  - facebook
  - trump
  - confidential
  - google
  - attack
  - trial
  - florida
  - politics
  - cia
  - vegas
  - lawyers
  - breaking-news
  - abortion
  - biden
  - russia
  - funeral
  - washington
  - raid
  - city
  - new-york
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672204933964/2cb4cc7f-2fb7-4fe5-ab70-5b445d53c358.jpeg
canonical: 'https://ferrelux666.wordpress.com/2022/08/17/trump-raid/'
---
[![Mar A Lago Pool Area](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191649101/ZInspoVPm.jpeg align="left")](https://rumble.com/search/video?q=Trump%20Raid)

<iframe width="100%" height="100" src="https://w.soundcloud.com/player/?url=https%3A%2F%2Fapi.soundcloud.com%2Ftracks%2F463228338&auto_play=false&hide_related=false&visual=true&show_comments=true&show_user=true&show_reposts=false&color=ff5500"></iframe>

[khl1fa](https://soundcloud.com/247_k) · [Mobb Deep Survival Of The Fittest :3](https://soundcloud.com/247_k/mobb-deep-survival-of-the-fittest)

I chose this track to illustrate the same kind of energy in terms of The Struggle. How The MAGA Crowd and Inner City Black Youths carry the same perception……. **‘we’re living this till the day we die, survival of the fittest, only the strong survive’**

In Bello Parvis Momentis Magni Casus Intercedunt ⚔️ In War Great Events Are Caused By Small Things **(Julius Caesar)**

**\_***Due to the Big Tech’s Cointelpro Style stalking activity & harassment against me and my publication, trying to stifle it, notice the changes taking place with the new platforms I’m using now for my network of sites. And thanks for supporting this independent media and the adjoining community and marketplace. The Story that I had next in line to do was expounding my take on that Roe Vs Wade Abortion Battle, but that will have to wait since the HOT issue now in The Press is this Trump Raid.***\_**

I’ll first preface by saying, speculations and opinions are valid, even if they are just conspiracy theories. It would be inappropriate of me to not entertain them, because putting on a ruse to manipulate The Public is possible, but for the purpose of this article, I’ll treat the topic as a bonafide event. Some are already speculating who they think **The Informant** is, and aside from Melania, the name going around is Jared Kushner, but he was not who I thought of when I first heard about a Mole. And knowing better, I wouldn’t mention who I think it is. And maybe Trump already knows too. So now that Federal Case against Trump has finally culminated to a TV show where we see a cliffhanger episode of The Business Mogul and Star of the hit show coming under FBI attack. A plot we’ve seen before on shows like **‘Empire’** and others. Now, I’d expected to eventually do another article on Trump some time in the future, **\_***but not like this***\_**. I mean this attack came out of nowhere. The Secret Service, The Palm Beach Police, The FBI and whoever else circulating, this sort of ammo and tactic is what you do with Drug Lords. You don’t run up on a Rich Man’s Home like that. You’re supposed to be civil. What’s getting ready to happen, because I must shed light on this, and the playbook is clear to see for those of us looking at cases, is The Mob Treatment. The way Trump and his Cronies are being handled by The DOJ is nothing short of how they **\_***would***\_** handle an El Chapo, Pablo Escobar, Medellin Drug Cartel Case, and/or Italian Mafia. Forget about that Russian Nuclear Arm Espionage take on the case. That’s just to establish some claim, let’s look at the way it is being HANDLED. The targeting of certain Trump Generals, Rudy Giuliani and Others. The ongoing legal pursuits against the former Presidency. Well, let me stop here for a moment and point out an observation I made in the past. It’s hard to tell sometimes what move to make, when you don’t know if it would pan out well in the far future. Trump was doing exceptionally well when he got in power the first time, meaning like a chess game, it worked out until his issue with **Michael Avenatti** whom The Public treated as some new guy that all of a sudden popped up battling Trump, when in fact, he was no Stranger to Trump and his **‘Apprentice’** show when you go back in his history. So if you are opposing **\_***Someone***\_** in a political chess game, the move you make should be well thought of. Watching that game at the time, I expected Avenatti and Trump to continue to go at it, but **\_***Somebody***\_** neutralized that Attorney from having a political future. And could it also be the same person or people behind Trump’s case? You see, it’s hard to calculate stuff to make it happen EXACTLY if you are master-minding and so other factors must be in harmony as well. And like one of those **Find Your Fate** Books some of us read back in the day growing up, there were always different scenarios in choosing a path to take. If you made the wrong choice, the story did not end well for your character. And there was maybe just one or two positive endings for the hero or heroine if you were that in-tuned to the character’s plot history and what actually made sense as the **‘correct’** move. So if you know that **The Feds** also assume jurisdiction over deciding who should be influential in politics, who should hold Office, and so forth as we’ve seen historic signs of that in this Country, then **you must** counter with an equal and effective move to protect yourself. How do you stop Meddlers from obstructing you? Obviously Trump is very much like his namesake. In a game, when you hold a trump card, you basically have a very good omen to win, and the Trump Family **are many**. Well, you start by assessing the situation and figuring out your enemy’s end game. You do a SWOT analysis not only on yourself, but them as well. Now Trump always win. Why didn’t he win the re-election? Well, it might be betrayal. Some mis-calculation. A fluke. Or maybe engineering of some sort. If you have The Feds after you like that, **well my gosh**, is it just really about what they say it is? The Russian Collusion, The Capital Riot, The Nuclear Docs, or is it more? What’s behind the scenes here. I’ve never seen an Ex-President who left Office be so disrespected. Okay let me digress a bit, if that alleged attempted coup of The Capitol didn’t result in the injury or deaths of those innocent Americans, then the case wouldn’t be so bad. But the initial charges that came out of it were just trespassing, destruction of property, and other mild stuff. It only got serious later on. Even then, Trump got Acquitted in that trial with that Attorney **Michael Van Der Veen** Defending him. It helped quell the legal attacks a bit, but it didn’t end there. People still see the horrific imagery that day of these Rednecks storming The Capitol, breaking into the hallowed halls of the building, ransacking the place and somewhere in The Department of Justice, on some FBI person’s desk is a file on **TRUMP**. And in the head of that Lead Agent is an ongoing agenda to get him. So what you are dealing with is a set of Agents versed in cases looking at you a certain way. You’re dealing with an agency with a history of descending on Mob Bosses and other Crime Lords. And you at **Mar-a-Lago** must have looked to them like a **Kingpin**. They showed up with the big guns as if you had your place lined with Gangsters. In the movies, a Spanish Drug Lord would have been better prepared to deal with The Feds. **What that was . . . . .Trump**, was a psychological attack on you. The place was not designed for that. It was the brainchild of it’s Matriarch Creator Marjorie Merriweather in the mid 1920s. It was a place for the wealthy to escape to. A beautiful sanctuary. It’s understandable why Trump would feel safe living and conducting business there. To go and invade the place like that mar it’s history. Now you can’t set foot back in it without a reminder that it was violated. A line has been crossed just to get back documents they could have had returned a nicer way. And you and your family are still mourning from the death of **Ivana Trump**. At least the NY Attorney General Letitia James showed a slight sensitivity to that at the time halting the investigation, but The People really behind deterring you would be looking to exploit every weakness. You don’t know what they may have on you already. They don’t care about your Status. The Mob built New York City, Las Vegas, Chicago, and other great places. YOU built a Mighty **Trump Empire** with all those Imperial Hotels across the globe and everything else with it. A Real Estate Tycoon and a National Treasure. They can’t wait to bring you down and do an **‘American Greed’** episode. In your defence, I would argue that if you were such **a problem**, then Agents who are supposed to be trained in all kinds of special areas of Intelligence should have made better chess moves than giving you A CHANCE in the first place. If I was sitting up in some Government Agency **and it doesn’t matter which one**, and I was given the task of controlling the outcome of The Country, I would have already had the metrics to determine WHO would be right to leave alone, and then hope my psychological assessment of the masses played out perfectly into the plot. It certainly would not have come to this. **\_***Somebody***\_** made a foolish move who is actually responsible. **Trump, all by himself is just a Character we’re observing in real time.** **Someone** who is controlling everything is reading all this politics and manipulating these events we are seeing. In Ancient Times in some empires this was the case also. The Royal Family was just a figure head and the true Ruler was someone else, either of The Noble Class, The Warrior, The Shaman/Priesthood or other Group, and he or she might just be a Criminal or Bum with manipulative Svengali Powers. For Trump, to be Subject to ongoing onslaughts of Political Attack, he must be going against the grain of something. He might not be listening to who is really in Power or under the sway of **The Controller** working behind the scenes. And neither are other people who are resisting. It’s the same Person or People responsible for the destruction of THIS Society right now, and not all of them are known or visible. I actually like Trump, though I have been critical at times. I’m not seeing him being at fault for winning the Presidency the first time around and poised for a second term. I’m more seeing The Chess Player at fault because **\_***they***\_** interfered with **Avenatti**. There have been several cases worse than his, where the person swam through carrying on with their lives, and some still are in Politics. And if you are trying to manipulate something, leaving him alone at the time and solving **that problem** in the manner a Government Agent would have back in the day, would mean still having a chess piece to move in place when the time came. Instead, you have a shrewd Opponent who saw enough of **The Insides of Washington, DC** so much so to the point where you’re keeping him out of the loop now, and without the full rights and standing of an Ex-President which he is entitled to. And there is this pervasive image that he’s not really Smart. **\_***Well,***\_** there are those Students we know of who aren’t very book smart, but some happen to reach very far in life, and in some of these cases, they are gifted in other areas. Some are smart enough to utilize their natural abilities in a way where they mastered some technique for survival, even outsmarting those intellectually gifted over them. So if Trump is a Fool to you, then why are you sweating him? Right now, like the rest of The American People, I’m looking at a show with a plot unfolding in real time where **The Star** **Of The Show** is besieged by a Shadowy Figure in Government messing with his livelihood and we get to see how he interprets these attacks **differently** from other characters we’ve seen on film where the finale resulted in failure or triumph.

Sign,  
Lhisa Mrklon

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191650368/qA-AatrWd.jpeg align="left")](https://miniinthebox.8zwg.net/c/3170166/461413/8200?prodsku=6789343&u=https%3A%2F%2Fwww.miniinthebox.com%2Fmen-s-going-out-shirt-solid-colored-shirt-collar_p6789343.html%3Fcurrency%3DUSD&intsrc=PUI2_2952)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191651902/PD09PRz9K.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191653361/e_8PWhh-j.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191654582/2xKUFZVKb.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191655987/euoaCZmpv.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191657639/Llg-jhRbv.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191659150/qwiFcPz3a.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191660702/CfvTgQOdO.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191662432/twtTlAS6q.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191664136/qA7Rdtarg.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191665568/Aw7AHOdgT.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191667419/cd2FLba6Q.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191669053/p26ekslr3.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191670654/XdJHrVXIB.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191671983/SjSRjiZkE.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191673469/jrvnL1HrV.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191675070/p79wvxYgx.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191676509/qzhGdU-pw.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191677934/AkxzE6PvR.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191679847/q2AT8eSea.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191681121/duAEcqYO6.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191682355/M7lnoBJRB.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191683537/oDmDp7rRL.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191684863/lRp1QQ0Em.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191686694/SwmoI8DSk.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191688552/QgHyA_gg8.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191689902/3cNGJjIXU.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191691163/dDHRf-Rmq.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191692598/l2yztpPFr.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191694095/03ljr9Qra.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191695546/8cfU_USiC.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191696995/QuIQ6WcS4.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191698518/IYPFUniza.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191700107/xx1XCw7fb.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191701577/YdXtcPA5E.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191702879/ba8jALMYI.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191704064/zUg1uojqR.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191705537/2wqOFnaGT.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191706777/lui9KoFlg.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191708088/gPNMNP1Fv.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191709867/FgZrgpucE.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191711182/mpG5ZtC6V.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191712451/7J63nVfV-.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191713887/7VkxD1l3n.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191715480/HlqQxtyAr.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191717133/tUImPG0Oc.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191718525/sfkGtbt4B.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191720401/kf1AcW2tp.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191722547/PoOm8HsKU.jpeg align="left")

### Like this:

Like Loading...

### *Related*
