---
title: "Co-Founder Of The Iconic Funk Band Dies At 68 \U0001F3A4\U0001F307\U0001F625"
date: '2020-09-27T20:54:13.000Z'
slug: co-founder-of-the-iconic-funk-band-dies-at-68
tags:
  - music
  - radio
  - cool
  - pop
  - song
  - group
  - blues
  - entertainment
  - party
  - soul
  - 90s
  - black
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672193912159/QZXlMDv5w.jpeg
canonical: 'https://ferrelux666.wordpress.com/2020/09/27/kool-gang/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193888218/10dbOP2-q.jpeg align="left")](https://www.koolandthegang.com/)

[**“Cherish” By Kool & The Gang**](https://www.youtube.com/watch?v=s09LuDYX12g)

*Requiesce In Pace Ut Vos* 🎷 *May You Rest In Peace*

Saxophonist Ronald “Khalis” Bell, one of the Founders of Kool & The Gang died September 9th 2020 at age 68. His band Co-Founder brother is Robert “Kool” Bell. From what has not been made known to the public. Well what can I say about this band? They had a lot of popular party jams I liked listening to. I played their music regularly back in the day. It’s nostalgic when I listen to them now. They were one of my favorite bands. They had nine members who played together through the many years as it dwindled down to about 7 or 6 remaining guys on the cover of their albums. Their music endured from them forming and playing in clubs in the mid 1960s, to the 1970s, throughout the 1980s, the 1990s and into the Millennia. They played Funk, Jazz, R&B Soul, Pop, and yes there even some Rock in there. Very talented group! Aside from the dance music, their ballads were exceptional as well. Timeless love songs still being played on the radio. Though we still have the surviving members, Kool has moved on into Heaven to play in the band of Angels.

SOME LINKS

[https://en.wikipedia.org/wiki/Ronald\_Bell\_(musician)](https://en.wikipedia.org/wiki/Ronald_Bell_(musician)) Ronald Bell

[https://en.wikipedia.org/wiki/Robert\_%22Kool%22\_Bell](https://en.wikipedia.org/wiki/Robert_%22Kool%22_Bell) Robert Bell

[https://en.wikipedia.org/wiki/James\_%22J.T.%22\_Taylor](https://en.wikipedia.org/wiki/James_%22J.T.%22_Taylor) James “JT” Taylor

[https://news.amomama.com/103560-remember-dennis-kool-the-gang-his-daught.html](https://news.amomama.com/103560-remember-dennis-kool-the-gang-his-daught.html)  
Dennis “DT” Thomas

[https://en.wikipedia.org/wiki/Kool\_%26\_the\_Gang](https://en.wikipedia.org/wiki/Kool_%26_the_Gang)

[https://en.wikipedia.org/wiki/Kool\_%26\_the\_Gang\_discography](https://en.wikipedia.org/wiki/Kool_%26_the_Gang_discography)

[**https://www.youtube.com/watch?v=xpVtaE5Mi6M**](https://www.youtube.com/watch?v=xpVtaE5Mi6M) **Performing Live, Their Best Hits**

[Michael Jackson And Kool & The Gang](https://www.google.com/search?source=hp&ei=-OxwX_uCMN2xytMP9eG98A4&q=michael+jackson+and+kool+%26+the+gang&oq=michael+jackson+and+kool+%26+the+gang&gs_lcp=CgZwc3ktYWIQAzoOCAAQ6gIQtAIQmgEQ5QI6DgguELEDEMcBEKMCEJMCOgUIABCxAzoLCC4QsQMQxwEQowI6CAgAELEDEIMBOggILhCxAxCDAToCCAA6BQguELEDOgUIABCSAzoICC4QsQMQkwI6AgguOgUILhCTAjoGCAAQFhAeUNwLWISGAWDKiwFoAHAAeAGAAbACiAGlMJIBCDAuMjYuOS4xmAEAoAEBqgEHZ3dzLXdperABBg&sclient=psy-ab&ved=0ahUKEwj73pzfjYrsAhXdmHIEHfVwD-4Q4dUDCAw&uact=5#spf=1601246996011)

[More Info On Ronald Bell’s Death](https://www.google.com/search?ei=M-BwX4WeMbqlytMP3M21uA0&q=ronald+bell+dies+at+68&oq=ronald+bell+dies&gs_lcp=CgZwc3ktYWIQARgCMgYIABAHEB4yAggAMgIIADoGCAAQCBAeOggIABAIEAcQHjoECAAQDVC5rghYor0IYJbYCGgBcAB4AIAB6QGIAfkMkgEFMC42LjOYAQCgAQGqAQdnd3Mtd2l6wAEB&sclient=psy-ab#spf=1601243855158)

Sign,  
**Lhisa**

### Was Kool And The Gang Back In The Day Your All Around Funk Band? Scroll Down And Leave Your Reply Below.

[![Kool & The Gang And Michael Jackson](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193889649/f3a2x-hbT.jpeg align="left")](https://ferrelux666.wordpress.com/kool-the-gang-and-michael-jackson/)

[![Robert Kool Bell At Ghostbar](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193891084/cIcuK6kEB.jpeg align="left")](https://ferrelux666.wordpress.com/robert-kool-bell-at-ghostbar/)

[![Ronald 'Khalis' Bell of Kool & The Gang](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193892307/BNBYNnv0A.jpeg align="left")](https://ferrelux666.wordpress.com/ronald-khalis-bell-of-kool-the-gang/)

[![Vintage Kool & The Gang](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193893565/qkPasIItJ.jpeg align="left")](https://ferrelux666.wordpress.com/vintage-kool-the-gang/)

[![Best Of Kool & The Gang, Island Def Jam 2011](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193894880/lr4b3qz0-.jpeg align="left")](https://ferrelux666.wordpress.com/best-of-kool-the-gang-island-def-jam-2011/)

[![Celebrate Kool & The Gang](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193896201/FtMYuPlGt.jpeg align="left")](https://ferrelux666.wordpress.com/celebrate-kool-the-gang/)

[![James (JT) Taylor](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193897354/oIdX0cI4m.jpeg align="left")](https://ferrelux666.wordpress.com/james-jt-taylor/)

[![Kool & The Gang BxW Photo](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193899030/qhumR7myr.png align="left")](https://ferrelux666.wordpress.com/kool-the-gang-bxw-photo/)

[![Kool & The Gang Logo](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193900313/AgD9w36-f.jpeg align="left")](https://ferrelux666.wordpress.com/kool-the-gang-logo/)

[![Kool & The Gang Millenial Collection](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193901597/mqqotklCs.jpeg align="left")](https://ferrelux666.wordpress.com/kool-the-gang-millenial-collection/)

[![Kool & The Gang, 9 Member Jazz, Funk, R&B Band](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193902946/-ePnYct16.jpeg align="left")](https://ferrelux666.wordpress.com/kool-the-gang-9-member-jazz-funk-rb-band/)

[![Kool & The Gang, Leverkusener Jazztage 2017-1963](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193904265/Dy1ZYak4m.jpeg align="left")](https://ferrelux666.wordpress.com/kool-the-gang-leverkusener-jazztage-2017-1963/)

[![Kool & The Gang](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193905743/jyptNpxxD.jpeg align="left")](https://ferrelux666.wordpress.com/kool-the-gang/)

[![Kool](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193906853/8wWVCHhPI.jpeg align="left")](https://ferrelux666.wordpress.com/kool/)

[![Robert 'Kool' Bell On Stage 2 Photo By Silvia Mautner](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193907986/qrYmwkXzE.jpeg align="left")](https://ferrelux666.wordpress.com/robert-kool-bell-on-stage-2-photo-by-silvia-mautner/)

[![Ferrelux Homepage_Kool-n-the-Gang](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193909266/aNMD2paXa.jpeg align="left")](https://ferrelux666.wordpress.com/2020/09/27/kool-gang/ferrelux-homepage_kool-n-the-gang/)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193910532/vkXygJE1u.jpeg align="left")](https://ferrelux.com/adverts/)
