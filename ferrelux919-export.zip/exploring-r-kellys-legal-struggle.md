---
title: "Exploring R. Kelly’s Legal Struggle \U0001F97E\U0001F3BC \U0001F4BC"
date: '2021-09-16T02:22:17.000Z'
slug: exploring-r-kellys-legal-struggle
tags:
  - interview
  - music
  - shutdown
  - communities
  - social-media
  - women
  - report
  - money
  - kids
  - parenting
  - girls
  - lawyer
  - attorney
  - dogs
  - trial
  - pandemic
  - covid-19
  - housing
  - jeep
  - pregnancy
  - parents
  - drugs
  - investigation
  - court
  - black
  - city
  - singer
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672208408708/d4bcfb92-ccf3-4f4a-b6c0-daedf74536cf.jpeg
canonical: 'https://ferrelux666.wordpress.com/2021/09/15/robert-kelly/'
---
[![R Kelly's Legal Battle](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192655892/nYnGMPdxa.jpeg align="left")](https://r-kelly.com/music/)

[**When A Woman Loves**](https://www.youtube.com/watch?v=_W0K_EkDoHk)**  
Profundum Tui Certaminis Decernit Altitudo Successus Tuus  
🎙 The Depth Of Your Struggle Determines The Height Of Your Success  
(R. Kelly)**

This was my previous August 2019 article on [Mr. Robert Kelly’s Legal Problems](https://ferrelux.com/2019/08/12/rkelly/), jailed and released on bond, then jailed again. We’re now in 2021 and the embattled R&B Singer is still behind bars. At the time during the thick of the pandemic shut down, his Attorney Steve Greenberg, made his best argument before The Court for his Client’s release, and even though he had a right to be free like the other prisoners who were offered that grace, R. Kelly was denied that right. The System fell to the will of his Haters who wanted him to suffer, with him even getting beat up by another prisoner one time. I think him ending up in jail in the first place could have been avoided had he just kept his mouth shut the first time he was swimming through his problems. The System wasn’t sure of certain things yet and chose not to move through with a case. And what happened? Well, we saw R. Kelly on the media circuit bragging to the effect of how teflon he was and such, and ongoing with it where it came off the wrong way. I don’t know if you all remember that, and a few weeks shortly after, The Justice System began to see where there might be a case and nabbed his butt. It was made possible especially when Attorney Michael Avenatti who was representing a couple of the women when he submitted a sex tape as evidence where it is believed that R. Kelly was having intercourse with a female under 18. Even though the allegations have not been proven to be true yet, a lot of people have him guilty in their minds based off their perceptions of him and hearsay. Now it’s really none of their business what his personal problems are with his life issues to be posting irresponsible stuff out there in Social Media. Despite what you know of his past to be so, have some respect for a person’s right to present the other side of the argument. Nothing is exactly as it seems sometimes. And this is a dilemma his Attorneys are dealing with. His legal team is shifting due to internal disagreements on how to proceed in defending him. Now, I find it hard to buy every last scandalous detail without suspecting an agenda. When you study human nature and you know people, especially originating from certain cultures, then you have to take these issues like a grain of salt. Consider WHO is complaining and WHY. I’m not saying all things by R. Kelly is Kosher. I just question motive, slander, artifice, and the like. You could stand up somewhere in the city and announce all kinds of shit about a person and garner an audience listening to it like it’s gospel. As a responsible individual, you should be dissecting fact from fiction, and fantasy from reality. Why is **the person** talking? Was he or she promised a come up from R. Kelly and it did not come true? Was the girl thinking she was the only one, and was hurt by the other women involved? Did she expect to be in his video and that did not happen? Was she expecting some amount of money, and got nothing? Was she promised a record deal and didn’t get it? Did she do some very sexually degrading things, and then looked in the mirror one day feeling ashamed, and now she wants to redeem her respectability again by hurting his reputation this way and delighting in his suffering? This is the way you should be looking at things. That’s why when certain payments were made, all of a sudden a complaint went away. So it was about money, not principle. And what about the parents involved, who knew his music, saw and heard stuff, but had no problem sending their young daughters to this grown man’s house to stay and take care of despite his known public lifestyle? There are discrepancies in some of their recanting of what they think happened at his house, especially when the young ladies themselves are contradicting their own stories. It’s not cool taking advantage of a man reported to have been a talented Street Performer who was somewhat illiterate when it came to higher academics, but had an extraordinary singing talent. And just because he had certain shortcomings when monitoring the financial side of things, doesn’t give someone the right to take advantage of his ignorance, that may have subsequently led to his demise. I’m disappointed in certain people still acting a fool over this and are not seeing the bigger picture. The only thing I fault R. Kelly for was not fulfilling a promise. People are only dealing with you because of who you are and what you can do for them. They are Users. So if he was using them also, they should have gotten something they valued out of it. He represented an opportunity for a young lady to get out of The Hood and live somewhere nice with a Mentor, while trying to get her career off the ground. That business model offered from a Benefactor is not unusual, but it should not come with abuses either. Most young women from whatever time period in history were old enough to understand chastity, and to not be around a man you have no real interest in since YOU are the one who must protect your chased status. Declining his advances and finding your prospects elsewhere would have been better as other females did at the time. Now, why did Beyonce’s parents know better choosing not to work with R. Kelly due to rumors, and not the parents making accusations now? And the flipside of that is when some females out here could care less about the rumors and would go along with the lifestyle seeing it as a much lesser risk, in favor of escaping a situation they’re in which they know is more problematic. And whatever rules he had at the house for them to follow might have made sense, and they would have been experienced enough to handle him. Also, notice that a lot of the women he messes with are of age though. There are women in almost every city still in favor of him. I doubt with what’s happening to him now legally that any non-disclosure agreement would hold them back from talking if there was really a problem. Groupies are going to be Groupies. Before everything went sour they were out there in public well-dressed and spending his money being another live-in Girlfriend. And it’s easy for another group of people to get involved in the affairs of an oppressed people when they play themselves out there. Stopping his scheduled events to perform somewhere isn’t solving the problem. Canceling his music from playlists, and getting him dropped by Sony is more hurting the prospective revenue he could earn to pay child support, and anybody else he owed money to. The issues discussed in R. Kelly’s cases are nothing new. Such common problems are resolvable and are best kept out of the public eye, but some Black People in this day and age want to either flagrantly air their dirty laundry on the public stage like some other people, or add to the misery of another by profiling their personal business out in the street. Mr R. Kelly, like other famous Defendants in their respective cases are greatly hurt by activities like that. When you think you are advancing justice by doing that, later you find out that someone was in fact lying or mis-representing the facts or something, and what you did was **hurt** a situation more. And being Black, they should know, especially if they are from broken families or troubled communities. Mr. Robert Kelly is from that, yet he managed to make something of himself. And instead of recognizing a man that may be fragile, emerging from that and might be in need of Special Supervision and Care, people used him and fed their own needs instead. I give credit to anyone who had access to him who tried to help him in some way before bad issues started arising in his life. Apparently his ex-wife for 13 years Andrea Kelly was not that person. You know when R. Kelly was released from prison the last time, one of the first things he did was to get a happy meal at McDonald’s because he thought about having the comfort of his Mom, as such childhood memories were pleasant. And he surrounds himself with women as a grown man. But what about the not so pleasing memories in life a person carries sometimes? Have anyone ever thought that maybe he had been victimized in some way while growing up. What was his life like? What kind of bad experiences did he have along the way, and how is he dealing with that still? For this guy to end up here like this in life, something went terribly wrong. Forget all about the sexcapades and other vice-ridden stories, and concentrate more on what kind of internal issues a person may be suffering from and why no one who had direct access to his life, cared enough to address it but gain from it, and maybe under the instruction of another. And if anyone of you is reading this, YOU being there failing to and enabling what is now being called into a criminal investigation, then you too are responsible and you should turn yourself in. You know so much, right. How could you NOT be responsible also? You were up in there with him and in his life. I understand a Superstar brushing off somebody trying to navigate his or her life, but I’m talking about not co-signing a lifestyle or at least granting sound advice, and not going along with it. There are a lot of interesting characters out there in public with all kinds of similar dire problems that did not end up like him, some of them are even in high political places somehow protected by a Justice System partial in prosecuting who It feels like going after. And I can see in other ways why he came under attack in his Industry. So many mixed up things, hiding what’s really going on. If you sit and study just enough of it with a keen eye and ear, you should notice some things. And I hope he is able to translate the suffering of his soul and the contempt directed at him effectively, where it exposes some other underlying concerns truly behind his problems.

**Lawyers Who Left The Case, Or Were Terminated**

[https://abc7chicago.com/r-kelly-lawyer-steve-greenberg-michael-leonard-trial/10759518/](https://abc7chicago.com/r-kelly-lawyer-steve-greenberg-michael-leonard-trial/10759518/)

[https://pagesix.com/2021/06/09/two-lawyers-removed-from-r-kelly-case-ahead-of-sex-abuse-trial/](https://pagesix.com/2021/06/09/two-lawyers-removed-from-r-kelly-case-ahead-of-sex-abuse-trial/)

[https://apnews.com/article/entertainment-music-arts-and-entertainment-trials-0d4752a71cbfc51980e2ee8a732470ec](https://apnews.com/article/entertainment-music-arts-and-entertainment-trials-0d4752a71cbfc51980e2ee8a732470ec)

[https://wgnradio.com/anna-davlantes/former-r-kelly-attorney-steve-greenberg-where-were-the-parents-when-things-were-supposedly-going-on/](https://wgnradio.com/anna-davlantes/former-r-kelly-attorney-steve-greenberg-where-were-the-parents-when-things-were-supposedly-going-on/)

😎 [R. Kelly’s 19 Minute Confession “I Admit”](https://www.youtube.com/watch?v=LHi3lKUVbR4) 😎

Sign,  
L H I S A

**Was R. Kelly Railroaded By The Justice System? Scroll Down And Leave Your Reply Below.**

[![Ferrelux Homepage_RKellyTrial 2021](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192657265/ggidZwxzJ.jpeg align="left")](https://ferrelux666.wordpress.com/2021/09/15/robert-kelly/ferrelux-homepage_rkellytrial-2021/)

[![R&B Sensation R Kelly Singing On Stage](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192658477/4D_UiTgiU.jpeg align="left")](https://ferrelux666.wordpress.com/rb-sensation-r-kelly-singing-on-stage/)

[![R Kelly's Attorney](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192659736/KJzqNVFmu.jpeg align="left")](https://ferrelux666.wordpress.com/r-kellys-attorney/)

[![R Kelly With His Attorney & Fixer](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192660967/AcGEdIo2U.jpeg align="left")](https://ferrelux666.wordpress.com/r-kelly-with-his-attorney-fixer/)

[![R Kelly](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192662406/smFsKmJ6_.jpeg align="left")](https://ferrelux666.wordpress.com/r-kelly-2/)

[![R Kelly Through The Years](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192663581/qXv1rwl7D.jpeg align="left")](https://ferrelux666.wordpress.com/r-kelly-through-the-years/)

[![R Kelly Released From Prison In Chicago](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192664635/EbWixh14o.jpeg align="left")](https://ferrelux666.wordpress.com/r-kelly-released-from-prison-in-chicago/)

[![R Kelly Visits McDonalds](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192666309/NCKMH4Mg2.png align="left")](https://ferrelux666.wordpress.com/r-kelly-visits-mcdonalds/)

[![R Kelly In The News With Alleged Child Sex Tape](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192667849/iejKPRpZi.jpeg align="left")](https://ferrelux666.wordpress.com/r-kelly-in-the-news-with-alleged-child-sex-tape/)

[![R Kelly In Court Outfitted In Prison Jumpsuit](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192669496/TZRlk9ED8.jpeg align="left")](https://ferrelux666.wordpress.com/r-kelly-in-court-outfitted-in-prison-jumpsuit/)

[![R Kelly At McDonalds](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192671086/kFt1Qgy09.png align="left")](https://ferrelux666.wordpress.com/r-kelly-at-mcdonalds/)

[![R Kelly In Prison](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192672453/eGUWJCNtn.jpeg align="left")](https://ferrelux666.wordpress.com/r-kelly-in-prison/)

[![R. Kelly and his publicist Darryll Johnson, right, leave The Daley Center after an appearance in court for Kelly's child support case, Wednesday, March 13, 2019, in Chicago. (Ashlee Rezin/Chicago Sun-Times via AP)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192673963/jc3iUe268.jpeg align="left")](https://ferrelux666.wordpress.com/r-kelly/)

R. Kelly and his publicist Darryll Johnson, right, leave The Daley Center after an appearance in court for Kelly’s child support case, Wednesday, March 13, 2019, in Chicago. (Ashlee Rezin/Chicago Sun-Times via AP)

[![Embattled Singer R Kelly](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192675389/RgoT_ANOj.jpeg align="left")](https://ferrelux666.wordpress.com/embattled-singer-r-kelly/)

[![R Kelly And His Child Support Problems](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192676693/XUXCq9H6M.jpeg align="left")](https://ferrelux666.wordpress.com/r-kelly-and-his-child-support-problems/)

[![Another One Of R Kelly's Look](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192677803/TlK8hXd48.jpeg align="left")](https://ferrelux666.wordpress.com/another-one-of-r-kellys-look/)

[![Another One Of R Kelly's Looks](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192678925/TlHUl9QQE.jpeg align="left")](https://ferrelux666.wordpress.com/another-one-of-r-kellys-looks/)

[![R&B Singers Aaliyah & R Kelly](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192680059/bhn466aCW.jpeg align="left")](https://ferrelux666.wordpress.com/rb-singers-aaliyah-r-kelly/)

[![Singer R Kelly With Attorney Steve Greenberg](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192681531/Tpre0j7IN.jpeg align="left")](https://ferrelux666.wordpress.com/singer-r-kelly-with-attorney-steve-greenberg/)

[![R Kelly's Media Battle](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192682809/uIf2ma7Qm.jpeg align="left")](https://ferrelux666.wordpress.com/r-kellys-media-battle/)

[![Steve Greenberg Clashes With Avenatti Over R Kelly](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192684076/bl0vhDNeH.jpeg align="left")](https://ferrelux666.wordpress.com/steve-greenberg-clashes-with-avenatti-over-r-kelly/)

[![R Kelly's Lawyer](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192685292/cnRCXnNl1.jpeg align="left")](https://ferrelux666.wordpress.com/r-kellys-lawyer/)

[![R Kelly's Legal Battle](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192686251/W5u3-179kc.jpeg align="left")](https://ferrelux666.wordpress.com/r-kellys-legal-battle/)

[![R Kelly's Legal Battles](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192687403/D4LEMquPe.jpeg align="left")](https://ferrelux666.wordpress.com/r-kellys-legal-battles/)

[![USGrants](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192688522/Wzh6M4IJg.png align="left")](https://www.usgrants.org/sign-up?affiliate=134980)

### Like this:

Like Loading...

### *Related*
