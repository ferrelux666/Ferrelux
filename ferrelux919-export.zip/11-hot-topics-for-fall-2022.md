---
title: "\U0001FA99 11 Hot Topics For Fall 2022 \U0001FA99"
date: '2022-10-15T00:33:41.000Z'
slug: 11-hot-topics-for-fall-2022
tags:
  - twitter
  - news
  - wordpress
  - facebook
  - trump
  - google
  - youtube
  - social-media
  - online
  - elon-musk
  - kids
  - people
  - vp
  - woman
  - trial
  - vote
  - florida
  - olympics
  - election
  - topics
  - children
  - '2022'
  - abortion
  - immigrants
  - america
  - queen-elizabeth
  - voting
  - washington
  - censorship
  - president
  - court
  - new-york
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672204302646/2bf51661-30a2-4cf3-815d-644336534c8d.png
canonical: 'https://ferrelux666.wordpress.com/2022/10/14/fall-2022-topics/'
---
[![Mike Pompeo Is The Guy](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191504126/eSVk30QVe.png align="left")](https://rumble.com/v18ry3e-mike-pompeo-biden-has-no-answers-for-americas-problems.html)

<iframe width="100%" height="100" src="https://w.soundcloud.com/player/?url=https%3A%2F%2Fapi.soundcloud.com%2Ftracks%2F767789107&auto_play=false&hide_related=false&visual=true&show_comments=true&show_user=true&show_reposts=false&color=ff5500"></iframe>

[Tesla](https://soundcloud.com/tesla97717) · [Signs (Live At Abbey Road Studios, 6/12/19)](https://soundcloud.com/tesla97717/signs-live-at-abbey-road)

**I chose that track for this article because signs are not only visibly obvious, but there are also subtle ones you don’t see that indicate political stuff as we are currently dealing with in our lives out here and online.**

Praesto Et Persto 🧍🏽 I Stand In Front And I Stand Firm

Some of these below topics I might flesh out some more as time goes on, but here are some drops in the bucket.

**Weaponizing The DOJ Using Big Tech To Censor Us**

This has got to stop! Traditional American Values are under serious attack by It’s own Government. People using the internet trying to promote themselves or a business shouldn’t be coming under attack because they don’t have the same views as the people running The System. My subtle thought  provoking creative activities are still currently being followed and targeted by cowards working with and **within** Big Tech. And you know about **The Libs Of Tik Tok**, **Babylon Bee**, and Other Independent Thinkers & Publishers also with material still under regular attack. I wasn’t going to make mention of MY situation on my last article covering Queen Elizabeth’s funeral, and letting that run for 25 days in honor of her Coronation. Now, I had some small success battling Google, but Facebook still wants to be a Dick. Notice how **Mark Zuckerberg** every now and then pops up out of the blue after certain legal incidences involving Facebook, letting **The Media** know that his network was hacked, yet when he closes people out of Accounts, being a Hacker himself, asks for sensitive personal legal documents from people to be uploaded to the site in order to get back in. And the people they are actively targeting is who made their service very popular. When I first began entertaining Social Media, my favorite spot WAS **Myspace**. It was better than Facebook & Twitter in it’s original form then. And in some respects, as they currently are now, is still competitive. **Whoever** was trying to hurt the success of that Platform blackballing it to a very marginalized space on the internet now like it’s a ghetto, is under-estimating the intellect of some people and how they might view that. There may have been some wrong people engaged in criminal activity using Myspace many years back where it concerned Kids, buts The Feds handled the problem on that sector. And guess what? The problem moved to the now popular social sites and is still an issue, but worse, yet The Government isn’t shutting them down. At the time, Myspace had a lot to offer where certain things didn’t affect you and your space on the site. They even had the courtesy to respect People’s data to migrate everything to the new design. So we’re talking about professionalism. Forcing people to use Facebook, Twitter & Google monopolizing Social Media trying to manage & control people’s thought process would more spark dissidence in smarter people utilizing smaller independent Brands offering a similar service they need. **\_***And you know what?***\_** Some of us existed at a time when there WAS no Social Media Site, yet we were able to successfully communicate, organize & mobilize Many. These People trying to obstruct your rights are VERY dependent on seeing your online activities, that simply not using the internet or your phone for something deters their ability to track you. And there goes their Operation. They have no idea where you are or what you are doing. You don’t need to be on the internet to influence people. Sure, your word spreads faster on that medium, but when there was no Facebook, Twitter, or Youtube, some of the most influential people were able to circulate their transformative ideas still in a time when People were ready and receptive to it. And if you are observing some of the things I am seeing concerning their censorship activities of Independent voices, then you’ll notice the limitations & weaknesses of Big Tech that they are apparently oblivious to. And maybe **Elon Musk** can improve Twitter if he takes it over, but it would have been better had he offered to use his money to re-vamp Myspace or created **his own** Social Media Platform.

**The Trial Of Alex Jones & Info Wars**

I like Alex Jones. It’s a pity that The System is trying to lynch his Operation and use it to try to come after Other Conspiracy Theorists. In the past he was right about A LOT of things. We can’t always be right about EVERYTHING. He is The Head Honcho you think of out of the rest of people doing a similar  thing, when you think back at a time on Youtube when these conspiracy theories were very popular and relatively uncensored. So trying to stop him and his general views is a goal of The Establishment, however, I don’t recall him telling anybody to go harass or hurt anyone listening to his show. You either agree with his findings or not. The Justice System having access to the finest technology had **all that time** to cyber-spy and STOP would-be criminals following his content and ruthfully acting on it.

**Olympic Kids Suing The FBI**They were right to. The evidence was not only there, but ongoing proof of The Molester’s crimes. You would think that certain Citizens operating at the highest level Representing Our Nation Abroad, would at least deserve the highest care Law Enforcement can give them when they return home.

**Cosby’s Juneteenth**

Well this came as a shock with The Justice System rolling back around with another out of the blue charge against this guy with that whole sex thing. **WHY?** Oh, he was also trying to help R. Kelly’s case.

**Supreme Court Overturning Roe V. Wade**

I support a woman’s right to choose. If this is a Free Country, then you would not entertain the downgrading of Womens Rights like Other Oppressive Nations on The Globe. We are not Cattle. The Right should be there. In observing all this, I understand that a political technique may be at play here meant to repeal **something else**, and this digression is an unfortunate part of the sequence before things change back.

**The Upcoming Elections**

Well, will people vote? Do they care? I’m extending my commentary out to New York Governor **Kathy Hochul**, to step up and show more fight as we inch closer to that big date because this is your moment to prove something. You’ve heard the criticisms & speculations. Can you keep New York BLUE? Can you erase an aged old career stereo-type of women? You know people are looking for you to fail. I know I made some observations about the possible direction of New York, but I haven’t left The Party **YET**. I’m well aware of how I look out here WHY I’m often mistaken as **Republican**, **since College**. And I agree with Tulsi Gabbard for leaving Yall to be Independent. Interestingly enough,  before, I was mistaking her on face value for a Republican even though she was on the Democratic Debate Stage. And like other independently-minded people, we’re both on the same kind of Red Wing websites. These days I am feeling them even more due to similar interests, BUT I am still an **Old School Democrat**. And I realize we are not liked anymore with the recent way the politics is swinging now. And you are caught up in it. Your Opponent Lee Zeldin IS NOT Playing with you. He wants YOUR Seat. Look at that determined face, ready to debate and all, expounding on what he wants to do. One important move on his list if he wins, is to fire District Attorney Alvin Braggs. He’s on these news circuits gathering crowds listening to him and his rhetoric. The suspicious attacks he recently suffered outside his home and on stage speaking, is concerning. He even reported not receiving any Protections from your Office. Now Kathy, how does that look? And you are married to a Former SDNY Prosecutor. People are taking this Lee Zeldin guy seriously. And he’s a White Male. He’s alleging that you are afraid to debate him and he’s got The Republican Media backing him and jeering you. Now you are an intelligent woman, you speak well, and you have been **IN** New York leading it with Former Governor Andrew Cuomo and Others for many years. And this is where I have to ask, do you care for the job? What would Cuomo do? He’s a tough guy. Would he stand for this Lee Zeldin Republican guy coming in here with the zeal to take over? According to the information out there, he wants to hurt womens rights. I commend the way you swiftly moved like the tough girl you are, to protect Abortion and other rights for Women in New York. The State also demographically boasts more women than men, so it is poor strategy for Zeldin to be targeting us. And he’s not the right Republican to turn New York RED with the views he has. You and your team have got to step on this and come out in full force as the days draw near so that The People can see some **Cuomo** in you. Remember, people like myself who supported Cuomo knew we had a Strong Leader capable of warding off Bad Republicans from hijacking the State, and he was Notorious with that at The Helm defending Our Territory. And the word around town isn’t Cuomo anymore, so what people should be thinking about now is HOCHUL. And IT should be able to defeat a Zeldin.

**Trump On Trial**

Oh God, The System finally got Its way where now a Former President HAS to take The Stand. What will Trump do? What will he say? With the looming investigations, trials and all, can another run for The Presidency still be in reach? Though Trump is still the best choice for The Republican Lead, if he can’t make it, some are already looking to Florida’s Governor Ron DeSantis. Well, before he came into the picture, the person I was eyeing as a potential runner for them was **Mike Pompeo**. And then, I heard small reports about Tucker Carlson possibly running, **which isn’t odd**. They are going to need SOMEBODY.

**The Jan 6\*\*\*\*\*\*\*\*th** **Capitol Riots, Madagascar, & Others**

Now, when something happens in one nation and it is successful, **or sort of,** the news reaches another and there you go. When The American January 6th Capitol Riots happened and failed. It didn’t matter, The People of Madagascar, rose up attacking their Government and succeeded, storming the place, chasing out their World Leaders and inhabiting the prestigious Government space ransacking and playing around with things much like the American Siege attempt. There were also wild protests happening in Kuala Lumpur as well. These style of political Uprisings were made famous by The People of Argentina regularly rising in mobs marching in The Streets onward to beat up Government Officials and put them out of power.

**The Border Crisis Continues**

It IS a problem. Let’s be real. The criticisms are valid. We can’t have random Illegal Aliens coming into  The Country like this. There is a proper process one must undertake to be admitted. And now they are being bused and dumped into Democratic Sanctuary Cities in urban neighborhoods already saturated with people who came here legally competing over the meager resources.

**Defending Kamala Harris**

Oh this woman has endured all manner of spectacle & ridicule in The Public Eye on many a controlled Republican Media Platforms proving yet again an well-known racial concept. Had she been a bungling White Male in that Post, the onslaught of negative commentary would not be so forthcoming. I remember a time when Dan Quayle was our 44th VP. People were saying he was not very smart or competent, but he served under President George Bush going about his job without ongoing malicious slander & libel. I don’t think Kamala is terribly lacking as The Media suggests. Something is going on that’s making The Administration fail in certain areas. Sometimes catering to and trying to appeal to certain groups hurt a government. The Corporate PR Strategy they employed looks great on paper but in practice, isn’t working given the grave issues in our time to deal with. With our First Lady Jill Biden being a School Teacher and the politically correct things that goes on coloring and masking the reality of things in these institutions, it’s hard for a real person, to show and do what is in our nature. When Kamala Harris was on stage debating prior to becoming VP, **that was her,** going through the process being herself with the decked out campaign bus and all. She had the most professional manner going about it even upstaging Mayor Deblasio at the time. She even had that strong urban Black woman face with the attitude when necessary. I knew she meant business. You saw the way she handled Vice President Mike Pence on stage at the time, and how she tore into Biden. Well, somebody tamed her. Someone got involved interfering with her image trying to make her more softer and appealing to White People getting her to downplay her most authentic self for approval. When I saw that, I wondered, why is she smiling, and laughing like that, and side-stepping answering questions. Do they have her on some kind of calm and giggly meds? That’s not my girl from **‘A Different World’** who is **‘Living Single’** ofcourse I’m referencing popular back-in-the-day TV shows to illustrate a sort of image Kamala Harris had prior to being chosen as VP, making history as the First Ethnic Woman to hold that Title in America. She’s simply not getting the chance to BE who she is and work in a manner that’s effective for her. And why should she care to lead the country? I’m certainly not voting for Pete Buttigieg who they are thinking about pushing for President if Joe Biden opts not to continue. Now had this woman been allowed to be her Black self in that Corporate space and work how she would, it would have been better. She would have come out with that dreaded nigger face and tone insulting right back those characters on Fox News, Newsmax, Sky News, Sunrise 7, and so forth and showed them something. You know who was **real** that kept a bit of herself still while seemingly trying to be “appealing” to Whites, Michelle Obama. Going along with that “tame” Black technique isn’t always advisable. Nothing is wrong with it, but if it isn’t really you, or your personality, then it’s artificial. The woman got somewhere in life being WHO she was, and operating how she does. Now, we are seeing her and her achievements being jeered as if she was some incompetent minority person trotting along in life, and already being overlooked when she has a right to run for President and be taken seriously along with her chosen running mate . . . . . now let’s see, who might be good, . . . . . **perhaps** Senator Cory Booker.

Sign,  
Lhisa Mrklon,  
*Your All Year Round Pundit*

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191505405/JddnUsgh2.jpeg align="left")](https://lightinthebox.tv2h87.net/c/3170166/805530/8199?prodsku=7857928&u=https%3A%2F%2Fwww.lightinthebox.com%2Fcustom-suit-wedding-special-occasion-event-party-notch-black-vintage-jacquard_p7857928.html%3Fcurrency%3DUSD&intsrc=PUI2_5801)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191507028/PjK7TiRel.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191508839/9xcJQBRMhR.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191510326/8WouERFW9.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191511722/1QdKBwz_J.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191513197/bQ2WSPk1Z.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191514595/4Q8JniOl5.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191516713/0LKW2EB0g.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191518207/FJGXF8kYj.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191519965/cv94iPZ0w.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191521474/7WItV9Qo0.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191522760/nuVtCbjYJ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191524074/MtuMEFNlM.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191525672/7DM2VxEf8.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191527192/ICQn1GN4N.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191528734/1IvmC1oHQ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191530133/f1ZU7Ahyg.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191531911/0k8u1zaep.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191533248/N3uEPfzrS.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191534619/1Cy8Cu_zS.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191535894/AWZ8zkPQW.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191537180/KSsXSt-za.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191538523/IuYH7ftlp.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191540246/yxCp5dOps.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191541666/gxpAEPr-j.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191542944/78MbGU9_q.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191545209/jefeDNIOK.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191546414/1O7oSc8nk3.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191547963/6M0eXeMwp.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191549479/lpeYdpdgV.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191550826/W5dCGMjJQ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191552441/dxsymTw2L.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191553939/HC02m3k6W.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191555088/xmfmbiU4Z.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191556348/7m6zS82H4.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191558083/hq2HCZ5cI.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191559690/ATR40VR5e.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191560822/wJtGSiykC.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191562234/cmbP2eH8u.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191563511/DdaTLbfPv.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191564987/FMQuGxf6U.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191566364/CNtG9o-9i.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191568056/sG3U4H5BO.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191570274/vu7pZOZ9u.jpeg align="left")

### Like this:

Like Loading...

### *Related*
