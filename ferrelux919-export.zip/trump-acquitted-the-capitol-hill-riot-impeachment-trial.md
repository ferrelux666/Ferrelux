---
title: "Trump Acquitted: The Capitol Hill Riot Impeachment Trial \U0001F4BC\U0001F4DC\U0001F4FA"
date: '2021-03-10T18:47:50.000Z'
slug: trump-acquitted-the-capitol-hill-riot-impeachment-trial
tags:
  - trump
  - attack
  - country
  - chinese
  - riot
  - dog
  - french
  - usa
  - africa
  - france
  - constitution
  - china
  - italy
  - politics
  - election
  - biden
  - voting
  - middle-east
  - new-york
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672193312518/bK0wG_MKB.jpeg
canonical: 'https://ferrelux666.wordpress.com/2021/03/10/trump-acquitted/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193261243/Cu2sPCYPC.jpeg align="left")](https://www.c-span.org/video/?508916-1/impeachment-trial-day-4-part-1&live=&vod=)

Michael Van Der Veen, Trump Attorney Walking On The Senate Floor On The 4th Day of The 2nd Impeachment Hearing (Washington, DC Feb 12th 2021)

[**Battle Hymn Of The Republic**](https://www.youtube.com/watch?v=yAqNe-m0a8s)

Carpe Diem 🐘 Seize The Day

So our Ex-President, Donald J. Trump pulled up in his Motorcade Monday night, triumphantly returning to Trump Tower in New York City. Despite several financial & social losses due to his current unpopularity with that Capitol Siege thing, he still has a lot to be grateful for. If not for his Attorney Michael Van Der Veen standing up on that Senate floor effectively arguing, he would be seeing an impeachment from that 2nd attempt. A jury of his peers agreed that the Constitution guarantees certain rights, and it was proven that The Democrats themselves over the 4 year period have consistently made worse speeches & commentary inciting violence against Trump & other Republicans or policies, and they got away with it. So now Trump has a right to be back on The Political Stage. And he‘s supposed to still get all the briefings and other things Ex-Presidents are entitled to unless he waives it. The Democrats have motioned to completely close him out of everything like a Pariah. I get the anger at him, but you still don’t have a unified Country. You have a faction out there trying to get Trump back. A lot of people are still saying that The Democrats stole The Election; like who would vote for Biden? In fact, some people who voted for him regret doing so right after. There are pending lawsuits against his policies. My argument has always been, why not keep what you have? What’s the difference? You had Trump and his continued presidency was disrupted for Biden. The American people have got to make up their minds. You can’t complain now. Take what you get. If Biden wants to go and stop the Keystone Pipeline, messing up people’s job opportunities, he has a right to do so. If he goes and make a policy to upset our normal way of life by keep insisting on social restrictions due to Covid-19, you gotta go along with that. If he decides this year that for the month of June he wants to make the White House into a Fag House, he can do that. And if he wants Muslims coming into the Country with their militant religious agenda moving amongst a Western people here they see as infidels, to the point where they’re now publickly showing their interest in wanting to take over Italy, then they can do that because Biden doesn’t understand something. Arabs liking Pizza is one thing, but Italy is one of our greatest treaty allies, The Pope is there, and it is one of the central places humanity emerged from with religious freedom to where we are now. Prior to that during President Obama’s rule, Arab Muslims were trying to gain a political stronghold into France, where all the Constitutions/Treaties are. It was a strategic place to attack giving the history. You know who is not playing games with Muslim Extremists? China! The Chinese are apt in recognizing a foreign People trying to muscle in on them. And they are aggressively handling that threat. The Chinese People already have their own language, writing system, calendar, spiritualism, and way of life they value to protect from invaders. Anyway, Trump and his Allies are waiting in the wings for a fuck up, so they can come out and say, **‘you see, they don’t know what they’re doing’**. And if that happens, you’re gonna have those Rednecks to deal with again, a multitude marching up North all the way from The Deep South on to 2300 Plantation Avenue, better organized to attack. Now I’m a fair person. Like the previous Incumbent and his Predecessor, I related what I thought and President Biden deserves that equal treatment for the sake of The Country. He needs to know what the fuck is up being our current Commander In Chief. It doesn’t matter now whether he stole the Election or not, even Trump was accused of that. What we should be concerned with is what has always been there, our global enemies. They don’t like you, and being naive with them is going to get us screwed. Their agenda has not changed. Showing them your weaknesses and other problems just goes to show what techniques can be used to circumvent the Mighty United States. They don’t care about you and your policies. It’s about looking for a way to get a foothold into deciding your life. They don’t have the military might to stop you overseas, but coming here and taking over whole neighborhoods, and trying to impose Islam and their way of life over susceptible Blacks & Hispanics is a tactic until they can breed up, and spread out and reach that poor unsuspecting Lily White Person in the next neighborhood. And if one White Person correctly sees it for what it is and makes a case of it, under a Biden Administration he or she might be seen as a racist for pointing that out, and condemned for it, when under Trump, they could have shown and prove something political quietly happening in these Refugee Cities that’s being ignored. So Biden will have to decide whether he’s a president to Everybody or a President for The American People. As for Trump, he won that impeachment lawsuit, but there are still several more including one from The NAACP as you’d expect. And all this is happening because a Pandora’s Box was opened. Everything was okay in the Elite Political Class until grubby Prosecutors got a hold of certain people and their cases which should have been handled more delicately. A Noble Class of people got swept into a lower class status, being treated unfavorably for White Collar crimes that weren’t as serious compared to murder, rape, arson, kidnapping, assault, etc. It happened to a lot of people over the years, and when it happened to Michael Cohen, and other characters around Trump, people laughed and cheered, not realizing an emerging problem. Something that was very resolvable back in the day with simple legal remedy, progressed to a more punitive outcome. This is what happened to Michael Avenatti also. This is why The Southern District of New York (SDNY) wants Trump so bad. Due to whatever shenanigans was at play behind the scenes and the cruelly constructed media narrative that led to the demise of certain Top People, The SDNY is a big bad legal dog that got a rabid taste of that and wants more. Just think, if a distinguished Attorney like Michael Avenatti got wrongfully convicted over that Nike shit, and was made to endure prison for a while due to a flimsily constructed charge like a Hobbs Act Violation, I believe was grossly mis-used in his case from its true intended purpose, then you can imagine what they plan on doing with Donald J. Trump. Now you see that same dog on the prowl right, with the disgusting slime dripping from its mouth. When Trump was in power, he held all the cards, and that wild SDNY dog barking at the White House gate got fed a lot of people and now it wants The Master.

Sign,  
Lhisa 666

### Do You Think Trump Is Responsible For The Jan 6. 2021 Insurrection? Scroll Down And Leave Your Reply Below.

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193262644/nBfoaWScP.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193263924/XAhbxgvN1.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193265508/EJwyDQmTU.jpeg align="left")

LONDONDERRY, NEW HAMPSHIRE – AUGUST 28: President Donald Trump speaks a rally at an airport hanger on August 28, 2020 in Londonderry, New Hampshire. The rally takes place one day after Trump formally accepted his party’s nomination to end the Republican National Convention at the White House. Addressing hundreds of supporters, many wearing face masks, Trump is expected to make the case for his re-election against his opponent Joe Biden. (Photo by Spencer Platt/Getty Images)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193266767/Jbtwg6ft0.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193268139/HbrCeXiW5.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193269656/iofGWERdy.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193271010/ebFcE65Km.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193272508/lQ4zesyDv.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193277154/5mYXwA18J.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193278773/AFmIEbyJ-.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193280179/FvUkFhT5x.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193282057/n1Ydxg2wD.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193283404/dFt0d_LZl.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193284649/S2LZj6azD.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193286037/C3tROMMh4.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193287298/EYMYyd-jX.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193288815/oPgQSs86j.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193290468/ltPms5gEq.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193292453/toTezesS6y.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193293720/MHXSZvCCj.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193295311/ebDq_k36J.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193296543/dJfFgc5iL.jpeg align="left")

This Sunday, Jan. 10, 2021, image from a video released by Schwarzenegger shows former Republican California Gov. Arnold Schwarzenegger delivering a public message. Schwarzenegger compared the mob that stormed the U.S. Capitol to the Nazis and called President Donald Trump a failed leader who “will go down in history as the worst president ever.” (Frank Fastner/Arnold Schwarzenegger via AP)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193297747/8KlOtCue7.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193299184/YhiiYdlAg.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193300578/sfvOpJDxd.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193302331/YzUkTlwSZ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193303779/6z2qA4oP_.jpeg align="left")

WASHINGTON, DC – FEBRUARY 12: Michael van der Veen, lawyer for former President Donald Trump, walks to the Senate floor through the Senate Reception room on the fourth day of the Senate Impeachment trials for former President Donald Trump on Capitol Hill on February 12, 2021 in Washington, DC. Trump’s defense lawyers will present their case on Friday, where his legal team will argue that he should be acquitted of inciting an insurrection. (Photo by Jabin Botsford – Pool/Getty Images)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193305424/Gias6v3wj.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193306614/oeXZ7FmzC.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193307940/ovkOH5FBl.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193309230/wzLbRKvOF.jpeg align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193310659/gFvUpvkEs.png align="left")](https://www.discovercars.com/?a_aid=Ferrelux)
