---
title: "Raping Olympic Kids \U0001FA7A\U0001F938\U0001F3FE‍♀️\U0001F3C5"
date: '2018-07-21T19:07:48.000Z'
slug: raping-olympic-kids
tags:
  - parenting
  - children
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195412729/shp5Koayw.png
canonical: 'https://ferrelux666.wordpress.com/2018/07/21/raping-olympic-kids/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195406470/ehhhOO4B4.png align="left")](https://www.ferrelux.us/)

  
Mea Mihi Conscientia Pluris Est Quam Omnium Sermo 😞 My Own Conscience Is More To Me Than What The World Says (Cicero)

**American Women in sports are still battling the industry rape crisis. This years Espy awards aired Wednesday July 18, 2018 where the Women Gymnasts, about 141 on stage were featured at the end of the show winning the Arthur Ashe award for courage. It’s a shame that when you are an athlete regardless of gender, the people around training you fail to protect you. When a parent sends a child off to these programs to represent the country in an international competition & win, you expect the proper protections in place & bureaucracy governing the enforcement of it in such an institution. This sexual abuse thing was a problem that the people handling it should have foreseen & prevented. It’s disheartening to hear that these little kids were around some sexual predator professionally disguised as a doctor with legal access to raping them in whatever manner using the excuse of being a physician & the silence of other professionals acting as Enablers. You mean to tell me that you can’t use common sense to identify a depraved lurker, a man in lust, a looney tune eyeballing a kid & you’re suppose to be the Guardian? They need to be convicted too. You can’t be this standby person knowing in your heart of hearts that something wrong like that is going on between persons around you & turn a blind eye to it. What a national disgrace. So these kids are just property to you, a commodity. And for some reason, this Larry Nassar guy was given a comfortable job with the freedom to invasively examine female patients apparently with no female Nurse in the room. And this went on for over a decade even though there were victim complaints over the years. How could you just sweep that under the rug like that. What Officials condoned that? This is a rape system & there are other industries like it. You can’t just punish the sexual predator alone, the people surrounding it are arguably more guilty. They knew about it & didn’t have the conscience to do something to stop it, either out of fear of losing their job or also sharing the same depravity. I could never keep a job like that, ETHICS, would be an issue. Sometimes, YOU might be the one to stop something. We are not in warfare, dark or uncertain times when all kinds of debauchery, threats, & victimization runs rampant until a hero/heroine or some new power system shows up & stabilizes everything. We are already living in a system with sound Law & Order. You can’t just be doing something over here & it goes unnoticed. So what’s going on are people choosing to part-take in the iniquity (even vicariously) & not expose it.**

**~ Lhisa Mrklon**

**Some Links**

[https://en.wikipedia.org/wiki/Larry\_Nassar](https://en.wikipedia.org/wiki/Larry_Nassar)

[https://www.usatoday.com/story/sports/2018/07/18/espys-2018-all-winners/798871002/](https://www.usatoday.com/story/sports/2018/07/18/espys-2018-all-winners/798871002/)

[**https://www.independent.co.uk/news/world/americas/larry-nassar-latest-victims-settlement-us-athletics-doctor-sexual-assault-how-much-a8354681.html**](https://www.independent.co.uk/news/world/americas/larry-nassar-latest-victims-settlement-us-athletics-doctor-sexual-assault-how-much-a8354681.html)

[**https://www.nytimes.com/interactive/2018/01/24/sports/larry-nassar-victims.html**](https://www.nytimes.com/interactive/2018/01/24/sports/larry-nassar-victims.html)

\*\*[https://www.bbc.com/news/world-us-canada-42894833](https://www.bbc.com/news/world-us-canada-42894833)  
\*\*  
[**http://michiganradio.org/post/meet-7-women-and-girls-testifying-against-larry-nassar-friday**](http://michiganradio.org/post/meet-7-women-and-girls-testifying-against-larry-nassar-friday)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195407710/c8Ja4blrh.jpeg align="left")](https://ferrelux.com/adverts/)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195409184/-upqQ4YCq.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195410743/7MgCy6a22.png align="left")
