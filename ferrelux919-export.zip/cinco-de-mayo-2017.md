---
title: "\U0001F388Cinco De Mayo 2017\U0001F335"
date: '2017-05-05T21:45:36.000Z'
slug: cinco-de-mayo-2017
tags:
  - history
  - spanish
  - french
  - war
  - france
  - american
  - civics
  - mexico
  - spain
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195881054/Fl_tY_mMf.jpeg
canonical: 'https://ferrelux666.wordpress.com/2017/05/05/cinco-de-mayo/'
---
![Fiesta-logo](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195876609/ttt6r28o6.png align="left")

**The 5th of May was the day when Mexicans who were poorly armed, defeated the French.**  
**That day is celebrated today as a symbol of resistance. You have to understand that  
Mexico previously defeated Spain in 1810, & later won against America in 1868.  
So they defeated 2 major powers already & despite not having the military might,  
Mexicans proved themselves formidable against France in their 3rd foreign  
conflict situation to maintain their Independence as a free & strong people.**

**Find out more about this celebration**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/tJmlUljRWDw?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

**Here’s a More In-depth view of the history.**

[http://www.youtube.com/watch?v=aqUDUoMh9bo](http://www.youtube.com/watch?v=aqUDUoMh9bo)  
**Another Short Perspective**

[http://www.youtube.com/watch?v=QIICWQyK72Y](http://www.youtube.com/watch?v=QIICWQyK72Y)  
**And More on why it’s popular in America.**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/kQgwRyLyjqA?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195877692/n6HWwTNsm.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195879202/qRfcPi867.png align="left")
