---
title: "\U0001FA9EMelania Trump’s White House Moments (So Far)\U0001F4AB"
date: '2017-04-27T23:00:29.000Z'
slug: melania-trumps-white-house-moments-so-far
tags:
  - trump
  - women
  - speech
  - politics
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195891850/F8nVrv-Bj.jpeg
canonical: 'https://ferrelux666.wordpress.com/2017/04/27/melania-trump/'
---
![Donald  Melania Trump](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195887821/XROigAque.jpeg align="left")

\*\*Okay, just recently, this year’s Easter egg roll. Again, another copying of Michelle Obama. Well, it’s no secret that she admires the former First Lady.  
\*\*

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/FReYBz2QLIs?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

UPDATE: The above video got deleted from youtube, but here’s a little of what  
Michelle did & said – [https://www.youtube.com/watch?v=BspVAG3Wzp4](https://www.youtube.com/watch?v=BspVAG3Wzp4)

**Here she is with her speech, when she hosted the International Women’s Day Event at the** \*\*White House. Some people have a problem with her foreign accent & don’t think she should be speaking much publicly, BUT, I really don’t have a problem hearing that Transylvanian accent though.  
\*\*

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/LeQFAa0JC4I?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

**The Jackie Kennedy Look…… Well, if you’re going to be First Lady, come on. There’s**  
**nothing wrong with drawing inspiration from somewhere.**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/FXIEEmq_ksI?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

\*\*  
The Meeting with Michelle Obama passing the torch of FLOTUS……….\*\*

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/rxdfRZptSwk?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

**Prior to getting to the White House, the campaign plagiarized speech…………**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/RcbiGsDMmCM?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195889083/duCQGOJSp.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195890413/5UTt0rzak.jpeg align="left")
