---
title: "The Oscars 2017\U0001F626Steve Harvey Moment"
date: '2017-03-13T20:49:08.000Z'
slug: the-oscars-2017steve-harvey-moment
tags:
  - event
  - mistake
  - show
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195940410/xbc6kvCCM.jpeg
canonical: 'https://ferrelux666.wordpress.com/2017/03/13/oscars-2017/'
---
[![88th Annual Academy Awards - Arrivals](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195936007/EYn3Qykvb.jpeg align="left")](https://www.oscars.org/news/tag/:~:text=Posted%20Friday,%20February%2010,%202017%20-%2010:15%20Oscar%C2%AE,Sunday,%20February%2026,%20on%20the%20ABC%20Television%20Network.)

HOLLYWOOD, CA – FEBRUARY 28: Model Chrissy Teigen (L) and recording artist John Legend attend the 88th Annual Academy Awards at Hollywood & Highland Center on February 28, 2016 in Hollywood, California. (Photo by Ethan Miller/Getty Images)

**Oh, it happened again, Another Steve Harvey moment. When the mess up happened, the comedy star suffered ridicule online but in reality, he did the right thing by not letting** **the unofficial winner pass the day where it all ends up in the press wrong.** **He corrected the mistake LIVE! So after that, no one was expecting another event like** **this to unload in 2017 when the wrong winner was announced again. This time with** \*\*2 veteran actors.

\*\*

**The original mess up with Steve Harvey, 2016.**  
[https://www.youtube.com/watch?v=B2LInrKn1hE](https://www.youtube.com/watch?v=B2LInrKn1hE)

**Now, the Oscars version………………..**  
[https://www.youtube.com/watch?v=h8KImR5SYpI](https://www.youtube.com/watch?v=h8KImR5SYpI)

**Steve Harvey’s comments after that Oscar fiasco…..**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/CxT95I_ep4c?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

**Other commentaries from fellow Actors….**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/Yd5gmOSVfw8?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195937701/0o2W3hz_L.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195939089/eVmwBQEVk.jpeg align="left")
