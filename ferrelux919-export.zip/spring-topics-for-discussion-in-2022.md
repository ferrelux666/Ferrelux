---
title: "\U0001F33FSpring Topics For Discussion In 2022\U0001F54A️"
date: '2022-04-07T01:45:13.000Z'
slug: spring-topics-for-discussion-in-2022
tags:
  - spring
  - twitter
  - news
  - instagram
  - facebook
  - rights
  - trump
  - google
  - youtube
  - social-media
  - online
  - internet
  - post
  - clients
  - ethics
  - actors
  - small-business
  - professional
  - discussion
  - pandemic
  - crime
  - urban
  - politics
  - cia
  - topics
  - networks
  - immigrants
  - russian
  - washington
  - military
  - hollywood
  - censorship
  - black
  - birthday
  - new-york
  - laws
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672192005353/vk9M0k3Z3.jpeg
canonical: 'https://ferrelux666.wordpress.com/2022/04/06/spring-topics-2022/'
---
[![Trump Takes On Big Tech](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191974243/Ap3e1bK8i.jpeg align="left")](https://www.takeonbigtech.com/)

<iframe width="100%" height="100" src="https://w.soundcloud.com/player/?url=https%3A%2F%2Fapi.soundcloud.com%2Ftracks%2F6635680&auto_play=false&hide_related=false&visual=true&show_comments=true&show_user=true&show_reposts=false&color=ff5500"></iframe>

[DJFAB\_](https://soundcloud.com/borregofabian) · [Edwin Starr feat. Stevie Wonder – War Superstition](https://soundcloud.com/borregofabian/war_superstition)

\_\_  
Impari Marte 😠 In Unequal Combat\_\_

I Wish You All A Safe & Happy Easter

---

The War Against BIG TECH\*\*\*\*

Trump is right to go after these guys in his lawsuit with his website, **TakeOnBigTech.Com** for people to launch their complaint as well. There are ALOT of unscrupulous practices these tech giants are engaged in and are still doing it while under several federal investigations as if they are above The Law. Now many years back, I cautioned people about these tech giants and advised using other competing networks. There are many smaller ones out there offering similar technology where you can take your material. Note a few suggested ones I have in the sidebar where you can also subscribe and follow my activities. The problem with Google/Youtube, and Facebook/Instagram, is an ethics issue. You could be a User in good-standing for many years on there posting general stuff, until they take too much of an interest in **YOU** personally and feel an unrighteous need to a cross a line with you. A professional platform is supposed to run and govern neutrally and fairly with Clients, **\_***you don’t try to get involved in the personal life of an online User out of the blue like that, stalking him or her ALSO outside of your social media network trying to interfere in the persons life and/or his or her commercial activities, especially engaging in a collaborative effort with other tech giants against that person or small business, and feel that you can’t be held legally accountable for your cyber crimes, because it’s all documented and provable in and outside of a Courtroom. These crimes are even more egregious when you can even prove the extent of the insidious Agenda due to the bad judgment of The One(s) behind it clearly targeting a person or company in illegal ways.***\_**

**The Ongoing Effort To Unseat Madison Cawthorn**

Leave Young Cawthorn Alone! That poor Dude. He worked so hard to repair his life after that car crash, struggling to walk again. He accomplished so much. And being the youngest elected Politician Representing North Carolina, The Republican Party should be proud to have such a Fighter like him helping them. It’s not the first that you’ve had Politicians in your ranks make loose comments, and they were older gentlemen. It’s not a secret that Washington, DC is a meat market when it comes to lewd interests. The illegal drug issues are well known too. The ones among you attacking him for casually saying it shouldn’t worry if the commentary does not apply to you.

\*\*\*\*Judge Ketanji Brown Jackson

---

Congratulations to YOU for being nominated and approved as the first Black Woman to sit on The Supreme Court Of The United States.

**Will Smith & Chris Rock**

As expected, the memes and creative videos spoofing that slap incident at The Oscars is all over the place. And what’s sad are people involving themselves in their personal matters dragging it out and adding more disparaging commentary. I’m inclined to go beyond distractions like this to wonder about what the rest of the world is NOT paying attention to. According to some Conspiracy Theorists, just before something BIG is about to go down, the rest of the global masses must be distracted by some other event they are paying way too much attention to, which prevents them from noticing a real issue taking place that they should be more concerned about.

.

**The Continued Increase In Urban Crime**

Well, societies around the world got upset these past couple years with the pandemic affecting our lives in multiple areas, so naturally it threw off the normal flow of things. Now people don’t want to go back to work. And the idle among them are making trouble in the streets. All you had to do from the beginning of the crisis was leave everything as it was. People die all the time from illnesses. Ya’ll should never had done the global pandemic thing. You now have a problem re-organizing society. Let people take care of themselves and their sickness as they did since the dawn of time.

**Critical Race Theory Being Taught In Schools**

I’m tired of the many people out there using the terms **CRT** and **Woke** spreading it all over the media like a goddamn FOOL! What you need to examine is WHO is really behind it being IN your schools in the first place. Do you know that many of your Educators in these institutions talking about that stuff are Jewish? And guess what, if ya’ll remember growing up, the topic was always IN the classroom. It was not outright called “CRT” nor the term “woke” was ever used. **\_***WHY?***\_** Well, the term “woke” is a recent construct from an urban street phrase, ‘Are You Woke?’ meaning a person of Color being alert to the racial injustice happening around them and in their lives and knowing how to handle it. The term “Critical Race Theory” as taught in college is an attempt to intellectualize these Black Issues. But if you remember, those of you who had Jewish Teachers in any grade, race or racial discussions often came up and sometimes it was constructive.

**The Ukraine / Russia Conflict**

You know, the more I keep seeing that Zelenskyy guy on the big screen, the more I am reminded of certain key things to look for that Conspiracy Theorists like to point out about certain big events in the news. I mean, we just keep seeing this Jew all over the place acting a role. Now, notable top Russian Generals have been killed already in battle. And these are trained soldiers. Zelenskyy carries himself as if he had years of training as a Guerilla Fighter or something defending his country, but leave that persona to the real people who have done it in Cuba, South America, Asia & Africa. That model looks way better on them. I’m seeing exactly what some people feel about all this and so many people are being fooled right now. And there is more I’d like to say in the future regarding why you are seeing those 2 Ukraine flag colors everywhere. As for Putin, I get why he wants Ukraine back. I study a lot of things and a few years back I’d noticed how friendly and accessible they were to The American Military occupying their territory, and I thought **hmm**, that’s interesting. How’d that happen? Aren’t they supposed to be deferring more to the interest of their fellow Soviet States. And what’s happening **\_***now***\_**, from a political and military perspective is the norm really if you study history. It would be stupid had Putin not try to do anything about it.

**Migrants At Our Borders**

Well, a territory or country is defined by Its borders. I think by now in our history had the U.S focused more on building our own technological feats here, we would already have a state of the art **force-field** set up that was impenetrable, and you can only get through if someone at the command post turned it off. Also with it, would be some type of futuristic weapon that zapped a person neutralizing him or her on the spot.

**\*\*\* If any new issues pop up in the coming weeks leading into Easter, I might update this. \*\*\***

**The Brooklyn Subway Shooting**  
Well….something else DID happen, and this was very drastic. A mentally ill black guy in New York decided to smoke bum a subway car he was in and shoot up some people in the confusion. The First reports said there were 36 shots, now they say it was 33. Now, when I see and hear odd events like this in news, what comes to mind sometimes is conspiracy stuff, especially with these numbers. A Special Ops event designed to control The People. Now President Biden a day before made a speech about gun control, and then this happens. People don’t just turn themselves in a day after events like that. They are not easily found like that and they don’t remain in the state or general area to be found. Usually there is an extensive manhunt after the person who is desperately trying to evade capture. So now, what we are about to see is more legislation designed to disarm The People at the expense of 10 dead and about 9 injured New Yorkers. **\_***Oh and it’s interesting to note that The Shooter was on Youtube making all sorts of crazy violent comments directed at a person. Google is busy eyeing the accounts of non-violent people leading normal lives, but failed to identify a truly questionable person using their services.***\_** \_\_Another interesting thing to note is how almost every April each year, there are violent sacrificial happenings such as this breaking out just before or around Hitler’s birthday.  
\_\_**\_**\_[Excerpt Of Biden’s Recent Gun Control Speech](https://utreon.com/v/3bJesOQPQ3W)  
[News & Opinions On The Subway Shooter](https://rumble.com/search/video?q=subway%20shooter)  
*\*\**\*\*

**Which Big Tech Company Are YOU Having Problems With Now Or In The Past? Scroll Down And Leave Your Reply Below.**

**Sign,**  
**Lhisa Mrklon**

[**VISIT THE EMPIRE STATE BUILDING**](https://www.tiqets.com/en/new-york-attractions-c260932/tickets-for-empire-state-building-general-admission-p974092/?partner=ferrelux&tq_campaign=New%20York)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191975552/ydbWpxicJ.jpeg align="left")](https://lightinthebox.tv2h87.net/c/3170166/898314/8199?prodsku=8593339&u=https%3A%2F%2Fwww.lightinthebox.com%2Fmen-s-sleeveless-running-tank-top-tee-tshirt-top-athletic-athleisure-summer-cotton-quick-dry-breathable-soft-fitness-gym-workout-basketball-running-ac_p8593339.html&intsrc=PUI2_7096)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191977127/fFr5PO9ss.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191978787/sWDdYVBDZ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191980618/W9YJMeJj1.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191982730/d0piIADVM.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191984148/pAy9BtTWpE.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191985693/UzuADoO0s.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191987015/RBigPA8td.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191988334/z73iyEun3.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191989525/tzVvb4bIe.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191990830/rW1IM3yCJ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191992251/RERnrxSgh.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191993753/t6hIBw0DW.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191994971/Lx-xR5D4R.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191996331/NDNpkmWLM.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191997685/rqVJVnm6Y.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191999114/AaOeAzzuM.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192001116/GAubjAHTD.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192002796/AfKgu2jim.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192003997/XPbKm1Dkh.jpeg align="left")

### Like this:

Like Loading...

### *Related*
