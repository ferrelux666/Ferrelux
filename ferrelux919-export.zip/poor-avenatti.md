---
title: "Poor Avenatti ⛈\U0001F632\U0001F3DB"
date: '2019-08-27T20:36:17.000Z'
slug: poor-avenatti
tags:
  - interview
  - trump
  - money
  - media
  - politics
  - court
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672194805304/2RbmjSC-d.jpeg
canonical: 'https://ferrelux666.wordpress.com/2019/08/27/avenatti/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194778870/V6ECJl8qR.png align="left")](https://www.ferrelux.us/)

  
[Mickey Spillane ~ Theme from the 80s Private Eye TV Show ‘Mike Hammer’](https://www.youtube.com/watch?v=QDWtESy4fOs)

*Sapiens Nihil Affirmat Quod Non Probat*   ⛈  *A Wise Man States As True Nothing He Cannot Prove*

THEY, are out to get him. I mean…….really. We first met Michael Avenatti on the scene as Porn Star Stormy Daniels Lawyer. He seemed together, not afraid, and knowing his facts. He and Stormy were legally hitting Trump with the 1,2 punch. They were all over TV with it. Cops supporting Trump, even went as far as to set up Stormy when she was doing one of her sex shows in a state that had a certain legal clause about touching the viewing customer (as they incited her to do). She was able to beat the charge after the arrest, and be a heroine paying the bail of the other women working that night, then get on TV talking about the desperateness of the President. The case seemed fun and a nice thorn in the side of Trump, that he decided to call her ‘horse face’. Well that didn’t matter the night he paid to have sex with her. It could have just ended clean there, but Trump (allegedly) sent a goon to threaten her and her kid while he was running for President to not talk about the affair, and THAT mistake is why she’s on the scene. The sex scandal payoff case was annoying the President, but it all started to go south when the Judge at the trial threw out the case. They tried appealing, but as time went on, nothing came of it. Stormy herself after seeing some fundraiser in her name on Twitter circulating, turned on her former Lawyer accusing him of fraud. He publicly explained that the funds were used where her case is concerned, and as time went on, there was no further news on that. The 2 parted ways. The news earlier this year, late February into March began covering actor Jussie Smollet and his “lie” about being attacked in the streets of Chicago in the early wee hours of the morning on a cold night, for being gay and Black. Also, in the weeks following, the R. Kelly sex scandal case re-surfaced in the media. It was Michael Avenatti who received an old tape he says showing R. Kelly having sex with an underage girl (14), and he decided to send it to the Authorities. Avenatti was representing one of the now grown women accusing R. Kelly of molestation. As others came forward with charges, R. Kelly briefly ended up in jail, but as the spotlight Lawyer ran into his own legal troubles, that helped R. Kelly’s case. Avenatti went from being this tough Lawyer helping women, to his own legal coverage of Journalist headlines shading him as a crook. He is accused of a high crime of trying to defrauding the sportswear giant, Nike of billions years ago. So now he’s fighting extortion charges. Gee, I wonder how and why this just popped up. I bet Avenatti knows. It’s revenge time. Avenatti has publicly declared that there are Mighty people out there that don’t want him on the scene. Man, this sure dampens any political agenda he had like running for President. When Sean Hannity, Tucker, and them were calling him a 3rd rate Lawyer, and other jeering stuff, if that were true, then you (Republicans in favor of Trump) shouldn’t feel threatened by him. He has some interesting ways of doing things. The man is effective and he looks great. His look and behavior reminds me of an old gangster movie with him starring as the private eye who wins in the end. I hope he beats the charges and gets back on the scene.

[Michael Avenatti, Updates](https://www.google.com/search?source=hp&ei=fIdlXa-ABOKe_QalgZngBg&q=michael+avenatti&oq=michael+avenatti&gs_l=psy-ab.3..0l10.57588.65728..66408...3.0..0.458.2584.16j4j4-2......0....1..gws-wiz.....0..0i131.K1kRiF33l4Q&ved=0ahUKEwivrtO056PkAhViT98KHaVABmwQ4dUDCAs&uact=5#spf=1566945739557)

Lhisa,  
Special Agent 666

### Do You Suspect Donald Trump Is Behind Michael Avenatti’s Sudden Legal Troubles? Scroll Down And Leave Your Reply Below.

[![90](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194779987/BUjMRgPtn.jpeg align="left")](https://ferrelux666.wordpress.com/90-3/)

[![960x0](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194781367/SRZyWdPyh.jpeg align="left")](https://ferrelux666.wordpress.com/960x0/)

[![112620fb-8601-4b88-8988-ca7fbfcf4461-avenatti-kelly](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194782701/eTxBne3Bm.jpeg align="left")](https://ferrelux666.wordpress.com/112620fb-8601-4b88-8988-ca7fbfcf4461-avenatti-kelly/)

[![105812893-avenattithumb](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194783909/maz6FDL3m.jpeg align="left")](https://ferrelux666.wordpress.com/105812893-avenattithumb/)

[![5p-7p The Situation Room CLEAN with CC](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194785216/o_RuPYlV2.jpeg align="left")](https://ferrelux666.wordpress.com/5p-7p-the-situation-room-clean-with-cc/)

[![WEST HOLLYWOOD, CA - JULY 26: Attorney Michael Avenatti participates in a city-sponsored panel discussion on July 26, 2018 in West Hollywood, California. During the discussion, Avenatti announced that he is representing three more women who will come forth to claim they were paid by Donald Trump, AMI Entertainment and Michael Cohen to remain silent. Avenatti represents Stormy Daniels in her lawsuit against President Trump over a $130,000 payment to silence her about an alleged affair with Trump. (Photo by David McNew/Getty Images)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194786603/V1Nk-ddUO.jpeg align="left")](https://ferrelux666.wordpress.com/attorney-michael-avenatti-joins-panel-to-discuss-mueller-investigation/)

WEST HOLLYWOOD, CA – JULY 26: Attorney Michael Avenatti participates in a city-sponsored panel discussion on July 26, 2018 in West Hollywood, California. During the discussion, Avenatti announced that he is representing three more women who will come forth to claim they were paid by Donald Trump, AMI Entertainment and Michael Cohen to remain silent. Avenatti represents Stormy Daniels in her lawsuit against President Trump over a $130,000 payment to silence her about an alleged affair with Trump. (Photo by David McNew/Getty Images)

[![ct-1550271081-nrmmpmvqto-snap-image](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194787858/4AzNPURKO.jpeg align="left")](https://ferrelux666.wordpress.com/ct-1550271081-nrmmpmvqto-snap-image/)

[![Avenatti-style](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194788890/36544H_wd.jpeg align="left")](https://ferrelux666.wordpress.com/avenatti-style/)

[![speaks onstage at Day 2 of the Vanity Fair New Establishment Summit 2018 at The Wallis Annenberg Center for the Performing Arts on October 10, 2018 in Beverly Hills, California.](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194790275/rJXJLOqVE.jpeg align="left")](https://ferrelux666.wordpress.com/181114175116-michael-avenatti-file-1010-exlarge-169/)

speaks onstage at Day 2 of the Vanity Fair New Establishment Summit 2018 at The Wallis Annenberg Center for the Performing Arts on October 10, 2018 in Beverly Hills, California.

[![maxresdefault](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194791476/DdhBeMgAK.jpeg align="left")](https://ferrelux666.wordpress.com/maxresdefault-8/)

[![michael_avenatti-charges_30122_c0-0-2000-1166_s885x516](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194792474/xCMcqV5ag.jpeg align="left")](https://ferrelux666.wordpress.com/michael_avenatti-charges_30122_c0-0-2000-1166_s885x516/)

[![Untitled-collage-2-998x749](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194793786/CN6oAaKHm.jpeg align="left")](https://ferrelux666.wordpress.com/untitled-collage-2-998x749/)

[![Michael-Avenatti-criminal-gq](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194795027/g6fGhVcWl.jpeg align="left")](https://ferrelux666.wordpress.com/michael-avenatti-criminal-gq/)

[![michael-avenatti-1](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194796428/WtRcRzAXA.jpeg align="left")](https://ferrelux666.wordpress.com/michael-avenatti-1/)

[![Michael-Avenatti](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194797634/m44eB3vBM.jpeg align="left")](https://ferrelux666.wordpress.com/michael-avenatti/)

[![MichaelAvenatti](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194799652/V04uDIfC8.jpeg align="left")](https://ferrelux666.wordpress.com/michaelavenatti/)

[![avenatti](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194800804/ZY_n0YDbj.jpeg align="left")](https://ferrelux666.wordpress.com/avenatti/)

[![1543904808890140995](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194802423/8FIYBpqSg.png align="left")](https://ferrelux666.wordpress.com/news/attachment/1543904808890140995/)

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/Wybi5qiLu64?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/UgRPGX55VVM?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/-vYVDPbL_EA?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/Zz7gCALneO8?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/iv6Ug3-V7KI?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194804147/tUH7DgLydJ.jpeg align="left")](https://ferrelux.com/adverts/)
