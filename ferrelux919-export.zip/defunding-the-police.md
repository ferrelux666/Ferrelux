---
title: "Defunding The Police \U0001F416\U0001F694\U0001F463"
date: '2020-07-19T18:50:59.000Z'
slug: defunding-the-police
tags:
  - education
  - class
  - recruitment
  - state
  - money
  - funding
  - kids
  - teens
  - joke
  - caribbean
  - african-american
  - financial
  - police
  - military
  - indian
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672194052493/Za-IqyR8c.png
canonical: 'https://ferrelux666.wordpress.com/2020/07/19/defunding-police/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194014944/-AegX-VaI.jpeg align="left")](https://en.wikipedia.org/wiki/100_Blacks_in_Law_Enforcement_Who_Care)

[**“Police & Thieves” – The Clash (1977)**](https://www.youtube.com/watch?v=N3A8uNG3GH4)

*Modus Operandi* 👮 *Mode of Operation*

When you’re an irresponsible Officer, and permitted by The System to escape punishment so you can do it again targeting the Underprivileged, and some of your Colleagues do the same, then you get criticism and civil unrest, leading to some type of reform you may disagree with. But let’s look at everything in perspective. A series of events popped off this year that are related. Things are not just happening for no reason. Something is up. Movements towards a drastic change for the future is playing out right before our eyes, under cover. So this is about something else. Using Black People’s issues is just the excuse. Placating you with The Black Lives Matter mural on 5th Avenue & other places in New York City for example, might be a huge tactic that has little to do with caring for our Civil Rights, but more to do with a grander political agenda. Since there is a live problem between Blacks & The Police, a Puppet Master somewhere may be exploiting that to serve a bigger cause. When you’re about to setup a new system, you start moving certain chess pieces of your plan into place. You already started showing signs of it, so to enforce something, you might gradually need to do away with the standing Police Force, in favor of Military Police governing The Streets. So in reality, what you’re trading away is a softer civilian disciplinary corps for a fiercer set with impunity from the new regime, where The People, can’t protest or call a Soldier to justice. You see I would be careful folks with these sudden changes because you might be setting yourself up. Things may look good for a while till you see it’s not about you.  
Yes, there is a problem, but there is also a world around you. These things are globally decided by the people who run it, and are done not so much for your benefit but for theirs, while manipulating you. Pay attention to all the surrounding shit. Don’t be so gullible going along with stuff. You might want to fight to hold on to something. Remember you don’t really have any true political power, but what we do have is a mind. It’s not hard for a street dude or gal with little power, to all of a sudden create enough of a problem that it can fuck up the plans of the very Powerful. It’s been happening since antiquity. You with your small band of Operatives, doing what you’re doing, can manipulate too. You’re very much like THEM, but born in humbler settings, understanding very much how the game is played. And you’re standing up there like a G, with little resources in defiance. The People take notice and you have influence. They understand you. You speak their language. You’re real. You’re a Leader. The System did not expect you. You’re disrupting a process. Simply eliminating you right away might expose something, or make you a Martyr. And you’re well aware of this, but there’s something guiding you, a power that’s behind you that they have no control over. For some reason you prevail and continue to. And there are others dispersed about the lands with a similar awakening, working just like you and can hold their own like any fictional hero you admire. And it’s just a matter of time when a formidable team forms challenging THEM. And the story often ends as many of them do in history, where The Person succeeded in inspiring a counter-movement effecting a change stopping something, and in some cases toppling a regime. So anyway, back to the legislation of defunding the police. You know, they really do need to cut funding for certain aspects of law enforcement that aren’t really necessary. If you live in one of these policed neighborhoods or have access commuting through there, you will notice after a while the ridiculous handling of certain cases & persons. Mind you, there are Cops who have an intelligent way of doing things and reading situations to know what to do, and what not to do. And these Cops don’t get enough credit. And they don’t get involved in stupid shit. Their names don’t come up on a roster out there like that in shame. Nor do you see them being investigated. So these are the ones in your community that are doing a professional job. Now, aside from the cases out there in the media everyone knows about, there are other minor shit around your block that the media doesn’t cover. Governor & former  
Pro-Wrestler Jesse Ventura, on his show ‘Conspiracy Theory’ exposed a secret government activity where an ordinary American Citizen just going about their business leading their lives, can end up on ‘A Watch List’ for no reason, simply because they may have said a buzz word on the phone or typed something online that their system flagged when in reality, the person just made an innocent comment. He featured a basic young White female who got on their list by chance. So she was followed around for no reason. Now, the way things really work in life is like this. While they are busy watching you & me, following us around, they aren’t paying attention to him or her over there who is actually the criminal. They later find out after the crime. Now him & her, know they aren’t being watched, why they can mug somebody or commit some heinous crime. In many cases, the person on the “watchlist” don’t appear to be involved in the solicitation to commit a crime or a party to one, but yet they follow the person for no reason day after day, week after week, month after month, & year after year and still no data of criminal mischief. Just a file of ‘oh on this day he wore a nice Adidas sneaker, picked up his friend & saw a movie, they ate at the restaurant over there, and parted ways.’ You can’t take that shit to a Judge. It more looks like YOU the Cop is abusing your power taking a daily interest in somebody hoping he commits a crime so you can validate your activity when YOU are actually the one violating that person’s civil liberties and you have no damn case. If there was really something going on, no Cop would need to do that. A Criminal is a Criminal, that means they are out there fluently committing crimes and you can catch them live on camera or in the act. Real Cops, are excited about actively catching bad guys. They may have a Cold Case File sitting there on the shelf that they look at from time to time in an effort to finally solve an old crime. That’s what they spend time doing. They need funding for the upkeep of the Station, equipment, reward money for Intel on a case, forensic stuff, etc. They are not trying to get funding for a bullshit local Anti-Terrorist Op or other bogus program, where they pretend there is an issue in the area that don’t really exist and getting the neighborhood community centers & businesses involved collecting data on people. If any of you notice that sort of thing, or you notice it around you being the Subject spied on, then you know how it works and the fool they’re using. You may even notice it around someone you know. A guy or gal, goes about his/her life only to see some person from time to time where they are spying on them. The Cop may sometime use a certain bum or neighbor to do the watching passing by, and there is absolutely no reason for that individual to be where you are. In some cases, what the Cop doesn’t realize is that the person may be well versed on FBI/CIA shit, might be an Agent too, WHY the case isn’t going anywhere. And maybe they have someone or something looking out for them why they can just evade you & disappear like that. They are well aware of the spy tactic and don’t care. And ‘The Powers That Be’ that know better, have bigger things on their mind and maybe that person you are watching is Somebody, they wouldn’t mind in league with them, and so your case becomes a nuisance to them, where they pass ordinances neutralizing the Cop from bothering such persons. That’s kind of what’s taking place now. It has happened subtly before in history. You see despite all that surveillance, they don’t know who people really are. And the fool they are using who claim they know the person, don’t know shit. They are not someone The Subject talks to or would invite anywhere. So they can’t establish a personal relationship with the Subject to tell the Officer anything important. The Clown they are using already got made and is just taking their cop handout money telling them shit. The other Mentally Ill Ass, they keep using that you see every other day, already blew their case. So this is a joke. I grew up watching real Cops, you know the Ones that actually solve cases using excellent strategy & police work. They were able to solve the most basic misdemeanor, to the very wicked crime. You can still see these old time crime cases watching ‘The FBI Files’, ‘Cold Case Files’, ‘American Greed’, ‘Dominick Dunne’ & so forth. You Newbies can get a chance to see what a real Cop looks & sounds like. They can read a person & situation right. And I can do the same. I still keep myself well versed on the right things while watching all this crazy shit happening now. So I know the difference. Certain shit, I would not be doing if I was looking to investigate someone. Another thing too what these Cops don’t know about, is the ethnic shit. You’re investigating certain Asian, Italian, Hispanic, Caribbean, Jewish, Indian, Arab, or Other Community not knowing certain in-depth info about that Culture why cases don’t go well. The person may or may not fit a Cultural Stereotype. Then there’s all that idiosyncrasy. All that gets in the way too. Your case may have been getting somewhere until one or two fuck-ups with The Agent, Informant or other Spy saying or doing something that sparks distrust, because he or she don’t understand certain social customs and it makes your case turn to shit. This also happens amongst “Whites” where the Cop who is also White and undercover makes a mistake with that Skinhead group not taking a certain beer or saying or wearing something that cause suspicion when as a bonafide Skinhead you should know better, and your infiltration process fails. So no, a stupid operation should not be funded. Using the extra city revenue to bring back community youth programs is not a bad idea because in the past, kids had somewhere to go and something they cared to do, not hanging out in the street getting dissed, jumped, getting into trouble, or other messed up shit. And they don’t need to be getting involved in these police kids recruiting programs either, risking themselves getting caught up as pawns on a case they have no business on. Teens just need to be safe somewhere doing something constructive, under the proper care & supervision of the right Individuals.

Lhisa, Special Agent 666  
The Untouchable

### Should Your Hard Earned Tax-Payer Money Go Towards Cops Engaged In Unethical Surveillance Practices In Your Neighborhood? Scroll Down And Leave Your Reply Below.

[![Ferrelux Homepage_DefundingPolice](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194016493/7Mtp4qLia.png align="left")](https://ferrelux666.wordpress.com/2020/12/24/goodbye-2020/ferrelux-homepage_defundingpolice/)

[![Alert Police Vehicle](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194017755/7ssL3S1wK.jpeg align="left")](https://ferrelux666.wordpress.com/alert-police-vehicle/)

[![A Cop](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194019049/finQLNNPP.jpeg align="left")](https://ferrelux666.wordpress.com/a-cop/)

[![Abolish The Police Protest Sign](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194020433/S52vE21qu.jpeg align="left")](https://ferrelux666.wordpress.com/abolish-the-police-protest-sign/)

[![Black Lives Matter March](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194021818/NN8_oEgmW.jpeg align="left")](https://ferrelux666.wordpress.com/black-lives-matter-march/)

[![Cop On Radio](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194022902/gzUB95GWX.jpeg align="left")](https://ferrelux666.wordpress.com/cop-on-radio/)

[![Black Lives Matter_Alton Sterling](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194024524/7bDGSe_LU.png align="left")](https://ferrelux666.wordpress.com/black-lives-matter_alton-sterling/)

[![Cop Graduating Class](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194025762/yKN_7dNVB.jpeg align="left")](https://ferrelux666.wordpress.com/cop-graduating-class/)

[![Cop Art Data Interactive](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194027303/dTyKAJiEx.png align="left")](https://ferrelux666.wordpress.com/cop-art-data-interactive/)

[![Cop Infantry T-shirt](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194028697/iN2Zo4L2t.jpeg align="left")](https://ferrelux666.wordpress.com/cop-infantry-t-shirt/)

[![Close up of the statue of liberty, New York City, vintage process](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194029973/hyb1N8UuL.jpeg align="left")](https://ferrelux666.wordpress.com/close-up-of-the-statue-of-liberty-new-york-city-vintage-process/)

Close up of the statue of liberty, New York City, vintage process

[![Cop USA Flag](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194031203/HkbPcVvi6.jpeg align="left")](https://ferrelux666.wordpress.com/cop-usa-flag/)

[![Join The Boldest](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194032535/9oazNshBh.png align="left")](https://ferrelux666.wordpress.com/join-the-boldest/)

[![Correction Officers](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194033916/XPtLw5Mcg.jpeg align="left")](https://ferrelux666.wordpress.com/correction-officers/)

[![Durham Police Car](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194035145/9yQTevaUx.jpeg align="left")](https://ferrelux666.wordpress.com/durham-police-car/)

[![Infantry Cops Geared Up](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194036298/MkT-1znwy.jpeg align="left")](https://ferrelux666.wordpress.com/infantry-cops-geared-up/)

[![Miami Police Kneel With Protesters](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194037574/Hr4t5DeB6.png align="left")](https://ferrelux666.wordpress.com/miami-police-kneel-with-protesters/)

[![Oldtime B&W Photo](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194038946/t0dGuXF8x4.jpeg align="left")](https://ferrelux666.wordpress.com/oldtime-bw-photo/)

[![Police And Protesters Go At It](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194040173/ZsJR0P8B_.jpeg align="left")](https://ferrelux666.wordpress.com/police-and-protesters-go-at-it/)

[![Police Taking A Knee](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194041254/CicCsHMXZ.jpeg align="left")](https://ferrelux666.wordpress.com/police-taking-a-knee/)

[![President Trump Sporting Blue & Red Tie](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194043287/vhjrrN7LB.png align="left")](https://ferrelux666.wordpress.com/president-trump-sporting-blue-red-tie/)

[![Young Cops](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194044697/onb5mDHCO.jpeg align="left")](https://ferrelux666.wordpress.com/young-cops/)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194046115/77TBsMAA7.jpeg align="left")](https://www.discovercars.com/?a_aid=Ferrelux)
