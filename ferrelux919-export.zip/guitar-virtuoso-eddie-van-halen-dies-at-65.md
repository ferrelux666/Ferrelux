---
title: "Guitar Virtuoso Eddie Van Halen Dies At 65 \U0001F3A4\U0001F3B8\U0001F307"
date: '2020-10-12T19:00:24.000Z'
slug: guitar-virtuoso-eddie-van-halen-dies-at-65
tags:
  - music
  - health
  - entertainment
  - cancer
  - guitar
  - celebrity
  - hollywood
  - 90s
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672193881189/XrSJfR_G9.jpeg
canonical: 'https://ferrelux666.wordpress.com/2020/10/12/van-halen/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193835691/4aIoHpPEo.png align="left")](https://www.eddievanhalenstore.com/)

[**“Running With The Devil” – Van Halen**](https://www.youtube.com/watch?v=i5txwFv-zYM)

*In Animam Viventem Ieiunium Vitae*  👿  *Living The Fast Life*

I’m a Rocker too and I actually did a rendition of ‘Running With The Devil’ and although I’ve enjoyed listening to a few of their songs, Van Halen was not one of my favorite hard rock bands. And there were other guitarists I was paying more attention to in The Heavy Metal World at the time, however I didn’t mind seeing them though because I actually liked David Lee Roth’s antics on stage performing. I also loved him as the band’s Front Man at the time before he was replaced by Sammy Hagar, who I liked as well as a Vocalist. But, I have to mention Eddie Van Halen because he does deserve recognition for also making VAN HALEN what it was with that electrifying guitar playing that made him one of the greatest guitarists of all time. It was HIS guitar playing on Michael Jackson’s rock track, “Beat It”. Eddie had a lot to offer. He had a nice look to him and seemed like a cool guy. He had a long battle with cancer and he’ll be very missed by the Rock World.

**SOME LINKS**

[Some Info On His Death](https://www.google.com/search?ei=DoKDX6vaLqS1ggfiirPICg&q=eddie+van+halen+dies&oq=eddie+van+halen+dies&gs_lcp=CgZwc3ktYWIQAzIGCAAQFhAeMggIABAWEAoQHjoNCAAQsQMQgwEQsAMQQzoHCC4QsAMQQzoNCC4QsQMQgwEQsAMQQzoLCAAQsQMQgwEQyQM6CAgAELEDEIMBOgQIABADOggILhCxAxCDAToLCC4QsQMQgwEQkwI6AggAOgIILjoICCEQFhAdEB46CQgAEMkDEBYQHkoFCAgSATFQzKQCWLbeAmD55QJoBHAAeAKAAbsJiAHBIZIBDzAuNC4xLjEuMS4yLjAuMZgBAKABAaoBB2d3cy13aXrIAQrAAQE&sclient=psy-ab&ved=0ahUKEwirmZe6xq3sAhWkmuAKHWLFDKkQ4dUDCAw&uact=5#spf=1602464838439)

[Some More Info On Him As An Artist](https://www.google.com/search?ei=JoCDX4KgJeuzggfKmKnoCg&q=eddie+van+halen&gs_ssp=eJzj4tTP1TcwTCtLyzNg9OJPTUnJTFUoS8xTyEjMSc0DAHqyCQI&oq=Eddie+&gs_lcp=CgZwc3ktYWIQARgAMg4ILhCxAxCDARDJAxCTAjIECAAQQzIECC4QQzIOCC4QsQMQgwEQxwEQowIyCgguELEDEIMBEEMyCAguELEDEIMBMggIABCxAxCDATIECC4QQzIECAAQAzIICC4QsQMQgwE6BwgAELADEEM6CggAELEDEMkDEEM6AggAOgoIABDqAhC0AhBDOgcIABCxAxBDOgoIABCxAxCDARBDOgcILhCxAxBDOgsILhCxAxDHARCjAjoQCC4QsQMQgwEQyQMQQxCTAkoFCAgSATFQ6oAdWPKnHWDSzB1oAnAAeAKAAbUDiAH3JZIBCjAuMTAuNy4zLjGYAQCgAQGqAQdnd3Mtd2l6sAEKyAEKwAEB&sclient=psy-ab#spf=1602464789005)

**\\m/ \\m/**  
**: L H I S A :**

### Was Eddie Van Halen The Best Rock/Heavy Metal Guitarist? Scroll Down And Leave Your Reply Below.

[![Van Halen Women And Children First, Back Cover Photo By Norman Seeff](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193836901/zADNKCQje.jpeg align="left")](https://ferrelux666.wordpress.com/van-halen-women-and-children-first-back-cover-photo-by-norman-seeff/)

[![Van Halen's Eddie & David](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193838228/SWDbjDO1H.jpeg align="left")](https://ferrelux666.wordpress.com/van-halens-eddie-david/)

[![Young David Lee Roth](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193839599/jy0mEGIxY.jpeg align="left")](https://ferrelux666.wordpress.com/young-david-lee-roth/)

[![Valerie Bertinelli & Eddie Van Halen](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193840719/eCvGsJWXA.jpeg align="left")](https://ferrelux666.wordpress.com/valerie-bertinelli-eddie-van-halen/)

[![Van Halen Album Photo](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193841797/CDzlCW678.jpeg align="left")](https://ferrelux666.wordpress.com/van-halen-album-photo/)

[![Ferrelux Homepage_EddieVanHalen-Oct2020](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193842838/RSX7BFNaD.jpeg align="left")](https://ferrelux666.wordpress.com/2020/12/24/goodbye-2020/ferrelux-homepage_eddievanhalen-oct2020/)

[![Van Halen Earth Logo](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193843940/6gavmtnFg.png align="left")](https://ferrelux666.wordpress.com/van-halen-earth-logo/)

[![Van Halen Silver & Blue Logo](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193845456/YQeAbdz7x.png align="left")](https://ferrelux666.wordpress.com/van-halen-silver-blue-logo/)

[![Van Halen White & Blue Logo](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193846523/z3MPCa_sO.jpeg align="left")](https://ferrelux666.wordpress.com/van-halen-white-blue-logo/)

[![Superstar David Lee Roth](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193847903/f0OsJSCc5.jpeg align="left")](https://ferrelux666.wordpress.com/superstar-david-lee-roth/)

[![Eddie Van Halen With Guitar B&W Shot](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193849077/D9JVJhQ_n.jpeg align="left")](https://ferrelux666.wordpress.com/eddie-van-halen-with-guitar-bw-shot/)

[![Eddie Van Halen Wedding Photo](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193850222/0AWbPkqqu.jpeg align="left")](https://ferrelux666.wordpress.com/eddie-van-halen-wedding-photo/)

[![Eddie Van Halen Playin' B&W Photo](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193851327/TJTtxg3ll.jpeg align="left")](https://ferrelux666.wordpress.com/eddie-van-halen-playin-bw-photo/)

[![Eddie Van Halen 'Old School' B&W Photo](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193853616/5DotRg-cE.jpeg align="left")](https://ferrelux666.wordpress.com/eddie-van-halen-old-school-bw-photo/)

[![Eddie Van Halen Jumping](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193854775/-SZZLu4jL.jpeg align="left")](https://ferrelux666.wordpress.com/eddie-van-halen-jumping/)

[![Eddie Van Halen Jumpin'](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193855789/kHWmnf_UF.jpeg align="left")](https://ferrelux666.wordpress.com/eddie-van-halen-jumpin/)

[![Eddie Van Halen Jamin'](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193856976/7OS7uIRUc.png align="left")](https://ferrelux666.wordpress.com/eddie-van-halen-jamin/)

[![Eddie Van Halen In The Spirit](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193858426/gFeHraiFt.png align="left")](https://ferrelux666.wordpress.com/eddie-van-halen-in-the-spirit/)

[![Eddie Van Halen Body Photo](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193859684/LAVErLPzc.jpeg align="left")](https://ferrelux666.wordpress.com/eddie-van-halen-body-photo/)

[![Eddie Van Halen Cool Photo](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193860923/KTGmj0NN0.jpeg align="left")](https://ferrelux666.wordpress.com/eddie-van-halen-cool-photo/)

[![Eddie Van Halen Crouching & Playing](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193861969/XoCs_ZErq.jpeg align="left")](https://ferrelux666.wordpress.com/eddie-van-halen-crouching-playing/)

[![Eddie Van Halen Doing A Solo](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193863554/1x0IRUSRD.png align="left")](https://ferrelux666.wordpress.com/eddie-van-halen-doing-a-solo/)

[![Eddie Van Halen In Practice](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193864756/HL-Jrf-bB.jpeg align="left")](https://ferrelux666.wordpress.com/eddie-van-halen-in-practice/)

[![Eddie Van Halen Art](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193865789/Hsi08t-1D.jpeg align="left")](https://ferrelux666.wordpress.com/eddie-van-halen-art/)

[![Eddie Van Halen 1955-2020](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193867099/Ey7EvxoLA.png align="left")](https://ferrelux666.wordpress.com/eddie-van-halen-1955-2020/)

[![Eddie Van Halen & Valerie Bertinelli Wedding Photo](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193868407/ZY4bM-74i.jpeg align="left")](https://ferrelux666.wordpress.com/eddie-van-halen-valerie-bertinelli-wedding-photo/)

[![David Lee Roth Sassy Posing](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193869485/AuPgdnT19.jpeg align="left")](https://ferrelux666.wordpress.com/david-lee-roth-sassy-posing/)

[![David Lee Roth Body Pose](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193870866/Trfy5zG7Q.jpeg align="left")](https://ferrelux666.wordpress.com/david-lee-roth-body-pose/)

[![David Lee Roth Acting Silly](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193872276/ku0uGzl1x.jpeg align="left")](https://ferrelux666.wordpress.com/david-lee-roth-acting-silly/)

[![David Lee Roth & Eddie Van Halen](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193873636/KW_jvREFi.jpeg align="left")](https://ferrelux666.wordpress.com/david-lee-roth-eddie-van-halen/)

[![Classic Eddie Van Halen](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193874781/ns2i2Q8tQ.png align="left")](https://ferrelux666.wordpress.com/news/classic-eddie-van-halen/)

[![Casual Eddie Van Halen](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193876078/mZYognp62.png align="left")](https://ferrelux666.wordpress.com/casual-eddie-van-halen/)

[![An Older Eddie Van Halen](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193877439/ZwCRSTdsf.png align="left")](https://ferrelux666.wordpress.com/an-older-eddie-van-halen/)

[![A Corporate Shot Of Eddie Van Halen](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193878614/yDX4SNA-B.jpeg align="left")](https://ferrelux666.wordpress.com/a-corporate-shot-of-eddie-van-halen/)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193879779/9wT70YpGX.png align="left")](https://ferrelux.com/adverts/)
