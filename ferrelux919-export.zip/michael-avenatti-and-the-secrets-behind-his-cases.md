---
title: "☕Michael Avenatti And The Secrets Behind His Cases\U0001F3CE"
date: '2021-06-11T03:03:51.000Z'
slug: michael-avenatti-and-the-secrets-behind-his-cases
tags:
  - system
  - trump
  - industry
  - games
  - setup
  - report
  - conspiracy
  - usa
  - sports
  - government
  - attorney
  - constitution
  - la
  - lawyers
  - united-states
  - america
  - california
  - washington
  - raid
  - investigation
  - president
  - court
  - new-york
  - laws
  - justice
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672193011094/ksvIOrccP.png
canonical: 'https://ferrelux666.wordpress.com/2021/06/10/michael-avenatti/'
---
[![Michael Avenatti, Eyeing The Public](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192948434/EWNWA_IER.jpeg align="left")](https://www.cbsnews.com/newyork/news/michael-avenatti-prison-nike-extortion/)

\*\*[The Original 1980s ‘Amazing Stories’ Theme By John Williams](https://www.youtube.com/watch?v=yqfYNfg2ik8)   
Quod Ita Iniquis, Vir Ut Vir 👁 Man To Man Is So Unjust  
\*\*

When we last left off from this saga, I’d expressed a few things [here](https://ferrelux.com/2021/03/26/avenatti-trump/) in my prior article establishing some points. Now let’s continue. So this guy Gary Franklin came into Mr. Avenatti’s life. And the public never knew of him before other than a mere mention of him being a coach for youngsters at his elite basketball team The Cal Supremes. And he was doing well with his $72K per year Nike Sponsorship salary being a coach and occasionally running errands for them making what The SEC, NCAA and other institutions would deem illegal payments to aspiring athletes. This sort of offense is punishable by law, but this guy didn’t mind doing it just as long as he had a job. Well one day, The Nike Corporation decided that they will no longer sponsor the youth program and instead of just accepting that and move on, this guy had a plan up his sleeve. He must have seen the end coming one day because he had in his possession all kinds of receipts and proof of his illegal work for Nike to show somebody some day. And well, he had a friend name Jeffrey Auerbach who according to some sources, his child was also trained by Gary Franklin, and this Auerbach guy is a Consultant who’s also apparently involved in Showbiz Media amongst other businesses of his past like investments. So you have to wonder sometimes about motivation because why should he care? Well, it’s Nike and it’s a big company and I know some secrets, and any darn thing you can think of that he might say. So here we have mostly Black youths playing basketball, their Black Coach and this Auerbach guy all in California. Okay so, why would Nike all of a sudden drop a lucrative yearly contract where they aren’t paying that Coach much money to get Players to play at Nike events and wear Nike gear and so forth? I would think that if Gary Franklin had been collecting all kinds of secrets from them to eventually use one day, he should have been prepared for a sudden drop in activity. He obviously knew that what he was doing traveling between New York & California and anywhere else to make these payments to the kids families were against the federal regulations, but it was okay since he still had a job with them. Alright, but if he cared about these kids as he expresses in articles & videos, then he should have left that whole thing alone, keeping everybody’s secrets including Nike’s. He should not have been yapping to anybody. Who else aside from Jeffrey Auerbach did he tell before making a case of it? Now everybody is in trouble because of him. He could have kept his mouth shut, moved along to doing his own fund-raising activities or find a new Sports Sponsor, but no, Gary wanted to **HURT** Nike because he was hurt. And what did he do? He saw this high profile Lawyer on TV name Michael Avenatti with the Stormy Daniels thing going after President Trump and thought if I only had him representing me. And so he went to his friend Jeffrey to put together all the details and evidence in a digital file since he did not want to, and to have this guy be his articulate mouthpiece and presenter. And so Mr. Avenatti agreed to take his case. But before I continue, let me answer a previous question. If you are a Sports Giant doing some shady activities for years and all of a sudden you don’t want to fund a program anymore **WHY?** Maybe they got caught. Something was up and Gary Franklin should have sensed that given his part in it. So if you are running these payments for Nike, wouldn’t you suspect the company is doing other inappropriate activities also? Shouldn’t you have just left that whole mess alone and move on to greener pastures? Maybe Gary wasn’t sure if his name came up during an internal investigation. Maybe he was well aware or atleast suspected it would. So why go to Avenatti? Why also involve this Auerbach guy along the way? What card game was Franklin playing? Would a Nike Executive sit him down and explain too much about their operation? Or did he know a bit more than he was letting on. I figure if you’ve been in The Sports Arena for years you should be aware of a few seedy things especially if the information is already publicly out there. Why would he not be aware of other illegal activities like investment fraud, and drug-related gang activity? Whether a person was aware of it or not, it wouldn’t be hard to hear about or come across public information concerning The Sport, and The Government Investigations surrounding The Industry. And if he was aware of some of it, maybe he got scared and for insurance decided to keep records of what Nike had him do. But that wasn’t just it. You see, he apparently liked his job being The Coach of The California Supremes and earning his little $72K a year that he was so proud of. Though he felt cut-off and disrespected, he wanted to be back in again. Well that’s stupid because The Company clearly did not want him and had their private legal reasons why. Remember many family’s got exposed because of this scandal. So Gary went on to make trouble coming in with the big guns pushing Avenatti on them and he secured a $1.5 Million Settlement along with Whistle-Blower Protection. So what’s wrong with that? Well…….Gary. Remember he seemed to like his job and secretly wanted that arrangement back. But wait, didn’t he relate to Avenatti all that damaging material against his former Boss, even wanting 3 Executives fired? So why on Earth would they want him back? Generally, this confusion lies in what you told your Attorney you wanted then, versus what you’re saying now in Court, and ofcourse the truth. Why was Nike at the time treating him like a nobody? How much did he really know? Well……..during this course of events, for a good number of years The FBI had a probe into that industry using some Black guy name Marty Blazer as their Informant, and this information was already released to the The Press, and it’s still very much out there if anybody bothered looking. And you know what else is out there, that investigation into related gang activity between New York and California **(and possibly other states)**, just about the same places this Coach traveled to. What was going on at the time that also got published, was a young beat Cop from Philadelphia name Christopher Harper, who ended up shortly after working as an FBI Special Agent in the Eastern & Southern Districts of New York on missions. The news articles out there go on to recount how he got shot by Ronell Watson, a Crips Gang Member, but he survived. And while he was in his own case seeking prosecution against his would-be Killer, just roughly about the same time he was involved in investigating Michael Avenatti. In fact, he was the one who filed the initial complaint. So when you read enough information and filter through the nonesense, you get exactly what’s going on here. So many people aren’t following this case right because if they were, they would be asking the right questions and researching further. And since I’m your Storyteller, let me take you on this wild journey. Now there’s another side to this. Fasten your seat belt. Okay so, prior to how we all learned about him in 2018, let’s take a look back into his past. If you’re Michael Avenatti and you’ve been out there fighting the big cases for The Little Guy over the many years, every now and then your name should come up in the news articles and on TV in that area where you live and work. Well wouldn’t he have racked up along the way some kind of enemy well before Trump? Well we know of a few re-occurring ones from The Press and that would be fine if it was just them, right? Well what does that have to do with Nike? Because, if you have some people that don’t really like you from your past, and now you got really big all of a sudden, sometimes jealousy kicks in, anger kicks in, and hatred kicks in. When you’re somebody going about life successfully, there’s no reason **other than the norm** for you to be having severe problems all of a sudden that wreaks of a malicious hand behind it. Many people feel that it’s Trump, and granted there were issues there. You can’t discount his many Supporters wanting to see his victory, and perhaps helping to mess up Michael Avenatti in some way played a role. But what if it’s Somebody else though? Well now his case becomes a **Whodunit**. So Michael, the lead character in our story, was doing well in life until one day somebody gave him a case to represent this Stormy Daniels Chick, a Porn Star whom reportedly was threatened after having sexual relations with a then famous Presidential Candidate that became our 45th President. Apparently no one else wanted to touch that case, but our hero Attorney who is not afraid to also represent The Strays of Society, took on the challenge and yes, the case didn’t go anywhere because a beloved sitting President had the power and the favor of The Justice Department at the time. And this was also a time where The Public don’t get to see what’s happening politically in the background because when you’re a Leader and might want an Upstart trying to dethrone you off The Scene, you don’t need to say much since people already know. Everybody on The Circuit got the mental note, so a plot ensued. And a handful of people from his past inter-played with the present in a way where certain events led up to his current legal dilemma because nothing about it is coincidental. Now the Nike Attorney Scott Wilson described his part of the experience with Avenatti as \_\_The Twilight Zon\_\_e and that’s interesting when you look at this whole thing because that’s a clue. When you start looking hard enough, it all makes sense. Almost all the characters involved in any part of his legal troubles were in his life at one point. And this character knows that character. And because one couldn’t directly defeat him or was too cowardly to face him, a group decided to work together with a new character involved to take him down. Do you see where I’m going with this? Prior to him Representing Stormy Daniels, you should want to know **WHO** was the person he decided to help get justice for, that got his name all up in the local papers and on the news out there in California several years ago? The Paraplegic Man, Geoffrey Johnson that’s right? Why is that case so important? Well, people overlook it. They just dismiss it as some homeless Veteran guy who was falsely accused of a crime and he ended up in the LA County jail where he was terribly abused by other inmates and to escape it, he reportedly leaped out a window and wound up paraplegic and labeled mentally-ill. And Avenatti was able to win his case against The Justice System there with a Settlement for him **(and incidentally that same year other paraplegics also won various settlements from The Government)**. And many people stop there and jump to the part of the tale where they believe that Avenatti embezzled his client’s money ignoring his answer to that accusation, but what people need to think about is how odd this whole thing is. And did you even follow what I just said? Yeah the part about, Avenatti locally being in The Press on this particular case back then. And now, this same Paraplegic Man is in the picture currently amongst others opposed to Avenatti. What happened? A series of events. It’s what we don’t hear about that should concern you. And when you go digging, you might find an answer. Stop trying to look at this Lawyer as if he’s a die-hard Criminal and start looking at what’s really going on. Things like this don’t just happen out of the blue like that. Now let’s get back to that old case and what went down. You see, at the time there was this Sheriff in town name Leroy Baca, and he looks kind of like Rudy Giuliani. In fact, he Rudy and Arnold Schwarzeneggar often met to discuss The Judicial System out there in California. So alot of people liked this Sheriff on the surface, but underneath, all kinds of ugly truths came out about how he ran The Prison out there. And you what? It sparked an investigation from The ACLU and others, but he was still holding on to his job while dealing with those pending lawsuits until one day, this Attorney popped up with a paraplegic man he was representing and the added pressure from that case tipped the scale that year where Sheriff Lee Baca decided to step down from his long standing position he held since the late 1990s **(he had been building his career since mid 1960s)** because of the subsequent FBI **probe** into his prison. Do you know how deeply hurt he must have felt? He prided himself on that job. A lot of people still liked him though even though he was accused of allowing monstrous atrocities happening in the prisons at his direction and under his watch. A lot of people knew and liked him, and a fundraiser was setup for his legal benefit and one of the attendees behind it was Attorney Mark Geragos, yes the same guy a few years later when Avenatti said he wanted his help to conduct a “probe” on Nike. The term must have rang a distant bell in his mind to tag along. Remember he was involved and there with Michael at Nike, but never got charged for his role in it. When you’re in The Justice System as a District Attorney, or other Prosecutor, you would know or know of all the other people in your league. And sometimes the same Prosecutor will end up on cases that a Defense Attorney he once battled is on now. So it’s a very small world and a personal keeping score business. So now let’s get back to the current where some shady characters cropped up into the life of Michael Avenatti at this point in time where something that looked like another typical case, turned out to be his demise. Now you tell me, don’t you think that his whole legal battle with former employees at his Law Firm Jason Frank, Scott Sims, and Andrew Stolper has some bearing in connection to his cases. The signs are there. You only need to do the research. I don’t know why some of the other publications are failing to draw the connection. This is big news. So one of The Prosecutors on Avenatti’s California case, Brett Sagel is a known friend of Andrew Stolper who himself was once a Prosecutor in the same Office, but later went to Avenatti for a job where at some point, a disagreement happened and he was terminated by Avenatti. Andrew Stolper left with Scott Sims and Jason Frank to form their own law firm, but the severance was not exactly clean. Over the years Jason Frank would fight in Court against Avenatti insisting that he was owed money, and the sum increased well into the millions each time. Mind you, when they were all employed by Avenatti, they too were Attorneys involved in that paraplegic man’s case except for Andrew Stolper, who chose to represent one of the accused Cops under federal investigation concerning the Sheriff Lee Baca probe. You see, old bonds are hard to break. Fast forward to where we are now, again the same Players in a corrupt system. Oh, and you should note that Brandon Fox and Nicola Hanna were also involved in Prosecuting Sheriff Lee Baca at the time. And those same Prosecutors ended up **now** trying Avenatti. So how is a fairly innocent Defendant supposed to make the much needed headway in that Court System amidst a lack of checks and balances to ensure a proper judicial process. Why isn’t a Prosecutor with all that questionable back-story and emotional attachment, recusing himself from his position? A similar thing happened in New York as well with those Prosecutors. They all know each other. When someone previously worked in a department like Attorney Scott Wilson did, knowing who to contact and when and can access this person at will without any formality involved, then as a Lawyer for a big Corporation, you can call that Prosecutor at any time and legally jam up somebody on some orchestrated charge as we saw at Nike, even though Avenatti wasn’t arrested after that meeting since there was nothing apparently criminal about it, but that same Lawyer felt he needed to place a call to Avenatti inciting a conversation, baiting him, where it eventually resulted in an arrest. And no where at anytime did that young Lawyer state he felt Avenatti was trying to extort his Corporate Client while he was under the direction of Prosecutors. Now how is this Country better than some places in the world you claim you’re better than? At least in those places, Avenatti would have been respected better where they probably would have just played around with him a bit psychologically alluding to a charge, but then let him go. He would then know to stop doing something or go about it differently. So let me get back to this ex-Sheriff Lee Baca thing and continue expressing why I think that ties together somehow with Avenatti’s problems. It never dawned on me before because there was absolutely no reason to even know about him. It only occurred to me recently following the case a certain way and because I’m inclined to notice certain things and be an Empath, I picked up on a quirk and it seems that the symbolism all makes sense in context, complete with all The Players that would be behind it. This is why instincts are good to have and why I felt Michael Avenatti is a decent soul who just got setup. And some of you in The Public may believe what you like in The Media Narrative since you’re gullible and buy anything anyone tells you without exercising due diligence, but for the rest of you, believe this, when you see patterns, shadiness in something or just have that gut feeling, don’t dismiss it. So what did I find? Well…….if you’re someone powerful in a position to avenge someone you liked who another person brought down, in your own arrogance, or just to note as a private message to that other person, you might purposely encode what you achieved. It may not be obvious to many, but it is potently significant. And only another with a discerning eye and way about them would actually recognize it. So what is it? Well…….I alluded to this mystery the last time to peak your interest and none of you seemed to have figured it out yet because if the code was actually hidden, like a treasure to search for, many of you would go looking deep within the dockets desperately trying to find it, but a Wise Games Man in control of the whole thing would hide such a token well before your very eyes that you ignore the one obvious place it would be. So I’ll give you one more chance to figure it out before I reveal it. And once we let that cat out the bag, it opens more room to explore another strange and darker side I noticed about this case I might tell you some time. It’s just a matter of how to present it because I almost don’t want to share it. For now, I’ll just leave you with a popular quote from Avenatti.

**I’m Used To Litigating Against Incredibly Competent, High-Quality Lawyers That Are Very Good Chess Players ~ Michael Avenatti**

It was important for his Attorneys to vigorously fight that case because he represented The American People. Him being exonerated would have meant that our government can’t just bring trumped up charges against someone and use a corrupt system to make it stick. Now, Defendants in similar high profile cases are in jeopardy due to the same scenario. That’s why they could raid a Legal Icon like Rudy Giuliani the other day, and his Attorney son Andrew Giuliani (Little Rudy) was out there admonishing The Judicial System. This is why you Republicans might not see Trump make it as your Leader again because now that your Opposition is in Power and saw how it all works, it is far too tempting to use the same legal science to bind up Donald Trump and send him way into the same torturous prison system that Avenatti was made to endure. When you put your differences aside and fight for your common Constitutional rights, you can ensure that some day when a greater threat should come upon you in the land, atleast a former foe has your back because you’re all Americans. Michael Avenatti currently awaits sentencing in New York over that Nike case. And it’s not fair that he was convicted in that trial if you actually followed the case. He didn’t deserve to get arrested over it or end up in prison suffering harsh conditions in the first place. All that just shows how untrustworthy your system is. How you mistreat those among you that worked very hard from humble means to acquire an esteemed position, while you lovingly take under your wing the most foul & lowly among you and wonder why the rest of the world don’t respect you because on the one hand you favor this one with the worse case, but condemned the other who had a much less offense simply because you don’t like the person despite how wrong it looks on The World Stage. You’re the only nation with an excessive prison population due to minor offenses when other Countries look for every reason not to put a person behind bars, but employ a more effective legal remedy. There are other places on the globe much older than The United States of America where even this country had to stoop at the foot of The Masters and learn from their Judicial System. Too bad as a nation you dropped out of school early trying to gain your independence from Britain before you could fully grasp the value of proper Jurisprudence. It’s no wonder why it all sounds so strange to you in Court when thoroughly educated Defense Attorneys are explaining it to you.

Sign,  
Lhisa Mrklon  
Critical Legal Theorist

### Was Michael Avenatti Setup? Scroll Down And Leave Your Reply Below.

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192950193/ujAwD99oY.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192952211/3J0EpiFbH.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192953442/4jEi9vZyp.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192954724/59Dv-myK9.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192956011/IVyO1Tp6I.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192957374/EW5eRVyvR.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192958968/yNgAKoqac.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192960619/zCQZRQM3u.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192962194/8gVKWCVg8.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192963323/bxTrRqCm-.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192964341/5OjgdqFyZ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192965636/PsgvC13dI.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192967274/VZwfzcMdc.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192968855/YAUt_4ksp.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192970534/CEHwwuP5u.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192972331/XSWejt58k.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192973904/lFaKjnmWt.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192975149/pHnFiRsXw.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192976485/KDO-i7IiC.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192977733/Ycao_NuDS.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192978910/8zTs58sj_.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192979971/dmC0UcPh5.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192981405/Rlqp9iJpw.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192982525/RXv2sLc_j.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192983905/JxdGyrntK.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192985453/NFhCutf6R.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192986766/VXPLxxnvC.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192988322/WFRchw0US.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192989639/Cf6DSD4a0.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192991007/W2S6nD-d5.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192992615/Q7vbEDc8G.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192994213/lYqDDu3om.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192995633/cubKmLGiP.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192996950/vS4PMaF7M.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192998583/50NM0b3JD.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192999720/xk_tebFmV.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193000843/7-k38vzgP.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193002080/vQslpYm08.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193003502/sHYOIrkzJ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193004668/W_SjmZ5Pr.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193005904/yzrvCEm5k.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193007212/Y0MU74XsN.jpeg align="left")

SHOP ITEMS ON SALE  

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193009188/zXCah6T47.jpeg align="left")](https://lightinthebox.tv2h87.net/c/3170166/898314/8199?prodsku=5682229&u=https%3A%2F%2Fwww.lightinthebox.com%2Fmen-s-oxfords-spring-fall-comfort-casual-low-heel-lace-up-walking_p5682229.html&intsrc=PUI2_7096)
