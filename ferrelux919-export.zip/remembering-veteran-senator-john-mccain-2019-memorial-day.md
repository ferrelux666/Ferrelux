---
title: "Remembering Veteran Senator John McCain (2019 Memorial Day) \U0001F6F3\U0001F488\U0001FA82"
date: '2019-05-26T18:41:48.000Z'
slug: remembering-veteran-senator-john-mccain-2019-memorial-day
tags:
  - trump
  - war
  - uncategorized
  - politics
  - america
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195056138/72APLPtET.png
canonical: 'https://ferrelux666.wordpress.com/2019/05/26/mccain/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195032495/Ht7G7BFir1.jpeg align="left")](https://www.ferrelux.us/)

Soldier Track – [Metallica’s ‘One’](https://myspace.com/metallica/music/song/one-1749850-51924507?play=1)

*Dulce Bellum Inexpertis*  🛳  *War Is Sweet To The Inexperienced*

Even after his death battling cancer, our current President, can’t help but take a dig every now and then at deceased American war hero and Senator, John McCain. So what’s the problem here? What did he do? Oh, he got captured. Well doesn’t that happen sometimes. Trump was from the 80s, didn’t the ‘Missing In Action 2’ Star Chuck Norris, playing Colonel Braddock get caught by Colonel Yin in Vietnam and by the end of the movie we see him and his small band of American soldiers battle their way out. And what about Rambo? Look man, you’ve gotta separate fantasy from reality. He’s not Rambo or Braddock doing the kung-fu or using a large machine gun that does not run out of ammo. That’s the real problem here. Trump was never in a real army on a real battle field to realize how that really goes, to be attacking John McCain. It’s easy to criticize. The man endured torture. Eventually his Asian captors realized he was the son of somebody famous during the prisoner negotiation process and began treating him better. They offered to release him first, but John insisted on the lesser privileged soldiers caught with him be let go first. That showed Leadership. I’m sure if it was Trump or his sons, not only would they have been captured too, but they would have insisted on the caviar treatment. After returning to the states, it could have just ended there with the recovery process and a little footnote in history, but he decided to serve his country more by becoming a Politician. Again, he tries to be fair when making political decisions. He ran for President a few times without winning. His most famous run, against Barack Obama where he silenced a racist woman in the audience likening Barack Hussein Obama to a Middle Eastern terrorist. When Obama won, he wasn’t out there carrying on like a fool in the Senate against him, he was busy being a Maverick Republican. But who did we see riling up the masses? It was YOU Mr. Trump. And you finally brought down the prestige of the Oval Office to the level of Reality TV. OH MY! Leave this dead man alone, stop bringing him up in the news taking swipes at Meghan McCain from time to time. He didn’t vote the way you wanted him to in the Senate, or he held out too long and whatever, leave it be. While on his death bed fighting cancer, you could not let it go still. That made him look good to some un-deciders. He’s probably beyond the grave laughing at you. He’s still remembered as an American war hero given the full burial rights despite what you think. As a sitting President, you shouldn’t be saying anything negative. I don’t know why you’re complaining about money you or the government spent in burying him or what favor you think his family owes you. There is a certain decorum expected of a man in your position. Now, I’ll leave the rest of the commentaries to his daughter Meghan McCain and his widow Cindy McCain as they are currently braving Trump attacks from time to time while grieving.

Lhisa Mrklon,  
Special Agent 666

[![Ferrelux Homepage_McCain-2019MemorialDay](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195034455/cqsqNuKm8.png align="left")](https://ferrelux666.wordpress.com/ferrelux-homepage_mccain-2019memorialday/)

[![McCain0](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195036912/HkSEQAO-u.png align="left")](https://ferrelux666.wordpress.com/mccain0/)

[![McCain1](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195038468/8MzZriBGFd.png align="left")](https://ferrelux666.wordpress.com/mccain1/)

[![McCain2](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195040145/Lfud9z_PZ.png align="left")](https://ferrelux666.wordpress.com/mccain2/)

[![McCain3](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195041961/bZ65tgkD0.png align="left")](https://ferrelux666.wordpress.com/mccain3/)

[![McCain4](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195043616/_rww5KHS6.png align="left")](https://ferrelux666.wordpress.com/mccain4/)

[![McCain9](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195045351/oE4_hfp8u.png align="left")](https://ferrelux666.wordpress.com/mccain9/)

[![McCain8](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195046729/9jWbv8RKu.png align="left")](https://ferrelux666.wordpress.com/mccain8/)

[![McCain7](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195048622/4QTxQVq0p.png align="left")](https://ferrelux666.wordpress.com/mccain7/)

[![McCain6](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195049860/fd-Iop3ob.png align="left")](https://ferrelux666.wordpress.com/mccain6/)

[![McCain5](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195051151/ILgN29cbf.png align="left")](https://ferrelux666.wordpress.com/mccain5/)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195053418/iWXW2J-0L.png align="left")](https://ferrelux.com/adverts/)
