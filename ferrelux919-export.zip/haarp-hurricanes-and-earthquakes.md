---
title: "HAARP Hurricanes & Earthquakes \U0001F30F\U0001F5FB"
date: '2017-09-26T16:09:24.000Z'
slug: haarp-hurricanes-and-earthquakes
tags:
  - texas
  - hurricane
  - tragedy
  - mexico
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195709052/wg73Hqhgp.png
canonical: 'https://ferrelux666.wordpress.com/2017/09/26/haarp-technology/'
---
\*\*

[![HAARP Tech](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195703226/czYoFpkM7.jpeg align="left")](https://www.dailymotion.com/video/xk79lu)

Laudem Virtutis Necessitati Damus 💦 We Give Necessity The Praise Of Virtue *(Quintilian)*\*\*

\*\*  
DISASTER RELIEF FUNDS\*\*

[**Red Cross**](https://www.redcross.org/donate/disaster-relief?scode=RSG00000E017&gclid=Cj0KCQjw9afOBRDWARIsAJW4nvzYFgx04iY8zlapblFfL_vfv9lUVkc64Y_K9q8fKpFfBcxfd3cLY20aAp__EALw_wcB&gclsrc=aw.ds&dclid=CPbh08Glw9YCFay5swod2AYCtA)[**Unicef**](https://www.unicefusa.org/donate/support-hurricane-matthew-relief-efforts/30966?utm_campaign=2016_misc&utm_medium=cpc&utm_source=20160107_google&utm_content=matthew&ms=cpc_dig_2016_misc_20160107_google_matthew&initialms=cpc_dig_2016_misc_20160107_google_matthew&gclid=Cj0KCQjw9afOBRDWARIsAJW4nvxbxrcRQSsCJcmm0hgVvb1f0J5DCpfvez1FVwH-pOInc5fcJfz2ZKMaAuziEALw_wcB)[**All Hands Volunteers**](https://give.hands.org/give/145160/#!/donation/checkout?amount=60&recurring=4)[**Global Giving**](https://www.globalgiving.org/projects/hurricane-harvey-relief-fund/?rf=twtr)

\*\*  
NOW FOR THE CONTROVERSIAL\*\*

**With the recent 2017 hurricanes destroying Puerto Rico & the Mexican Earthquake, people are speculating again that it must be HAARP technology since the American government can create storms & earthquakes & project them where they like using their machine. If that’s true, notice the places being attacked. We have a current U.S. President that don’t like Hispanics** *(even though his wife can pass for one given her fine ethnic looking features)* **& now all of a sudden 2 Spanish countries have huge “natural” disasters wiping them out. Whatever you believe, we’ve heard these arguments before with past isolated destructions & many of them are still valid since the technology exist. The weather patterns of a natural real storm makes more sense than, the one that strike all of a sudden like a weapon without a proper propagation one can see coming.**

\*\*One Thought On It  
\*\*

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/SDDPyZKfSYA?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

**A Top Scientist Speaks**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/viMH3K2xmpI?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

**Here’s Another Opinion On That**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/xMdO39b4Lqo?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195704866/wi8rf5xvL.png align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195706271/lZUE4EMw9.png align="left")](https://ferrelux.com/adverts/)
