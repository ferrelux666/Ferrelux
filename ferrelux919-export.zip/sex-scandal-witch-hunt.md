---
title: "Sex Scandal Witch Hunt \U0001F459\U0001FA72\U0001F3E8"
date: '2017-12-05T18:49:47.000Z'
slug: sex-scandal-witch-hunt
tags:
  - jobs
  - women
  - money
  - uncategorized
  - crime
  - politics
  - hollywood
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195655267/pq2xosjuC.png
canonical: 'https://ferrelux666.wordpress.com/2017/12/05/sex-scandals-2017/'
---
[![42nd Street Blinking Sign](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195648400/mtNElZE2R.jpeg align="left")](https://www.christianpost.com/news/2017-the-year-of-the-sex-scandals.html)

\*\*  
Genus Est Mortis Male Vivere 🥺 To Live An Evil Life Is A Type Of Death *(Ovid)*\*\*

\*\*  
WOW! 2017 has been a whopping year for the witch hunt against the sexist chauvinistic males in Hollywood & Politics. The workplace has always been a place for that, but what’s not being aggressively discussed is the bitchiness amongst women that makes them a target for sex abuse. I appreciate the all of a sudden support for the women who suffered in these national sexual harassment situations, BUT these cases usually happen when women fail to like each other in the workplace. They make it easy for men. This part of the problem isn’t being discussed as it should. In a typical scenario, when you have a bunch of bitches on a typical corporate job, the older bitch sees the younger bitch trying to come up in the world & this bothers her, so she tries to make trouble for her because she wants to be still seen by the Executives as relevant, but she has been in this hostile work environment with these sexist men for decades though while other women left. How was she able to retain her job? Well, she sacrificed dignity & respect for it. You see, some women are very comfortable turning tricks in the workplace. And you can tell who they are. If YOU are not doing it & this older bitch keeps trying to make trouble for you consistently, don’t assume that she fears losing her job to them provoking you out of the blue, the real problem here is that she is jealous & offended at you being there, the younger & more attractive competent female the guys in the place are talking about or passing your cubicle unnecessarily to look at. It makes her blood broil. She’s been there comfortably working there quietly being a ‘working girl’ under the guys of appearing as a decent corporate woman, who is now being neglected because they’re tired of her & no longer get excited over her & to desperately retain the coveted status as the private sex toy in the office, she has to mentally operate like a street corner prostitute & get you off that block. When the men see her craziness, they realize she really wants this & make her work for it. They’ll up play their interest in the other lady in the office, maybe one or two of them oblige, but the rest don’t. Her crazy ass keeps fighting with who she feels threatened by, instead of appreciating the scorn. So she works & works & works at it until they relent. It has nothing to do with the actual employment. It has everything to do with the trinkets, handouts, & favors of these men. And now, she’s the center of attention again with her old ass because in her psyche, she cannot lose the position. Why isn’t that scenario being discussed in Hollywood or on these political TV talk shows? Is it because it might shame women? LOOK, not all women are complaining. That’s why they can whip their dick out & do ’em, it’s a part of the job. Both of them have consented to it. The mistake these men make is trying to do it with the wrong woman in there. You only live your crazy lifestyle with the pool of people into that shit. That’s why they got in trouble. The men not getting in trouble are the ones doing it correctly with their own private sex circle & they keep the people involved happy.\*\*

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195649498/ldl6osHpQ.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195650771/u0foRWTDN.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195652045/aDHsVs1Pb.jpeg align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195653396/Yy4PrmpKr.jpeg align="left")](https://ferrelux.com/adverts/)
