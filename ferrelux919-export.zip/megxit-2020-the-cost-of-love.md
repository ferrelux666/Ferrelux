---
title: "MEGXIT 2020: The Cost Of Love \U0001F37D\U0001F495⚔"
date: '2020-02-27T20:52:59.000Z'
slug: megxit-2020-the-cost-of-love
tags:
  - interview
  - news
  - break
  - toronto
  - canada
  - class
  - travel
  - intel
  - society
  - walmart
  - camera
  - wedding
  - love
  - crash
  - marriage
  - reporter
  - california
  - journalist
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672194314281/--LqtZ_ba.jpeg
canonical: 'https://ferrelux666.wordpress.com/2020/02/27/megxit/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194293910/7nyCzddib.jpeg align="left")](https://www.ferrelux.us/)

[**“Situation” (Move Out) – Yazoo, From Their Album, Upstairs At Eric’s**](https://www.youtube.com/watch?v=49Me9xPEJX0)

*Non Mihi, Non Tibi, Sed Nobis* ✈ *Not For Me, Not For You, But For Us Both*

Another STRIKING story this New Year came from the Duke & Duchess of Sussex, Harry and Meghan deciding to step down from royal duties for a simpler regal life and were willing to sacrifice their royal place for it. Now how this was supposed to go is like this…….. The Queen & the rest of royal society agreed at 33 years old, it’s a significant time for Harry to find someone to marry. So for the sake of their Society they allowed him to wed one not quite to their royal liking for his heart’s sake. So they prompt her, train her a little to fit in, the wedding went well, & now she’s supposed to fall in line with the quaint protocol & not cause a stir. Well, if she was a Black British Woman, THAT may have worked since she would already have the breeding & seasoning, but Harry got with an American he met in Toronto, Canada. She already has a certain lifestyle & mindset different from The English. Our Beloved deceased Princess Diana had a similar problem, but she was English. Her personality was a bit different & she described the rest of the royals apart from her children as “cold” and other creepy language in interviews. If you follow any of the stuff Conspiracy Theorist, David Icke used to expose back in the day and now, then you know about The Reptilian stuff. Well, maybe Little Meghan Sparkle got a little too curious, snooped around like ‘Alice In Wonderland’ & saw something that frightened her. Not everyone can handle certain things; they can’t vet you for that. Now, seeing Reptilian humanoids shapeshift out of human form, walking about freely in the flesh would not have bothered ME. In that interview on the lawn she gave BEFORE Megxit, she looked scared complaining in skittish words how difficult that life is, being under scrutiny. Hmmm, many people just being ordinary Americans are under major scrutiny & surveillance all the time, let alone a Celebrity. You’re supposed to have a way of handling it. The rivalry with Kate Middleton is not enough to leave. If it was racial stuff with snide chatter about the palace, she passed certain lines already not to let that affect her. So no Meghan, YOU’RE leaving because of something else. Something you can’t talk about publicly. As we watch them further, maybe that’ll get out somehow. Till then, we’re left with gossip & speculations. On one side, people are blaming Meghan Markle for the split. Her own father went on air in an interview talking how the royal standards they inherited need to be maintained and how they cheapened the royal legacy, and “…..It’s like Walmart with a Crown…..” Now, alot of what he meant was the first thing I thought of, when I heard their split from the Royal Crown. And I’ve been watching their moves from the Courtship of Meghan, to the wedding and birth of Archie, to the move from the luxury apartment to the millions spent upgrading Frogmore House, to now. Though I’m supportive of them, I don’t like it. When you have a royal place, with titles & everything, it needs to be honored. You don’t play around with it or try to escape it. I get that there are some difficulties involved with the expected duties. Prince Harry missed his own son’s birth because of some pre-scheduled meeting he had overseas I guess he had to attend. And there were some rumors about, that Prince William was keeping him occupied with his own duties he dropped on him, so he doesn’t have much time for Meghan. And Harry is 6th or 7th in line for the throne, so being that heavily involved in working for The Queen is not that necessary. Being a young newly wed with one child right now, Harry & Meghan would like to enjoy their idea of a better life. All the signs were there from the beginning that there would be issues. She’s a mixed Black female on the lighter side, not of British birth, and a divorcé. Okay, but it could still work right? Well, what if she has a problem adjusting. You just don’t learn centuries of royal history, the British mindset, English customs & ways in a year. Kate Middleton already had that. She was more of a real person before her transformation into The Duchess of Cambridge, so you can’t do certain things anymore or behave like you use to. Getting that perfect mannequin look and stoic character down packed is crucial. You shouldn’t be animated, charming or too likeable. Our late Princess Diana being from there had those challenges too and did the best she could trying to balance what was expected of her with who she really was. It IS frustrating. In the interview on the lawn Meghan admitted she didn’t know what she was getting into & a friend was trying to warn her. Now she didn’t need to date Harry. She could have kept her lying on a California beach in her flip flops lifestyle with anybody else. When you connect with Upper Class Persons, Nobles, & Royals moving among them, YOUR status changes as well. You don’t eat or hangout in the same places anymore. Your ties with them needs to be minded a certain way because you are of a Class. I know media personality Piers Morgan blames Meghan because Harry would never have done this if it wasn’t for her controlling the situation. BUT WAIT, on the other side, people are saying Harry is responsible. He’s been waiting to break away & have been hatching a plan, but just needed the right person to do it with. Now they’re out there trying to get a job. The Queen told Harry publicly if things get hard, he can always return home. Like I said, I don’t think they should be out there like that, away from his real protections. You’re still a Royal Prince the leeches are going to follow around like they did your mother, especially NOW. Diana tried stepping away from royal duties too, and you made a similar speech she gave, but it didn’t work for her, even when she traveled abroad. When she divorced and was free to live her life, no longer a royal, the press still cared enough to furiously drive after her in a tunnel killing her. So young man, I pray & hope you know what you are doing.

\*\*[Videos On Megxit](https://www.youtube.com/results?search_query=megxit)  
[Articles on Megxit](https://www.google.com/search?source=hp&ei=-S9YXsb_AviwytMPh_2NyAM&q=megxit&oq=megxit&gs_l=psy-ab.3..0l2j0i131j0l7.2880.5490..6042...0.0..0.194.678.4j3......0....1..gws-wiz.....6..0i362i308i154i357.S3IriyCO8XY&ved=0ahUKEwiG4IeQ0vLnAhV4mHIEHYd-AzkQ4dUDCAs&uact=5#spf=1582848491697)  
\*\*

Sign,  
Lhisa

### Was Meghan & Harry Right To Disrespect The Royal Family Like That? Scroll Down And Leave Your Reply Below.

[![The Royal Split Meme](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194295231/x-SBlLEDZ.jpeg align="left")](https://ferrelux666.wordpress.com/the-royal-split-meme/)

[![Prince Charles Supports Harry & Meghan](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194296405/-rS1h9Vpu6.jpeg align="left")](https://ferrelux666.wordpress.com/prince-charles-supports-harry-meghan/)

[![Meghan's Megxit](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194297784/A_9elVtBE.jpeg align="left")](https://ferrelux666.wordpress.com/meghans-megxit/)

[![Meghan & Harry and their Son Archie](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194299093/H7hrqxn1k.jpeg align="left")](https://ferrelux666.wordpress.com/meghan-harry-and-their-son-archie/)

[![Leaving The Queen Without Telling](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194300621/NUpApErRz.png align="left")](https://ferrelux666.wordpress.com/leaving-the-queen-without-telling/)

[![The Royal Cost](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194302688/H8Ixpod3m.png align="left")](https://ferrelux666.wordpress.com/the-royal-cost/)

[![The Queen Disappointed In Harry's Megxit Meme](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194304099/JNDga6xyE.jpeg align="left")](https://ferrelux666.wordpress.com/the-queen-disappointed-in-harrys-megxit-meme/)

[![Royal Family Births](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194305114/AaCZoABx-.jpeg align="left")](https://ferrelux666.wordpress.com/royal-family-births/)

[![Prince Charles Will Fund Megxit](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194307028/7yvezaAkL.png align="left")](https://ferrelux666.wordpress.com/prince-charles-will-fund-megxit/)

[![Kate Vs Meghan Meme](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194309615/Y6CydWDGP.png align="left")](https://ferrelux666.wordpress.com/kate-vs-meghan-meme/)

[![Ferrelux Homepage_Megxit2020](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194311028/c0eK2leVe.png align="left")](https://ferrelux666.wordpress.com/2020/12/24/goodbye-2020/ferrelux-homepage_megxit2020/)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194312603/plPvSgfk3.jpeg align="left")](https://ferrelux.com/adverts/)
