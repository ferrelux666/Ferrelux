---
title: "\U0001F5F3️ 11 More Key Topics For Fall 2022 \U0001F342"
date: '2022-11-12T01:55:26.000Z'
slug: 11-more-key-topics-for-fall-2022
tags:
  - twitter
  - news
  - trump
  - social-media
  - online
  - riot
  - elon-musk
  - war
  - vote
  - crime
  - florida
  - election
  - ukraine
  - topics
  - putin
  - basketball
  - '2022'
  - america
  - russia
  - voting
  - washington
  - arizona
  - new-york
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672204251150/e72e95a3-17b6-4506-9434-88b1af26b059.jpeg
canonical: 'https://ferrelux666.wordpress.com/2022/11/11/more-fall-2022-topics/'
---
[![Veterans Day 2022](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191377678/WxkCl3DOj.jpeg align="left")](https://odysee.com/@theandressegovia:d/a-veterans-day-reflection:6)

[**The Doors ~ The Unknown Soldier**](https://odysee.com/@AVisionDarkly:b/Doorssoldier:8)

*Res Rusticae 🌎 Country Matters*

**\_*Hey Folks, as the year comes to a close, we’re still seeing unresolved topics and as you know this year I came under Big Tech attack still targeting my constitutional rights to live and operate as I do because in a so-called free country we really have no rights, especially if you are a person of Color.*\_**

**Veterans Day 2022**

It is very important each year to reflect on the freedoms we currently have and the sacrifice it took.

**The New Black Panther Movie**

I was looking forward to the part 2 of this movie, ofcourse with Chadwick Boseman still alive acting in it AS Black Panther. And because he is no longer among us, it dampened my anticipation. And now that the new movie is out, my interest is still low due to Covid-19 messing everything up before with the restrictions where now I can’t really enjoy **\_*the experience*\_** as I did before the pandemic. I’ll get around to doing a review of the film some time. I urge people to go see it.

**The 2022 Midterm Elections**

So they are still counting some of these votes and it’s just over a week after. I was expecting Dr. Oz to win though. When Oz first entered the race, I thought, what is he doing? Politics is not your place, nor is it a good look for you. But then I looked and listened to his opponent, Mr. Fetterman, and over that period of time, I realized that Oz was the stronger Candidate, however people held on to their doubts about him. Now moving right along, out in Georgia, I was expecting Stacey Abrams to hold on to her seat, and Black Men are being blamed for her loss which is interesting because I only heard about Stacey Abrams, I still don’t know off the top of my head who won. And if Black Men voted for that White guy, we’ll see how that turns out. Now here in New York, I had to give my vote to Kathy Hochul, even though I did not plan to, due to the whole Cuomo scandal. I saw young Andrew Giuliani throw his hat into the ring to run for Governor, and I didn’t know who the other Candidates were on The Republican side, then as time went on, all of a sudden, this Lee Zeldin guy popped up taking the lead. With the headway he made across the tide of the current politics, his potential win was drawing close. Had it been a Republican Candidate I actually liked and he was saying and doing all the right things and could win, I wouldn’t mind it if it was right for New York. But something about that Zeldin guy, his face, that zeal in his eyes, what he was saying, the way he got around the city, was telling me look, this guy has an agenda that is not cool. And it looks bad for this woman to NOW just get beat like that. And Cuomo chose her as his Lieutenant, so voting to help her, **in a way** was voting for Cuomo. With Womens Rights at risk here and in the Country, a woman should be the face of the fight.

**Kari Lake**

I had to give this woman her own section for discussion because I like her. I’ve been watching her campaign progress and was impressed by it. So I don’t believe the reports I’m seeing that she lost her bid for governorship of Arizona to Katie Hobbs. I don’t think these Candidates are losing because of Trump being “toxic”. During the time, he’s been handling and “winning” his legal cases. Almost everybody he’s been backing WON their Office **or right** to be the lead Candidate well before The Election. **\_*Something*\_** went wrong though, because I was expecting some kind of red wave happening in certain states. I expected Kari to win Arizona. She’s been handling herself well. Because I like her, I didn’t say anything critical though I don’t totally agree with everything she says. If I were to be obtuse and come at her for The Democrats, I know just how I would go about attacking her position using clever political strategies. But she’s my girl right now. She reminds me so much of the female version of an animated character I grew up watching on TV that if I were to say who it was, people would see what I mean. And this is not an insult to her at all, infact it’s a compliment because I really liked him in the 1970s cartoon series. With the way Kari looked and acted, the facial expressions, the hair, the outfits, the accusatory tone, the quick comebacks, re-evaluating reality, gaining support for the agenda, popping up here and there wreaking amusing Republican havoc and laughing, and going all the way to a win, I figured the only way The Democrats might stop her, is to some how trick her into saying her name backwards, Ekal Irak. It’s a joke ofcourse, but meant to be a metaphor. That Mxyzptlk character in **The Superfriends**, was no joke. He was effective and clearly won those episodes, that only a quirk like that could undo his power and make him disappear right back to the 5th dimension . . . . . for a while.

**Snubbing Mike Pence**

Another person to give a separate section to for discussion **IS** our Ex Vice President Mike Pence. When Trump was President, I expected him to go on for another 4 years but Joe Biden won and Pence accepted that. And then that January 6th Insurrection happened which further caused a divide between him and Pence, whom the rioting Protesters blamed for not using his power to block Biden from taking Leadership. If he had the power and chose not to help Trump, at the time it was his prerogative. He’s a Christian weighing carefully in his mind, heart and soul decisions impacting the Country. And yes, it looked like a betrayal to some people, but abusing power is a betrayal also to a Democracy. So with Trump out there campaigning again and making strides, he got entangled by The NY Attorney General Letitia James trying to bind him so he can’t run again. But before all that, I was expecting Mike Pence to run for President due to his unique position now, but since I didn’t see any strong signs of that, I figured okay, maybe Mike Pompeo who has been conducting himself well with the public statements and commentaries and so forth, showing presidential qualities. Atleast he was my pick, but the GOP having seemingly turned on Trump, is showing interest in Florida Governor Ron DeSantis, but is he ready? Does he have enough experience? Can he handle it?

**Russia Detaining Brittney Griner**

It’s a pity that she went through Customs with that cannabis oil. If she did it in the past without issue in Russia, then she got held this time due to politics. Now she’s a bargaining chip. It’s interesting to note that before that incident, she had fond memories of Russia. She trained and played there and spoke positively about the place. So it’s sad to see that she got caught up in the current political hostilities. Her problem seems to be a petty one to overlook. Now due to sanctions against Russia in support of Ukraine, America has to consider releasing 2 Russian Political Prisoners in exchange for her and Paul Whelan, and the current negotiations aren’t going anywhere.

**Russia Vs Ukraine**

Before the conflict, things were cool between them until Ukraine made a mistake hiring the wrong President. When I first heard about the outbreak of war, I was hesitant to put up the Ukraine colors or commentary about it dressing the website up with the prevailing politics, like so many other persons & companies because I took issue with the facts. First of all, I keep seeing signs of a global conspiracy led by secret societies, and things that I am doing online is being noticed in such a way that I take offense to the misconceptions and timing of things. You see, I know what **something** is and why I used it, but THEY aren’t as Enlightened.

**Firing Tiffany Cross**

This poor young woman, lost her show, **The Cross Connection**. The person instrumental in getting her fired was Tucker Carlson, after he aired a piece on her. Tucker is an asshole to be calling her the most racist person on TV, when in that news broadcast world, everyone being honest knows it’s him. Now, I like Tucker . . . . **sometimes** . . . . I agree with him on stuff, and other times, he’s making commentary that’s inflammatory spewing hate and he thinks it’s funny. Now this Tiffany gal was a healthy balance to that and they went and canceled her beautiful show. It’s an illustration of the type of reality you find in certain corners of the internet. Where Tucker is being real with the White perception of things, and Tiffany, is holding it down representing how Black Folk might view that same topic. And there are other Anchors similar to both of them for us to watch, but just getting rid of people like that destabilizes the situation whereas one news person is now without that other person they know is more likely to go off on a topic he or she may shy from, and is now burdened to fill a void to an audience, while on the other Front, that polarizing person has no Challenger to put him or her in check. I’ve been in all kinds of places from the Red Neck Cyber Woods to the Inner City Cyber Jungle, so I appreciate both sides.

**Elon Musk And Twitter**

You’ve been taken over by a foreign power 😯 Think of him like you would in TV Land 🤔 You know, this Military Aristocrat Asian Villain plotting to take control 😟 And now he’s began the next phase of his operation 😧 Ya’ll know me, I’m just being funny. With the transition process happening still, it’s too early to critique his management of it. I still think he overpaid and inherited a overly glorified simplistic platform as opposed to creating from scratch his own substantial masterpiece people would want to be on.

**Inflation 2022**

It’s sad that almost on a daily basis the prices of things continue to go up and up and up. And a great deal of our money is going out of our Country to fund The War In Ukraine. Famine and war goes hand in hand, as well as pestilence and death. And it might not end this year. It is interesting to note how many poor people here find a dollar to spend on lotto, where the jackpot increases to roughly $600 Million for example every year, and that investment goes somewhere, yet we’re still talking about inflation.

**Nancy Pelosi’s Husband Attacked**

When I first heard the report, I took it as it was. A Political Attack! As I kept hearing additional reports about it, I wondered why The Republicans were doubting it and smirking. This was a crime. There was nothing funny about it. So I listened to their arguments and I thought at first Anchor Greg Kelly was trying too hard to initiate suspicion on it, but as the days went by he began making a little more sense with his arguments finding fault with the crime story. And other Journalists took note carrying the arguments away. So now I went back to listening to people who believed an actual crime happened, and collectively they agree with arguments that are also plausible. So now I draw you back to another political attack that happened before that. Remember the raid on Trump? If you believe that was not a staged front to help him politically, then you should at least consider that the attack on Paul Pelosi, though meant for Nancy was real.

**HAPPY 🦃 THANKSGIVING**

\*\*\*\*Sign,\*\*\*\*\*\*\*\*Lhisa Mrklon,  
\*\*\*\****Still, Your All Year Round Pundit***

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191379173/ipeMgCC6GW.jpeg align="left")](https://lightinthebox.tv2h87.net/c/3170166/805530/8199?prodsku=8707638&u=https%3A%2F%2Fwww.lightinthebox.com%2Fmen-s-suit-vest-waistcoat-party-evening-festival-casual-vintage-british-solid-colored-double-breasted-slim-polyester-men-s-suit-black-v-neck_p8707638.html%3Fcurrency%3DUSD&intsrc=PUI2_5801)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191380523/Uie5XQJ71.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191381972/rOSkZVoEh.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191383973/mCGAoNoEX.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191385493/qzGw1JEbH.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191386895/7_r-SVatj.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191389006/78mtfZS8A.jpeg align="left")

U.S. Senator Kamala Harris (D-CA) accepts the Democratic vice presidential nomination during an acceptance speech delivered for the largely virtual 2020 Democratic National Convention from the Chase Center in Wilmington, Delaware, U.S., August 19, 2020. REUTERS/Kevin Lamarque

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191390734/EU_h27XtH.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191392341/FthDsASO4l.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191393648/z4VmSA5m2.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191395352/jIi0jdsfqI.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191397097/vR2TxmjmX.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191399069/Guu0WyP6X.jpeg align="left")

Ukrainian President Volodymyr Zelensky reviews the Slovak guard of honour during a welcome ceremony at the Presidential palace in Bratislava on September 24, 2020, during his two-day official visit in Slovakia. (Photo by VLADIMIR SIMICEK / AFP) (Photo by VLADIMIR SIMICEK/AFP via Getty Images)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191401050/sef7PA1-n.jpeg align="left")

PALM BEACH, FLORIDA – NOVEMBER 08: Former U.S. President Donald Trump speaks during an election night event at Mar-a-Lago on November 08, 2022 in Palm Beach, Florida. Trump addressed his supporters as the nation awaits the results of the midterm elections. (Photo by Joe Raedle/Getty Images)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191402425/XjYwmWSuR.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191403813/N9J5chT__.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191406037/7bTuIHLdm.jpeg align="left")

epaselect epa04382210 Ukrainian tanks drive on a road on the outskirts in the eastern Ukrainian city Slaviansk, Ukraine, 03 September 2014. Russian President Vladimir Putin and Ukrainian President Petro Poroshenko agreed on joint steps to solve the conflict in eastern Ukraine, the offices of both leaders said on 03 September after a telephone conversation between the two. EPA/ROMAN PILIPEY

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191407232/nofeHB8Rr.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191408517/QDmlxGmr0.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191410390/aB4ZUC8St.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191412266/km_IgL1K9.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191413865/9OVK7rPgJ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191415364/kYxVO2YuL.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191416749/az-HikqLm.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191418073/LEB0l0hYQ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191419564/-9iF75cIR.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191421771/kUk40T6VP.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191423353/5YX9VEO-y.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191424730/N8xtblOCH.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191426075/VFRtOrT5S.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191429467/6JBJSCcMG.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191431020/IPt9AlyA4.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191432241/O0NeyVCvz.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191433866/c7-gmIRzY.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191435172/SR02YfAWd.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191437048/01YeQDMb6.jpeg align="left")

WASHINGTON, DC – OCTOBER 18: U.S. House Minority Leader Rep. Nancy Pelosi (D-CA) and her husband Paul Pelosi arrive at the White House for a state dinner October 18, 2016 in Washington, DC. U.S. President Barack Obama is hosting a state dinner for Prime Minister of Italy Matteo Renzi and his wife Agnese Landini. (Photo by Alex Wong/Getty Images)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191441844/hAX1jJ86CF.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191443476/rZsHEehLD.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191445638/rPWxxXnJf.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191447349/ZfqDrIP57.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191448744/BKkY6SaYv.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191450743/dUdCdJUjY.jpeg align="left")

Democratic presidential candidate Hillary Clinton waits to speak to supporters at the Human Rights Campaign Breakfast in Washington, October 3, 2015. REUTERS/Joshua Roberts

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191452184/FgYMWzRbG.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191453700/XBjWiiiD9.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191455088/-Aqd_WG8V.jpeg align="left")

OLYMPUS DIGITAL CAMERA

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191457242/MufGw-_fVr.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191458932/G1ZyvqfLJ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191460622/in8PgY3Wh.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191462454/au-qWXxNX.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191464070/RGWlIo23r.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191465514/3GFLq3J0F0.jpeg align="left")

CHICAGO, ILLINOIS APRIL 25: In this photo illustration, The Twitter profile of Elon Musk with more than 80 million followers in shown on a cell phone on April 25, 2022 in Chicago, Illinois. It was announced today that Twitter has accepted a $44 billion bid from Musk to acquire the company. (Photo Illustration by Scott Olson/Getty Images)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191467026/CbZ2OY0Ko.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191468567/zb6U4_P7j.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191470303/xl96aebk0.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191471558/401GMWO4A.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191472961/U-khxeGGQ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191474496/8q6B3q9Po.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191475963/DpXzCRiQk.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191477702/8E-d5768M.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191478964/48NIifq_9.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191480620/2UJON5QTc.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191481998/YwEMaAXKj.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191483684/jNqGo2Lme.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191490856/3_7v93n-7.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191492440/XtbP01n3P.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1677692260025/12657d79-488e-4fdc-8237-588ae885fab5.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1677692292031/702b0b16-3918-41b5-827f-04769a58d4f8.jpeg align="center")

### Like this:

Like Loading...

### *Related*
