---
title: "⚠Las Vegas Shooting 2017\U0001F4A5"
date: '2017-10-26T18:25:05.000Z'
slug: las-vegas-shooting-2017
tags:
  - music
  - las-vegas
  - festival
  - gun
  - musician
  - death
  - singer
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195684700/pDxBAylOE.png
canonical: 'https://ferrelux666.wordpress.com/2017/10/26/las-vegas-shooting/'
---
\*\*

[![Las Vegas Mass Shooting Vigil 2017](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195677088/SyUBbET5IM.jpeg align="left")](https://www.dailymotion.com/video/x62x5ej)

Nobis Vivimus Mundo Plena Insanus Populus 🤪🥴🤬 We Live In A World Full Of Crazy People\*\*

**Another Infamous Shooting, The Media plays around the tube for answers, asking ‘When Will It Stop?’** **Well, it won’t really. Whether it be some conspiracy terror tactic, or a madman shooting, we live in a** **Country where this sort of thing is becoming the norm now. Why? It’s the culture. You may be the** **‘Greatest Country In The World’ as you put it, but your society needs serious help. Some of the other** **countries around the world are better governed where in their newspapers, you are reading about** **normal levels of crime in a big city, not some privileged weirdo with a massive gun collection that goes** **to a music festival for target practice. Where were the cops & secret agents the government employs to** **protect us? Probably busy watching some normal colored person living his or her life, scrutinizing everything,** **desperately trying to criminalize the poor man or woman, when there was someone ELSE obviously more dangerous** **who was able to FINANCE & ORGANIZE a domestic terror attack, but ‘The Powers That Be’ won’t call it that or treat the crime like that,** **BECAUSE they say, he was a privileged White Man who was simply ‘deranged.’**

**MORE INFO ON THE CASE BELOW**  
[Fox 5 News](http://www.foxnews.com/us/2017/10/26/las-vegas-shooting-internet-searches-missing-hard-drive-could-be-key-to-motive.html)  
[ABC News](http://abcnews.go.com/US/las-vegas-shooters-laptop-missing-hard-drive/story?id=50709285)  
[CNN](http://www.cnn.com/2017/10/03/us/las-vegas-shooting-investigation/index.html)  
[Washington Post](https://www.washingtonpost.com/news/morning-mix/wp/2017/10/02/police-shut-down-part-of-las-vegas-strip-due-to-shooting/?utm_term=.b74793a844e0)  
[Chicago Tribune](http://www.chicagotribune.com/news/nationworld/ct-california-police-las-vegas-shooting-20171026-story.html)  
[The Atlantic](https://www.theatlantic.com/international/archive/2017/10/isis-amaq-las-vegas/541746/)

<iframe src="https://www.nytimes.com/svc/oembed/html/?url=https%3A%2F%2Fwww.nytimes.com%2F2017%2F10%2F15%2Fus%2Flas-vegas-shooting-civilian-first-aid.html" style="border:none;max-width:500px;min-width:300px;min-height:550px;display:block;width:100%"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/pRnbzkMsgmM?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/Tge2TABOYH4?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195678826/ovAU2aJIp.png align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195680445/AlyN2y7Fc.png align="left")](https://ferrelux.com/adverts/)
