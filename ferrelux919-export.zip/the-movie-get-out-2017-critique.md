---
title: "The Movie Get Out (2017) \U0001F39F\U0001F39E (Critique)"
date: '2018-04-14T15:21:17.000Z'
slug: the-movie-get-out-2017-critique
tags:
  - django
  - movie-review
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195515213/VJguM5DVI.png
canonical: 'https://ferrelux666.wordpress.com/2018/04/14/get-out/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195510016/grxnLgiXY.png align="left")](https://www.ferrelux.us/)

**A full plus year well after the February release of this film, featuring a ‘Black Actor’ Daniel Kaluuya, as the star, continues to enjoy its value & success. It was written, produced & directed by Jordan Peele, who’s also ‘Black’. I didn’t like the film. I preferred Kaluuya’s role in the movie ‘Black Panther’ because he played an African Leader of his own tribal domain. Historically in racist horror films & other genres, the Black character is often killed off early in the film. First of all, a Black person, unlike a Caucasian, wouldn’t be involved in, or be doing certain things, or going to certain places pondering/wondering to wind up dead or have a crazy situation happen on them. It’s not our nature. And that’s why those past Hollywood films didn’t make any sense to us & many of those films would have been much better scenically & conceptually, had they left the Black character out. So to play off that motif, we see again in this movie, a dumb Black guy, not racially conscious enough, dating a racist White female trying to lure him to his enslavement & death. If not for his occasional flash photography, talking to the hypnotized negro servants on the plantation, snooping & noticing strange stuff & MOST OF ALL, his continual cellphone communications with his Pro-Black friend assessing his situation & letting him know what time it was & for him to GET OUT, our hero of the story would have failed to retain his life & freedom. He ended up doing what we never saw ever in any previous horror films by a Black character, except for comedy skits & the movie ‘Django,’ where the oppressed Black character rise to victory. That was the moment of the movie I liked, when our fool ‘woke up’ & saw the light for what those people really were & smite them. A simple film that Jordan Peele felt he needed to put out there. I don’t think a sequel is necessary. The Film received nominations from SAG, Golden Globe, Critic’s Choice Awards, & NAACP, however, it won for best foreign international film, at the British Independent Film Awards. Who else would be that open minded to appreciate the latent messages behind it all & not be offended? Well, not to be topped, in 2018 the film had a few Oscars nominations, but won the Academy Award for Best Original Screenplay. Jordan Peele graciously accepted the award making history as the First Black to win in that category.**

**~ Lhisa Mrklon**

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195511056/sM6r5t_s_.png align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195512644/q2OX65kq9.png align="left")](https://ferrelux.com/adverts/)
