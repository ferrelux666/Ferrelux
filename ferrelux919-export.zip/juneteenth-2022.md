---
title: "\U0001F985Juneteenth 2022\U0001FAB6"
date: '2022-06-30T02:14:51.000Z'
slug: juneteenth-2022
tags:
  - website
  - technology
  - facebook
  - philosophy
  - google
  - business
  - career
  - meta
  - legal
  - hacking
  - alphabet
  - hope
  - silicon-valley
  - identity
  - doj
  - freedom
  - brand
  - companies
  - scam
  - products
  - usa
  - holiday
  - advocate
  - texas
  - fake
  - stalking
  - america
  - crisis
  - fraud
  - prayer
  - censorship
  - president
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672191801528/ZE7r1DWeT.jpeg
canonical: 'https://ferrelux666.wordpress.com/2022/06/29/juneteenth-2022/'
---
[![Negro, Breaking Off The Shackles](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191768654/MqvPSYqlQ.jpeg)](https://jackmillercenter.org/emancipation-proclamation-juneteenth-holiday/)

<iframe width="100%" height="100" src="https://w.soundcloud.com/player/?url=https%3A%2F%2Fapi.soundcloud.com%2Ftracks%2F126575336&amp;auto_play=false&amp;hide_related=false&amp;visual=true&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;color=ff5500"></iframe>

[Gong Brazil](https://soundcloud.com/gong_brazil) · [Redemption Song – Bob Marley – Zurich – 1980-05-30](https://soundcloud.com/gong_brazil/redemption-song-bob-marley)

Libertas Inestimabilis Res Est 😊 Freedom Is A Possession Of Profound Value

**_**_Public Service Announcement:_**_** __There are some__ **_**_heavy-weight_**_** __topics I plan on taking on soon that has hit the airwaves pissing people off. Right now, I’m basically covering my ledger of topics in this particular order for this year. As you know, I’m also busy with the social justice work of taking on a Corrupt Monopoly. And I advise for people to spread their wings using other developing social media sites aside from Google, Facebook and other Monopolous Big Tech Corporations also working with them, who obviously have an ongoing record of violating the trust and rights of Its Users. They engage in under-handed insidious activities targeting certain people and small businesses why you would want to move your resources & content elsewhere. And you don’t need to have had any prior issues with them for them to decide one day that your political views aren’t aligned with theirs, or the ad program you are independently running on your website, might attract competition away from their Ad Services, depriving you of your right to free enterprise. They take it upon themselves to go beyond their own site jurisdiction trying to stalk and interfere with your life and livelihood even though you did absolutely nothing to them, and they do it in such an open and flagrant manner trying to hurt you. Their so-called business profile, Google AMP technology, and other products are a cover for it with the continued doxxing and other covert wicked activity, even long after you canceled use of their service within days. Google has ceased to be a reputable search engine, and the other ones very co-dependant on their technology aren’t that great either. Facebook/Instagram has also proven themselves to be in bed them as well using their resources trying to hurt your career or hijack use of your business name, brand or Identity by mis-representing it through fake or spoof accounts and closing the actual Celebrity or Business Owner out of their verified account. And then going around trying to obstruct the online tools and resources they see the person using, harassing him or her, not realizing__ **_**_that too_**_** __is a cyber-crime. Oh these attacks are happening at the highest levels. You can tell from the internal process. They even enlist overseas cohorts. Also, it’s sad that a supposed American Company can’t hire their own home grown tech person, many of them now are of Arab or other East Indian descent who are ill-equipped with relating to Westerners and our values and way of life. As a result, instead of following standard procedure, their own prejudices and waywardness enter the picture. Take a look at the several lawsuits these tech giants have had in the past attacking other cyber personalities or brand owners, yet they still engage in the same terror tactics yearly, why several Prosecutors around the Country are still working to bring them to justice.__ **_**_Why?_**_** __Well these types of cases are best fought and won a certain way. Now the solution for these Big Tech Corps to amicably resolve the problem with the person from the very beginning was simple, but their nature is to delight in an on-going unnecessary conflict with someone that eventually affects their bottom line. There was a time when these tech giants were respectable professionals that actually competed with one another and The Public benefited, now there is an abuse of power I’m exposing with my own case, which came about as a result of them maliciously targeting me out of the blue,__ **_**_and they don’t realize how they look doing it. They are so caught up in a false sense of invincibility, that they fail to see how truly vulnerable and powerless THEY really are.  
~Stay Tuned~  
_**_**

A private activity of promoting Juneteenth on my website certain times over the years, talking about it, and relating to it has culminated in interest by some over time where a collective of other Social Activists and Advocates who had been trying, finally got it passed as a federal holiday. It brought a humble smile on my face this year round to NOT make such a case of it here, but to let others carry the banner parading it on their websites. My Readers from over the many years, at least those paying attention can infer these sort of things I opt to do when they aren’t seeing something and are viewing instead one of my subtleties. Now the ones **_**_really_**_** paying attention to my work, are following my other sensible moves and have begun to realize some steps they need to take. Now I deal with a range of varied topics on here appealing to different types of people from the very least, to some of the most prominent people in Society being inspired by my material. And there is a reason why I would head this article with a dutiful PSA educating all of you thoroughly, that even in a so-called free time, there are certain wicked groups of people in and about our communities hovering, singling out and targeting you, in our present day using technology, and their efforts are concerted and crazy too. They do not have a right to be in the mix. Who you are as a free thinking person and what life-changing thing you are doing is none of their business. How and when you decide to do something is not their concern. Why you’re NOT doing something they think you should be doing, is also a personal matter that they were not invited to. You know yourself and situation better. You are not an object or commodity to be trifled with. You’re a living being with a soul, endowed by your Creator with free will, to live as you choose on the planet. So no person or government has a right to enslave you or fashion some contrived rule or circumstance to bring about your enslavement. Freedom is not just being physically “free”, it is also freedom from any form of immoral practice designed against YOU.

**Sign,**  
**Lhisa Mrklon**

[**SEE SOME HIGHLIGHTS OF THIS YEAR’S JUNETEENTH CELEBRATION**](https://www.pbs.org/articles/learn-about-and-celebrate-juneteenth)

**What New Social Media Site Are YOU On That You Like Better Than FB, Youtube, etc.?** 🙂  
**Scroll Down And Leave Your Reply.**

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191770167/oi9xIvh_d.jpeg)](https://lightinthebox.tv2h87.net/c/3170166/940974/8199?prodsku=4915236&u=https%3A%2F%2Fwww.lightinthebox.com%2Ftiebao-men-s-cycling-sneakers-anti-slip-damping-cushioning-ventilation-impact-wearproof_p4915236.html&intsrc=PUI2_7362)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191771456/zZoBd5LkD.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191773185/HxwZY3sdv.png)![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191774673/kIofFkYZI.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191775966/lTBuzG3xW.png)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191777580/dtS3hZhre.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191778753/3GYO5Hc52.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191780423/Brsd-2A3h.png)![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191784826/Mmtw_QgJ-.png)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191786202/huUWeF0u3.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191787808/27Ygyh8dj.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191789506/ZkKpezUKB.jpeg)![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191791134/BNNJDwxtB.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191792215/1FufuDm6Z.jpeg)![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191793590/mfwPhJDqi.jpeg)![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191794988/i2XZxjx6R.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191796392/ztRydw5JL.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191797884/F9ajRJdMg.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191799352/BcJpkPild.png)

### Share this:

*   [Twitter](https://ferrelux666.wordpress.com/2022/06/29/juneteenth-2022/?share=twitter)
*   [Reddit](https://ferrelux666.wordpress.com/2022/06/29/juneteenth-2022/?share=reddit)
*   [Pinterest](https://ferrelux666.wordpress.com/2022/06/29/juneteenth-2022/?share=pinterest)
*   [Tumblr](https://ferrelux666.wordpress.com/2022/06/29/juneteenth-2022/?share=tumblr)
*   [LinkedIn](https://ferrelux666.wordpress.com/2022/06/29/juneteenth-2022/?share=linkedin)
*   [Email](mailto:?subject=%5BShared%20Post%5D%20%F0%9F%A6%85Juneteenth%202022%F0%9F%AA%B6&body=https%3A%2F%2Fferrelux666.wordpress.com%2F2022%2F06%2F29%2Fjuneteenth-2022%2F&share=email)
*   [More](https://ferrelux666.wordpress.com/#)

*   [Telegram](https://ferrelux666.wordpress.com/2022/06/29/juneteenth-2022/?share=telegram)
*   [Print](https://ferrelux666.wordpress.com/2022/06/29/juneteenth-2022/#print)
*   [Skype](https://ferrelux666.wordpress.com/2022/06/29/juneteenth-2022/?share=skype)

### Like this:

Like Loading...

### _Related_
