---
title: "\U0001F62FTrump June Assassination Attempt Fail\U0001F62E"
date: '2017-06-27T17:10:28.000Z'
slug: trump-june-assassination-attempt-fail
tags:
  - play
  - trump
  - attacks
  - conspiracy
  - show
  - hate
  - china
  - italy
  - korea
  - united-states
  - america
  - president
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195840881/XnRFrbALN.png
canonical: 'https://ferrelux666.wordpress.com/2017/06/27/trump-assassination-theory/'
---
**  
*Humiles Laborant Ubi Potentes Dissident 🤢🤮🤒 Poor People Suffer When The Powerful Disagree***

\*\*  
Rumors & plotting of assassinating our current President Donald J. Trump have been swirling since last year with numorous occult videos on youtube calculating the date & hour & such of their interpretations of Illuminati plans,…WELL……he’s STILL HERE! 🙂\*\*

**The attempts started last year though with one of his own. Check out this young Caucasian boy.**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/rrJ-BN1nEGg?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

**The plan is still on though. The Shakespeare in the Park play drew on it with the actor who’s playing Julius Caesar dressed as Trump & Calpurnia, his wife, looking like Melania Trump. Well, this theme of getting rid of Trump is very popular despite the controversy. Even Kathy Griffin got in trouble for her extreme artistic expression with the effigy of severed head of the President.**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/-qfzqBr1qh0?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

**Here is Trump Supporter affected by these jokes featured on the Alex Jones Channel………**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/mSZ9QJOZqpg?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

**Here’s Mark Dice, another Trumpy finding a fault with it too………….**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/D0VjWVUQ4Go?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

**But she paid the price though with attacks on her career. There are those popular & common who**  
**supported her actions. It still doesn’t kill the popular sentiment.**

**The Buzz about Trump being taken out is still anticipated if any of the common folk prophecy reports are true. Look at some of these videos below.**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/HjBnBVHoGTs?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

**Future Anticipations………….**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/Me-vTmuvN1o?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

**Nostradamus Soon To Be Fulfilled Prophecies**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/Q_a4d6grlAY?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

**More on the above………………..**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/wCIb5HRCsGA?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195824819/Rh_l7f311.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195826669/5e9qlWn3q.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195827961/mcUJer5rG.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195829195/SrqOeDlbo.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195831182/A0XzPrW_T.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195832442/kzvt_OAIY.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195833789/BFg6EiHbj.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195835097/g_4sjnENQ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195836364/YFSf3seeyc.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195837662/sXLmzez0_.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195838853/hX4EAvTf4.jpeg align="left")
