---
title: "Mariachi Kid Sings Natl Anthem & Gets Racist Tweets \U0001F615\U0001F97A"
date: '2013-06-22T12:23:39.000Z'
slug: mariachi-kid-sings-natl-anthem-and-gets-racist-tweets
tags:
  - spanish
  - kid
  - sad
  - immigrant
  - hate
  - entertainment
  - children
  - young
  - musician
  - tweets
  - singer
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672196126431/GFWmVZsLK.jpeg
canonical: 'https://ferrelux666.wordpress.com/2013/06/22/mariachi-kid/'
---
[![Sebastien De la Cruz](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196118705/NSkMpp7wg.jpeg align="left")](https://www.dailymail.co.uk/news/article-2341300/Sebastien-De-La-Cruz-Brave-11-year-old-mariachi-singer-shrugs-hateful-racist-backlash-NBA-national-anthem-performance-saying-hes-just-proud-American.html)

Sebastien De la Cruz sings the national anthem before Game 4 of the NBA Finals basketball series between the San Antonio Spurs and the Miami Heat, Thursday, June 13, 2013, in San Antonio. (AP Photo/David J. Phillip)

**Hi Ya’ll. When you view the below videos, you’ll get the basis of my blog today. So many subtle political changes have taken place in America in favor of Spanish immigrants which we have seen in the news. Some of them include free medical insurance & other government benefits, an illegal reporting a crime that happened to him/her without the threat of deportation, certain approved rights within Arizona including the right to express their culture in the classroom, American HR forms & other legal documents separating themselves from other classes of races as if they were a neutral race of their own & not of mixed blood, favors from Obama & so forth. The point is, Hispanics are looking for special treatment & have gotten it to some extent, but when it comes to the racist reality of those not in power (since majority rules) they are still generally perceived as cockroaches. Many of them are seen with suspicion & under attack in White neighborhoods but yet they wish to segregate themselves from the struggle with Blacks whom they are safest among. And now some Hispanics discriminate against Blacks & even attack them. Regarding the below videos, if it were an older person who had been out there prepared to handle it like Pitbull & others, then it wouldn’t have bothered me or the masses as much, but a really young boy who didn’t do or say a damn thing to deserve such a disgraceful attack on his person? This should show Hispanics (& the term is questionable too) that they are not socially acceptable amongst them & quit trying to identify with THEM even if you are light skinned because if you are Spanish & love being Spanish, you need to get rid of your Spanishness to fit in. If you are unwilling to lose your culture (which frightens them) then you have no business trying to look for social approval amongst their kind. Let these videos marinate in your mind for a while & consider a better strategy in recouping what your ancestors lost…..(on the more ethnic side of your breed I mean).**

[![Mariachi Kid, Sebastien De La Cruz, After Racist Backlash](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196119960/gXT1qZE0O.jpeg align="left")](https://ferrelux666.wordpress.com/mariachi-kid-sebastien-de-la-cruz-after-racist-backlash/)

[![Mariachi Kid, Sebastien De La Cruz](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196121187/EDoqj7ntc.jpeg align="left")](https://ferrelux666.wordpress.com/mariachi-kid-sebastien-de-la-cruz/)

[![Mariachi Kid, Singing](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196122441/_5PUXvoCc.jpeg align="left")](https://ferrelux666.wordpress.com/mariachi-kid-singing/)

[![Mariachi Kid, Performing](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196123793/L14PRqe6n.jpeg align="left")](https://ferrelux666.wordpress.com/mariachi-kid-performing/)

[![Mariachi Kid, On Stage](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196125159/F7-X7J_ey.jpeg align="left")](https://ferrelux666.wordpress.com/mariachi-kid-on-stage/)

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/CFIyUJHEaSE?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>
