---
title: "“Shithole” Countries \U0001F5FA\U0001F30B\U0001F3D7"
date: '2018-01-18T17:55:47.000Z'
slug: shithole-countries
tags:
  - trump
  - africa
  - immigration
  - norway
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195615900/1p5CDq_nI.png
canonical: 'https://ferrelux666.wordpress.com/2018/01/18/shithole-countries/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195611386/t8RB5oBFp.png align="left")](https://www.ferrelux.us/)

**Felix Annus Novus 🎉 Happy New year (2018)**

**Ooooh here we go again. Trump on the Immigration thing. He claims to have never used the derogatory term referring to African & Caribbean nations as “Shithole” countries that the U.S. are accepting immigrants from, and that they should let in more people from places like Norway. Well…………people from well developed wealthier European countries would NOT want to relocate to America because that would be a drop in their standard of living. The point that Trump missed is the whole propaganda effect of promoting the lie that life is better in America. So when poorer immigrants come here thinking life is better, they quickly learn that the only real value is struggling amidst the stresses of life to earn the American dollar is the only strong suit here, because in reality, what they left behind was a better way of life, & THAT is the real sacrifice.**

**Sign,**  
**Lhisa**

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195612879/hLbhU04qA.png align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195614265/uB-Xb73KI.jpeg align="left")](https://ferrelux.com/adverts/)
