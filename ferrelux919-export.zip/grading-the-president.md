---
title: "♟️\U0001F4D3Grading The President\U0001F52E\U0001FA84"
date: '2022-05-01T02:48:46.000Z'
slug: grading-the-president
tags:
  - fear
  - oracle
  - facebook
  - trolling
  - cheap
  - trump
  - jobs
  - google
  - employment
  - meta
  - build
  - culture
  - fb
  - history
  - country
  - laptop
  - spanish
  - policy
  - magic
  - food
  - vp
  - layoff
  - grade
  - politics
  - men
  - party
  - texas
  - rehab
  - drug-addiction
  - alcohol
  - celebration
  - america
  - journalist
  - joe-biden
  - corn
  - president
  - court
  - mexico
  - revolution
  - quest
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672191966624/M9_OAPXZz.jpeg
canonical: 'https://ferrelux666.wordpress.com/2022/04/30/grading-the-president/'
---
[![Biden Clip Art](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191926114/SQ7lJBSyjD.jpeg align="left")](https://utreon.com/v/ZC2jypTLQCe)

<iframe width="100%" height="100" src="https://w.soundcloud.com/player/?url=https%3A%2F%2Fapi.soundcloud.com%2Ftracks%2F198263426&auto_play=false&hide_related=false&visual=true&show_comments=true&show_user=true&show_reposts=false&color=ff5500"></iframe>

[Sombreli Corelli](https://soundcloud.com/bakaricsasa) · [Daddy Yankee – Gasolina – Dj – Baka – Rmx – .mp3](https://soundcloud.com/bakaricsasa/dady-yankee-gasolina-dj-baka-rmx-mp3)

**Ibi Multa Sunt Ambitiosi Politici, Et Nemo Ex Eis Facere Meum Generis Bonum 🧱 There Are Many Ambitious Politicians, And None Of Them Do My Race Good (Pancho Villa)**

**\_***My past few articles have been tackling the subject matter of Google & Facebook’s unethical probing practices and Cancel Culture policies collaborating with other Big Tech Companies behind the scenes, unfairly targeting certain persons & businesses. And as it stands, the issue in part has reached growing awareness with very recent media coverage further exposing it. When you tell a company (Google) that you don’t want their Business Listing anymore due to some serious ethical issues with it after THEM reaching out soliciting you to have one, and their refusal to delete that business profile from their system, including Google Maps, when they were instructed to, tells you all about their immoral practices, especially involving other big tech firms in the process, trolling around the person or small business on the internet, exposing their private information on the web.***\_**

As we head towards the mid-term, discussions have already began about grading The Administration again. Now, a long while back when I started doing that sort of thing as a joke on here and my Circular went around, I noticed an uptick in such conversations. So where we last left off, the general media agreed with fervor that the performance of **The Biden Administration** deserved a big fat red **F** after the perceived failure of Afghanistan. And since then, I’ve observed your Administration battle ridicule and contempt. And as it stands this time around, at least to me, you have worked your way out of the **F** status on to a **D**, and with continued careful policies and handling of things with sound overall judgment, I foresee a solid **C** in the coming future, but expect your Haters to continue keeping your grade down despite certain accomplishments because they don’t really like you. You’re the only President in the U.S. History to have ever appointed a Black Female Supreme Court Judge, Ketanji Brown Jackson, fulfilling a campaign promise, among others. The job of being President is hard and your Critics are in an easier position to be criticizing. You should commend your self for being so old and challenged, yet still performing a civic duty as President to The American People. One thing to wonder about Biden, is, if you’d met a Fortune-Teller, prior to taking this job, who told you that there would be relentless attacks aimed at you concerning Hunter Biden, would you have still accepted The Presidency? You see, you took time off from ascending to the role of President the first time to mourn the death of your other son, Beau. And you could have continued doing so, further relieving yourself from any official duties, but you opened yourself wide up for criticism when you took on the role of President. And as you see in the media, some people don’t want to let go of **Hunter Biden** and Burisma. All that is up for discussion as he’s still alive and well somewhere recovering from substance abuse, and every now and then he makes comments to the media, and the way The Press is treating that laptop story, tells you something. So now, YOU have to deal with the constant reminders of **this son** and his prior political activities, from your Critics who have a definite agenda. And even if you stepped away from Power, they already engaged in a heavy campaign maligning our poor VP Kamala Harris from assuming her rightful role as the next President since they prefer Trump. What a shame. Such negative press coverage. Oh what will you do? **Hmmm.** **Oh Wait!** I recall just a few years ago, that there was One in the Kingdom who posed a threat. The People have forgotten about him, but if you are our current Leader, now under siege by a growing monopoly of right wing Journalists and Politicians seeking to displace you as Ruler and install **Donald J. Trump**, you’ll need a Champion. Someone who grew up in The Democracy, and knows. Someone who helped The Party several times in his early years, knowing The Laws of The Land. When this particular Knight appeared at Court, just his presence on the airwaves inspired fear in your Opponent at the time when he ruled The Kingdom. So much so that, a sinister plot was devised to lure this Italian Knight far away from Court to be sabotaged by an evil Wizard who now has him encased. And there was none brave enough in your Court to go out into that dark enchanted wilderness and rescue him from this embattled situation. And so, an old charismatic Political Opponent can rise again to try and assume power due to his growing factions. Look about you Joe. There is none in The Kingdom strong enough to help you defeat Trump. He is ever so brazen NOW rallying his troops for a political battle against you because there is NO ONE to fear. But a Wizard must be defeated. A legal spell has one of your best Knights trapped from being able to help defend you. When The People needed A Hero, he was there. So much so that they wanted him To Lead. And as he met up with a magical demise due to that Wizard on a stormy day invoking The Goddess Nike to overtake him, The Knight looked toward The People, telling them to choose YOU as our new Leader. And here we are. And ever since 2018 Trump and his Wizard has weaved a spell in the land where The People are now seeing YOU as a senile leader who must give up power. But if you could just find and send out what few good men you have left with the right weaponry and protective talismans on a quest to find this Knight, Michael, and help him defeat The Wizard and his wicked magic, **\_***then maybe***\_** you could turn the tide.

Sign,  
Lhisa Mrklon  
Your Divine Oracle

**Will Biden’s Administration Succeed In Defeating Trump Again? Scroll Down And Leave Your Reply.**

\*\*

[![Happy Mother's Day In Spanish](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191927256/5QsxoykWW.jpeg align="left")](https://www.dailymotion.com/search/Mother%27s%20Day/videos?sortBy=most_recent)

  
\*\*

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191928701/E8VgQTBJB.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191930589/_g737PMel.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191932064/wz_oP768Hf.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191933361/NckyG4h9m.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191934897/_PxzioyxO.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191936247/3OllL1rX8.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191937742/npzSflm-0.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191938896/H31c2PocG.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191941343/kCiiTA-Qj.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191942621/28migO9N1.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191944056/Ciq8wpnlG.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191945475/HoLZ1Mt7Q.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191947254/GGdYSxc18t.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191948745/KHVlP9i4E.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191950073/gsKynk0Tv.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191952032/zrajllC88.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191953871/iYorFCDRb.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191955416/L4qKzbKHr.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191956729/qbljgNHeP.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191958099/nlwlENuSd.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191959344/5KxgMklv-.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191960914/d4iFkoJ5_.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191962554/3Ob5vvQXl.jpeg align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191964530/9P8ipEJfc.jpeg align="left")](https://lightinthebox.tv2h87.net/c/3170166/898314/8199?prodsku=8838190&u=https%3A%2F%2Fwww.lightinthebox.com%2Felectric-neck-massager-intelligent-pulse-massager-control-far-infrared-heating-pain-relief-health-care-physiotherapy-relaxation_p8838190.html&intsrc=PUI2_7096)

### Like this:

Like Loading...

### *Related*
