---
title: "\U0001F61F How The Mass Killer Succeeds \U0001F632"
date: '2022-07-18T07:51:11.000Z'
slug: how-the-mass-killer-succeeds
tags:
  - amazon
  - facebook
  - google
  - psychology
  - crazy
  - youtube
  - hacking
  - videos
  - social-media
  - data-mining
  - training
  - manifesto
  - discord
  - kids
  - teachers
  - mental-health
  - hackers
  - teens
  - walmart
  - school
  - guns
  - texas
  - blood
  - street
  - children
  - conversations
  - police
  - america
  - counseling
  - new-york
  - fire
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672191760532/wm2WBuFll.jpeg
canonical: 'https://ferrelux666.wordpress.com/2022/07/18/mass-killer/'
---
[![Gun Made In Taiwan](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191731025/B8X1-8Yd8.jpeg align="left")](https://utreon.com/v/l2cyWWcTSHW)

<iframe width="100%" height="100" src="https://w.soundcloud.com/player/?url=https%3A%2F%2Fapi.soundcloud.com%2Ftracks%2F77770868&auto_play=false&hide_related=false&visual=true&show_comments=true&show_user=true&show_reposts=false&color=ff5500"></iframe>

[PKP MusiC](https://soundcloud.com/pkpmusic) · [Ice T – Killers](https://soundcloud.com/pkpmusic/ice-t-killers)

**Vive Memor Leti ⚰️ Live Mindful Of Death (Persius)**

***Let me first make a note that this unveiling is a current work in progress. As you know, I am still tending to a legal matter concerning Facebook & Google collaborating in trying to obstruct my work online, along with their Enablers as you can readily see signs of it in the search engines controlled by them. So I will need you to check back later as I develop this piece. Essentially, my argument on the topic all boils down to the fact that the people controlling these social media platforms are way too involved in bothering normal long standing law-abiding persons like you and me trying to fight the good fight, instead of using those same probing technology to obstruct actual criminals openly using their resources.***

**ALRIGHT!** So few days later I’m here breaking this down. You know, it’s shocking how sometimes Law Enforcement can’t solve crimes when the tools are there for them to online. Just a casual search anywhere can yield info of certain access tools The Government uses to spy on people. So this Uvalde Shooter must have been known about. And he certainly was, but deemed not a threat, despite all that stuff. Some of his Classmates knew better. And what about the New York Subway Shooter? Well, his online videos shows him carrying on with bitter commentaries about race and Society. Why wasn’t he seen as a threat then? Well, there are A LOT like him, but are least likely to do what he did after being triggered. **\_***But you know what I notice?***\_** Facebook, like some others, is a nosey website that oversteps their bounds targeting certain individuals, wanting to know too much about that person, as if that helps them, even closing the person out of their account trying to force him or her to upload their personal IDs with their real names and other vitals to store on their servers though Facebook is careless with data, and the site is susceptible to Hackers. When Mark Zuckerberg was asked similar probing questions in his Hearings recent years back, they gave him a taste of his own invasive medicine, and of course he didn’t think private details of what he ate that day or where he stayed that night needed to be known to The Public. But he data-mines peoples information, for what? I think if you know all that stuff, and are using algorithms, you should be able to stop or solve a crime. I know when a case was closing in tight on Zuckerberg several months ago, Facebook all of a sudden got HACKED! **\_***Really?***\_** When you are doing the stuff you are doing then, the parents of those dead children, relatives of massacred victims and so forth have a right to sue The Social Media Giants as well, and not only them, the Big Tech email services too. Many of them collaborate with one another as they engage in spying on certain Users. The signs are there. With all that technology you mean to tell me that you could not spot those 2 Killers? Oh but I get it, they were just average looking persons in The Society with a Common Lifestyle. You only watch and stalk after attractive people with interesting lives. And I’m reminded of that em-passionate cry Night Show Host, **Jimmy Kimmel** made after that Uvalde massacre, asking when are these killings going to stop. Well, when The FBI and Big Tech decides to stop scrutinizing the average Joe & Jane, and start developing a proper pattern of surveillance designed to spot future Attackers like that. They get away because they know enough about how IGNORANT The System is to them. I notice that too about The Hoodlums in The Street. They brazenly go about because the average Security Guard is too busy watching Some Woman’s Ass, or Conversating. So in the recent days when News Broadcasters are still criticizing the slow and fearful response of The Uvalde Texas Crew’s lack of ability to save those kids, it revealed just how unprepared they were in dealing with such an Attack. It would have been better had they sent S.W.A.T. who I know would have done had a blueprint layout of the place, and would have had the school heavily surrounded with soldiers on the roof and also scaling the side of the building, fully armed and ready to shoot to kill, while another soldier out there in the S.W.A.T vehicle is on the megaphone with their antics talking to the Perp inside. I try not to cover too much sad topics like this because there is NOTHING The System can say or do to heal the loss of their loved ones. The crime should never had happened!

Sign,  
Lhisa Mrklon  
Your Social Critic

**Would You Know What To Do If A Mass Shooter Opened Fire In A Crowd? 🥸 Scroll Down And Leave Your Reply.**

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191732673/jgk7SMwG2.jpeg align="left")](https://lightinthebox.tv2h87.net/c/3170166/805530/8199?prodsku=8742577&u=https%3A%2F%2Fwww.lightinthebox.com%2Fmen-s-upf-50-running-sun-protection-long-sleeve-t-shirt-outdoor-rashguard-hiking-hoodies-performance-athletic-top-navy-blue-l_p8742577.html%3Fcurrency%3DUSD&intsrc=PUI2_5801)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191734101/UY1yE1_mz.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191736369/ad3vy8GNN.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191738172/kiCjY1vx9.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191739414/pSMpM5z9h.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191740652/jnh8hv3pa.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191742064/sXQSKpZX3.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191743568/SeSg6BTG5.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191745199/EoTl-bRuJ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191746752/hNTdyaqkC.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191748124/H_pgN3CLJ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191749790/-wj6Wu1pB.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191751984/yz1Q76c5A.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191753524/A2RF29wlq.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191754999/fWrJLVpx_.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191756896/YhoRPg4Xe.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191758808/jvrc_clbv.jpeg align="left")

### Like this:

Like Loading...

### *Related*
