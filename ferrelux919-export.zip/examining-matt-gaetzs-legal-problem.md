---
title: "\U0001F389Examining Matt Gaetz’s Legal Problem\U0001F37A"
date: '2021-10-01T18:49:54.000Z'
slug: examining-matt-gaetzs-legal-problem
tags:
  - news
  - trump
  - legal
  - women
  - usa
  - government
  - race
  - florida
  - democracy
  - america
  - teenagers
  - washington
  - new-york
  - laws
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672208223842/8be3861f-ed14-4a43-847a-99061f3c1830.jpeg
canonical: 'https://ferrelux666.wordpress.com/2021/10/01/matt-gaetz/'
---
[![Matt Gaetz, Looking Like A Mobster](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192621906/znB6xzHeZ.jpeg align="left")](https://gaetz.house.gov/media/in-the-news)

[**“Da Da Da” – Trio (From The 1980s Movie ‘Private School’)**](https://www.youtube.com/watch?v=caPnfxDTjuQ)**  
Pro Bono Americano Populi, Debemus Ponere Nostra Suis Commodis Primo 🦅 For The Good Of The American People, We Must Place Our Own Interests First (Matt Gaetz)**

So I’ve been observing Florida Representative Matthew Louis Gaetz, and his issues for some time now since that whole splash came out months ago in the media with him being exposed as allegedly having sexual relations with a 17 year old female, transporting her across state lines, and paying for sex using an online payment app. And this brings into question the age of consent by state, and how exactly does The Justice System plan on proving intent, or will they just rely on word of mouth as evidence like they did the R. Kelly Case. And notice too the people The Justice System prefers to go after, with cases that pale in comparison to those powerful persons involved in The Pizza Gate Scandal and other pedophile, sex trafficking rings not aggressively being investigated further. And it was amusing watching the Congressman for weeks go to and fro across the public media circuits defending himself against hurtful allegations, and he could have been treated better on ‘Tucker’ by the way. And while looking at the whole spectacle, I thought, you know, I never knew this guy existed. To be honest, it was news to me that he was one of Trump’s top faithful followers. I mean I was busy paying attention to other people and things to notice. I didn’t know who he was until this political scandal. And whosoever thought it was a great idea to bolster this case against him to try to make him into a social pariah, might have made a mistake. Such moves sometimes could cause the demonized person to gain fans. He’s someone I’ve been studying to get a gauge of, to try and understand the real reason why he came under attack. Well, he’s fairly intelligent, and when he’s not out there politicking, he has a party animal side to him. Big Deal. Who among you don’t have a less political lifestyle when you go home? And I bet some of you people have some innocent stuff you’re doing that can be upgraded to something more criminal. So what if he’s a Trump Man. He’s doing his job being loyal to his Political Party. A lot of the stuff he’s saying out there makes sense. Ya’ll acting like what he’s saying isn’t valid. And as I do with you, I’ll correct any suspicious rhetoric I feel he might be delivering. Apparently his only prior mistake was being blindly supportive of the mis-use of Florida’s ‘Stand Your Ground Law’ given the insensitivity to the death of Trayvon Martin, but many of you who criticized Matt Gaetz on that also failed yourselves to respect a Community of Color in securing justice against that Black child’s killer though you pretended you cared. At least he recently recognized and commented against the depraved surveillance of less privileged civilians in certain neighborhoods who are not terrorists or criminals. Right now, in his current Office amidst the looming legal case, Gaetz is handling himself quite well trying to protect the founding values of The Country, unlike The Opposing Political Party. Who cares about the Frat Parties at his Frat House. Just don’t go there. Be responsible and stop trying to put away Political Candidates, great and small that represent the fiber of this Nation. You dramatically risk the constitutional foundations of your Judicial System by playing around with cases carrying charges that have little to no merit and granting a conviction anyway so that you can set a bad precedent. This is happening too frequently now in the public eye. What do you want, ANARCHY? Even if someone were to bring a charge of ‘he said, she said’, with no proof, each State has it’s own set of internal laws governing what is permissible or not. And some of these laws are too vague, or lack clarity, that they should be re-written more precisely. Do you know that The Court System gets clogged up with cases also due to the varied legal loopholes. Let’s look at The New York Hearsay Laws for example, why did a Committee revising laws, in the 1990s move to legally admit hearsay **(even if it’s questionable)** into The Court System? Do you see what’s wrong with that, and how it hurts people when **\_***mis-used***\_**? This has been going on for many decades now. So a mentally-ill, wicked, or corrupt individual that does not like somebody in the State of New York, can fabricate “hearsay” or claim they heard you say something, and bring up charges against a person just to hurt that individual. That’s a serious problem, especially when New York has their “long arm of the law” policy to reach over into another state to try to bring charges against a person while being OBLIVIOUS to the person’s legal rights in their own Home State. These laws in New York have been grossly exploited over the years to secure wrongful convictions. **\_***What other State does this?***\_** Before you go after some poor hapless Citizen, or well-to-do Politician, you need to be re-writing federal and state laws to mean EXACTLY what you mean, using the right wording and scenario. So many wrongfully convicted persons that were already affected in some way need to be absolved too. They should not be going through another day in Hell trying to overturn a conviction. I see how flagrantly you’re going after people you don’t like out here, based off hearsay alone as evidence. ARE YOU SICK? It’s hurting people’s lives. What about the instigator making the false allegations? No one is investigating him or her though? There was a time when law enforcement, a psychologist, a teacher, or other skilled or street smart person back in the day, would take into account The Source of the information and wonder about his or her motives in reporting it. There was a time that if YOU, the real criminal presented yourself too much, you risked being discovered why you kept a low profile in your effort to screw over somebody. Nowadays, with a Justice System as your Partner In Crime, you can openly run a muck with guilt written all over you, in persecution of a decent person.

**Sign,**  
**Lhisa Mrklon**  
**Your Legal Eagle In The\_\_\_\_Court Of Public Opinion**

**Should Random Hearsay Be Admitted Into Court? Scroll Down And Leave Your Reply Below.**

[![Ferrelux Homepage_Matt Gaetz](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192623422/RnMGT644L.jpeg align="left")](https://ferrelux666.wordpress.com/ferrelux-homepage_matt-gaetz/)

[![cropped-matt-gaetz-roll-call.jpg](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192624620/FoT9jvjK8.jpeg align="left")](https://ferrelux666.wordpress.com/cropped-matt-gaetz-roll-call-jpg/)

[![Matt Gaetz, Pleading](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192625787/2XmCCZ2Eu.jpeg align="left")](https://ferrelux666.wordpress.com/matt-gaetz-pleading/)

[![Matt Gaetz, Looking Like A Mobster](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192626950/EsYtogwOO.jpeg align="left")](https://ferrelux666.wordpress.com/matt-gaetz-looking-like-a-mobster/)

[![Matt Gaetz, HBO's The Swamp](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192628333/oleBf4jcy.jpeg align="left")](https://ferrelux666.wordpress.com/matt-gaetz-hbos-the-swamp/)

[![Matt Gaetz, Fat](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192630338/ZZr8pSiV-.png align="left")](https://ferrelux666.wordpress.com/matt-gaetz-fat/)

[![Matt Gaetz, Comical](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192631489/nVXHB4_hR.jpeg align="left")](https://ferrelux666.wordpress.com/matt-gaetz-comical/)

[![Matt Gaetz, Sinical](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192632509/lehP6gNVU.jpeg align="left")](https://ferrelux666.wordpress.com/matt-gaetz-sinical/)

[![Matt Gaetz, Roll Call](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192633786/H9ZjOh6_S.jpeg align="left")](https://ferrelux666.wordpress.com/matt-gaetz-roll-call/)

[![Matt Gaetz, Angry](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192635004/Ai9CDNsXl.jpeg align="left")](https://ferrelux666.wordpress.com/matt-gaetz-angry/)

[![Matt Gaetz, A Classic Look](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192636004/LHCsmHjRg.jpeg align="left")](https://ferrelux666.wordpress.com/matt-gaetz-a-classic-look/)

[![Matt Gaetz With Facial Hair And Hair Slicked Back](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192637370/zHSRQt888.jpeg align="left")](https://ferrelux666.wordpress.com/matt-gaetz-with-facial-hair-and-hair-slicked-back/)

[![Matt Gaetz Travelling](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192638534/7_nIJXxEs.jpeg align="left")](https://ferrelux666.wordpress.com/matt-gaetz-travelling/)

[![Matt Gaetz At The Capitol](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192640013/yNIdmCLSn.jpeg align="left")](https://ferrelux666.wordpress.com/matt-gaetz-at-the-capitol/)

[![Matt Gaetz And Girlfriend](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192641611/MJF3fLYrA.jpeg align="left")](https://ferrelux666.wordpress.com/matt-gaetz-and-girlfriend/)

[![Florida Congressman Matt Gaetz](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192642934/yD8CpkkZ3.jpeg align="left")](https://ferrelux666.wordpress.com/florida-congressman-matt-gaetz/)

[![Cartoon Of Matt Gaetz](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192644398/A5CEnOxI2.jpeg align="left")](https://ferrelux666.wordpress.com/cartoon-of-matt-gaetz/)

[![A Fat Matt Gaetz](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192645743/IkguuemIs.png align="left")](https://ferrelux666.wordpress.com/a-fat-matt-gaetz/)

[![USGrantsOrg](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192646821/3BAK93Y6E.png align="left")](https://www.usgrants.org/sign-up?affiliate=134980)

### Like this:

Like Loading...

### *Related*
