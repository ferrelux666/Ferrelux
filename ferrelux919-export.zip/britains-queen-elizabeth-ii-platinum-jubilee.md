---
title: "Britain’s Queen Elizabeth II \U0001F49C Platinum Jubilee"
date: '2022-06-13T03:33:22.000Z'
slug: britains-queen-elizabeth-ii-platinum-jubilee
tags:
  - history
  - english
  - party
  - platinum
  - queen-elizabeth
  - kate-middleton
  - festival
  - meghan-markle
  - birthday
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672191864172/AC7V186IF.jpeg
canonical: 'https://ferrelux666.wordpress.com/2022/06/12/queen-elizabeth-platinum-jubilee/'
---
[![Queen Elizabeth In Her Earlier Years](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191809782/bHnAeBc2_.jpeg)](https://rumble.com/v174n8f-president-joe-biden-and-first-lady-jill-biden-congratulate-the-the-queen-du.html)

<iframe width="100%" height="100" src="https://w.soundcloud.com/player/?url=https%3A%2F%2Fapi.soundcloud.com%2Ftracks%2F252515203&amp;auto_play=false&amp;hide_related=false&amp;visual=true&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;color=ff5500"></iframe>

[Queen](https://soundcloud.com/queen-69312) · [God Save The Queen (Remastered 2011)](https://soundcloud.com/queen-69312/god-save-the-queen-remastered)

Spero Populus Cogitare, Et Diligenter De Futuro 👑 I Hope People Will Think Very Carefully About The Future (Queen Elizabeth II)

__My campaign exposing the immoral practices that the Parent Companies of Google & Facebook, and their other Big Tech Enablers do behind the scenes, goes on until remedied because if this information was overtly known and circulated, certain Creative and Independent Thinking people and companies they secretly don’t like and maliciously target, would not be signing up to use their services if they knew exactly what it actually was. More will be shared with you in the future as I publish more articles on trending topics, but for now, you should exercise due diligence on things being marketed to you from them either directly or indirectly.__ _It’s usually the opposite of what they promise. Also, pay attention to the very People behind these companies. What do you notice?_

**  
Well. . . .celebrating The Queen of England’s 70th year of rulership on the throne certainly was festive. The events leading up to it could have been smoother. You know, the issue with Meghan Markle and Prince Harry’s exit from their Royal Duties, and also the Prince Andrew sex-trafficking scandal. The Queen also, celebrated her 96th Birthday without Prince Philip physically being present at the festivities, but homage was paid to the deceased Monarch. All in all, the festivities went well with notable Celebrities present and top Performers taking the stage that each day, you looked forward to the next unveiling of events.**

**Sign,**  
**Lhisa Mrklon**

[**A Brief Video On The Queen’s Historical Reign**  
](https://www.dailymotion.com/video/x8aq2wo)

**And How Did YOU Enjoy The Queen’s Platinum Jubilee? 🥳 Scroll Down And Leave Your Reply.**

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191811068/3nRqUabyp.jpeg)](https://miniinthebox.8zwg.net/c/3170166/461413/8200?prodsku=4867956&u=https%3A%2F%2Fwww.miniinthebox.com%2Fbridal-wedding-princess-pageant-prom-crystal-tiara-crown-headband_p4867956.html%3Fcurrency%3DUSD&intsrc=PUI2_2952)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191812619/CWhYxmt--.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191814198/slQ8AqYDR.jpeg)![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191815559/cXQX7sNPK.jpeg)![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191816864/UPYWRgrhY.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191818557/iGPfb75ic.jpeg)![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191820504/Zox6yBJw0.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191821960/AEJ6YczhR.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191823276/qDMAEgLyT.jpeg)![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191824511/umYacvBcV.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191825831/1XT9UZf6-.png)![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191827458/NoCI2e00f.png)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191828866/d07HmXgqy.png)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191830575/IR5THaAoa.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191831864/kpVbQEwRG.gif)![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191833651/tDNH90tu0.png)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191835286/wBotIVrrJ.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191836578/XDnYDNNCa.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191838083/5CdYec2lN.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191839649/oKsdkKh4K.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191841116/iNXrXA1Bo.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191842473/1UhJrymxH.jpeg)![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191844214/SnxyA6Oh0.png)![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191846121/FJutuLxPD.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191847681/0SZtJQL-u.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191849157/NcTYNybP5.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191851415/E1Qvw6guX.jpeg)![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191853008/arqTKB3WN.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191854635/c3r_ag4p2.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191856202/daP8BPCZ8.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191857693/zs7GgKI9D.jpeg)![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191859146/Ta74hO6O9.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191860519/0k2_IbN3X.jpeg)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191862439/InoXRfnX6.png)

### Share this:

*   [Twitter](https://ferrelux666.wordpress.com/2022/06/12/queen-elizabeth-platinum-jubilee/?share=twitter)
*   [Reddit](https://ferrelux666.wordpress.com/2022/06/12/queen-elizabeth-platinum-jubilee/?share=reddit)
*   [Pinterest](https://ferrelux666.wordpress.com/2022/06/12/queen-elizabeth-platinum-jubilee/?share=pinterest)
*   [Tumblr](https://ferrelux666.wordpress.com/2022/06/12/queen-elizabeth-platinum-jubilee/?share=tumblr)
*   [LinkedIn](https://ferrelux666.wordpress.com/2022/06/12/queen-elizabeth-platinum-jubilee/?share=linkedin)
*   [Email](mailto:?subject=%5BShared%20Post%5D%20Britain%27s%20Queen%20Elizabeth%20II%20%F0%9F%92%9C%20Platinum%20Jubilee&body=https%3A%2F%2Fferrelux666.wordpress.com%2F2022%2F06%2F12%2Fqueen-elizabeth-platinum-jubilee%2F&share=email)
*   [More](https://ferrelux666.wordpress.com/#)

*   [Telegram](https://ferrelux666.wordpress.com/2022/06/12/queen-elizabeth-platinum-jubilee/?share=telegram)
*   [Print](https://ferrelux666.wordpress.com/2022/06/12/queen-elizabeth-platinum-jubilee/#print)
*   [Skype](https://ferrelux666.wordpress.com/2022/06/12/queen-elizabeth-platinum-jubilee/?share=skype)

### Like this:

Like Loading...

### _Related_
