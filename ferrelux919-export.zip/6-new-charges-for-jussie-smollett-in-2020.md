---
title: "6 New Charges For Jussie Smollett In 2020 \U0001F96A\U0001F48A\U0001F3B6"
date: '2020-03-18T19:14:36.000Z'
slug: 6-new-charges-for-jussie-smollett-in-2020
tags:
  - network
  - salary
  - job
  - trump
  - legal
  - actors
  - money
  - la
  - fraud
  - hollywood
  - black
  - justice
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672194287045/goORNJlFj.jpeg
canonical: 'https://ferrelux666.wordpress.com/2020/03/18/smollett/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194235694/x_sNuTLoQ.jpeg align="left")](https://abcnews.go.com/Entertainment/jussie-smollett-pleads-guilty-charges-disorderly-conduct/story?id=69175776)

[**“Leave Me Alone” – Michael Jackson**](https://www.youtube.com/watch?v=crbFmpezO4A)

*In Statu Quo Ante* 😡 *In The Same Condition As Before*

Where we last left off with Jussie, a year ago, the Dude got off free of all charges and it should have ended there, BUT some mean people in the Justice System could not let it go and felt he needs TO PAY, literally. They said it’s about him lying with the gay bashing MAGA hoax and all, and him not saying he’s sorry, but what’s really going on here is that SALARY he was complaining about. Sure there is always a LEGAL hook you can claim to prosecute somebody with, but when they learned about his 65k dollars he made per episode, I bet those Cops working on his case got pissed off at the audacity of him complaining about ‘low pay’ when it takes a year for them to see the same amount out of money on their paycheck when all he’s doing is portraying a gay singer from a dysfunctional family on TV in about 10 episodes that takes only a few weeks to shoot. Yes the salary is low by Hollywood standards, but DAMN, it sure beats being a Cop walking a beat. OFCOURSE they would be mad at you, and wasting their time with a false report. They really thought you got your Black effeminate ass beat down by some White Hate Mongers and nobody did shit to you. Oh, You Black Fool! You shamed and embarrassed the Black race & Fags everywhere. You made it possible for Trump & his Supporters to use what you did as an example in their political efforts. Instead of hurting Trump & his Republicans, as you aimed to do, it made him (MAGA) look better. And as expected you never apologized to them. When I first heard your story on the news, I wondered 2 things, first, WHY would anybody attack YOU out of the blue, you’re so likeable like Rupaul, and second, why would you be out on the streets 2 o’clock in the morning in sub-zero weather, alone going to ‘Subway’ to get a sandwich? I gave you the benefit of the doubt like most people until we turned and couldn’t support you anymore because “the truth” was obvious. Even if there is some strand of evidence supporting your claims, it wasn’t forthcoming to debunk all that evidence against you. Had you just done a press conference where you dressed up nice, looked at us with that doughy gay eye, tell us you had a weak fag moment in your lapse of judgment, we would have sighed and said awhh, poor Jussie, yeah the Fox Network should have paid you more & they drove you to that, we forgive you, & we would have supported a public cause to increase actor salaries, BUT NO, you had that arrogance in your step, and pomp in your voice like you’re Straight, and despite the outcome of your case, you were there still saying you were genuinely attacked. Yeah Nigger, the Cops would be mad, that’s why they re-ignited your case by levying 6 new charges. Also at the time, they wanted you to recompense the city $130k for looking for your fake attackers and you refused to pay. Had you just complied and been nice with everything, I’m sure those additional charges would not have popped up. Now you have a problem, the same as before. And notice the timing, ‘Empire’ is currently airing THE FINAL 10 EPISODES of the show closing due to this. There was talk about bringing his character back on the show since he played an integral part and I agree. I also agree with the many of us out here that this whole case is tired and they should leave it alone. The Black female Mayor of Chicago, Lori Lightfoot recently decided to fire the Police SuperIntendent, Eddie Johnson who publicly headed the legal onslaught against you, due to he himself getting in trouble over ethical lapses weeks before his retirement. Now that, kind of helped you. And when your legal team went to move your case out of Chicago to California where they stand a better chance of winning, a Judge blocked it. You poor Bitch! What might help a bit NOW, is that Corona Virus Pandemic because trial proceedings are timely. With quarantined sick people related to your conviction unable to testify, a case can’t be won. And this new case against you is absolutely unnecessary anyway. Jussie’s REAL punishment here is possibly not working again in Hollywood. He can’t go anywhere in the land without someone thinking about his gay hate crime hoax. And he’s still the Butt of jokes. That alone hurts his career. Prior to any stable acting job on the big screen, Jussie struggled at times working odd jobs to make a living while earning humble royalties off past acting jobs, and when real success came, it showed a promise for an affluent future, until an impatient & insatiable vibe took hold of his character, but he’s not completely to be blamed. Anybody involved that he spoke to should have stopped his trend of thought in that direction. And the Fox Network knew about his dissatisfaction with them over his career. He wanted his music under them released, & more money which he had a right to. He took it upon himself to self-release his own album, but the sales weren’t coming & forget about his songs hitting the charts. All of that could have been sabotaged by someone wanting to see his failure. He felt exploited by The Industry and it drove him to desperation hoping his report of a sudden physically racist and gay attack on him in the street would spark concert sales & bring enough public out pour so the Executives at The Fox Network would realize his value and increase his pay. All the publicity seemed to be working well, but experienced crime solvers working the case was seeing YOU as the culprit, especially with their findings which they hid from the News Reporters at first, as they watched YOU, go all around the TV shows supposedly ‘hurt’ but looking well, freely talking & performing at your Los Angeles concert telling people you fought back & you’re “the gay 2Pac”. You raised people’s eyebrows. I was wondering what the fuck are you doing talking and being all over the place like that, you’re a crime victim. In your interview with Robin Roberts, at one point after asking you poignant questions, leading you to re-tell your horrific tale, we can see Robin doubting you. And people dissecting your story the next day trying to analyze a lie. You were dealing with experts in their field and you were out of your league. But anyway, I hope the new case the cops of the City of Chicago are trying to build on him goes NOWHERE, so he can concentrate on re-building his life because even though he fucked up, there is no real crime here to waste time on when the resources should be solving a real case, and Jussie still has a fan base of people who care, because we’re still remembering Jamal Lyon, the character he played on ‘Empire’, and really, a person should be able to move on.

[**Videos On Jussie’s New Charges**](https://www.youtube.com/results?search_query=jussie+smollett+new+charges)[**Articles on Eddie Johnson Being Fired**](https://www.google.com/search?source=hp&ei=bW1yXrK1H5-xytMP37SM8Ao&q=eddie+johnson+fired&oq=eddie+johnson+fired&gs_l=psy-ab.3...2810.9356..10290...0.0..0.216.1811.13j6j1......0....1..gws-wiz.....6..0i362i308i154i357j0i131j0j0i22i30.pYHCQqDDhSc&ved=0ahUKEwjyn_Gx2KToAhWfmHIEHV8aA64Q4dUDCAs&uact=5#spf=1584568159616)

**P.S. – Hey Folks, I’ll give my thoughts on the Covid19 Pandemic soon. I just had this particular story (& another) pre-scheduled at this time**.

Sign,  
L H I S A

### Isn’t The Fox Network Responsible In Some Way For Not Addressing Jussie Smollet’s Complaints, Which May Have Drove Him To The Edge. Scroll Down And Leave Your Reply Below.

[![Jussie Smollett Stars Stand Behind Actor After Apparent Hate Crime](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194236922/0Ntxqz1zO.jpeg align="left")](https://ferrelux666.wordpress.com/jussie-smollett-stars-stand-behind-actor-after-apparent-hate-crime/)

[![Jussie Smollett Low Haircut](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194238338/aCTNcE4bX.jpeg align="left")](https://ferrelux666.wordpress.com/jussie-smollett-low-haircut/)

[![Jussie Wants To Play PRINCE](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194239491/-EpvDordJ.jpeg align="left")](https://ferrelux666.wordpress.com/jussie-wants-to-play-prince/)

[![Jussie Smollett with 12 Flag Pins](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194240880/P4a9HylJ9.jpeg align="left")](https://ferrelux666.wordpress.com/jussie-smollett-with-12-flag-pins/)

[![Jussie Smollett In Jeans Top, Spotlight, Schumer Media Group](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194242214/P8gcEe0Ou.jpeg align="left")](https://ferrelux666.wordpress.com/news/jussie-smollett-in-jeans-top-spotlight-schumer-media-group/)

[![Jussie Smollett In Suit](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194243360/nwR7iVGOB.jpeg align="left")](https://ferrelux666.wordpress.com/jussie-smollett-in-suit/)

[![Jussie Smollett In Trenchcoat](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194244531/HFdwePsmK.jpeg align="left")](https://ferrelux666.wordpress.com/jussie-smollett-in-trenchcoat/)

[![Jussie, & his two so-called Attackers](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194246269/UOZwjR_e0.jpeg align="left")](https://ferrelux666.wordpress.com/jussie-his-two-so-called-attackers/)

[![Jussie, & The 2 African Brothers](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194248197/H8FaMXgTw.png align="left")](https://ferrelux666.wordpress.com/jussie-the-2-african-brothers/)

[![Lucious & Family](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194249791/TcCkxyZPz.jpeg align="left")](https://ferrelux666.wordpress.com/lucious-family/)

[![Smollett](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194250983/WGk2tbEAZ.jpeg align="left")](https://ferrelux666.wordpress.com/smollett/)

[![Trump Vs Jussie](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194252523/kIR1ErPzS.jpeg align="left")](https://ferrelux666.wordpress.com/trump-vs-jussie/)

[![Jussie Smollett In Grey Jacket & Cap](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194254259/vEXaF9OP1.png align="left")](https://ferrelux666.wordpress.com/jussie-smollett-in-grey-jacket-cap/)

[![Jussie Smollett Fox 5](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194255669/Ojur9n2vK.jpeg align="left")](https://ferrelux666.wordpress.com/jussie-smollett-fox-5/)

[![Jussie Smollett Fox 5 Promo](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194257129/WvzBnw9hN.jpeg align="left")](https://ferrelux666.wordpress.com/jussie-smollett-fox-5-promo/)

[![Jussie Smollet In Studio](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194258504/nturV6BT0.jpeg align="left")](https://ferrelux666.wordpress.com/jussie-smollet-in-studio/)

[![Jussie Smollet In Robe](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194259711/-vKeh8Li9.jpeg align="left")](https://ferrelux666.wordpress.com/jussie-smollet-in-robe/)

[![Jussie Smollet Fox Promo Shot](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194261078/yxzIwm21L.jpeg align="left")](https://ferrelux666.wordpress.com/jussie-smollet-fox-promo-shot/)

[![Jussie Lounging](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194262164/VxmxpXOSf.jpeg align="left")](https://ferrelux666.wordpress.com/jussie-lounging/)

[![Jussie Grinning](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194263972/fmZvkNcTC.jpeg align="left")](https://ferrelux666.wordpress.com/jussie-grinning/)

[![onstage during the 2015 Billboard Music Awards at MGM Grand Garden Arena on May 17, 2015 in Las Vegas, Nevada.](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194265361/FMAJyUgKD.jpeg align="left")](https://ferrelux666.wordpress.com/hakeem-jamal-perform/)

onstage during the 2015 Billboard Music Awards at MGM Grand Garden Arena on May 17, 2015 in Las Vegas, Nevada.

[![Empire, Season 6, Jussie Smollett Scandal Promo](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194267015/L9BcNfB4U.jpeg align="left")](https://ferrelux666.wordpress.com/empire-season-6-jussie-smollett-scandal-promo/)

[![Empire, Brothers](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194269235/f1ID4i9i7.png align="left")](https://ferrelux666.wordpress.com/empire-brothers/)

[![Empire Star Jussie Smollett](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194270812/xSsk_vbY6.jpeg align="left")](https://ferrelux666.wordpress.com/empire-star-jussie-smollett/)

[![Empire Label, Jamal Lyon Played by Jussie Smollett](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194272250/QccUeeoz_.png align="left")](https://ferrelux666.wordpress.com/empire-label-jamal-lyon-played-by-jussie-smollett/)

[![Empire Cast, Andre & Wife](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194273590/DwGcey7Fd.jpeg align="left")](https://ferrelux666.wordpress.com/empire-cast-andre-wife/)

[![Empire Cast Casual On Set](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194275241/UBWcVxHVp.png align="left")](https://ferrelux666.wordpress.com/empire-cast-casual-on-set/)

[![A Gruff Jussie Smollett](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194276627/zTjqZTXzC.jpeg align="left")](https://ferrelux666.wordpress.com/a-gruff-jussie-smollett/)

[![A Serious Jussie](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194278410/v_ReInQmY.png align="left")](https://ferrelux666.wordpress.com/a-serious-jussie/)

[![Actor Jussie Smollett](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194279639/u-jlTHMKL.jpeg align="left")](https://ferrelux666.wordpress.com/actor-jussie-smollett/)

[![Cookie & Lucious Cover Image](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194280814/qVpW0f23D.jpeg align="left")](https://ferrelux666.wordpress.com/cookie-lucious-cover-image/)

[![Cookie & Lucious Empire Poster](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194282142/a7wZR6DLn4.jpeg align="left")](https://ferrelux666.wordpress.com/cookie-lucious-empire-poster/)

[![Ferrelux Homepage_March2020-EmpireJussie](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194283950/BO5Uj3G24.png align="left")](https://ferrelux666.wordpress.com/2020/12/24/goodbye-2020/ferrelux-homepage_march2020-empirejussie/)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194285427/VONMRGdlb.jpeg align="left")](https://ferrelux.com/adverts/)
