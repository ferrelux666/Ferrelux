---
title: "Biden Harris Mid-Term Grade \U0001F4DA\U0001F366\U0001F4FA"
date: '2021-07-02T01:35:00.000Z'
slug: biden-harris-mid-term-grade
tags:
  - trump
  - legal
  - hope
  - vp
  - uncategorized
  - politics
  - god
  - washington
  - joe-biden
  - elections
  - prayer
  - investigation
  - laws
  - justice
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672192940869/p1Eeyn4ev.jpeg
canonical: 'https://ferrelux666.wordpress.com/2021/07/01/biden-harris-midterm/'
---
[![Biden, The week Cover](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192898564/Z5OCuCS9G.jpeg align="left")](https://www.pbs.org/newshour/nation/read-the-full-indictment-against-the-trump-organization)

[**“I Fought The Law” – Bobby Fuller Four**](https://www.youtube.com/watch?v=OgtQj8O92eI)

Lex Talionis 😖 The Law Of Retribution

Well Joe, your July 4th Covid-19 Vaccination Agenda won’t be met to fully celebrate opening up The Country again but that’s okay.  Congratulations to First lady Jill Biden for making the cover of Vogue Magazine, but Melania Trump should not have been denied the same respect. Thanks for formally recognizing Juneteenth as a federal holiday. You missed saying “God” on the National Day of Prayer, and the public also criticized you about not properly honoring the 77th annual D-Day. Your grade *from me atleast*, has improved from a C to C+ and here’s why… you keep hanging in there passing useful bills despite the hate. Now your enemies are always gonna hate. They want you out! And they don’t want to see Kamala Harris become our next President. Now on the Black Side, many are not too disturbed by you, but you can’t please ‘em all. The conversations for reparations continue. And a mix of people are still calling Trump their president and that he never lost. And I see the justice system moving in on his corporation. And some of his more extreme Supporters are already vowing to attack as a result. Oh Boy! This mess could have been avoided had a couple of things played out differently. Sitting around the media circuits telling people how incoherent you are as a President and how bad Kamala may be at something, is stupid. They had a chance to leave some things alone before. Somebody’s bad play messed up the whole thing. Complaining now is dumb. If we rewind back a little, people were saying how great it was to get Trump out because he’s unpresidential material. And now they have a seasoned Politician in there, a Senior Citizen they’re making fun of simply because he may have slipped a few times. There is no respect either way. It’s a job a person should not want. If any of the Critics were plucked from their media chair and given the task to run the country, I bet he or she would be under heavy scrutiny from their peers also. So now with The Manhattan DA’s Office continuing their investigation of Trump and his activities, all this pose a potential problem. Are we going to need military forces out there backing off Domestic Terrorists For Trump from rioting? You see, if there’s to be any complaint at all it should be coming from those who know better and was pointing out some things way before. You see before this, I was expecting a fair face off between Trump and Avenatti at the time of the re-election if that got a chance to happen. I feel that any hiccup disrupting that process in any part, eventually led to where we are now. People don’t have a right to complain about you Biden. You were a former VP waiting in the winds competing and destined by The Press to lose. And if they truly wanted that, they should not have fanned the flames against Michael Avenatti the way they did, bringing about a sharp shift in the political wave, washing away any potential of the kind of hopeful change they were looking for from a particular person they wanted leading them. No Democrat who took part in it should be complaining, and no Republican who wanted Trump out should complain either, because they let it happen. If something had a fair chance to happen, then we all would be a little better off despite who won. The Presidential Game is a coveted seat, but someone acting a fool over it, could lose it as we saw. The slightest wrong move, a bad suggestion from somebody, a failed move somewhere could lead to losing power. At the time, Trump had all the chess pieces in place all right and he should have won, but the variable factor of some person’s mind against him, combined with his own folly could explain what went wrong. Now he’s out there dealing with legal issues. Fore-seeing a problem before it happens is always useful. While you were on your way out of Office, it would have been more strategic to let your Minions in The Justice Department drop the charges on somebody before someone makes the connection to now try and use all that against you. Now look where you are. Your problem was not Avenatti so much, but all those other hidden people who did their research and it’s all out there. All this was happening anyway. Had you just kept the distraction of Avenatti in place, people would not have noticed or cared about some things with you. Removing him from The Scene left a gap. And talking about Hunter Biden’s alleged international corruption is going no where. It also brought unwanted attention and scrutiny to you instead. And that mess affected Rudy Giuliani and others around you too. All that wouldn’t have mattered in the Golden Age of Politics. Someone like Avenatti would have just been another Opponent out there and if you lost to him, then it wouldn’t be a big deal. Now, in today’s time with the dumbing down of society and reality TV, the sensationalism and over-reacting to something, is breaking people. You had a formula that was working for you before though. And as we watch this circus play out against Trump, people need to remember that we know from the past that whatever **it is** that has been working in his favor, is still there. The failures here and there is just a part of it. There’s no reason for him to sacrifice *hope* when under his own power all his life he has been able to thrive. What he should have done was had a fore-thought, and left well enough alone. You’re now saying that the investigation against you is politically motivated, just like how Avenatti made the same claim in Court and it was ignored. Well, if they can tie you up like this, then no more further opportunity for presidency. They are roughly using the same playbook you let loose to get Avenatti, right back on you now. This is what happens when you miscalculate and set a course a series of events that gets away from you and takes on a life of its own, and eventually it starts affecting you like life in The Twilight Zone.

Sign,  
Lhisa Mrklon

**Are You Happy With Joe Biden Being Your 46th President? Scroll Down And Leave Your Reply Below.**

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192900470/xAEnz0vQ1.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192902400/fQAtMmhCg.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192903748/MRrLMGn66.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192905188/ufPeTW7ZR.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192906396/Yl7jz9Vv1.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192907963/t013Pu-sh.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192909388/iDE35g2KY.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192910916/tQ2uvsj4_.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192912476/c0cSrmqHO.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192913846/Q9-PUh4qq.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192915150/ixkOD_ijO.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192916622/C1Bopf8R1.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192918252/xWn3sobL1.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192920048/2ra_J9bSS.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192921986/lfxO8Wjzx.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192923501/p0ujgFdIB.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192924989/53Ggq5DjR.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192926270/_n6iWex_n.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192927626/2Umj8dGiA.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192929097/518SJxSe6.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192930581/skxPI9YCy.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192931999/WPp2tmkg8.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192933299/cIq7t14c4.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192934612/cunmHnEnG.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192935886/kvXi6zpdW.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192937485/LSpTwehFY.jpeg align="left")

SHOP ITEMS ON SALE  

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192939219/fzTMg6_gt.jpeg align="left")](https://miniinthebox.8zwg.net/c/3170166/461413/8200?prodsku=4968166&u=https%3A%2F%2Fwww.miniinthebox.com%2Fluxury-clear-view-mirror-flip-smart-case-cover-for-samsung-galaxy-s7-edge-s7-s6-edge-plus-s6-edge-s6-assorted-colors_p4968166.html%3Fcurrency%3DUSD&intsrc=PUI2_2952)
