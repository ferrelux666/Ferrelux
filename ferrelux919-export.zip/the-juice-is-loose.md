---
title: "The Juice Is Loose \U0001F3C9⚽\U0001F3C8"
date: '2017-08-03T18:07:33.000Z'
slug: the-juice-is-loose
tags:
  - legal
  - hotel
  - trial
  - crime
  - court
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195801144/niTOglByF.jpeg
canonical: 'https://ferrelux666.wordpress.com/2017/08/03/the-juice/'
---
\*\*

[![OJ, Juice Is Loose Poster](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195775219/67m94zSJi.jpeg align="left")](https://abcnews.go.com/us/oj-simpson-granted-parole-las-vegas-robbery/story?id=48689499#:~:text=%E2%80%94%20--%20O.J.%20Simpson%20has%20been%20granted%20parole,released%2C%20Simpson%2C%2070%2C%20was%20emotional%2C%20showing%20visible%20relief.)

  
Certum Voto Pete Finem 💑 Set A Definite Limit To Your Desire

\*\*

**Ok, this guy should not have been in jail for just trying to get back his stuff. Even one of the guys that “stole” it from him testified on OJ’s behalf for his release. They all knew it was wrong, but** **what the whole thing was about why he was put behind bars in the first place was that infamous** **trial where he was found ‘Not Guilty’ for the slaying his ex-wife Nicole Simpson & her guy friend** **Ron Goldman. The case was handled bad in the first place, like many such cases. The zoned in on OJ as the killer without regard to some THINGS that has happening in the area at the time,** **mob stuff, drug stuff, & the sort where some evidence led to that. If by chance OJ had ANYTHING to do with it, a private investigator recently years back came out with his book showing step-by-step his findings that the murders were committed by OJ’s mentally & emotionally disturbed son & he was covering for him. A documentary was also done on this theory & it seemed quite convincing but yet the Goldman’s did their documentary recently aired on the same channel 7 station showing OJ as the guilty killer. They never got a dime from him & the only solace was** **the courts using an excessive break in & robbery charge to GET HIM. How fucking crazy, even** **legal experts thought what they charged him for was out of boundaries giving the “robbery” case, HIM trying to stop a hotel selling of his own football items he tried to retrieve with the** **help of some friends.**

**~ Lhisa**

### Did O.J. Kill Nicole? Scroll Down And Leave Your Reply Below.

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195776518/lr5A6L0iE.jpeg align="left")

O.J. Simpson tries on a leather glove allegedly used in the murders of Nicole Brown Simpson and Ronald Goldman during testimony in Simpson’s murder trial June 15, 1995 in Los Angeles. (Photo by Lee Celano/WireImage)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195777779/v43_GLrWc.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195779370/Cq-NfFtW1.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195781045/OmNWEIeqO.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195782569/C7YzEjY61.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195784280/twi4-vqDp.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195785515/imaRAzSlGO.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195786694/4Krfrg6nT.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195787935/yOgOs0jqiL.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195789270/EHiP77hJo.jpeg align="left")

O. J. Simpson appears at an evidentiary hearing in Clark County District Court on May 14, 2013 in Las Vegas, Nevada. Simpson, who is currently serving a nine-to-33-year sentence in state prison as a result of his October 2008 conviction for armed robbery and kidnapping charges, is using a writ of habeas corpus to seek a new trial, claiming he had such bad representation that his conviction should be reversed.

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195790512/Jh7bnGQm_.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195791711/SzSezyJhM.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195793481/Ab4knoAkb.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195794754/U6RsMXyMH.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195796125/lkpqDxwYa.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195797732/eA7gQkJc-.jpeg align="left")

LOVELOCK, NV – JULY 20: O.J. Simpson speaks during his parole hearing at Lovelock Correctional Center July 20, 2017 in Lovelock, Nevada. Simpson is serving a nine to 33 year prison term for a 2007 armed robbery and kidnapping conviction. (Photo by Jason Bean-Pool/Getty Images)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195798952/s0lPngk3r.jpeg align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195800027/WdZo3MPGc.png align="left")](https://ferrelux.com/adverts/)
