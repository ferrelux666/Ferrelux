---
title: "\U0001FACF Dems Shutting Down Trump’s Govt \U0001F3E6"
date: '2024-03-01T19:49:23.349Z'
slug: dems-shutting-down-trumps-govt
tags:
  - nathan-wade
  - trump-case
  - trump-sneakers
  - run-dmc
  - letitia-james
  - republicans
  - government-shutdown
  - nikkihaley
  - '166'
  - rapper
  - nyc
  - apprentice
  - ivanka-trump
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1710386412590/7055f7d7-c22b-4ee8-ac6b-5bd77ad21bbf.jpeg
---
**Quid Consumens Anima Mea Ius Nunc Est Trump ⚖️**  
**What Is Fueling My Soul Right Now Is Trump 💼**\*(NY AG Letitia James)\*

🗽 [Some Things The New York Attorney General Said Against POTUS 45](https://www.politifact.com/article/2022/aug/12/context-what-ny-attorney-general-letitia-james-sai/)

**🎶**[**RUN DMC - IT’S TRICKY**](https://odysee.com/@RapUndergroundUnreleasedorRare:8/Run-DMC---It%27s-Tricky--Music-Video-HD:e)  
*This speech is my recital. I think it’s very vital, to rock a rhyme that’s right on time. It’s Tricky is the title. Here we go. It’s tricky to rock a rhyme, to rock a rhyme that’s right on time. It’s tricky. How is it? Tricky, Tricky, Tricky, Tricky. ~*[Lyrics](https://www.lyrics.com/lyric/6650981/It%27s+Tricky)*😆*

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1709541109422/5b35f1af-bd2f-45dc-b4a5-cbe92d31f809.jpeg align="center")](https://gettrumpsneakers.com)

***Trump’s version of that rap would be***: *This speech is my recital. I think it’s very vital, to win your vote and right on time. It’s tricky with the lawfare. Here we go. It’s tricky to win your vote, to win your vote and right on time. It’s tricky. How we say?*  
*Tricky, Tricky, Tricky Tricky.*

**Ofcourse the title of this article is misleading, *but true*. We are potentially facing a partial government shutdown soon and I left some links below for you to peruse, but the timing is great for what I’m really taking about, *you know,* Trump’s 2024 Re-Election. They are really trying to stymie that, and fortunately for him, The Supreme Court is deciding whether he has Immunity or not. We are 8 months away from going to the polls again, those of you who still vote.**

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1709537291037/a07336bd-a4d8-4e96-ad56-2b09f30bfbff.webp align="center")

**Now it’s Monday, March 4, 2024, and as you know it’s Women’s History Month. Guess who is hanging in the race hoping to become America’s First Woman President, *ding, ding, ding, ding,* that’s right Nikki Haley. Like I said a couple articles back when I covered** [**The Capitol Insurrection**](https://ferrelux.com/a-proud-boys-sentence)**, where Nikki is now, is where I’d expect Former VP Mike Pence to be. You see no one except her Die Hard Fans want her to be President, but hypocrisy shows itself in the end of all this. They should have shown it from the beginning. What she did correctly was an Old School move, *hang in there*. When people dropout, you stay, and now you’re in position to contend for the throne as a Republican with all your Democrat friends helping you. Look, somewhere in the early stages Pence did not feel it was his time. *Really?* You could have stopped this. Now someone less qualified took your place.**

🤔 **Oh Look, She Won The Republican Primary In Washington, DC ✅**

[https://www.npr.org/2024/03/04/1235724479/nikki-haley-wins-dc-republican-primary](https://www.npr.org/2024/03/04/1235724479/nikki-haley-wins-dc-republican-primary)  
[  
](https://www.npr.org/2024/03/04/1235724479/nikki-haley-wins-dc-republican-primary)[https://www.aol.com/news/nikki-haley-wins-district-columbia-014550823.html](https://www.aol.com/news/nikki-haley-wins-district-columbia-014550823.html)  
[  
](https://www.aol.com/news/nikki-haley-wins-district-columbia-014550823.html)[https://www.cbsnews.com/news/nikki-haley-wins-washington-d-c-primary-first-win/](https://www.cbsnews.com/news/nikki-haley-wins-washington-d-c-primary-first-win/)

👉 **UPDATE: SHE DROPPED OUT OF THE RACE**

[https://www.cbsnews.com/news/nikki-haley-dropping-out-republican-presidential-race/](https://www.cbsnews.com/news/nikki-haley-dropping-out-republican-presidential-race/)

[https://www.cnn.com/2024/03/06/politics/nikki-haley-2024-presidential-race/index.html](https://www.cnn.com/2024/03/06/politics/nikki-haley-2024-presidential-race/index.html)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1709799087779/c72f44cf-223e-4c63-ad50-257bb777bdb1.webp align="center")

**And now it’s Thursday, March 7, 2024. So Nikki Haley finally dropped out of the race and has not yet endorsed The Trailblazing Trump. The Supreme Court a couple days ago ruled in favor of POTUS 45 having immunity so that should slow down the lawfare until it’s completely extinguished. Trump is the Head Nominee. People are still guessing who he’ll choose as VP, and he’s said in a recent interview that he knows *who it is*. The choice should be obvious, as prior, it was VICE POTUS 48, but with all that transpired since The 2020 Election, we can’t be too certain. Democrats are out to hurt his Administration, desperately trying to shut it down. They’ll stop at nothing to jimmy his chances and playing chess, he might need to choose *the one* who first of all is in line to his principles, endeavoring to carry on The American Dream and ensuring Its legacy and tasked with protecting all involved in that effort, securing their protection well after.**

❎ **When Pence Ended His 2024 Run For President**

[https://apnews.com/article/mike-pence-2024-president-campaign-republican-trump-0ec44fc2a5b8683f34883e0ea72b2ab2](https://apnews.com/article/mike-pence-2024-president-campaign-republican-trump-0ec44fc2a5b8683f34883e0ea72b2ab2)

[https://fortune.com/2023/10/28/mike-pence-exits-presidential-race-this-is-not-my-time/](https://fortune.com/2023/10/28/mike-pence-exits-presidential-race-this-is-not-my-time/)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1710121298299/062d0a8f-7cc8-4ee9-8ef0-a8f49c3a7f8c.jpeg align="center")

**And now it’s Sunday, March 10, 2024. *Hmm* so Fani Willis’ case against Trump may fizzle out completely on account of her alleged legal indiscretions romancing Co-Counsel Nathan Wade before and during the Trial. Her, Nathan Wade and others were entertaining to watch for a time being questioned at The Stand, as intrusive at it was sometimes. I don’t think any Black Person being used by Puppet Masters to prosecute Trump should stand. It’s a sham and does not help our people. American Politics right now is a farce, and playing into that mess has dire consequences. People who are accustomed to better government are trying to save The Country as others are comfortable with the decline. I hope the cases against Trump drop and stop, I just glimpsed someone’s report that The System is trying to start a new one. Biden’s recent State of The Union Address went well, but they can’t keep pushing that Old Man like that. He apparently knows better when his sound judgment kicks in. About a little over a week before The SOTU, when people were feeling Russia, he remarked to The Public, *something to the effect,* when since did we as Americans start rooting for Russia. He made an intelligent comment, but my answer to that is The State Of Our Consciousness right now, a lot of people are not *feeling* America like we used to and are seeing what life is like beyond our shores anywhere else. John F. Kennedy Jr. is right to speak on that the other day relating The Idea of America and what it stood for and used to be as I have been telling you and he was eloquent. And those old 80s movies and shows exemplify what we were. People don’t *believe* it anymore. We’re not seeing THAT today and we’re certainly not living it. The Country for many of us went from I Am Proud To Be An American to sort of hiding away, closing off from it, and just trying to survive each day. You can’t even do something normal like before without that coming under attack too. The Country is not ours anymore being overran by people we don’t know, in a silent take over and you expect us to participate in that. They are also privately, covertly, and sometimes openly, and even brazenly persecuting people not going along with their sick agenda, showing you what’s *wrong* but yet some of you still miss it.**

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1710385913149/921e0464-8d1a-4bdf-afca-7a28af3b38f3.webp align="center")

**So now it’s Wednesday, March 13, 2024, and I’ll close this article by bringing it back home to Queens, New York where the injustice of one of our legends recently got remedied in The Court System. I’m talking about RUN DMC & JAM MASTER JAY. It was all over The News, see the below links. We lost Jam Master Jay as he sat in his Recording Studio chilling when someone he knew shot him reportedly over being closed out of a drug. Back in the 80s, the Rap Group were known to be cool good guys wearing Adidas and advocating against the use of drugs and other wrong doing. So Jay’s end having anything to do with that and located in the area that gave birth to his rise, is sad. There might be more to it than what’s currently known. At some later point we might find out more in some interview or documentary. Like certain other interesting places in America, a lot of famous people came from Queens including POTUS 45 and Yours Truly, whether born or migrated. The signs are there when you’re a Winner, able to readily identify things for what they are, shift and shock at a whim, handling the situation. We grew up here, and were taught by the very best about certain things in life just like some of you living in similar parts of Our Country. So it should not surprise you to see particular people being stressed a certain way by a corrupt system to somehow navigate and rise above it. And we know where each other live, work and hang out too, trying one another, honing our skills and branching out in life, ready to meet one another again *(or the like)* at some fateful point in life and form VOLTRON fighting that ominous Foe, be it what it may, us surviving these attacks, getting to our feet to form the Blazing Sword, and up we go and down with the might of our justice, slaying that Beast, saving the day, meeting the cheer of The People and finally going home back to our daily lives in The Castle.**  
  
**Sign,**  
**Lhisa Mrklon**  
**#166**

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1710386340449/89f287c5-9a58-427a-bdff-ab592ed0732e.webp align="center")](https://gettrumpsneakers.com/products/gold-sneaker)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1710389870730/4bf25074-92cf-4835-a4fa-6e10d05f8cc1.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1709537635247/ecc44f2b-7fd7-437b-8145-ac6f54450ad5.jpeg align="center")

**🌎 SOME LINKS ON THE PARTIAL GOVERNMENT SHUTDOWN**

[**https://abc7.com/partial-government-shutdown-2024-deadline-federal/14469599/**](https://abc7.com/partial-government-shutdown-2024-deadline-federal/14469599/)

[**https://www.cnn.com/2024/02/23/politics/federal-government-prepares-shutdown/index.html**](https://www.cnn.com/2024/02/23/politics/federal-government-prepares-shutdown/index.html)

[**https://www.cnn.com/2024/02/26/politics/government-shutdown-deadline-congress/index.html**](https://www.cnn.com/2024/02/26/politics/government-shutdown-deadline-congress/index.html)

[**https://www.nbcnews.com/politics/congress/democrats-warn-potential-government-shutdown-biden-calls-meeting-lawma-rcna140428**](https://www.nbcnews.com/politics/congress/democrats-warn-potential-government-shutdown-biden-calls-meeting-lawma-rcna140428)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1710387373282/9697c340-a943-4cb8-b101-a7904a8f8202.jpeg align="center")

**🎤 LINKS ON RUN DMC's JAM MASTER JAY**

[https://en.wikipedia.org/wiki/Jam\_Master\_Jay](https://en.wikipedia.org/wiki/Jam_Master_Jay)

[https://www.nbcnews.com/news/crime-courts/hustlers-grifters-greed-jam-master-jay-met-tragic-end-rcna141076](https://www.nbcnews.com/news/crime-courts/hustlers-grifters-greed-jam-master-jay-met-tragic-end-rcna141076)

[https://www.theguardian.com/us-news/2024/feb/03/jam-master-jay-murder-trial-run-dmc](https://www.theguardian.com/us-news/2024/feb/03/jam-master-jay-murder-trial-run-dmc)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1710388289052/eff97d0b-39c6-4b83-8572-ef55278d23a2.jpeg align="center")

**⚖️ INFO ON PROSECUTOR FANI WILLIS' CASE AGAINST TRUMP**

[https://www.usatoday.com/story/news/politics/elections/2024/03/01/fani-willis-hearing-live-updates/72804883007/](https://www.usatoday.com/story/news/politics/elections/2024/03/01/fani-willis-hearing-live-updates/72804883007/)

[https://www.pbs.org/newshour/politics/watch-live-closing-statements-in-hearing-to-possibly-remove-fani-willis-from-trump-georgia-election-case](https://www.pbs.org/newshour/politics/watch-live-closing-statements-in-hearing-to-possibly-remove-fani-willis-from-trump-georgia-election-case)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1710389402742/5ce88c0d-5632-4f11-8d3b-f97e961a4267.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1710389096288/a220423c-43a2-49de-a98f-22973b268eb2.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1710389143012/b9473408-cc18-42f0-b7e2-4b572ece4d25.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1710390004081/efd0739d-d2ea-4cbd-8336-d14134b4ab0f.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1710390332322/ed770604-d37b-4f88-be46-cedb5b99f2ae.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1710394694399/2c8494f3-36a6-4656-9d3c-18f3282d829f.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1710394727072/f312d0c2-3010-4e0a-a085-4e0597e2b7f9.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1710394748626/b10ee7e3-652f-4c06-b2c3-3cba274e8d59.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1710390480595/81b15ace-a0fd-48bb-b8b7-9d88eacb1295.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1710395357199/70d4f678-75ae-4480-b3ce-9d3a0be70643.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1710395396040/01d519ee-cf15-41e3-a32a-179c837d7212.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1710390995465/f4fbf29e-f819-436c-8c5f-c323e4a59b86.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1710391017842/1f12e0e8-bd46-4b78-9c97-983a81dffcd8.png align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1710391082936/7344ad82-e3f2-45c7-8175-421d8701cfe3.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1710391116636/922c1c8a-4612-4436-83be-b7fa3b688165.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1710391448152/faef98e6-fb35-4123-a21f-c65ab5f9949b.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1710391650750/0d36b241-1f2d-46bd-84d3-9f1a8e982d2b.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1710391674452/8b8c3cce-36a7-4e93-9477-3c8c31ff2b41.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1710392416878/348255ef-8f12-4202-818c-e10e825ecaca.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1710392438532/5f7db216-9e12-46fa-b035-cf1f7054fcfa.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1710393046717/94e8ce5f-2480-41bc-be8e-a1f4c4ed88b4.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1710391926060/644aa6b1-7f06-4e75-8e94-49bfc2436391.jpeg align="center")
