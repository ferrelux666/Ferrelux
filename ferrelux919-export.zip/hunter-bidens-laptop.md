---
title: "\U0001F6AC Hunter Biden’s Laptop \U0001F4BB"
date: '2022-12-07T04:09:46.000Z'
slug: hunter-bidens-laptop
tags:
  - twitter
  - news
  - facebook
  - trump
  - computer
  - social-media
  - administration
  - doj
  - laptop
  - money
  - financial-fraud
  - investment
  - investor
  - energy
  - lawyer
  - attorney
  - china
  - international
  - vote
  - wealth
  - child
  - gas
  - power
  - charity
  - election
  - ukraine
  - topics
  - basketball
  - alcohol
  - negotiations
  - drugs
  - '2022'
  - america
  - russia
  - overseas
  - crack
  - fraud
  - computer-repair
  - president-biden
  - censorship
  - tragedy
  - geek
  - investigation
  - red
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672203889670/3cc98505-1f8e-4666-9acc-e052b2f3c6a1.jpeg
canonical: 'https://ferrelux666.wordpress.com/2022/12/07/burisma/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191349424/-P_uJtIgb.jpeg align="left")](https://rumble.com/search/video?q=Hunter%20Biden%20Laptop)

Lucri Bonus Est Odor Ex Re Qualibet 💵 Sweet Is The Smell Of Money Obtained From Any Source *(Juvenal)*

[STEPPENWOLF ~ THE PUSHER](https://odysee.com/@AVisionDarkly:b/Steppenwolfthepusher:7)

*Let me first congratulate President Joe Biden for successfully negotiating the release of Basketball Olympian Brittney Griner from Russia, but Marine Paul Whelan and Others still need to be freed.*

Notice how I left the topic of Hunter Biden’s Burisma situation alone, not making much mention of it this year or last, due to respect for Joe Biden and his Presidency, and now as more interest is drawn to the case, I have to talk about it. When I first heard accounts of this story before it developed, I thought at the time, why leave your laptop with all that sensitive information like that with some random tech guy? You’re the son of a really big political figure. You should have a vetted private person handling your most sensitive information. And now this albino bug-eyed tech dude *(John Paul Mac Issac)* always wearing that swamp green beret with a pom pom, is on various TV Networks exposing you. But I left the story alone and concentrated on people with cases I cared more about. And as I watched the ongoing saga with Republicans not leaving that Burisma Thing alone, I realized *you know what*, they really have something, but I’m supposed to be on Team Democrat and they’re in power right now and despite that, I did make candid commentaries against certain aspects of The Party, but I’m not out here with an agenda to dump on them either. I do however, have a **RED** side, and I AM feeling a lot of their rhetoric. I remember Joe Biden stating earlier in his Presidency in contrast to Trump, that he will not use his power to interfere with legal cases, and I thought, well that’s fair, but it would be nice to have a hand in helping Someone legally if he or she needed it. Fast forward now where THE HEAT picked up in The Press among his Haters targeting Hunter Biden, and we find where Joe sends a powerful message dressed up as a Dictator on stage with the ominous crimson and shadow background, flanked by Marines, warning you about his wrath. That’s a loving Parent protecting his Child. Well talk of his son, the drugs, the alleged Burisma investment fraud and such ensued and what happened? Well, somewhere in **Mar-A-Lago** a raid took place and Joe is saying he and his Administration knew nothing about it. *Hmm,* you’re a Leader of a Powerful nation with an Archenemy out there vying for your job though. The thing to notice is a Person with a certain past. Remember Joe suffered **A LOT** of personal tragic losses on his way to where he is now. And dealing with Hunter’s substance abuse issues over the years has been trying too. So I get his curt and angry responses to **The Media**. It’s insensitive to be attacking people when they’re down, but this is POLITICS. People who are notorious die-hard Trump Fans don’t care. If Trump has to be held accountable, so does Joe through his son Hunter Biden’s dealings with that Burisma Scandal. And with the recent convictions of prominent persons in The News for White Collar Crimes of less magnitude like Elizabeth Holmes *(Theranos),* Former Top Attorney Michael Avenatti, and others, makes looking at Hunter even more attractive. But let’s LOOK at Hunter for a moment. He has been heavily ridiculed on both sides. Black Men in particular look at those druggy photos of him and see a *Crack Head*, remembering a time in Joe Biden’s Senate history where he had loathsome things to say about Black Criminals and proposed a heavy incarceration time for even the mildest Drug Dealer. And now his Rich Child, Hunter Biden got swept up in The Drug Craze with years of addiction to various ones, to which I say, **\_***Goddam, Goddam, The Pusher Man***\_**, quoting Steppenwolf’s Song. But I have a more Romantic view of the situation, you see. When I look at Hunter Biden’s photos, *(the better ones I presented in the gallery)* I see possibilities. This guy could be well cleaned up and re-presented. He’s educated and not bad looking. He’s got the All-American breeding, a nice Catholic background, the ivy-league upbringing, a career in Finance, he was in The Navy, and he’s a Lawyer with Political experience. He’s been overseas doing that **World Food Program** and other charitable works. If he is that smart in negotiating financial deals and so forth to be so enriched as he is accused of, then he understands other critical things too, like how to negotiate strategic trade deals to bring our Country out of economic collapse. And I’m thinking he looks like a potential Candidate for President. He kind of reminds me of JFK Jr. If The Democrats are skiddish about Joe being unable to serve another 4 years for a 2024 run, well what about his son? Joe has been criticized for being a King, and it would follow suit that the Crown Prince is next in line for The Throne. And what about Burisma, it being a Ukrainian Energy Company and The War going on right now and what led up to it? Well he has an Attorney, and certainly being President like how Trump was with issues, offers certain protections. **The People**, might not want The Biden Administration gone as they showed you at The Polls. I don’t agree with everything, but certain people want their rights. I don’t agree with the argument that Trump-Backed Candidates lost because of him, because they were winning before. Republicans lost this past Election due to **timing**. When Ya’ll went up in The Supreme Court overturning the long-standing *Roe v. Wade*, it opened a panic box. You did it **\_***before***\_** The Election. It set off a lot of Womens Rights groups. And the incident came off the heals of other Womens Rights being trampled on around The Globe in certain Countries. Everything else you were doing was great and you were poised to win this election till you made that move setting yourselves back. Now, let’s get back to Hunter. The Democratic Party is gonna need a new young fresh Candidate for President reminiscent of a time when things were better. I don’t know much about Hunter Biden. And it’s time that The People heard a bit more positive takes on him than all that negative stuff. He needs to come forward. Likewise, if Trump remains encased in legal battles as they are trying to hold him, then one of HIS sons, **\_***Prince Don*\*\* Jr.*\*\*, \*\*****Lord Eric****\*\* or young \*\*****Baron Trump****\*\* must come forth as \*\*****Prince Hunter’s Opponent***\_\*\* and engage in a political duel for President Of The United States Of America.

**Sign,  
Lhisa Mrklon**

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191350764/ekLqCOm5K.jpeg align="left")](https://miniinthebox.8zwg.net/c/3170166/461413/8200?prodsku=5938703&u=https%3A%2F%2Fwww.miniinthebox.com%2Fmen-s-casual-daily-simple-t-shirt-solid-v-neck-short-sleeve-blue-red-black-gray-cotton_p5938703.html%3Fcurrency%3DUSD&intsrc=PUI2_2952)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191351904/bNAxOPhOI.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191352952/XBHzXDw0H.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191354045/sZ98HqqVw.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191355874/cxTmd5AG3.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191357234/YMt9zXETt.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191358433/No68olPPn.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191359693/5VqfZaeqi.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191361497/n3-yieXpR.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191363020/h7-fgOR9N.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191364477/qUqztwBxk.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191366011/7shFuAfJX.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672191367815/Xz8iFVWVA.jpeg align="left")

### Like this:

Like Loading...

### *Related*
