---
title: "June 2026 Topics \U0001F614 \U0001F620 Calm & Restless"
date: '2026-06-02T02:10:00.000Z'
slug: june-2026-topics-calm-restless
tags:
  - juneteenth
coverImage: >-
  https://cdn.hashnode.com/uploads/covers/6269a04eaedfbdb0ce1a65f6/74a34ed1-0e2a-4258-843f-e3992a920b3b.jpg
---
Today is Monday June 1st 2026, and we begin with this 4th annual evaluation of 18 topics I held over from discussing to present at this time for public consumption in determining which one stands out as the most significant one to award this year. The past 3 winners of previous years were Andrew Tate (2023), Former President at the time, Donald J. Trump (2024) & New Jersey Senator Corey Booker (2025) where they all had issues or a huge problem to take on and somehow defeat.

I'LL WRITE MORE SOON

I’LL SET A PHRASE & SONG REAL SOON TO THIS WITH PICS AND SIT TIGHT AS I POST THE REST OF THIS MATERIAL

So today is now Tuesday June 30th 2026, the last day of this month, since my original post opening up this article and what has changed, well, we may not do just 18 for this time around, let’s make it 21 since too many topics popped up this year. There are also carryover issues from the past years I’ll mention. And what’s going on with Me? Well, Life is real busy. Like many of you dealing with the day to day living amidst whatever your Profession or Business is, certain things had hit me this year on short notice that I had to deal with. For those of you who can relate on a Personal or Corporate level, I had to do a major overall on replacing certain Services I use to Operate through for Contingency Purposes which took up a lot of time and although that’s not unusual, it was quite a few resources I use where those Companies were doing internal changes of their Resources and taking their Business on another path and these are Major Corporations who do this sort of thing all the time but this year it was multiple, not just the one or two, and adjusting to the changes under a new Structuring on My Back End has been daunting amidst other responsibilities and to unwind from all that Stress. And certain parts of my re-adjustments are not over yet, but I’m here. It reminds me of the days way back when I worked in The Corporate World for several Fortune 500 companies when all of a sudden Management recives orders to make some major change by such and such a date or complete some Project and we’re all on it either creating a monstrosity having to do with some legal or financial thing or we had to change over all our shit to a new System. The process was tense and everything had to be right. In my case, parts of it looked and felt like yet another odd harassing big brother cyber-attack against my Modus Operandi as intelligent as My Networking is why I use certain companies, resources and technology based off my research and evaluation of things. So if I am using your company and resources anywhere, I thought enough of you to trust doing so atleast for a time in some cases which is a credit to you, especially coming from the kind of background I have in The Private Sector & Government. What I noticed over the years is that my Spying Haters are slow on this, and when they finally realize WHY I chose something or setup something a certain way using this Platform instead of this other one or service on the forefront or backend, is because I’m aware of particular information that goes beyond the norm to look for, plus I tested it enough to know better. I’m also currently expanding My Outfit and prefer to work with certain people and corporations paying the same kind of attention to critical things and it’s really hard to find that kind of dedicated interest. A lot of good services come and go. You see one day what looks like a big impressive company and before the following year is up, they’re gone with all that loan and grant money and credentials and backing Investors all a waste of time and resources. Many long standing Giants of a bygone Era are no longer operating. Some of which I once worked with. I try to keep things real simple. Whatever my complications are behind-the-scenes are carefully thought of even if I have to take time off to handle that, then come back online with these topics like I never left. Thanks for your Patience.

Below are the hot issues, but first let’s re-visit a two from previous years, going forward. Centennial High School Student Karmelo Anthony; it’s a shame that the whole incident with another Texas Teen, Austin Metcalf of Memorial High School happened and it extended further into a racial issue. He lost his self defense trial getting 35 years by a mainly White Jury with no Blacks for murdering Austin and in response his father, Jeff Metcalf went on a drunken binge spewing out all kinds of bigoted comments in a Video. Karmelo now has a heavyweight Legal Team doing his Appeal Pro Bono. As for College Graduate Luigi Mangione, his Defense Attorney has been making very successful headway steering the course of his case despite him killing United Healthcare CEO Brian Thompson. His Team was not able to get the Death Penalty off the table but there was a TMZ Broadcast saying that he might just only serve 5 years for that using a rare defense.

1.  THE NEW YORK KNICKS WIN 1ST NBA CHAMPIONSHIP
    
2.  N.A.S.A SENDS THE FIRST BLACK MAN TO ORBIT THE MOON
    
3.  DEVASTSTING EARTHQUAKE IN VENEZUELA
    
4.  MUSICAL KILLER D4VD
    
5.  GOLFER TIGER WOODS MARCH 27TH CAR CRASH
    
6.  IRAN’S STRAIT OF HORMUZ CONFLICT WITH TRUMP
    
7.  CHINA & THE CURRENT DALAI LAMA SELECTION FEUD
    
8.  SEVERE GLOBAL FAMINE IN 2026
    
9.  THE BACHELORETTE TAYLOR FRANKIE PAUL SCANDAL
    
10.  GLOBAL CHILD INTERNET SAFETY
     
11.  NBC ANCHOR SAVANNAH GUTHRIE’S MISSING MOTHER
     
12.  THE CURE FOR DEAFNESS
     
13.  NEW PANDEMIC SCARE WITH HANTAVIRUS & EBOLA
     
14.  FRANCE ENDS KING LOUIS XIV RACIST COLONIAL CODE NOIR
     
15.  JOURNALIST DON LEMON ICE-CHURCH ARREST ON JAN 30TH
     
16.  PAM BONDI BATTLES HER OWN LEGAL PROBLEMS
     
17.  LUPITA NYONG’O STARS AS HELEN OF TROY
     
18.  THE 2026 & 2028 OLYMPICS TRAVEL BAN FOR COLORED ATHLETES?
     
19.  2026 FIFA WORLD CUP RACISM
     
20.  SUPREME COURT RULES AGAINST TRANSGENDER MEN IN SPORTS
     
21.  JUNETEENTH HOLDING ON BY A THREAD
     

I’m Experiencing TERRIBLE TECH PROBLEMS So I’ll POST LATER, BUT THE WINNING TOPIC WAS THE CURE FOR DEAFNESS.

Sign,  
Lhisa Mrklon

#198
