---
title: "Happy New Year 2020 \U0001F38A\U0001F9E8\U0001F387"
date: '2019-12-29T23:15:08.000Z'
slug: happy-new-year-2020
tags:
  - blog
  - review
  - gallery
  - new-year
  - usa
  - world
  - happy
  - queen
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672194533903/zDMjMtIov.png
canonical: 'https://ferrelux666.wordpress.com/2019/12/29/newyear2020/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194496782/eQ5Ybpa8u.jpeg align="left")](https://www.ferrelux.us/)

\*\*[Michael Jackson ~ “Heal The World”](https://www.youtube.com/watch?v=BWf-eARnf6U)  
\*\*

\_Interdum Volgus Rectum Videt, Est Ubi Peccat  ✌  At Times The World Sees Straight, But Many Times It Goes Astray  
\_

IT’S THE END OF A DECADE! I have to agree with the Queen of England calling the past year “bumpy”. I thank you all for following these posts. I wanted to end with the last 2 being mild about TV shows & letting them run to close out the year positive. I have some heavier topics you’ll read about sometime next year, so the controversial issues continue. I’ll also post some follow up material on past posts. We don’t know what 2020 will bring. Soooo much stuff is going on. Stay Tuned…….

[WHO DIED IN 2019](http://www.youtube.com/watch?v=P7nVerVIOPg)

[https://theweek.com/speedreads/886163/queen-elizabeth-acknowledges-2019-bumpy-year](https://theweek.com/speedreads/886163/queen-elizabeth-acknowledges-2019-bumpy-year)  
[https://www.townandcountrymag.com/society/tradition/a30260865/queen-elizabeth-christmas-message-transcript-2019/](https://www.townandcountrymag.com/society/tradition/a30260865/queen-elizabeth-christmas-message-transcript-2019/)

Peace,  
Lhisa

### How Did The Last Decade Treat You? Scroll Down And Leave Your Reply Below.

[![Ferrelux Homepage_Jussie Smollet-Aug2019](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194498204/kVXrcz1OQ1.png align="left")](https://ferrelux666.wordpress.com/ferrelux-homepage_jussie-smollet-aug2019/)

[![Ferrelux Homepage_HappyNewYear2020](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194499588/kN6lIgrLv.png align="left")](https://ferrelux666.wordpress.com/2020/12/24/goodbye-2020/ferrelux-homepage_happynewyear2020/)

[![Ferrelux Homepage_ShowsMissed2019](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194501224/l-5gfQ9oH.png align="left")](https://ferrelux666.wordpress.com/ferrelux-homepage_showsmissed2019/)

[![Ferrelux Homepage_NotMissedShows2019](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194504218/mrnJnuqTZ.png align="left")](https://ferrelux666.wordpress.com/ferrelux-homepage_notmissedshows2019/)

[![Ferrelux Homepage_MassShootingsOct2019](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194505843/SQ6cbr0HP.png align="left")](https://ferrelux666.wordpress.com/ferrelux-homepage_massshootingsoct2019/)

[![Ferrelux Homepage_MissingCDCWorker-Oct2019](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194507196/l5cq5519q.png align="left")](https://ferrelux666.wordpress.com/ferrelux-homepage_missingcdcworker-oct2019/)

[![Ferrelux Homepage_SchoolScandal2019](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194508784/v_IVobHz5.png align="left")](https://ferrelux666.wordpress.com/ferrelux-homepage_schoolscandal2019/)

[![Ferrelux Homepage_Avenatti-Nike-Aug2019](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194510553/ePkIO8UXD.png align="left")](https://ferrelux666.wordpress.com/ferrelux-homepage_avenatti-nike-aug2019/)

[![Ferrelux Homepage_Kaepernick-Sept2019](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194512225/xl-rb2FVA.png align="left")](https://ferrelux666.wordpress.com/ferrelux-homepage_kaepernick-sept2019/)

[![Ferrelux Homepage_Rkelly-Aug2019](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194513524/awrltm3jO.png align="left")](https://ferrelux666.wordpress.com/ferrelux-homepage_rkelly-aug2019/)

[![Ferrelux Homepage_MuellerReport-July2019](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194514846/vGW3JhVHe.png align="left")](https://ferrelux666.wordpress.com/ferrelux-homepage_muellerreport-july2019/)

[![Ferrelux Homepage_Biden-July2019](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194516135/8X4Vze0pE.png align="left")](https://ferrelux666.wordpress.com/ferrelux-homepage_biden-july2019/)

[![Ferrelux Homepage_RaptorsVsWarriors_6-21-2019](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194517422/5Ih8fIiUr.png align="left")](https://ferrelux666.wordpress.com/ferrelux-homepage_raptorsvswarriors_6-21-2019/)

[![Ferrelux Homepage_AvengersEndgame6-2019](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194518669/UFWQyyUs0.png align="left")](https://ferrelux666.wordpress.com/ferrelux-homepage_avengersendgame6-2019/)

[![Ferrelux Homepage_SussexRoyalBaby](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194520048/47Kk6iPo3.png align="left")](https://ferrelux666.wordpress.com/ferrelux-homepage_sussexroyalbaby/)

[![Ferrelux Homepage_McCain-2019MemorialDay](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194521539/YUOeEIFOk.png align="left")](https://ferrelux666.wordpress.com/ferrelux-homepage_mccain-2019memorialday/)

[![Screenshot (8)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194523171/Ve5wcjgAp.png align="left")](https://ferrelux666.wordpress.com/screenshot-8/)

[![Ferrelux Homepage_Easter2019](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194524456/eKMEYFdbD.png align="left")](https://ferrelux666.wordpress.com/ferrelux-homepage_easter2019/)

[![Ferrelux Homepage_March2019-Creed](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194526009/xAaHom8BN.png align="left")](https://ferrelux666.wordpress.com/ferrelux-homepage_march2019-creed/)

[![Ferrelux Homepage_Bush Senior-Feb2019](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194527159/gh5o586uer.png align="left")](https://ferrelux666.wordpress.com/ferrelux-homepage_bush-senior-feb2019/)

[![Ferrelux Homepage_Feb2018-Aquaman](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194528802/tRJp_7hNN.png align="left")](https://ferrelux666.wordpress.com/ferrelux-homepage_feb2018-aquaman/)

[![ferrelux homepage_jan2019-newyear](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194530524/48K9V7_uZ.png align="left")](https://ferrelux666.wordpress.com/ferrelux-homepage_jan2019-newyear/)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194531928/ArIWpKKOG.png align="left")](https://ferrelux.com/adverts/)
