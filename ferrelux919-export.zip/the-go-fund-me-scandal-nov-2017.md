---
title: "\U0001F3DE The Go Fund Me Scandal (Nov 2017)\U0001F3CC\U0001F3FB‍♂️"
date: '2019-04-28T20:02:45.000Z'
slug: the-go-fund-me-scandal-nov-2017
tags:
  - money
  - scam
  - crime
  - fundraising
  - fraud
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195115375/l_UL4Nhl6.png
canonical: 'https://ferrelux666.wordpress.com/2019/04/28/gofundme/'
---
![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195098280/som-JbC3L.jpeg align="left")

Playlist ~ [Songs About Money](https://myspace.com/ferrelux/mixes/money-718965)

*Magnus Inter Opes Inops* 🤑 *Poor In The Midst Of Great Riches (Horace)*

What can I say about this case? well……., it shows how a scam is easier to fund than a perfectly legitimate cause. This story pops up every once and again in the news on the latest legal event. Well, they need to bury it already, it’s all over. There is NOTHING else they can do to turn this around. So this was a feel good story about a homeless vet who gave his last $20 to help a stranded female fill up her car to get home. And in gratitude, so touched by his help, she & her boyfriend set up a GoFundMe page to raise $10,000 to help him get off the streets. Oh but many people were touched by the story too that they donated their money to help him & they raised over $400k for his cause. The couple were on TV talking about it and all was well until greed set in. Everything was okay as long as everyone shared the wealth as agreed, BUT the couple controlled all the money and the so-called homeless Veteran, decided to sue. People still felt sorry for him as if he was being victimized when in fact it was all a fraud that went wrong and the truth unraveled. All they had to do was get along, no one would have been the wiser. Now they ended up in an embarrassing legal problem. I feel more sorry for all the people who ever tried using Crowdfunding sites unsuccessfully. I bet there are many good things people need money for, but the effort didn’t quite take as a lie would.

**~ Lhisa Mrklon**

\*\*[ALL THE LINKS ON THEIR GO FUND ME SCAM](https://www.google.com/search?ei=XgHGXNPXBq6k_QbMmarIBw&q=go+fund+me+scandal&oq=go+fund+me+scandal&gs_l=psy-ab.3..0l3j0i22i30l6.7147.9043..9306...0.0..0.360.1405.1j6j0j1......0....1..gws-wiz.......0i71j0i131j0i67j0i3j0i10j0i22i10i30.Gokeyxq8UoI)  
\*\*

[![Screenshot (8)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195099884/kXSpFT_Nb.png align="left")](https://ferrelux666.wordpress.com/screenshot-8/)

[![MEGYN KELLY TODAY -- Pictured: Mark D'Amico, Kate McClure and Megyn Kelly on Monday, August 27, 2018 -- (Photo by: Nathan Congleton/NBC/NBCU Photo Bank via Getty Images)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195101326/hQM2BhyjF.jpeg align="left")](https://ferrelux666.wordpress.com/megyn-kelly-today-season-1/)

MEGYN KELLY TODAY — Pictured: Mark D’Amico, Kate McClure and Megyn Kelly on Monday, August 27, 2018 — (Photo by: Nathan Congleton/NBC/NBCU Photo Bank via Getty Images)

[![untitled](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195103593/oSvUaYmR8.png align="left")](https://ferrelux666.wordpress.com/untitled-8/)

[![6214950-0-image-a-2_1542272460131](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195104915/b6YTZtWbk.jpeg align="left")](https://ferrelux666.wordpress.com/6214950-0-image-a-2_1542272460131/)

[![maxresdefault](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195106225/kf3MjOQoj.jpeg align="left")](https://ferrelux666.wordpress.com/maxresdefault-7/)

[![merlin_148144548_a6c014ba-af79-4dd2-aa1c-cfd24a4d83e6-articleLarge](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195107390/sQ6thFCF_.jpeg align="left")](https://ferrelux666.wordpress.com/merlin_148144548_a6c014ba-af79-4dd2-aa1c-cfd24a4d83e6-articlelarge/)

[![rs_1024x759-181120113700-1024-Mark-DAmico-Kate-McClure-Johnny-Bobbitt](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195108803/bCP2xs0S84.jpeg align="left")](https://ferrelux666.wordpress.com/rs_1024x759-181120113700-1024-mark-damico-kate-mcclure-johnny-bobbitt/)

[![4104439_083018-wpvi-homeless-gofundme-investigation-11pm-video-CC-vid](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195109984/oAu2cstlS.jpeg align="left")](https://ferrelux666.wordpress.com/4104439_083018-wpvi-homeless-gofundme-investigation-11pm-video-cc-vid/)

[![190110_wnn_gofundme_arrest_hpMain_16x9_992](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195111703/qjns_ifJR.jpeg align="left")](https://ferrelux666.wordpress.com/190110_wnn_gofundme_arrest_hpmain_16x9_992/)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195113452/O-M1rwlrt.png align="left")](https://ferrelux.com/adverts/)
