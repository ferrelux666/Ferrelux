---
title: "\U0001F4A3Roving Protesters Attacking Racist Statues\U0001F4E2"
date: '2020-06-27T19:16:09.000Z'
slug: roving-protesters-attacking-racist-statues
tags:
  - ads
  - freedom
  - people
  - finance
  - natives
  - africa
  - global
  - politics
  - christian
  - america
  - bible
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672194092984/Oskbn4DoH.jpeg
canonical: 'https://ferrelux666.wordpress.com/2020/06/27/racist-statues/'
---
[![Another Statue Bites The Dust](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194059653/YnxQ9qcKE.png align="left")](https://www.thesun.co.uk/news/11826866/topple-the-racists-map-statues-full-list/)

[**“By The Rivers of Babylon” – The Melodians (1970) adapted from The Bible, Psalms 19 & 137**](https://www.youtube.com/watch?v=e57brp0HGDA)

*Dimitte Populum Meum*  😈  *Let My People Go*

Congratulations Black People, on running amuck with the Global Protesting taking the lead with your other racial allies helping to fight your cause and getting some new civil laws passed in our communal interest. You’re successfully going around all media, attacking brand imagery like Aunt Jemima & Uncle Ben’s but when is it going to stop? I get the need to remove what are perceived as historically racist statues but once that door is open, we’re going to need to go all the way with that. Like, removing every last object depicting, symbolizing, or anything that reminds you of systematic oppression. And somehow this is realistic to you amidst a system you still don’t yet control. You see, that should have been done back in the Colonial days when the Slave Uprisings were happening all over the world. What happened? Well, you stopped. Some bargaining & treaties were made & you went right back in your place while THEY remained ruling like you’re poised to do now. So you’re comfortable just as long as you are given the right to sit alongside a White person while riding a bus, or given an extra dollar to work, or offered some recognition as “The First Black to” do something. Now you’ve rustled some feathers that we’re seeing a pushback from some uncontained racists randomly targeting unsuspecting Blacks again with hate crimes. ALL THIS, coming off the heels of a series of events starting from that Covid-19 shit, government mandates to quarantine & mask-up in public, the rationing of needed food & supplies, the racist deaths of a few Blacks targeted during this sensitive time, and Black Outrage over it. So ofcourse, you have a right to Justice, but what concerns me more is the real revolution that needs to happen within the race. You still don’t have that. Before Colonization, we had our own land rich in resources, an intact culture & customs, homogeneous race, our own non-Christian & non-Muslim & non-Jewish faith, our own Mother Tongue, a Calendar, a system of work & finance, our own system of education, our own government, our own society and empires, coming of age & marriage ceremonies, & so forth. Now we’re in a ridiculous structure to date, where another race of people are controlling whether you have a right to a job, financial accounts, housing, or the right to generally live your way as a free people. Billions of dollars are put into studying your ghettoism, nigger shit, and how to keep those conditions alive to ultimately destroy you. But do you know why for centuries now they are still unable to exterminate you? Well, your Ancestors know & have left a timeless blueprint for you, that whosoever has the wisdom to, & can read that shit, will know & can lead. And you know what, you don’t even need that if you are intuitive enough, it is very much in your genetics. So it’s imperative you get that and know you are One with The Universe. What you need to do is recognize the god in you & the god in the one before you. You have the power to manifest reality. When the first Europeans came to Africa, the folklore about The People there were well known. It was so important to The White Man to convince you that it was The Devil, and dispel the Magic of Egypt, drive out the tribal Shamans & Witch Doctors of The West and the East, and poison the minds of Africans to give up their gods whom they knew for millennias, in favor of a European god-figure named Jesus Christ, till it hit the Southern parts of the continent. And when you did that, you lost the one thing that defined you, empowering a foreign god to enslave you to this day. You can argue all you want that the original Jesus of the Scriptures is Black & so forth, but you’re in a spell right now. You spiritually co-signed on another people’s beliefs agreeing with them that HE IS GOD. So it’s no wonder why THEY are seeing you as a stupid people to piss & shit on because the bible says you’re their property since you subscribe to that thinking. NOW, before Colonization, you had respect. They were fearful of those wild rituals you did where you had spiritual power, seeming god-like and news of it can only be found when really digging through the archives to learn some story that baffled European soldiers who were attacking Africans in their primitive habitat, but got mysteriously fucked up, to which they attributed what happened to witchcraft. Believe me the shit works. So I caution you to get back to the root of things. Stop wasting time with theatrics. You need way more self-respect, worship of each other, and some code of conduct only WE understand. The time is coming when spiritually, we will see WHO is The Master.

LHISA,  
Goddess Supreme

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194060911/BaVN_z9C-.png align="left")](https://www.thesun.co.uk/news/11826866/topple-the-racists-map-statues-full-list/)

### Will Our People (“Black”) Ever Be Free? 😮🤔 Scroll Down And Leave Your Reply Below.

[![Mandela Statue](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194062219/rDpbp-_5_.jpeg align="left")](https://ferrelux666.wordpress.com/mandela-statue/)

[![Nelson Mandela Statue](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194063531/CIVymdNAM.jpeg align="left")](https://ferrelux666.wordpress.com/nelson-mandela-statue/)

[![Ferrelux Homepage_RacistImagery-June&July2020](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194064748/bB_er4nK-.jpeg align="left")](https://ferrelux666.wordpress.com/2020/12/24/goodbye-2020/ferrelux-homepage_racistimagery-junejuly2020/)

[![Kaepernick Time Magazine Cover](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194066330/mvcyIfqug.png align="left")](https://ferrelux666.wordpress.com/kaepernick-time-magazine-cover/)

[![LionofJudah99](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194067699/xr0P_TR9D.png align="left")](https://ferrelux666.wordpress.com/lionofjudah99/)

[![Haile Selassie Book](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194068936/7oIRCmOmN.jpeg align="left")](https://ferrelux666.wordpress.com/haile-selassie-book/)

[![Christopher Columbus Statue Taken Down](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194070390/LoqWyYBle.png align="left")](https://ferrelux666.wordpress.com/christopher-columbus-statue-taken-down/)

[![Churchill Statue Disrespected](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194072030/sAke_8Qxx.png align="left")](https://ferrelux666.wordpress.com/churchill-statue-disrespected/)

[![Another Disrespected Statue](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194073719/OSIhe5bOs.png align="left")](https://ferrelux666.wordpress.com/another-disrespected-statue/)

[![Global Action Against Racist Monuments](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194075247/Fjdi1uDZu.png align="left")](https://ferrelux666.wordpress.com/global-action-against-racist-monuments/)

[![Robert Downey Jr In Blackface](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194076738/Pgl3MVSuU.png align="left")](https://ferrelux666.wordpress.com/robert-downey-jr-in-blackface/)

[![Jimmy Kimmel In Blackface](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194078088/79a6-y5p_.png align="left")](https://ferrelux666.wordpress.com/jimmy-kimmel-in-blackface/)

[![Some Statue Disrespected](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194079766/df1cYD9Fr.png align="left")](https://ferrelux666.wordpress.com/some-statue-disrespected/)

[![Statue of a Colonizer & Christian Subduing Native American](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194081216/H6ywFZwXZ.png align="left")](https://ferrelux666.wordpress.com/statue-of-a-colonizer-christian-subduing-native-american/)

[![Another Statue Bites The Dust](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194082440/GmQ3K9PoD.png align="left")](https://ferrelux666.wordpress.com/another-statue-bites-the-dust/)

[![Roosevelt, Native American & Negro](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194084325/r9D6gm88B.png align="left")](https://ferrelux666.wordpress.com/roosevelt-native-american-negro/)

[![Christian Statue Comes Down](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194085708/__POHsXqb.png align="left")](https://ferrelux666.wordpress.com/christian-statue-comes-down/)

[![The Uprising](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194087164/u9LEmYmyR.jpeg align="left")](https://ferrelux666.wordpress.com/the-uprising/)

[![3 Black Male Models](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194088801/sD7ryqaMXy.png align="left")](https://ferrelux666.wordpress.com/news/3-black-male-models/)

[![Aunt Jemima & Uncle Ben](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194090002/YMB2q0ILV.png align="left")](https://ferrelux666.wordpress.com/aunt-jemima-uncle-ben/)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194091649/PMw8p4mGs.png align="left")](https://voropro.com/training/get-your-real-estate-license/invite/2654/)
