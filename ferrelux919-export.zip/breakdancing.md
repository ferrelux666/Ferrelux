---
title: "\U0001F938\U0001F3FC‍♂️Break\U0001F46FDancing\U0001F938\U0001F3FC"
date: '2013-07-22T14:28:14.000Z'
slug: breakdancing
tags:
  - cool
  - entertainment
  - street
  - electric
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672196111705/0GBfVNNgz.jpeg
canonical: 'https://ferrelux666.wordpress.com/2013/07/22/break-dancing/'
---
![Break Dancer, Sunset](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196104752/BC8YNeKE1.jpeg align="left")

\*\*A quick one folks. Just got done viewing the below youtube video & was mesmerized by the technique. When I usually view beak dancing live & in the flesh, obviously the performance is great. Seeing those moves on TV, not so shocking, but in watching this old school style makes the danceform look other worldly. The perfect body precision, fluid movement & so on. Too Cool. ~ Lhisa Mrklon  
\*\*

[![Break Dancers, London 1983](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196105926/QTwrNZJvE.jpeg align="left")](https://ferrelux666.wordpress.com/break-dancers-london-1983/)

[![Break dancers, Los Angeles 1984](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196107427/_0gJODOBZ.jpeg align="left")](https://ferrelux666.wordpress.com/break-dancers-los-angeles-1984/)

[![Break Dancer, Girl](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196108774/W6Ia5CLr0.jpeg align="left")](https://ferrelux666.wordpress.com/break-dancer-girl/)

[![Break Dancer, Chick](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196110234/v3HDF5W1t.jpeg align="left")](https://ferrelux666.wordpress.com/break-dancer-chick/)

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/glM0XaGhYl8?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>
