---
title: "\U0001F93AThe Dark Swords Game Suck⚔️"
date: '2013-03-08T17:00:00.000Z'
slug: the-dark-swords-game-suck
tags:
  - game
  - scam
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1678826718131/b954bb85-c25b-4f7c-b682-6ff33ebc18a6.jpeg
canonical: 'https://ferrelux666.wordpress.com/2013/03/08/dark-swords/'
---
Hi folks, I had to remove the DarkSwords.eu game link because while setting up this site, I selected the so-called best fantasy games & after trying to play it, I realized how stupid it was, & the game client won’t let you to cancel your account; you’ll have to go to the main site & send a support ticket & hope they respond. On the surface, the game looks like a nice Tolkien type game only to log in to the client & find that there’s a discussion on buying a lottery package. I gave it a chance & there was no commencement of a game at all, just chatter. I’m going through each posted game I have on here, making sure that they are quality games because the nature of my site has to do with credible things I see as good to suggest to others. I have limited menu slots, but if you know of other games that are really good, let me know, because I may get rid of other games, or the game itself may no longer be available.

~ Lhisa  

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1678827136501/a3e9508f-b1c4-4966-aec9-f1a4eef8ae62.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1678827100129/ada46a88-52a7-470f-9292-7dee929005b4.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1678827159371/b8df35e4-73ed-4938-a4e5-9999899879c5.jpeg align="center")
