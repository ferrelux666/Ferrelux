---
title: "Biden Wins \U0001F5F3\U0001F4CA\U0001F37A"
date: '2020-11-19T19:33:33.000Z'
slug: biden-wins
tags:
  - trump
  - country
  - community
  - language
  - media
  - usa
  - global
  - skin
  - franchise
  - politics
  - democracy
  - election
  - america
  - biden
  - voting
  - president
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672193732908/C7yrHCnrw.png
canonical: 'https://ferrelux666.wordpress.com/2020/11/19/biden-harris/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193676314/tkm9ySQYQ.jpeg align="left")](https://www.usnews.com/news/elections/articles/2020-11-07/joe-biden-wins-the-presidential-election-defeating-donald-trump)

\*\*  
[“Wind Of Change” – Scorpion](https://www.youtube.com/watch?v=n4RjJKxsamQ)

\*\**Factum Infectum Fieri Nequit* 🎆 *A Thing Done Cannot Be Undone*

Well Congratulations Joe, you showed people that an Old Codger like yourself can still make an upset, fighting a fearsome Dude and winning. You know I’ve been hard on you in my past couple articles pertaining to your political efforts and I still won’t relent because it’s the duty of The Public to exercise their inalienable right to criticize. You need to know what people really think. And you can hear it here, but before I get to that, let me congratulate the VP Elect Kamala Harris for lining up your career just right, that eventually led to you becoming a fair prospect for the Presidency. Aside from whatever common racism you would expect, the only criticism out there is mainly coming from Black American Men pointing out that you have no linage in this Country to have been chosen since your parents are Indian from your Mother’s side, and Jamaican, from your Father’s, and they’re right. And that whole mixed race thing with you being celebrated as the First “Black” and “Asian” Female Appointed as Vice President is also debatable language. So anyway, anybody studying certain moves by The Government already sees this whole thing as a scam. And I don’t mean Trump contesting the Democratic victory. I’m talking about an old known playbook from back in the day. **You see, when one Party enters the Office and serves, then the other Party wins. Coincidence? No! It’s a numbers game. Republicans are odd, and Democrats are even: George Bush Sr, (41) Bill Clinton (42) George W. Bush (43) Barack Obama (44) Donald J. Trump (45) and now Joe Biden (46).** If all works out well, that’s how that normally goes. You’re not fooling anyone. To meet certain political agendas, things get manipulated a bit. You get a terrible guy in there to do certain things and then you time up something new. And Poor Trump having to bear a reputation he may not be guilty of. No one else wanted the job right? He’s a Trooper. Democrats have a reputation to seem all encompassing with the perverse multi-culturism, the welfare, the gay agenda, the mis-guided feminism, and every other odd societal ill they encourage into law that’s adversely affecting the society, which Republicans are trying to correct. Because really, we’re in a hypocritical society. We pretend we like and accept certain people and things when in reality **IT’S** the problem. When you say you’re The Mightiest Nation in the world, that was clearly true at one long point in history, until you compromised it by opening up your borders and airways to people who don’t belong or share your culture, religion, language, or philosophy. If you’re a parent raising your child in a nice loving secure home with all he/she could want, you don’t pick up a stray kid you feel sorry for out there who in every way is unlike your child and treat him/her as an equal roaming about your property. It’s naïve and you know what could happen, that stray you picked up off the streets may feel he/she is more entitled to the wealth of the home more so than that rich kid who should inherit it, and gives he/her a black eye. You’re seeing this now play out in certain American neighborhoods with an East Indian/Muslim society in general, frequently expressing contempt against another dark-skinned group of people who have been living here for many generations. WHY? Well they’re most loyal to their culture, traditions, language, and faith. The Constitution is a joke to them. Privately they engage in suspicious activities attempting to undermine that White American Man’s control. They’re organized, and move to buy up known American franchise and mainly hire their own. They change the language of signs and menus to their mother-tongue. They move their people into areas of government where they can attempt to police all the other races amongst them since they are naïve to their plot. Now the typical Racist out there is wasting time attacking Black and Hispanic People because they share more in common with them than they do an East Indian or Arab. The only way they’re going to notice the surprise takeover, is when they blink and see their neighborhood completely covered with them. And you know what will happen, **\_***a race fight***\_**. And I can see YOU guileless Democrats still caught up in that pipe dream that everything is all culture, peace and love. You’ll need a “racist” Republican setting things straight to maintain a Western Christian Democracy controlled by The American People. **And you had one.** What best than using the same designated Republican Man to continue as he was, **doing some things**, a Democrat with a nice reputation should not be caught doing. Simply hiding behind him, was a great cover to set back the order. And by the way, I’m not a great big fan of Trump, but I appreciate that he can see the obvious and waste no time to react. Do you wonder why certain Blacks great and small still support him as odd as that may seem? It’s because they’re looking at certain critical things important to them on a bigger scale as opposed to a Democrat who claims he or she cares about them. All that back history matters. Who’s rolling with you are people who haven’t figured out something yet. They’re caught up in that dream smoke. If one of the select few Democrats I actually liked did not get the chance to be The Elect and win, I would have been content seeing Trump continue to rule because what he’s doing is stable. It’s a trait of Republicans to be consistent in fulfilling deeds. You see like other Blacks who understand, I’d rather watch him go another term doing what he does, and only come out and fight where necessary if we disagree with a portion of that edict. NOW, we’re poised to have to deal with democratic uncertainty, a rollback of conservatism, a proliferation of gay Candidates coming out transgenderizing everything and it’s very clear that The Democrats is a Gay Party and we know that your main priority is under-mining the centuries long Church Teachings openly promoting a gay lifestyle all over TV as natural. When all that gay stuff reaches a place in your society intolerable for you, that’ll learn ya. You’re pushing that in such a way that it turns off **\_***a lot of people***\_**, and it exposes all what’s wrong with your political party. **I mean the mixed messages**. Shouldn’t you have chosen an American-born gay black female for VP instead, or just use Pete Butigieg? Kamala Harris coming from an Indian and Jamaican heritage are not places in The World accepting of Gays. So what are YOU saying Joe? The Pope recently congratulated you as the 2nd Catholic to take Office since Kennedy. And I wonder about The Pontiff because he’s so liberal. I’ll miss Trump. I mean, at times with people disagreeing and ridiculing him, I was reading his moves as to why he did something at the time, and what he was really up to. Had he just thought something through better on that Avenatti thing, and made a more clever move at the time when he could have still controlled his own destiny as described in [my previous article](https://ferrelux.com/2020/10/29/election2020/), he wouldn’t be in a stupor right now. So anyway Joe, some thoughts for you to ponder as we watch the way you’re treated in Office. By the way, I liked how you ran out on stage with that glint in your eye declaring your win, showing us how ready you are to get back in The Oval Office and lead. Your campaign was well played.

Sign,  
Lhisa Mrklon

### Do You Really Believe That Biden Won The Presidency? Scroll Down And Leave Your Reply Below.

[![Ferrelux Homepage_Biden Wins2020](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193678144/GGJFvGSZf.png align="left")](https://ferrelux666.wordpress.com/2020/12/24/goodbye-2020/ferrelux-homepage_biden-wins2020/)

[![WomensLib](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193679473/CdK0G0KS6.jpeg align="left")](https://ferrelux666.wordpress.com/2018/03/18/womens-day-2018/womenslib/)

[![VP Elect Kamala Harris In White For Womens Suffrage](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193680866/YaQiQMVLW.jpeg align="left")](https://ferrelux666.wordpress.com/vp-elect-kamala-harris-in-white-for-womens-suffrage/)

[![Trump Opposing Biden](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193682280/Fxzp5U81W.jpeg align="left")](https://ferrelux666.wordpress.com/trump-opposing-biden/)

[![Trump Against Biden](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193683566/0ylpSlWm0.jpeg align="left")](https://ferrelux666.wordpress.com/trump-against-biden/)

[![WILMINGTON, DELAWARE - NOVEMBER 07: A supporter of President-elect Joe Biden shows a calendar with Biden and Vice President-elect Kamala Harris on cover outside the Chase Center where Biden addressed the nation November 07, 2020 in Wilmington, Delaware. After four days of counting the high volume of mail-in ballots in key battleground states due to the coronavirus pandemic, the race was called for Biden after a contentious election battle against incumbent Republican President Donald Trump. (Photo by Joe Raedle/Getty Images)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193684784/XfZuaQRf_.jpeg align="left")](https://ferrelux666.wordpress.com/president-elect-joe-biden-and-vice-president-elect-kamala-harris-address-the-nation-after-election-win/)

WILMINGTON, DELAWARE – NOVEMBER 07: A supporter of President-elect Joe Biden shows a calendar with Biden and Vice President-elect Kamala Harris on cover outside the Chase Center where Biden addressed the nation November 07, 2020 in Wilmington, Delaware. After four days of counting the high volume of mail-in ballots in key battleground states due to the coronavirus pandemic, the race was called for Biden after a contentious election battle against incumbent Republican President Donald Trump. (Photo by Joe Raedle/Getty Images)

[![Ted Koppel And Joe Biden](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193685955/5VR3ugbHZ.jpeg align="left")](https://ferrelux666.wordpress.com/ted-koppel-and-joe-biden/)

[![Kamala Harris Giving A Speech](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193687066/TosPV9T9l.jpeg align="left")](https://ferrelux666.wordpress.com/kamala-harris-giving-a-speech/)

[![Kamala Harris Speaking](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193688207/2_hL9LaCV.jpeg align="left")](https://ferrelux666.wordpress.com/kamala-harris-speaking/)

[![Kamala Harris Speaks Again](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193689440/BWz_9PnGx.jpeg align="left")](https://ferrelux666.wordpress.com/kamala-harris-speaks-again/)

[![President-elect Joe Biden speaks at The Queen theater, Tuesday, Nov. 10, 2020, in Wilmington, Del. (AP Photo/Carolyn Kaster)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193690766/3SXCcVIlY.jpeg align="left")](https://ferrelux666.wordpress.com/joe-biden-2/)

President-elect Joe Biden speaks at The Queen theater, Tuesday, Nov. 10, 2020, in Wilmington, Del. (AP Photo/Carolyn Kaster)

[![President Elect Joe Biden Addresses The Nation](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193692372/WV7V9-fXX.jpeg align="left")](https://ferrelux666.wordpress.com/president-elect-joe-biden-addresses-the-nation/)

[![President Elect Joe Biden, 48 Year Career In Government](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193693711/dnhmviTHe.jpeg align="left")](https://ferrelux666.wordpress.com/president-elect-joe-biden-48-year-career-in-government/)

[![Audry Hilbert and Mile Picot celebrate the victory of President-elect Joe Biden and Vice President-elect Kamala Harris over President Donald Trump in San Francisco on Saturday, Nov. 7, 2020. (AP Photo/Noah Berger)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193694883/lpwDUh_Ea.jpeg align="left")](https://ferrelux666.wordpress.com/election-2020-california/)

Audry Hilbert and Mile Picot celebrate the victory of President-elect Joe Biden and Vice President-elect Kamala Harris over President Donald Trump in San Francisco on Saturday, Nov. 7, 2020. (AP Photo/Noah Berger)

[![Kamala Harris Breaking Bariers](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193696155/yM3-F0VOv.jpeg align="left")](https://ferrelux666.wordpress.com/kamala-harris-breaking-bariers/)

[![Democratic vice presidential candidate Sen. Kamala Harris, D-Calif., listens as Democratic presidential candidate former Vice President Joe Biden speaks Friday, Nov. 6, 2020, in Wilmington, Del. (AP Photo/Carolyn Kaster)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193697272/ood3cH2SM.jpeg align="left")](https://ferrelux666.wordpress.com/news/joe-biden/)

Democratic vice presidential candidate Sen. Kamala Harris, D-Calif., listens as Democratic presidential candidate former Vice President Joe Biden speaks Friday, Nov. 6, 2020, in Wilmington, Del. (AP Photo/Carolyn Kaster)

[![Kamala & Joe](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193698388/B_g_H7ReZ.jpeg align="left")](https://ferrelux666.wordpress.com/kamala-joe/)

[![Joe Biding Talking Again](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193699642/PpzqrjXaH.jpeg align="left")](https://ferrelux666.wordpress.com/joe-biding-talking-again/)

[![Joe Biden, The Younger Years](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193700977/yeT4ggJW5.png align="left")](https://ferrelux666.wordpress.com/joe-biden-the-younger-years/)

[![Joe Biden, Ready](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193702429/Ek8_IStAj.jpeg align="left")](https://ferrelux666.wordpress.com/joe-biden-ready/)

[![Joe Biden, Presidnt Elect 46](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193703870/9fu50DR4X.jpeg align="left")](https://ferrelux666.wordpress.com/joe-biden-presidnt-elect-46/)

[![Female Community Leaders React To The First Female Vice President Kamala Harris](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193705153/k8ivsZvSi.jpeg align="left")](https://ferrelux666.wordpress.com/female-community-leaders-react-to-the-first-female-vice-president-kamala-harris/)

[![Joe Against Donald](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193706467/EhPAd-MuT.jpeg align="left")](https://ferrelux666.wordpress.com/joe-against-donald/)

[![Joe Biden Addressing Supporters](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193707615/z7TyBqEyf.jpeg align="left")](https://ferrelux666.wordpress.com/joe-biden-addressing-supporters/)

[![Joe Biden Armed Forces Speech](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193708666/PfVzGPYg-.jpeg align="left")](https://ferrelux666.wordpress.com/joe-biden-armed-forces-speech/)

[![Joe Biden Gives A Speech](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193709960/kG0meqosJ.jpeg align="left")](https://ferrelux666.wordpress.com/joe-biden-gives-a-speech/)

[![Joe Biden Playing With A Dog](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193711220/Bngx54tgL.jpeg align="left")](https://ferrelux666.wordpress.com/joe-biden-playing-with-a-dog/)

[![Joe Biden With Jill Biden Wearing A Mask](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193712535/rVfyQpa_R.jpeg align="left")](https://ferrelux666.wordpress.com/joe-biden-with-jill-biden-wearing-a-mask/)

[![Democrat Biden](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193713751/Uw8TjioZC.jpeg align="left")](https://ferrelux666.wordpress.com/democrat-biden/)

[![WASHINGTON, DC - NOVEMBER 07: People gather at Black Lives Matter Plaza to celebrate former Vice President Joe Bidens victory over President Donald Trump in the 2020 Presidential Election near the White House on November 7, 2020 in Washington, DC. Earlier this morning several news outlets called the election for former Vice President Joe Biden after a multi-day delay in the results while the country waited for four contentious states to finish counting ballots. (Photo by Samuel Corum/Getty Images)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193714968/gQmnN6GWL.jpeg align="left")](https://ferrelux666.wordpress.com/washington-reacts-to-multiple-media-outlets-declaring-joe-biden-the-next-president-of-the-united-states/)

WASHINGTON, DC – NOVEMBER 07: People gather at Black Lives Matter Plaza to celebrate former Vice President Joe Bidens victory over President Donald Trump in the 2020 Presidential Election near the White House on November 7, 2020 in Washington, DC. Earlier this morning several news outlets called the election for former Vice President Joe Biden after a multi-day delay in the results while the country waited for four contentious states to finish counting ballots. (Photo by Samuel Corum/Getty Images)

[![Biden-Harris Supporters Partying](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193716449/W8uga4VsM.jpeg align="left")](https://ferrelux666.wordpress.com/biden-harris-supporters-partying/)

[![Biden-Harris Simple Campaign Art](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193718171/ys5OWbxEc.png align="left")](https://ferrelux666.wordpress.com/biden-harris-simple-campaign-art/)

[![Biden-Harris During Covid-19](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193719585/evgLjDd4K.jpeg align="left")](https://ferrelux666.wordpress.com/biden-harris-during-covid-19/)

[![Biden-Harris Campaign Pic](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193720797/gc26c6FEI.jpeg align="left")](https://ferrelux666.wordpress.com/biden-harris-campaign-pic/)

[![Biden vs Trump Campaign Contrast](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193722217/9X1GENX10.jpeg align="left")](https://ferrelux666.wordpress.com/biden-vs-trump-campaign-contrast/)

[![Biden Victory Speech](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193723470/DCqWwigAH.jpeg align="left")](https://ferrelux666.wordpress.com/biden-victory-speech/)

[![Biden Special](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193724667/7rdSuInHE.jpeg align="left")](https://ferrelux666.wordpress.com/biden-special/)

[![Biden On Abortion](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193725810/RATq6uyNp.jpeg align="left")](https://ferrelux666.wordpress.com/biden-on-abortion/)

[![Biden Checking Watch During Belmont Debate](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193726969/VTJ7BI239.jpeg align="left")](https://ferrelux666.wordpress.com/biden-checking-watch-during-belmont-debate/)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193728197/wcyMzBdPo.jpeg align="left")](https://ferrelux.com/adverts/)
