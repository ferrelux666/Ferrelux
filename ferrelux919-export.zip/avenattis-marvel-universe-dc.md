---
title: "\U0001FA90Avenatti’s Marvel Universe, DC \U0001F30D"
date: '2021-10-18T02:43:46.000Z'
slug: avenattis-marvel-universe-dc
tags:
  - challenge
  - legal
  - file
  - political
  - dark
  - magic
  - people
  - usa
  - water
  - movie
  - dream
  - entertainment
  - atlantis
  - comics
  - sentinel
  - mythology
  - politics
  - thanos
  - king
  - america
  - avengers
  - myths
  - court
  - black
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672206691819/2edf8681-068b-4ddd-9f4d-35796485f8fe.jpeg
canonical: 'https://ferrelux666.wordpress.com/2021/10/17/marvel-dc/'
---
[![SilverSurfer7](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192456342/QVQvXa0JK.jpeg align="left")](https://en.wikipedia.org/wiki/Silver_Surfer)

[**The Silver Surfer Theme**](https://www.youtube.com/watch?v=hHLI7VPFXro)[**My Version Of The Silver Surfer Theme In Latin & English**](https://www.tiktok.com/@ferrelux/video/7030600484608118021?is_from_webapp=1&sender_device=pc&web_id=7115954612502660651)  
[**Namor, The Submariner Theme**](https://www.youtube.com/watch?v=p4X5Ym4Y8vk)  
[**My Version Of The 1966 Submariner Theme In English & Latin**](https://www.tiktok.com/@ferrelux/video/7051691614099574021?is_from_webapp=1&sender_device=pc&web_id=7115954612502660651)

*This is the moment you all been waiting for if you’ve been following a particular series of articles I’ve been doing on somebody’s legal case.* [*Here’s the link to where we last left off*](https://ferrelux.com/2021/06/10/michael-avenatti/)*. Now this metaphoric re-telling of events for Halloween is The DC & Marvel Comics cross-over version, with a BIG reveal. The actual names & backstories of certain real people and established cartoon characters in this tale were changed for the sole entertaining purpose of relating information at least true in spirit. And ofcourse I put myself in it because it’s my story and I’ve been indulging in & writing esoteric stuff like this since grade school. And if you’ve been following my interests, then you know I like the marvel character Storm, and casted myself as her in this. Now you don’t need to take my little story seriously, but maybe you should. Have a wonderful Halloween.*

**THE MAIN CAST**  
**(Many of the names of these real-life people are changed to fictional ones)**

Gianni Michaelangelo Avengotti, Lead Role As The Sub-Mariner & Aqua Man  
Lhisa Mrklon, Lead Role As Storm  
Juan Luis Litrello, Lead Role As The Silver Surfer  
Howard D. Stewart , Lead Role As Duke The Sage  
Shareef Linroy Bacca, Lead Role As Sinestro  
Donald Trump, Supporting Lead As Himself  
Stan Swebnich, Supporting Lead As Dr. Strange  
Henry Swebnich, Supporting Lead As Warlock  
Dana Paris, Supporting Lead As Jean Grey & The Dark Phoenix  
Giuseppe Quinonez, Supporting Lead As Joseph Quinn  
Anwar Brahman, Supporting Role As Amir Ibrahim  
Alicea Presca, Supporting Role As Atlantean Princess, Alyse of Baor Isle  
James Mann, Supporting Role As Jaye Heiman  
Russ Van Cy, Supporting Role As Van Cyrus  
John F. Kennedy Jr., Supporting Role As Himself *(Digital Technology)*    
Robert Morgenthau, Supporting Role As Himself *(Digital Technology)*  
John Gotti, Supporting Role As Himself *(Digital Technology)*   
Brian Siegel, Supporting Lead As Brett Segal, The Cabbalist  
Nicholas Hannah, Supporting Role As Nicola Hans Atlantean of the South Seas    
Julius Andre, Supporting As Role Julian Dray Atlantean of Tyrrhenian Sea  
Brian Fox, Supporting Role As Brandon Wolf Atlantean of The West Seas  
Drew Stahlpur, Supporting Lead As Andrew, Atlantean From The Isle Of Britonia  
Jayce Frankfurt, Supporting Lead As Jason, Atlantean From The Franc Seas  
Stanley Simmons, Supporting Lead As Scott, Atlantean From The Scottish Isles  
Alex K. C. Weiman, Supporting Role As Alexander The Sea Cape Wise Man  
Treena Wilkens, Supporting Role As Stacey Wilks  
Andrea Strouse, Supporting Role As Andraika Stross  
Peter Guard, As A Voice For The 3 Headed Dragon Celnafermen**gardef**  
John Seylna, As A Voice For The 3 Headed Dragon **Celna**fermengardef  
Jack Furry, As A Voice For The 3 Headed Dragon Celna**fermen**gardef  
Miguel Cowen, Supporting Role As Coen Michaels  
Ray Moon, Supporting Role As Raymond Charles  
Marc Gerratos, Supporting Role As Mick Jerry  
Rudolph Giuliani, Supporting Role As Himself  
Jeffrey Burmen, Supporting Role As Geoffrey Bearman  
Mark Poledusky, Supporting Role As Mike Pedalski  
Ronald Sobleman, Supporting Role As Ricky Soberman  
Christian Harp, Supporting Role As Calvin Hopkins  
Danny Almonzo, Supporting Role As Dan Alphonso  
Wilson Scott, Supporting Role As Scot Welles  
Marty Brazen, Supporting Role As Martin Braze The Third  
Franklin Grant, Supporting Role As Greg Freeman  
Jeff Auers, Supporting Role As Mr. Geoff Howerback  
Morgan Piers, Supporting Role As Pierce Morrison  
Danielle Storm, Supporting Role As Tempest Dame  
John Jeffries, Supporting Role As Dr. Octopus  
Kevin Kevins, Supporting Role As The Penguin & The Kingpin (New Jersey)  
Mattison Cawthorne, Supporting Role As Captain America  
And The United States Inter-Galactic Government As Galactus

**\_***The Rest Of The Cast Of Characters, Whether Lead Or Supporting Can Be Played By Anybody Else***\_**  
Professor Xavier, Magneto, Wolverine, Cyclops, Gambit, Rogue, Spider-Man, Black Cat, Green Goblin, Hob Goblin, Bishop, Merman, Superman, Wonder Woman, Batman, Robin, The Wonder Twins, Gleek, Hawkman, Green Lantern, Cyborg, Black Vulcan, Black Manta, El Dorado, Scarecrow, Cheetah, Grodd, Brainiac, The Riddler, Lex Luthor, Thanos, Apocalypse & Ktulu or Cthulhu and Others.

Somewhere is the Marvel Universe in his Castle of Mysteries is Dr. Strange conducting his usual experimental magic, and in the process, he sees a disturbing vision of the future. Horrified by it, he proceeds to decode what it could mean, except that his intellect can only extend so far to interpret the rational.

**Dr Strange:** I must warn everybody. If only I could figure out who is doing this. How do I tell Sub-Mariner and the others that a great fault in the universe just happened that can change our world forever.

Meanwhile somewhere in another Universe is a sinister rogue doing the utmost devilish magic he’s ever conjured in his life, disturbing the realities of his dimension with another.

**Sinestro:** I’ve done it. I’ve tapped into an ultimate power source. With the star system aligned the way it is now, the moon and sun in place, all at the right time, I can raise **Apocalypse**.

Meanwhile, back in the Marvel Universe at the X-Men Headquarters, Professor Xavier has a psychic premonition and does not know what it means, but he definitely knows that it’s bad and calls the other X-Men telling them about it.

**Storm:** I must be psychic too because I’ve been having a bad feeling all this time and disturbing dreams roughly about the same thing.

And as the X-Men deliberate on what they should do, snugged up comfortably in his luxurious Atlantean Empire is Prince Namor, ever at peace with himself, and with no care in the world. Meanwhile, at another part of the Pacific Ocean, is a brood of Conspirators plotting against Namor for power headed by 3 Rogue Atlanteans who hate him: Jason, The Atlantean from The Franc Seas, Andrew, The Atlantean From The Isles of Britonia, and Scott, The Atlantean from The Scottish Isles. All 3 are visitors now residing in Namor’s territory since he welcomed them allowing them refuge since the last foreign Atlantean Civil War 5 centuries ago. They’ve now grown weary being at peace with Namor’s Kingdom and the time has come to show their true colors.

**Jason:** We can’t look too suspicious. It won’t be long until Namor realizes that something is wrong.  
**Andrew:** But why hasn’t he sensed it yet.  
**Scott:** That might not be unusual, a lot of people are still ignorant to the change, look at them.  
**Jason:** They’re stupid. I would have picked up on it. Nothing is quite the same anymore.

**Scott:** But that’s because we know. But what if you were him or her over there, you’d still be living your life unsuspecting.  
**Andrew:** He’s right, unless you’re expecting a problem, you ain’t gonna suspect a thing. Everything still looks the same. Not everyone here would feel the change. I’m more concerned about the Land Dwellers, somebody up there by now should know.

Meanwhile, on the Earth’s Surface in the City of Lost Angels lives an Old Wise Atlantean who senses the changes in time & space and is immediately concerned about his friend Namor, but before contacting him directly, he decides to contact Dr. Strange by using a magic crystal orb and inquire about the disturbances in The Universe.

**Dr. Strange:** Well Duke, the frequencies have changed, the molecules are unstable, strange things are happening out of time, and out of sequence, but not everyone notices yet.  
**Duke:** Well can’t you do something about it?  
**Dr. Strange:** My magic is not that strong. I’m working on something.

**Duke:** I need to warn Namor.

**Dr. Strange:** I’ve been debating whether I should or not. I’m not sure how he will react. From the visions, it entirely has something to do with him and some hidden enemy. I don’t know enough. Based on some of the things I saw, there are some people around him that are not good. And based off my experience with magic like this, timing is everything. I feel just leaving him ignorant like that for a while longer is best.  
**Duke:** But I don’t feel right about it. Tell me all what you know.

And while Dr. Strange recants his prophetic vision, back in the DC Universe, Sinestro continues the next wicked phase of his magic while still trapped within the prison walls of an old decrepit barge that Aqua Man placed him in on an abandoned sea. As he says the second set of incantations, nothing significant happened, atleast not noticeable to him.

**Sinestro:** The spell should have worked. I must be pronouncing a word wrong.

He does it again slightly changing the pronunciation of one word, and then he hears an earthquake. He thinks his magic is working, but unwittingly broke open another being from captivity who had been trapped for thousands of years in a magical prison beneath the sea in unknown parts under some large bales of flat sheet rock one on top of the other. And up rises **Ktulu**, spreading about the oceans in his massive form destroying many in his path. All over the airwaves is news of a deadly Sea Monster ravaging everything in sight that The Authorities beg for the help of Aqua Man at The Hall Of Justice. He comes out to tame the creature with his telepathic powers, but it has no effect.

**Aqua Man:** That’s strange. My powers are not suppose to fail me. Something is wrong. He tries his best to stave the creature off, but requires the help of Superman, Wonder Woman, & Green Lantern. He calls for them on his frequency monitor, but the message won’t go through. He does however receive help from an unlikely person. Coming to the rescue is Black Manta with some strange Atlantean technology he got from somewhere which manages to subdue the creature. Ktulu swims away in annoyance to some unknown place.

**Aqua Man:** How did you do that?  
**Black Manta:** I got this weapon as a reward from some guys months back who wanted me to do some favor for them.  
**Aqua Man:** It looks too sophisticated to be from here.  
**Black Manta:** They were some strange looking dudes. The 3 of them are Atlanteans.  
**Aqua Man:** So why did you help me? No doubt it would have benefit you to see me subdued.  
**Black Manta:** Nah Bro, all this is affecting me too. It’s destroying the planet. And I think all this happening now has something to do with those 3 guys.  
**Aqua Man:** We have some rogue Atlanteans, and I know them all, but none of them would dare summon Ktulu. Who are these 3 guys who spoke to you?  
**Black Manta:** They just appeared out of nowhere in my submarine asking me questions about you.  
**Aqua Man:** What kind of questions?  
**Black Manta:** Just stuff, like your history, your whereabouts, stories about you and so on. And then they wanted me to get your Trident the next time I fought with you in exchange for superior technology.  
**Aqua Man:** Why would they need you, when they could battle me themselves for it.  
**Black Manta:** That’s the part I didn’t fully grasp. They were too advanced to be asking me for help, but I took the offer.  
**Aqua Man:** But I beat you in our last battle.

**Black Manta:** I thought I failed too, but while fighting you, some of your Atlantean hair remained on me which one of them noticed, and that one stepped back talking to the other 2, and then they decided to take that and pay me. Why do you look so puzzled?

**Aqua Man:** Ever since that time. I’ve not been feeling quite like myself. Do me a favor. Just stand still and think about those 3 Atlanteans. I can use my power to see into your mind.  
**Aqua Man:** Wait a minute. I don’t know these guys. Their garb is Atlantean, and they look and sound like Atlanteans, but I’ve never seen or heard of them. The closest resemblance they have to anything I know is some history way back over at the Isles of Britonia, The Franc Seas, & The Scottish Isles. They kind of look like those 3 missing Atlanteans many centuries ago who wanted to come over to my current Kingdom under it’s old Ruler for refuge, but never made it, when we had that Civil War.  
**Black Manta:** The only other thing I can remember about my experience with them is that ahhm, ahhm, they were whispering something about some spell and changing destiny. I didn’t care what they did to you at the time because you were my enemy, but now I don’t know if you have noticed, but the entire atmosphere is really strange. Just yesterday I was walking down the street, and I passed somebody, only to happen to pass the person again, then I looked around and saw some semblance of myself walking towards me like a minute ago. I was shocked, and then it faded.  
**Aqua Man:** Interesting, it’s some kind of psychic phenomena. My friends at The Hall Of Justice have experienced some issues too. Come with me.

Meanwhile, back in The Marvel Universe, Duke, The Old Wise Atlantean visits Atlantis, but not by the usual waterways, he decides to be discreetly teleported right into Namor’s throne room by courtesy of Dr. Strange’s magic. And as some Subjects move about normally as they do, he walks pass them, making his way to Namor.

**Namor:** Duke! When did you get here? I haven’t see you in along time.  
**Duke:** I must have a word with you privately.

Namor hearing his serious tone, and sensing something of vital importance walks off with him to a private area in the palace.

**Namor:** Okay. What’s up?  
**Duke:** Are you alright?  
**Namor:** Yeah why?  
**Duke:** You haven’t experienced anything weird?  
**Namor:** No. Like what?  
**Duke:** I have reason to believe that something extraordinary is happening, and it affects you, in fact it is affecting everyone else also. I just learned from Dr. Strange that someone somewhere released something through way of magic, and it might have something to do with you and this kingdom based off certain visions he had.  
**Namor:** Everything is fine here. I’ve not been having any problems. Some of the creatures in the sea are a bit frolicky, but that’s it.  
**Duke:** Has anyone been acting strange around you?  
**Namor:** Like who?  
**Duke:** You know, anybody. Any odd thing?  
**Namor:** No, the waters are rising in certain parts that The Surface Dwellers are complaining, but there’s nothing strange about that. It happens in high tide. Tell me what you think is wrong.  
**Duke:** I don’t know, it wasn’t my vision, but what I can share with you is what I noticed with The Surface People. You know I live among them disguised as a regular person leading a perfectly normal life. Well someone came into my office whom I had met 20 years ago, talking to me about the same similar case I handled for him then as if it was new. And he looked exactly the same age.  
**Namor:** So, he just might be another Atlantean or other type of being pretending to be human.  
**Duke:** No. He is a regular person with no type of mutant power. And in his mind, he’s in his own time back then.  
**Namor:** He just might be crazy.  
**Duke:** No, he’s very much in his faculties. It’s just that something happened. Something I cannot explain. We appear to be in a pseudo-parallel universe or something.

**Namor:** Who else is experiencing this?  
**Duke:** I imagine just about any sensitive Mutant or Supernatural Entity on the planet should know by now.  
**Namor:** This is no joke. I don’t want to alarm anyone here. The reason why no one may be affected so drastically here is because we exist as a nation well below water that what’s happening up there would not reach us. Not yet anyway. This might explain the giddiness of some of the sea creatures. Hmm, maybe someone is trying out a new weapon. I must make an excuse to travel to The Surface World.  
**Duke:** You think I would come here without your excuse.

Duke then furnishes an immaculately sealed invite to an event.

**Duke:** I talked to some friends in high places to make every excuse for you when the time comes. They are aware of everything.  
**Namor:** Okay, let’s go.

Namor puts his Second-In-Command in charge who’s under the impression that he is attending some highly respected and special government meeting Florida. Meanwhile, at the headquarters of The X-Men, Rogue, Wolverine, cyclops and others are dispatched on missions to address mutiny among Mutants acting out over these mysterious changes. Some are very uncomfortable with it, while others like it. In New Jersey, The Kingpin is very happy with the changes because he can now use the gaps in reality to stay in power. And in his thuggish way he sends his goons out to acquire and secure territory consolidating his power. And when attacked by Cyclops & Rogue, he and his team is able to withstand, defeating them.

**Kingpin:** I don’t know what changed in The Universe, but I’m loving it. I can now setup my Mob Empire.

And over in New York somewhere, Spider-Man battles The Green Goblin, who appears to be a bit more powerful this time that Spider-Man is unable to finish him off quick enough. The battle grows tiring till Jean Grey shows up using her powers messing with his mind, till the psychic attack drives him back to his lair. And as more unsettling events pop out, The Avengers and The Guardians Of The Universe get involved trying to keep the peace.

Meanwhile back in the DC Universe at The Hall Of Justice, Black Manta further tries to offer his help to the team by calling a meeting with certain members of The Legion Of Doom in an attempt to investigate what’s going on.

**Cheetah:** Word on the Street is that it has nothing to do with Lex Luthor.  
**Black Manta:** I didn’t think it was him either, where is Lex anyway?  
**Toy Man:** He’s still off doing his own private research on this subject.

**Scarecrow:** Well that sounds suspicious, how do we know for sure it’s not him.  
**Toy Man:** You have my word. Believe me he is just as disturbed by this as we all are.  
**Grodd:** He’s probably working on some machine to try to change things back and take credit for saving the world. Ha ha ha ha.

**Black Manta:** Ok, so what about Brainiac? He conducts strange scientific experiments sometimes that backfires?  
**Cheetah:** He’s a super genius, but what’s going on out here appears to be out of his league.  
**Scarecrow:** From my own mental powers I sense all this has something to do with Aqua Man.

Surprised at his comment, Black Manta inquires.

**Black Manta:** Why? Because of that mysterious sea creature.  
**Scarecrow:** No. I suspected it well before. That monster appearing only confirmed it. My visions ceased after a while, but what I can tell is that somebody opened up a parallel universe much like our own where certain people and things are similar. I saw Aqua Man in Atlantis in the vision, but he looked and behaved kind of different.

Black Manta is now satisfied with trusting them, that he tells all of what he knows and have been doing with The Superfriends to resolve the issue. Meanwhile, at his private lair, Lex Luthor using his super intelligence, entertains math & science in their highest forms to measure and map out sound frequencies and seismic waves and so forth with his machinery to try to see a pattern. And based off his results, he predicts that the next disturbance will happen in the next couple of days in California. He then contacts Superman, who invites him over to The Hall Of Justice.

**Superman:** You know Lex, I never figured that we would ever be working together like this.  
**Lex Luthor:** You know that I don’t like you, but you’re the only one on this planet I feel can actually save us.  
**Superman:** I was thinking that maybe these troubles had to do with you, until I realized how little it profited you to be behind it. And then I thought about that demonic imp, Mxyzptlk that he probably escaped the 5th dimension and came here to make trouble again, but this was too chaotic even for him besides he likes playing games, and makes it his duty to pay me a visit, yet he never showed up. So now I have no idea who in the universe has this much power to make all this happen.  
**Lex Luthor:** You’re forgetting Darkseid. That’s who I have at the top of my list.  
**Superman:** But why? This does not look like his work.  
**Lex Luthor:** Says who? He’s really powerful. If anyone is unaffected by this it would be HIM.  
**Superman:** It’s too reckless. He’s very logical and dignified. If he was trying to do a takeover he wouldn’t be doing this. And he’s probably sitting on his throne in his dimension, peering at us in his crystal ball.  
**Lex Luthor:** So who then? The Gods?  
**Superman:** What Heavenly Being in any Universe would allow this?  
**Lex Luthor:** Hmmm. My evaluation is that we better do something about this soon.  
**Superman:** I take it that you haven’t spoken to Black Manta yet.  
**Lex Luthor:** What about him?  
**Superman:** Sit down, this is quite a story.

And as Superman relates everything he knows so far, he parts ways with Lex, who decides to meet up with Black Manta and the rest of The Legion Of Doom to see what else they can do in curbing the developing problems around the globe as temporary Super Heroes helping people.

Meanwhile in The Marvel Universe, in Atlantis, Jason & his friends grow weary at a missing Namor.

**Andrew:** This was not the plan. Where the hell is he?  
**Scott:** Maybe somebody told him about the disturbances. He should know by now. My friends up there keep me updated.  
**Jason:** But he wouldn’t know about us though and our plot. The word is that he’s off on some special conference, and it’s high secret.  
**Andrew:** I don’t like that. Maybe he knows about us?  
**Jason:** How the hell would he know? Did you tell him?  
**Andrew:** Ofcourse not, but all of a sudden he leaves. Come on?  
**Scott:** It might not be that strange. Maybe he was summoned or something. What’s going on in the Surface World is very serious. And remember he’s an Avenger. Now they’re all over the place trying to protect people according to my sources.  
**Jason:** Well we can’t wait for him. The plan was to gather our allies far and wide, ambush him, and seize the throne after Sinestro completed the spell.  
**Andrew:** And what happened with that by the way?  
**Scott:** I told you not to trust some inter-dimensional freak. We should never had helped him escape that prison.  
**Jason:** I thought he was an excellent Magician. We are supposed to have the power of The Mighty Apocalypse behind us as we seize Atlantis and join him in rulership over the whole Marvel Universe.  
**Andrew:** But *something* succeeded. The disturbances are coming from somewhere.

**Scott:** It’s probably partially successful. Remember Apocalpyse was imprisoned by very strong magic and certain things has to be fulfilled before he can fully rise again.  
**Jason:** Yeah, but something is out there. I can feel it.

Meanwhile, out in Oceanus in the waters thereabout swimming about unnoticed is a large sea monster. When some pilots fly over that part, they radio back their observation. Some Super heroes including Namor find themselves over there and are astonished at it. Namor tries using his Atlantean powers to link his mind to it, but the creature is not susceptible to his energy. And then he arrogantly yells.

**Namor:** Cthulhu. STOP! I Command You.

The monster ignores him, swimming towards Australia.

**Storm:** Quick, we must contain him.

While piloting their super transport jet, the side opens for Spider-Man and he let’s go a super strong batch of web on him, which only held him for a few minutes before he broke free. Professor Xavier attempts to read the creatures mind and senses confusion from it. He then relates what he saw to Namor.

**Professor Xavier:** It seems as though the creature is aware of another being like itself and is trying to find it.  
**Namor:** There is only one Cthulhu.  
**Professor Xavier:** I saw a glimpse of the creature’s mind before it shut me out. He is deeply hurt.  
**Namor:** Hurt by what? He’s unfazed.  
**Profressor Xavier:** From being imprisoned for centuries. I also sensed deep confusion as if it longs for something.  
**Namor:** He is extremely dangerous, which is why he was kept trapped in the deepest parts of the sea. Let me try to reach him again with my power. Maybe he will open up to me.  
**Professor Xavier:** No Namor, it’s too dangerous.  
**Spider-Man:** The Professor is right. Storm, fly over as close as you can and let me try this other batch of web.

When they tried that and the creature also broke itself free again, it grew even angrier, and it began wailing a piercing cry in protest that struck Namor’s heart. He leaped from the plane and into the water swimming up along the creature, and getting on top of it. Cthulhu wiggles around making noise and Namor tries to make a mental connection with it again letting it know he does not intend to hurt it. Cthulhu’s mind opens revealing strange memories, some of which he apparently shares with another Cthulhu, and before breaking free from that psychic lock, Namor gets a chance to see another version of himself in another land where he is called Aqua Man. Greatful that the creature revealed all that to him, he remarks,

**Namor:** Cthulhu, I am sorry that you went through all that, but I am not the one who attacked you, or should I say your parallel universe friend or version of you. Even if I am also this Aqua Man, I need to look into it further. My world as I know it is under attack right now and I’m going to need you when the time comes. Please return back to the deep until I summon you.

Cthulhu is strangely calm, but obeys. Namor leaps off him, flying up re-entering the X-Men starship and they fly back to Headquarters. Namor is still deeply disturbed by the visions Cthulhu showed him and wants to immediately get to the bottom of it. So he insists on a private meeting with Dr. Strange, Jean Grey, & Professor Xavier to try to decipher what’s going on.

**Dr. Strange:** I already told you everything from my perspective Namor. I wish I knew something else to tell you.  
**Professor Xavier:** What I’m sensing from you Namor is fear, but fretting about losing your name, title, power and kingdom due to this isn’t going to solve anything.

**Namor:** Who is this Aqua Man?  
**Jean Grey:** If he’s another version of you I wouldn’t worry about that.  
**Namor:** That’s not what worries me. I’m mad about who ever is behind this. Why would someone hate me so much to go about a sinister plan like this to pull out from under me all I’ve ever known.  
**Professor Xavier:** I sense your anguish, and we’re all trying to help. Devising an attack just to get *YOU*, while affecting the rest of the world is a bit strange. There must be some other part to it.  
**Jean Grey:** Until we can figure that I’d like to telepathically work with you to try to tap into something.  
**Namor:** I don’t like my mind being probed.  
**Jean Grey:** You found out what you did from Cthulhu. I’m just betting on a hunch that maybe I can tap into Aqua Man.  
**Namor:** Ok, let’s try.

After about a series of mis-trials, Jean Grey was able to psychically link to Aqua Man, through Prince Namor, and ask him some questions.

**Jean Grey:** Aqua Man, my name is Jean Grey. I’m a mutant from another universe who is aware of some of the problems you are dealing with in your world. They affect me too. My friends and I believe that a common enemy may be behind it. Do you know any information.

And Aqua Man, like Namor, who is trying to find answers, is alone in his room doing his own personal psychic meditations and is happy that some break through happened. He telepathically answers.

**Aqua Man:** Yes, I’m Aqua Man. I don’t know who is behind this yet. The only thing I can tell you is that the most capable good guys and the bad guys in our realm are working together to stop it.

**Jean Grey:** Do you know Cthulhu?  
**Aqua Man:** Ktulu, I subdued him with the help of a friend about a week ago. Why?  
**Jean Grey:** I must inform you Aqua Man that you have another celestial version of yourself in my universe and his name is Prince Namor, The Sub-Mariner.  
**Aqua Man:** I’ve heard of parallel universes before, but I have a twin, how?  
**Jean Grey:** He is almost exactly like you in terms of identity and history. And today, he just subdued in his own way a Cthulhu here in our realm. So what I would like to know is do you have any current enemies?  
**Aqua Man:** No, but I learned from a friend that there were 3 rogue Atlanteans who recently visited my realm. To me they looked more like the same three guys from our history about 500 years ago in a civil war our people had involving Britonia, The Francs, The The Scottish Isles. Their history still remains a mystery. We’re not sure what happened to them.

**Jean Grey:** Can you bring their faces to mind so I can see them.  
**Aqua Man:** Yes.  
**Jean Grey:** What else can you share with us.  
**Aqua Man:** It would be great if we can visit each other’s dimension. I’m in the DC Universe. If you follow my mind I can guide you to our general star system.  
**Jean Grey:** I captured a general idea. I’m from The Marvel Universe, now follow my mind.  
**Aqua Man:** We are very distant relatives. Our people I mean. So how is it possible that we have parallel identities. I mean who are you in my universe?  
**Jean Grey:** I’ve learned from past studies and experiences that sometimes the parallel you in another universe may not be exactly the same. Sometimes the race, culture and gender are different. And they may not have the same life story, experiences or powers.  
**Aqua Man:** Jean, I feel my power fainting. I might not be able to hold this connection longer. I have a friend name Wonder Woman who is of the realm of The Gods. She has telepathic powers and . . . . .  
**Jean Grey:** Oh Namor, we got cut off, but you were a perfect medium to your other self. The thought transference and reading your mind was crystal clear. And on top of it, you even answered as Aqua Man, but do you remember any of it?  
**Namor:** I think I know the 3 guys he’s talking about. But what’s strange is how they ended up in my universal narrative and not his DC Universe?

Aside from Professor Xavier & Dr. Strange observing the phenomena, also watching this psychic exchange the whole time was Duke, The Sage. Who remarks,

**Duke:** Maybe they are not who they claimed they were. They could be impostors.  
**Namor:** How do you mean?  
**Duke:** If Aqua Man said he does not know who they are in his present time, and can only re-tell a history about them. Then that might mean they either died in the Atlantean War, or escaped persecution by coming into our dimension.  
**Namor:** If most of the events in the parallel Atlantean world is true, then his story should more or less match up with mine.  
**Jean Grey:** Except for subtle differences. Don’t worry. Like you, I am sure he’ll get to the bottom of this.  
**Duke:** One crucial thing we do know is that there is a 7-day delay of events that just happened in his world and what is going to happen in ours.  
**Namor:** That’s something we need to keep secret. Unlike Aqua Man, we don’t have the villains here caring enough about humanity. We need to get in touch with this Wonder Woman somehow. And how can we get into that universe?  
**Duke:** We just found out some things nobody else knows yet and we need to be careful. Namor, you need to be playing the naive role still, until we can further find out what’s going on.

Meanwhile in the rest of The World, a very wealthy real estate Mogul looked in the mirror one day and noticed that he no longer was old, but reverted back to a younger version of himself due to the mysterious cosmic changes happening. Puzzled he remarks,

**Donald Trump:** I don’t believe it. With the changes happening, we are living in a pseudo time space. With a new lease on life, I can do whatever I want. Let me go run for President.

He then checks up on his family and sees that they too reverted back to a younger stage in their life, and then remarks,

**Donald Trump:** Kids! You all look young, but you seem much like your older selves though. I still remember everything and I tell you what, whatever is happening in this world, I don’t want to change it. This is a new time and a new age.

The wheels start turning in his head and he decides to get involved with some other people to build a Constituency. One of the people he decides to call is The Kingpin.

**Donald Trump:** We need to form an alliance. I see you holding it down in New Jersey, and I think I can take New York & Florida. Evenn though what’s happening is a good thing, the Super heroes out there are trying to ruin everything.  
**The Kingpin:** I agree. If things went back to normal tomorrow. I’d be seeing Spider-Man and others coming at me trying to ruin my life. I now have a chance at success. Look how I’m doing now.

**Donald Trump:** We need to get rid of these Mutants. Somebody somewhere unlocked something and that is the only good thing coming from them. Ah look Kingpin, do me a favor. Try to get in touch with The Human Juggernaut and some other people to take over their respective states. I have a whole bunch of things on my mind to get started with right now. I’ll get in touch with you next week.

Meanwhile back in The DC Universe, Aqua Man relates his psychic episode with Jean Grey to everybody at a meeting in the Hall Of Justice who were Justice League, and also present is Black Manta & Lex Luthor of The Legion Of Doom.

**Hawk Man:** This is great. With this break through we stand a better chance of beating this.  
**Bat Man:** Not so fast. We’re still at a disadvantage. We still don’t know what is going on or who is behind it.  
**Lex Luthor:** I might have some idea.

Everyone looks at Lex, as he explains,

**Lex Luthor:** The only other soul in the universe I know that dabbles his magic and could create a disaster like this is . . . . . .

And before he can say the name, they all think it, and shout

**S I N E S T R O ! ! !**

**Wonder Woman:** But how? Didn’t Aqua Man imprison him and all his wicked magic on a barge floating in a desolate sea several years ago?

**Lex Luthor:** About 5 years to be exact. And some Legion Of Doom members are known to beat the impossible. He must have kept a real low profile all this time.  
**Aqua Man:** Wait a minute, we don’t know for sure it’s him.  
**Black Manta:** But his comeback is too extreme. Why would Sinestro do this?  
**Lex Luthor:** Good question.

Meanwhile, back in the Marvel Universe, Jason, Scott & Andrew are eager to execute their plot, but with an absent Atlantean Prince, they cannot proceed with the original plan, and so they devise another method to seize power.

**Andrew:** I’m getting real tired of this Merman he has as Second-In-Command. He’s not even from this dimension.  
**Jason:** Yeah, that’s a problem. He’s too sharp.

**Scott:** I can’t get a beat on figuring him out. And we don’t know what he knows.  
**Andrew:** You think he suspects something?

**Scott:** I’m not sure. There’s no reason he should.  
**Jason:** Okay so, here’s what we’re gonna do. The spell Sinestro was suppose to do hasn’t come through yet. All that strange energy out there is coming from invoking something else. I even heard reports that Cthulhu is now free roaming about. Something bad is going on. Maybe we should pay Sinestro a visit again.  
**Scott:** Bad idea. We have to account for our time. We’re Top Level Atlanteans and any one of us going here or anywhere is highly noticeable, especially now. We’ll have to wait and see.

**Jason:** So let’s make an excuse for ourselves to go on peace missions, you know, to try and help these humans. Such a gesture would allow us to go about freely and garner some surface people in our interests.  
**Scott:** How do we get past Merman? He has to permit us?  
**Andrew:** Scratch that idea. I’m listening to it, and if I was left in charge I would wonder why are you interested in doing that when Namor is the only right person for it and he’s already out there. You would look questionable to me.  
**Scott:** He’s right. And another thing too we aren’t supposed to care too much about The Surface People. But we need Surface Allies for our plans though.  
**Jason:** We gotta get out there somehow. When Apocalypse rises, we need to be right there by his side with all our allies. Under his rule, we’ll become the new Masters of Atlantis.  
**Scott:** Namor with all his power and title being out there opposes that. We need to get that part under control. The takeover should have happened last week.  
**Andrew:** Leave that to me. I have a surface friend who can also socially engineer certain things to happen. He already knows about our ambition.

Andrew then proceeds in contacting Brett, his Surface Dweller friend to keep an eye on Namor.

Meanwhile, in the rest of the world, a strange lapse in time happens where people are living in a pseudo-reality where somehow certain people who are supposed to be dead are alive again. So we have someone from another generation living in another time period, where the last 100 years is sort of moshed together in one time where the 1920s, 30s, 40s, 50s, 60s, 70s, 80s, 90s, all the way to the year 2018 is all existing at the same time. Ragtime, Jazz, Swing, Bee Bop, Doo Wop, Rap, Rock, Pop, Hard Rock, Heavy Metal and so forth, are all relevant with the same existing Artists transcending time & space. The Top Models in those time periods are competing with the relevant ones now. This is a strange time all happening due to an unknown Magician mis-pronouncing just a couple archaic words from an old manuscript in an effort to call for the demonic entity Apocalypse, who requires a series of particular sacrifices in a 33 days rite. In the alternate universe, Sinestro realizes he’s about to run out of time if he fails to do this when the star system is so perfectly aligned right now.

Meanwhile, back in The DC Universe, Aqua Man and The Wonder Twins decide to travel way out where, and check up on the place he abandoned Sinestro 5 years ago, and sure enough he escaped. They look all around the barge and inside and remark,

**Wonder Twin, Jayna:** He was sealed in by his own terrible magic, and an impenetrable force-field around the barge kept anyone form breaking in. So how did he escape?

**Aqua Man:** Only someone with greater magic could break it.

**Wonder Twin, Zan:** Like from another dimension?

Aqua Man is particularly mad at this, and he’s even more concerned about his other self. He and The Twins leave immediately to return to The Hall Of Justice, so he can attempt to contact Jean Grey again.

Meanwhile, Sinestro continues to make mental contacts with Apocalypse, who is a couple spells shy from actually being able to emerge. Apocalypse is well aware of the catastrophes in the universe and is pleased at Sinestro’s bumbling. He says,

**Apocalypse:** Sinestro, you’ve invoked a more pleasing world among the other worlds to rule over. The disarray in these places are all the more suited, but I cannot tell you how to invoke my most ancient of names. You’ve said them all incorrectly. To escape my celestial prison, my Summoner, must know the correct invocation.

Sinestro is so overwhelmed by Apocalypse speaking directly to him, that he shivers and kneels with his head bowed, and utters,

**Sinestro:** Master, I tried. My mastery of magic is limited by my own measured mortality. Had I only existed in your time, I would have surely been your Minion, knowing your esteemed name.

**Apocalypse:** Though I might not rise in my true form to walk The Earth again, I must have a substitute vessel.

**Sinestro:** There are many humans here. Some who walk the earth with empty souls, others who are cloned and only need a soul.

**Apocalypse:** I know. I am well aware of what is going on in all worlds, but I require a person who can represent a symbol of my forthcoming.

**Sinestro:** You mean a sacrifice.

**Apocalypse:** I don’t require a human sacrifice. I want to inhabit a form. I need a person who fits every arrogance, posture, & rulership. It will be the final act.

**Sinestro:** I will have to think who might be fitting for you to embody. There are so many prospects to consider, Politicians, Musicians, Writers, Warriors, Lawyers, you name it.

**Apocalypse:** When the time comes. I will choose.

And an ominous Apocalypse leaves the communication process with his solemn silence and strange energy. Sinestro arises, saying,

**Sinestro:** Hail Sire.

Meanwhile, over at the Hall Of Justice, Aqua Man confirms to everybody that Sinestro is on the loose.

**Superman:** I am the most qualified among us who can fly about at record time to locate him. He can be anywhere on the planet.  
**Lex Luthor:** Yeah but do you know where to look? It might be a waste of time.  
**Wonder Woman:** We’re going to need a little magic.  
**Lex Luthor:** How about a little science? I’ve been mapping everything and have been right so far. It is possible that based off the data, I might be able to identity a consistent focal point since these events are happening around him.  
**Superman:** That’s a good idea.  
**Wonder Woman:** Meanwhile, Aqua Man, come with me.

Wonder Woman proceeds to lead him over to a private area to conduct a magical experiment with The Wonder Twins present. She places her magic lasso all around him, and forms a circle around him holding hands with The Twins.

**Wonder Woman:** Now close your eyes, all of you and meditate. We are all special here.

They try and try, and nothing happens.

**Wonder Twins:** We need more power. Hey, Super Man!

Super Man approaches holding hands with them, being a person of divine gifts as well.

**Wonder Twins:** It’s working, I can feel it.

**Wonder Woman:** Aqua Man, open your mind. Let me speak with Namor.

Meanwhile, in The Marvel Universe, Namor is exhausted and asleep in the guest suite at The X-Men Mansion. His mind takes a turn into the dream realm where he does hear Aqua Man reaching out to him in a void talking to him. And in the dream world, Namor speaks out,

**Namor:** How can you be me?  
**Aqua Man:** I just am. Listen to me. This is important. Sinestro. . . . .Sinestro. . . . . Sinestro. He’s the one. We don’t know where he is. He is dangerous. He is doing this. He broke free.

Then Aqua Man begins mentally transmitting everything he knows about Sinestro, plus history about The Legion Of Doom & The Super Friends, and these flood of images and stories compound Namor’s dream state. Aqua Man speaks again,

**Aqua Man:** Namor. Namor. We are one. What ever you think, I think. And what you might be feeling, I’m also feeling. Stay in touch. Friend. I will help.

The dream passes as Aqua Man is satisfied with his message. The next morning Namor wakes up remembering it and shares the dream with Jean Grey. She insists he tells Professor Xavier and Dr. Strange. Eventually everybody involved learns about it that day and conference.

**Duke:** All that is telling me something. This Sinestro must be caught.  
**Wolverine:** But how the hell do we tell people this?  
**Storm:** It might not be smart to.  
**Namor:** If people are out to get me, I don’t want anybody knowing all this.  
**Professor Xavier:** Jean, Dr. Strange & I will work on trying to locate this Sinestro. He can be anywhere in the universe. Our magical mental powers might be able to find him.  
**Rogue:** We still don’t know why or how he has anything to do with Namor.  
**cyclops:** Was it a grudge?  
**Namor:** I don’t even know him. And I’ve never heard of him before. We know from Aqua Man that it concerns Jason, Andrew & Scott. And from the dream, Sinestro kind of looks familiar, but I am not sure. I’ll have to go back to Atlantis and research that.  
**Duke:** What does he look like? I’m an old Atlantean, I know our history well.  
**Namor:** I’m not sure how to describe it. That human form he’s in is distracting me. According to Aqua Man’s feelings in his soul, that appearance is some type of guise. And he also shared with me that he thinks Sinestro is some type of celestial demon, who might have had some history in Atlantis.  
**Duke:** Well why would he think that?  
**Namor:** Because all this time when he & the Justice League were fighting The Legion of Doom, he was nothing but a guy with a power ring fighting Green Lantern, who had the opposite power ring. And as time went on, he came across more and more opportunity for power but used it selfishly. Then he took his attention off from Green Lantern, and then began attacking Aqua Man in menacing ways. And alot of what he does now seems to do with consolidating his power for something.  
**Duke:** Hmmm. I’ll need to look at our old records as well. There are a few mysterious un-accounted for entities. I can’t say exactly which one.

Namor and Duke leave right away for Atlantis.

Meanwhile, over the last few weeks, Donald Trump got in touch with a few powerful people in his rapid effort to form an elite syndicate. Aside from The Kingpin and The Human Juggernaut, he now has Craven, The Warlock, Black Widow, The Hobgoblin, The Green Goblin, and Flash Thompson. And he now seeks to get a consolidation of more Marvel Universe villains and heroes to endorse his presidential campaign. Brett Segal, The Cabbalist, who’s friends with with Andrew, The Atlantean of Britonia, makes his move to reach out to Trump and manages to secure a meeting.

**Brett:** Hey Man. Let me congratulate you. You’re right to be building like this. Let me tell you. There is a lot of money to be made in this and . . . . . . .

**Donald Trump:** Sorry to cut you off, but I don’t think you came all the way out here to talk to me about cash. What is your real reason?

**Brett:** Okay look, we need you man?

**Donald Trump:** Who’s we?

**Brett:** The Atlanteans. I’m friends with some of them and we don’t like what Namor is doing. And what you’re gonna need to do is . . . . . . .

**Donald Trump:** Wait, hold up. How rambunctious of you to first of all assume I care, and then have the gall to tell me what I should do?

**Brett:** I didn’t mean it that way.

**Donald Trump:** Ofcourse you did. You’re trying to manipulate me.

**Brett:** All I’m saying is we’re all cut from the same cloth. Your allies, my allies, what we want and so forth.

**Donald Trump:** Go on.

**Brett:** Something BIG is about to happen. You already see the changes. And . . . . . . .

**Donald Trump:** You’re a part of that?

**Brett:** Yes! We know what’s going on. And what will be great is if we can rid ourselves of some people. We don’t need The Avengers, The Fantastic Four, The X-Men and others messing with this.

**Donald Trump:** Too late for that. Some progress on their part is already being made.

**Brett:** But none of us will be able to stay in power.

**Donald Trump:** I don’t think you care about that. You’re up to some agenda. Tell you what, I’ll think about it. It was nice meeting you.

Trump ignores him, and makes a beautiful swing, with his golf ball hitting its mark. Brett is not completely satisfied with the pitch he tried to make, but feasts his eyes on Trump and his wealthy property and considers his prestige in hopes that one day he might get a chance to be so fortunate to have access to talking with him again. He then leaves the property. As soon as Trump gets back to his lair he immediately calls The Kingpin to inquire about Brett.

**The Kingpin:** Oh I know him, he’s alright. He works really well and has a fine background.

And Trump laughs, understanding exactly what he means.

**Donald Trump:** So do you know anything about his current interests.

**The Kingpin:** I here he’s been trying to get some people together to go against The Sub-Mariner.

**Donald Trump:** What’s his beef with him?

**The Kingpin:** I’m not sure.

Trump thinks about it for a moment, then remarks,

**Donald Trump:** Namor seems like a nice guy. He’s doing a lot to help people. I have no beef with him. Keep a watch on that Dude. Let me know who he talks to. I have a feeling that he’s way more involved with what’s going on in our world right now than he lets on.

**The Kingpin:** Okay, will do.

Meanwhile, in Atlantis with Duke. The people are happy to see their Ruler return even for a brief time. He confers with Merman first, who tells him,

**Merman:** Nothing strange caught my eye here, although I had some suspicious communications intercepted.

**Namor:** From who?

**Merman:** It came from the Irvine Sector.

Namor, not surprised given what he learned from his episodes with Aqua Man.

**Namor:** Ahm look, I’m going to need you to keep doing what you’re doing. I made a break through in determining who my hidden enemies are in this kingdom. And to protect you just in case their desperation sets in, I won’t reveal much. Just keep an eye on everyone.

He leaves Merman and proceeds to The Library of Atlantis and venture to where the most ancient and sacred texts are kept. They start reading about different types of demonic entities that came against the kingdom at any one point.

**Duke:** Oh this is going to take a while. We need to narrow this down some more. We’re talking about millions of scrolls here.

Prince Namor lays back in wonder, trying to figure out one or two details he can recall from the visions, and when he does, he blurts out,

**Namor:** He just has a big head and he’s kind of evil looking.

**Duke:** You’re amusing me Namor. Is that the best you can do?

**Namor:** If I could just transfer what I saw so you can see?

**Duke:** Can you at least draw some of it?

Namor gets some parchment and draws a few scenes from his vision with Aqua Man, and out of the 13 so far, none of them mean anything to an Old Atlantean. Namor makes more colorful drawings until one particular scene catches Duke’s eye. He takes it and looks at it intently.

**Duke:** I remember this place. You have everything correctly, right down to the docks. This is The Land Of Muur. These waters were infiltrated by a Phantom Pirate named Leebaka. A terrible man, but his crew liked him. He took pride in running his ship. It was his life. Legend has it that he never truly died. He roams without a soul. He even sailed up to the Irish Isles.

**Namor:** That’s crazy. But what does he have to do with me?

**Duke:** Nothing. This is about Sinestro, if this guy is in fact him?

**Namor:** So where did he make the leap from being Leebaka, to Sinestro?

**Duke:** The question I’m more concerned with Namor, is WHO, and where is he now in our universe. That should more concern you. We know his alternate being is Sinestro over in that other universe.

**Namor:** Great Neptune! You’re right.

They both quickly sift through some information to identify the exact scrolls on him, and pull out one.

**Duke:** This is what he looks like.

**Namor:** His true form, but notice he likes using the same kind of look when he assumes human form as depicted in these scrolls.

**Duke:** Hmm, all we need to do is think about where he will most likely be in this world, and what he would be calling himself since his names tend to be on the archaic side. Namor, you go on and head back to Professor Xavier and them, let me refresh my history on some things. I know a few details about his history and defeating him, but I just want to be sure.

**Namor:** I’ll hold on to this scroll. It looks like a nice composite of all I need to know.

**Duke:** It’s best you don’t. If we checkout any materials, it might send off some alarm. We don’t know who is involved in the plot against you even at this library. I’ll study everything and cover for you.

**Namor:** Alright.

Namor leaves Atlantis again, and upon reaching the X-Men mansion, he seeks counsel with Professor Xavier & Jean Grey.

**Jean Grey:** Oh it’s great that you were able to read some of that ancient stuff.

**Professor Xavier:** Duke is right to not let you leave with any of it. If somebody out here was to somehow get a hold of it who was not on our side, that would be really bad. Let me conduct an exercise with you.

Professor Xavier then locks his mind with Namor to see what he saw in the scrolls, and after getting a fill of it, he then disengages and thinks about it. And after a moment, he remarks,

**Professor Xavier:** I remember seeing someone that kind of look like that who is associated with a shipyard.

And paying attention to everything is Storm, who remarks,

**Storm:** We should contact Spider-Man. He knows the city well.

**Professor Xavier:** We might need to, but I don’t want to involve too many people in this. It has to be on a need-to-know basis.

**Dr. Strange:** We can’t hesitate, the more time this guy has out there wreaking havoc, the more risky the situation.

**Storm:** Well, the part I’m trying to figure out is what exactly is this all about? Is it just Namor? Or are we missing something else?

**Dr. Strange:** It’s seems all centered around Namor.

**Storm:** We don’t know if something else is going on at the same time.

**Professor Xavier:** She’s right. It will all start to make sense once we catch this Sinestro guy, at least his counterpart in our dimension. I’ll contact Spider-Man.

Meanwhile, down at the lower East Side of Manhattan, Spider-Man finishes off beating up a would-be robber, and tangles him in a web against a back wall. The on-lookers call the cops and Spider-Man swings off to his next stop. While roaming, dressed in one of his new and more advanced spidy costumes, his tiny radio transmitter goes off and he answers,

**Spider-Man:** Yallow, it’s your friendly neighborhood Spider-Man.  
**Professor Xavier:** Spider-Man, we need you.  
**Spider Man:** Xavier what’s up?  
**Professor Xavier:** Storm suggested I call you for our mission. It’s top secret. Come quickly.  
**Spider Man:** Sure.

He hurries to the mansion and as soon as he arrives, he’s greeted by everybody. They begin to slowly explain to him part by part the whole story of what is happening, and an hour later, finally reaching where his presence in all this matters. Professor X, then taps into Peter’s mind to show him the vision of the guy they are looking for.

**Spider-Man:** Ah, he looks sort of familiar, but I’m not sure. I’ll need more clues.  
**Storm:** We think he has something to do with shipyards and the sea.

Spider-Man thinks about it some more and responds,

**Spider-Man:** The only thing menacing I can recall about somebody having to do with the docks and our harbor was a series of articles I wrote several years back exposing the abuses at one of the cities private prisons. And about 5 years ago was when the top officials decided to do something about it. Here, I can pull that up on your computer.

He pulls up several articles he wrote as Peter Parker detailing horrific abuses at the prison, along with some graphic photos, but what is unknown to them as it is happening in the current pseudo-time, is that much things and events are out of place, and what happened already in some form somewhere else already at one time, is subject to repeat itself now in another form. And as Namor reads on, he is moved by the story of one of Spider-Man’s foes, and inquires about him,

**Namor:** So when you defeated Dr. Octopus and he got tried, and placed in that prison, didn’t you know that they were going to treat him terribly?

**Spider-Man:** No, I didn’t know that. I wouldn’t have wished that on him. Though we’re enemies, I actually respect his genius. In my last tussle with him, it was a hard fight, but I managed to destroy his expensive scientific machinery; you know that deadly weapon he constructed that he was going to use to control the world, and I busted up his power suit. The Authorities got him out of that octopus contraption and placed him in prison where somebody beat him up real bad one day, that it rendered him almost paraplegic. And I heard he almost got violated. He tried to sue the city when he got out due to The State making an error in charging him for espionage accusing him of working in cahoots with The Russians when it wasn’t him. I then heard he was homeless for a while.

**Namor:** That’s terrible. I feel sorry for this man. Can you find out where he is. I’d like to talk to him.

With a little research, they discover where he is now, and Namor goes with Spider-Man to see him.

They approach The Veteran Home, where he’s staying and get a chance to speak with him.

**Namor:** Hi. Dr. Octopus, I know of you.  
**Dr. Octopus:** Yes I know who you are Sub-Mariner. I’ve followed your progress over the years. Spider-Man, what brings you here?  
**Spider-Man:** You! What happened to you.  
**Namor:** Given my position and influence as a global peace keeper and Avenger, I want to seek justice on your behalf.  
**Dr. Octopus:** I’m not sure what good it will do, The System don’t care about people.  
**Namor:** I care. That should never had happened to you. I don’t care how sinister they were trying to make you out to be. It’s about dignity.  
**Dr. Octopus:** You know I fought valiantly for this country as a Marine, only to ship out, back into Civilian life and get treated like a nobody. So I took my engineering intelligence and became Dr. Octopus.

**Namor:** Tell me about that prison you were in.

Dr. Octopus slowly walks over to a briefcase, opens it, and a bunch of newspaper clippings pop out.

And with much pain in his voice, he lifts up a photo in his hand and says,

**Dr Octopus:** Do you see this. This is the man who did this to me. He is wicked. I was lucky to even get this picture. This guy does not like to be photographed. I don’t know how he got through life with little to no photos out there on him given his position and power. I was able to get this from a source. Notice how he looks. I don’t even think he’s human.

Namor takes the photo, and Spider-Man looks on

**Namor:** It’s him. I even feel weird looking at it.

**Dr. Octopus:** You know him personally?

**Namor:** Ahm, it’s a long story. I’d love to tell you about it, but first thing is first. We’re going to need you to come back with us to The X-Men mansion. They can accommodate you. Get your stuff and check out of this place.

Namor & Spider-Man contact Professor X, to let him know and they arrive in a spacious vehicle to pick them up.

Meanwhile, back in the DC Universe, Justice League Members & The Legion Of Doom, continue to work together to figure things out.

**Super-Man:** Just think, if you were Sinestro right now, where would you be?  
**Cheetah:** With all that magic, he would be wealthy right now cleaning out the city.  
**Toy Man:** Ooh, if I had that power, all my favorite toys would be everywhere bringing every city under siege.  
**Wonder Woman:** Fortunately, none of you gained access to what Sinestro may have discovered.  
**Lex Luthor:** And that’s the thing. We don’t know whether it has anything to do entirely with him and power, or some grudge against Aqua Man. This elaborate spell he’s doing seems to be about something bigger.

**Batman:** I agree, but what?

**Grodd:** Well, to answer your question Superman, if I were Sinestro, I wouldn’t be anywhere I could be easily found.  
**Brainiac:** That’s an excellent point. I’ve been thinking about this whole thing, and what would make more sense to me, is if Sinestro was being used by somebody.  
**Batman:** Like who?

**Brainiac:** I don’t know. It could be anybody with an agenda. Remember he was sought after and released right?  
**Wonder Woman:** And then this whole mysterious change in all our lives happened. Great Hera!

**Scarecrow:** I’ve been consulting with my inner-most spiritual self and found that Sinestro should not be our focus so much. There is one greater than he we must fight.  
**Super-Man:** DARKSEID!

**Lex Luthor:** I thought you said you felt it couldn’t be him.  
**Super-Man:** Either him or Mxyzptlk, but why?  
**Scarecrow:** You were right before Super-Man, I don’t feel it’s them at all. First of all, Darkseid wouldn’t attack this way. He likes challenges and would be directing his assault against you. Mxyzptlk, likes playing funny & tragic games with people, but there’s always a way out of his mess when you trick him into saying his name backwards. Both entities are powerful, but this here has something to do with something more ancient. I sense it.  
**Super-Man:** Any ideas?  
**Wonder Twins:** What could be so ancient to stir up this much trouble?

Gleek, their busy-body space monkey is fooling around the place while grown folks are trying to solve a serious problem.

**Wonder Woman:** Merciful Minerva. It would have to date back to the time of The Gods.  
**Super-Man:** None of the Super Villains of Krypton could do this, unless somehow they acquired some mystery weapon or token of magic.  
**Batman:** You think it’s one of them doing this?  
**Super-Man:** I would have sensed it. I am the only one of my kind here.

**Lex Luthor:** Which brings us back to Sinestro. Where can he be?

Gleek, got himself up on a work desk, messing around with some stuff he doesn’t understand, and when the computer begins to make some strange sounds due to him randomly pressing buttons, it frightens him and he leaps off, drawing the attention of the team. The Wonder Twins go over to see about him and notice the problem he made.

**Wonder Twins:** GLEEK! You ruined the computer. All that data lost.

Lex gets up immediately and runs over to it.

**Lex Luthor:** No he didn’t ruin it. He just accidentally hit a few of the function keys, and some secret codes I had programmed for my project.

Lex then brings the screen back to normal, and he notices a series of random letters and numbers across the screen that don’t mean anything, but look interesting enough to ponder, and in doing so, he remarks jokingly,

**Lex Luthor:** For a space monkey with limited IQ, he certainly figured out something.

**Batman:** What?  
**Lex Luthor:** Come look.

Batman heads over to the screen, and comments,

**Batman:** It looks like mumbo-jumbo, except for that phrase there, hi per spays.

**Lex Luthor:** HYPERSPACE! What if Sinestro is not even here on the planet, but is in his own bubble in time or something?

**Brainiac:** With the infinite possibilities of the universe, it is the perfect place to be.

**Wonder Twins:** We must tell Aqua Man.

**Wonder Woman:** He’s still asleep hoping to catch a premonition.

The team continue their conversation deciding on what move they should make next.

Meanwhile over at The Marvel Universe in Atlantis, Duke is satisfied with all the reading he did about that demonic entity, and heads over to his place to collect some tokens of magic he’ll need to use to defeat it. He then leaves Atlantis and returns to the X-Men mansion where he finds Namor and the team their with Spider-Man, and Dr. Octopus. They fill him in on everything. And this astonishing news, makes Duke even more interested in finding out some more stuff from Dr. Octopus.

**Duke:** Tell me, what kind of habits did you notice about him?

**Dr. Octopus:** Well, what struck me as weird about him is how people seem to like him. This guy is a notorious abuser. He delights in it. And he gets Minions to do his dirty work. They just follow his bidding.

Duke turns to Namor and says,

**Duke:** That’s that strange mind control power he has.

And Dr. Octopus Continues,

**Dr. Octopus:** And he’s heavily ritualistic. I mean, like clock-work. You’d think he was working a spell or something.

And Duke smiles, and says,

**Dukes:** Having some connection to the moon, and the stars right? He operates in a pattern that makes sense to him, right? That’s not terribly unusual but tell me, do you remember anything specifically designed around you?

**Dr. Octopus:** Come to think of it, no. I mean I wouldn’t notice. I would have to know, but there was this one thing though I noticed about the jail, no one whatsoever had any religious items. There was no cross, beads, crucifix, bible, or prayer card from any faith and I found that odd.

And Duke remains solemnly quiet, then asks

**Duke:** Did he ever say anything strange to you?

**Dr. Octopus:** Not really. Nothing out of the ordinary that a sinister person would say to you anyway. He did speak kind of strange though. He had an eerie tone and spoke in terms of perpetuity, like he didn’t expect to die.

**Duke:** That’s because he’s not human. Him being able to imprison you and other Super Villains like that in a private prison off The Docks tells me about the kind of people empowering him, and who knows about him and are protecting him.

Meanwhile, in Atlantis, Jason, Scott & Andrew, pass the time by playing ‘Dungeons & Dragons’ with their other friends Julian, Brandon, & Nicola. And while strategizing with that role-playing game, their real life objective is to somehow compromise Namor so they can gain Atlantis.

**Scott:** You know, we might be in over our heads with this plan.  
**Jason:** Well we got Brett out there. We just need to wait and time it perfectly.

**Andrew:** Who’s to say he’ll play himself. All this is a gamble.  
**Jason:** Sinestro knows what to do. No one will ever figure it out.

Meanwhile, in his magical castle, Dr. Strange is engaged in recruiting his older and more magically experienced brother Warlock, who tries to help him divinate the location of Sinestro.

Meanwhile, Namor uses his political power speaking at The Council of Nations, and other agencies empowered to act on complaints. They take what he has to say seriously and move to take legal action in favor of Dr. Octopus rewarding him 300 pieces of gold, tax-free due to his unjust suffering in the prison. And they agree to close the prison and prosecute Sheriff Lee Roy. The Free Press publishes Namor’s accomplishment asking him to come speak on various issues. They bring up his past victories on social justice matters where he cared enough about old people to expose malpractice happening at a hospital with the facility giving them dirty gowns to wear. They also noted his advocacy in reprimanding an unscrupulous company’s practices at a burial site where they cheated customers and failed to bury their dead. And they praise his other humanitarian efforts around the globe.

Meanwhile, at the X-Men mansion, they have a conversation about it all.

**Professor Xavier:** I hope Namor doesn’t wear himself too thin with all that humanitarian stuff. All that should just be a cover for our real mission.  
**Storm:** Professor, this distress signal just came in. The Mandarin is attacking The Fantastic Four.  
**Beast:** Why is he messing with them?  
**Storm:** Nothing makes sense anymore, it could be some power struggle over something. I’m dispatching you, Gambit, and Rogue to handle it.

They go out there, and realize it is a takeover plot for territory. After a fierce fight, they manage to subdue him and he disappears back to his lair.

**Fantastic Four:** We’re trying to protect Los Angeles from almost every villain in the galaxy. Had you not shown up, we would have lost the city.

**Rogue:** Oh that’s alright Sugar, we’re working on a way to normalize the universe again.

**Fantastic Four:** Thanks for your help.

Rogue, Beast, and Gambit head home. Meanwhile, Donald Trump is pleased to hear that he won over some new Mutants including, Black Cat, and Captain America. He’s so elated at the prospect of winning The Presidential Election with such a line-up that he goes out celebrating at a local tavern on The Floridian Docks where he has Supporters there throwing a Party. A lot of rich people are there and he’s enjoying himself as a young man. He meets a woman named Tempest Dame, coming on to him and they share the night.

Early next day, at The X-Men Headquarters, Professor Xavier calls a meeting to discuss Sinestro again and his impact on life.

**Professor Xavier:** We really need to find this dude QUICK! With what happened yesterday with The Mandarin trying to muscle in on L.A., it all fits a grander scheme. And I just had another premonition where we will have to worry about Thanos and also Galactus moving in on our world.

**Storm:** Ofcourse, with all the magical action going on I would imagine all that happening.  
**Dr. Strange:** My brother and I using our magic have identified a possible location.  
**Gambit:** Oh yeah? Who’s your brother?  
**Dr. Strange:** Warlock  
**Rogue:** Warlock? Who would have thunk it?  
**Dr. Strange:** Yeah a lot of people don’t know that.  
**Rogue:** You look different.  
**Dr. Strange:** Yeah, well, what we worked out is that Sinestro’s in the constellation of Orion.  
**Duke:** Why there?  
**Dr Strange:** We don’t know, but we assume it must have something to do with his spell.  
**Duke:** So how do we get him?  
**Storm:** Our ship will take too long.  
**Rogue:** Why not use The Guardians of the Galaxy  
**Professor Xavier:** We can’t deprive millions of people from their protection in the parts of space where they cruise. It must be someone capable enough, but discreet.  
**Storm:** Oh I know the perfect person for this mission, The Silver Surfer.

**Duke:** How do we contact him?

**Storm:** That’s the tricky part. He’s one of those Super Heroes you just can’t call up like that. Though he cruises the galaxies protecting worlds, he leads a normal life in his private time and can be on any planet right. We have no way of knowing, but let me contact The Fantastic Four. They might know.

Meanwhile at their Headquarters, The Fantastic Four answer an X-Men transmission.

**Fantastic Four:** Hey what’s up? I didn’t expect to hear from you guys so soon.  
**Storm:** We need a favor. Where is The Silver Surfer?

**Fantastic Four:** He’s on vacation. Why?  
**Storm:** A Vacation? This is not the time to be slacking off from duty with what’s happening?

**Fantastic Four:** I’m just pulling your leg. He’s being extremely careful these days due to all this. It’s affecting him too.  
**Storm:** Tell him that we discovered an answer and are in need of his help, pronto.

**Fantastic Four:** Absolutely!

Meanwhile, over at the DC Universe, the Super Powers Team are getting closer at pinpointing an idea of where in the galaxy they think Sinestro is with the help of Black Vulcan and Green Lantern, assisting Brainiac, Lex Luthor, and Grodd, who mapped it out in their own mathematical & scientific way based on a hypothesis, and came up with,

**Lex Luthor:** The Belt of Orion

**Batman:** And how did you get that?

**Lex Luthor:** Well, given what we know about him, and what his ambitions may be, and where the heavens are aligned now, we figure he’s up to something quite profound.

**Batman:** Sounds logical enough.

Meanwhile, elsewhere in his unholy space in the universe, Sinestro talks to the demonic entity Apocalypse.

**Sinestro:** Oh Great One, there are many in this world worthy of your inhabitance.  
**Apocalypse:** I seek only one.

He continues working his magic. Meanwhile, in The Marvel Universe, Donald Trump’s campaign for president grows and he cements more deals with people. And as things go well for him during the day, he’s being harassed at his office by that lady he picked up the other day wondering about their relationship. After dodging her calls earlier in the day, he finally answers,

**Donald Trump:** Oh hi Tempest, how are you?  
**Tempest Dame:** I’ve been trying to reach you. I thought we had something going. You’re ghosting me.  
**Donald Trump:** Ahh look Babe, you see what happened was, I had a very bad argument with my girlfriend Melanie, and I thought we were over. We’ve since made up again and I plan to marry her.  
**Tempest Dame:** WHAT?!  
**Donald Trump:** It’s true. I’m sorry I ghosted ya. I thought you would have moved on by now.  
**Tempest Dame:** You’re playing me!  
**Donald Trump:** No not at all. It’s the honest to God truth. I planned to continue dating you, but I learned my ex-girlfriend I thought I broke up with is carrying my kid. I gotta marry her.

**Tempest Dame:** You lying son of . . . . . . .  
**Donald Trump:** No. Hey. Hey. Stop yellin’.

She hangs up the phone on him. Before the office work day is over, he learns reports in the news of a mystery woman accusing him of inappropriate touching, sexual advances, and such. He ends up in a panic, and calls his friend Coen Michaels.

**Donald Trump:** I’m going to need you to shut this lady up. Pay her like 300 pieces of gold or something. Get her out of my face. It’s bad for my campaign.

**Coen Michaels:** O.K. Boss.

Coen Michaels and some goons track her down at her child’s playground and demand she takes the hush money and sign a non-disclosure agreement. She refuses, grabbing her child, running to her car, and speeds away. When she goes around town the next day shopping for a Lawyer, people knowing better don’t want her case. One guy blatantly tells her,

**Pimp Dave, A Ghetto Lawyer From Crenshaw:** Look Ahh, what did you say your name was? Oh ahhm Tits Dame, Trump is building blocks and is quickly becoming The Head Man around here. I can’t stain my reputation with him tryna help you. Now get the hell outta here. You shouldn’t have slept with him.

She’s angry telling him off in cuss words that sound like they’re from another place. It then dawns on her to go contact the one reputable person it makes sense to take her complaint to.

**Namor:** Tempest, looking at you, I sense you’re not fully one of ***them*** from the fact you chose me to represent you. Tell me your story.

**Tempest Dame:** Oh Namor, I was an infant in Atlantis at one point. My people are of the Britonia Atlantean bloodline. And I know you helped some of us find refuge during the civil war over 500 years ago. I’m a mermaid who left Atlantis when I was young to live here among the surface people. I like my life here. It isn’t always great, but I love it. This latest problem I ran into is just a matter of respect. I didn’t appreciate this guy playing me.

**Namor:** I heard your complaints from other people already in the circles I frequent, but how are you so sure he played you? I heard from other sources that Trump has a wedding date set for June, and from the timing of everything, he expects his child to be born in The White House while he’s president.

**Tempest Dame:** I don’t care. He should never had encouraged me. I thought I had a chance to score big, and. . . . . . .

**Namor:** Look ahh Tempest, I can’t represent you with a story like that. It sounds frivolous. I have other people who need representation with much more dire cases.

**Tempest Dame:** But Namor, you don’t understand. We can stop him from becoming President. Word on The Streets is that this guy is blowing up BIG. Look at all the stuff that is happening. It’s going to be dangerous.

**Namor:** Go on.

**Tempest Dame:** I heard a few things. These other people endorsing him that we keep hearing about are really about building some syndicate.

**Namor:** And you can’t be a part of it now, because you got your feelings hurt, so you want to mess it up.

**Tempest Dame:** Well if you don’t represent me you might be missing out on a chance to stop this whole thing. He is getting too powerful.

**Namor:** I see the line-up of Super-Villains he has working for him. He’s even winning over a few Super Heroes. Captain America, who I thought knew better, is over there now. So is Iron Man, and others.

**Tempest Dame:** See!

**Namor:** First get that gum out your mouth. It’s annoying me. Let’s get you cleaned up a bit to look better, more like a Soccer Mom or something. And let me think about your story and some way of defending you.

Tempest runs over thanking him with a hug and a kiss. The next couple days, they hit the airwaves with a news flash about Trump’s indiscretion. All the other Lawyers Tempest went to before, are shocked to see she got Namor to take her case and she’s loving the media spotlight. This draws Trump’s ire as he is so close in his art of sealing some epic deals. He calls his Fixer again.

**Donald Trump:** Ahh, Coen I’m gonna need you on this again.  
**Coen Michaels:** I know all about it Boss. I’ll get on it.

After that call Donald Trump then reaches out to Brett The Cabbalist, arranging a meeting with him.

Meanwhile, back at the X-Men mansion, The Silver Surfer shows up, and Storm is the first to greet him,

**Storm:** I’m so glad you’re here.

And Namor comes out greeting him,

**Namor:** So you’re the man who can help me.

Without answering, The Silver Surfer looks at Namor with a solemn gesture. Professor X & Jean Grey take Silver Surfer aside to try and explain this whole thing to him, when he blurts out,

**Silver Surfer:** I know already. I have all the answers. All this could have gotten worse. Who do you think is stopping it from expanding?

**Storm:** YOU?!

**Silver Surfer:** I’ve been tried by the worst forces already and survived. I already traveled back through time and space knowing each outcome already, and none is perfect. Sinestro does not even know this.

**Professor Xavier:** You know about Sinestro?

**Silver Surfer:** With my incredible abilities, there is little to nothing I wouldn’t be aware of in these universes, yet I am limited in some ways still.

**Beast:** Well why have you NOT seized Sinestro?

**Silver Surfer:** I will, but I can’t risk having the wrong outcome.

**Storm:** What do you mean?

**Silver Surfer:** I’m waiting for the right arrangement. If I stop him now, a domino effect will happen in time. If I stopped him yesterday, the same thing would happen. If I stop him tomorrow, it will definitely occur. He knows about me, but doesn’t know when I’ll come. He thinks his cloaking spell that he’s using where he is now will hide him, but it only works with Beings less powerful than me. I must congratulate you guys for thinking as far ahead as you did. And your friends in The DC Universe have also identified some things well. Now I am the one and only Silver Surfer, and I am a hidden mystery to some.

**Professor Xavier:** So you already know the outcome of it all, atleast from the times your visited.

**Silver Surfer:** You and Aqua Man, are not the only alternative reality affected. There are also other parallel worlds with alternate versions of the same beings. And while you’re Super Beings in this world, I am also concerned about the best possible point in time to choose to act, where even the reality of the most normal and human person who is also like you, can survive his drama too.

**Jean Grey:** So you’re concerned about another man somewhere in the universe who’s life may unexpectedly change if you choose to save the reality of just one person’s parallel fate.

**Namor:** I would want the same.

**Silver Surfer:** Namor, I will save all the different versions of you and everyone else to endure the fate I feel is best for everybody. The only thing limiting me is the choice of others. In other words, if one of you by your own will choose to do something compromising, it can either set me back or potentially ruin a good save,

**Beast:** You basically mean that Aqua Man should not be making any risky move or choices that might compromise Namor, or anybody else they are spiritually tied to since they are in a way, the same person, lest the other person ends up dealing with some version of the same problem.

**Silver Surfer:** And this is not easy for me. None of it is looking any good.

**Namor:** So can you guide us? Am I doing what’s right now?

**Silver Surfer:** I’m afraid to comment. It’s too risky. Just live your life. I’m more informed than you think. Don’t contact me anymore. When next you see me, this will be over………almost.

And with that said, he disappears.

**Rogue:** What’s that about?

**Gambit:** Strange guy.  
**Rogue:** He’s just leaving us hanging.  
**Professor Xavier:** No, I don’t think so. He definitely knows something.

**C**yclops:\*\*\*\* So we should just do what he says then and continue what we’re doing.

Professor Xavier’s mind is boggled by this encounter and he tries thinking through it. His thoughts are on Namor, assuming that his current choices may not be the right thing to do, but says nothing to him just to not trigger any further potential problems. So he responds in a solemn tone,

**Professor Xavier:** I’m going to retire for the night and think this through. Namor, just be careful.

Meanwhile in Atlantis, Andrew The Britonian frantically reaches out to Jason, Scott, and the rest of their circle of friends telling them,

**Andrew:** Namor needs to be stopped. FAST! I learned from my contacts in the Surface World that he is about to make some serious trouble. We can’t risk waiting any longer. We need to take over this place fast. I’ve already made some arrangements with some people. Back in Britonia 500 years ago in our Atlantean Kingdom, we had something called AUSA, it was the Atlantean Underworld Special Agents, and what we did was solve particular problems. I took the liberty to talk to some high council people to set that up here to PROTECT Atlantis, and they are deliberating on it.  
**Scott:** But what about Merman and the others protecting Namor?  
**Andrew:** If we get the High Council on board with us, we can move to seize Namor. I have Brett working on that, and now he’s returned to The Surface World to ensure a few things.

**Jason:** I only hope all this stuff works. It can turn out rather badly for us instead.

**Andrew:** Don’t worry.

Meanwhile, in the DC Universe, Superman flies through space to the belt of Orion to get Sinestro and as he arrives in that Star System scanning where he could be, he finds on an asteroid what looks like a camp of some sort, and as he enters, he finds asleep what looks like an alien being. He goes closer to examine the person, and find that it is not a real person at all, but some kind of humanoid form. He looks around and sees scientific stuff and what looks like spellcraft. He gathers samples of some of it, along with hair and skin samples from the lifeless being, he memorizes a few other things, and then leaves. Upon returning to the Hall of Justice, he shares his findings. Lex examines the material and remarks,

**Lex Luthor:** This is cloning technology. He must be trying to make a person.

**Hawkman:** For what?

**Superman:** I was discreet with everything, if it was Sinestro’s magic lab, on the surface, he would not know I was there.

**Scarecrow:** Unless he sensed your presence.

**Wonder Twins:** Oh what will we do? We should not take any chances with him. I say we destroy his lab.

**Superman:** That will immediately alert him.

**Aqua Man:** Please destroy it. It’s time we go directly to war with him.  
**Black Vulcan:** It would be great to learn the purpose of this clone.

**Lex Luthor:** Wait. Before you do anything. Let me run this sample through a program I have back at my place to see something first. Brainiac, will you join me. I’m gonna need your help. Anybody else wanna tag along?

Black Vulcan, Bat-Man, and Green Lantern leave with them to go to The Legion of Doom Headquarters. Once there, Lex submits the skin and hair sample in a machine for it to generate a result. Based on what it deduced, the super computer then outputs a DNA calculation of what the person should look like.

**Black Vulcan:** It looks like Sinestro. But why?

**Batman:** We need to warn everybody.

They leave quickly again using Green Lantern’s magic, right back to the Hall of Justice where they relate their findings.

**Robin:** Great Scott! Two Sinestros!  
**Batman:** Why would he want a twin?  
**Lex Luthor:** From what we know about him by working together in the past is that, he’s the only Sinestro in the universe, or should I say universes, which would mean he has no parallel kin.

**Batman:** So what’s the purpose of the clone?  
**Lex Luthor:** I don’t know. I say we destroy everything he has up there quickly, before we find out.

Superman leaves immediately to do so, and the rest of the team move to destroy the samples they have.

Meanwhile in the Marvel Universe, Brett The Cabbalist meets with Trump to discuss moves for getting rid of Namor.

**Donald Trump:** I heard about Namor before. I liked the work he was doing over the years. He’s never bothered me. I never imagined he would rise to such prominence so quickly here in our neck of the woods, and now I’m seeing what you were trying to tell me.

**Brett:** Don’t worry. My friends and I will handle it. We just need you as our ally in The Surface World, to ensure Namor’s demise.

**Donald Trump:** You got it. Now tell me more about this New World Order your friends are planning?

**Brett:** Well, at this point, you should know. It will happen soon. We are trying to raise Apocalypse.  
**Donald Trump:** APOCALYPSE! Are you serious? Didn’t the X-Men and some others use all their power to defeat him several years back?

**Brett:** It was all a spell at the time too, they were not keen to much. The stars are more favorable now to attempt it again. All parts of the spell is almost complete. He only needs a host body now.

**Donald Trump:** So he’ll be King of the world inhabiting someone’s corporal vessel. Who’s?

**Brett:** He’ll assume someone when he’s ready. Right now, we need to make policies working in our favor from all the other secret society groups.

**Donald Trump:** Keep me abreast of everything.

Meanwhile, Namor continues his global political legal work at his various work spaces depending on where he happens to be on the globe, representing persons, communities, and organizations. And he gets around pretty quickly to different locations by various means. And out of the 400+ cases he’s handling, the one he has as top priority now is the Tempest Dame case. And with him and her going around to all the media, a lot of people now feel that Donald Trump should not win the presidency due to this scandal. ***And now*** the people being so in love with Namor, are asking HIM to run for the top job. Some reporter puts him on the spot to answer and he says,

**Namor:** YES!

And privately watching this telecast, is Professor Xavier whose facial expression suddenly changes to a sad one as he says,

**Professor Xavier:** No.

Meanwhile, in Atlantis, news gets back to Jason and the rest of them about Namor, and their blood boils even more.

**Jason:** Now this lunatic wants to be King of The Surface Realm too.

Jason and his friends go over to the High Atlantean Council pushing their concerns again, and this time the leaders there see cause to allow for an independent agency to be created and led by the people Andrew suggested. And as the days go by, while Namor is out there doing what he’s doing, The Atlantean Underworld Special Agents (AUSA) is being born and appointed are: Brett, Andrew, Brandon, Nicola, Julian, and some other Atlanteans they suggest to be investigators and prosecutors. And before the day is over, they waste no time in opening up an investigation into the Atlantean Treasury to see how much spending Namor did. Then they start to look into all kinds of other things as well.

Meanwhile, back in the Surface World, at the X-Men mansion, some of the heroes there congratulate Namor running for president, while the others are worried. After making small talk, he retires to his room to try to tap into a psychic telepathic meditation with Aqua Man.

**Namor:** Aqua Man. Aqua Man. Are you with me?

**Aqua Man:** I’m here. Guess what I found out? Sinestro was trying to clone himself, but we destroyed the base.

**Namor:** Well I had a celestial visitor a few days ago called The Silver Surfer. He’s a really powerful nomadic guardian, and he said he saw through all time and space about each of our lives and the ones we spiritually share with other alternates, and he’s trying to pick the right point in our destinies to strike before attacking Sinestro, since moving one way or the other too soon or too late might offset our fates.

**Aqua Man:** I believe that. So what are you doing?

**Namor:** I’m just being Namor. I’m handling my issues here, and helping people. And you?

**Aqua Man:** I’m dead set on defeating Sinestro. As soon as we get rid of him, we can all breathe again.

**Namor:** True. Stay strong brother. Good night.

**Aqua Man:** Good night? It’s dawn here. Have a nice day.

Meanwhile, Sinestro returns to his asteroid to find his lab completely destroyed. And from the looks of things, and how it was done, he immediately knows it must be Superman and remarks,

**Sinestro:** They are on to me. Now if I am intercepted at any point by someone powerful enough to stop me, I can’t escape by ducking my soul out of my current form into my new cloned corporal body, but how did they find out about this place? I under-estimated them. I need to tell my constituents.

Sinestro uses his magic to disappear, and then re-appear right into the Irvine Sector of Atlantis where Andrew, Scott & Jason reside. He tells them everything, and they are livid.

**Jason:** What this means is that they probably know about us.

**Scott:** Not necessarily, it’s possible that maybe they don’t know everything yet.

**Andrew:** Don’t under-estimate Super-Heroes. You saw how they figured out where you were. I fear they might be on to our world domination scheme and have or will figure out that we are trying to raise Apocalypse. I say we move now to seize Merman into custody.

**Jason:** And charge him with what?

**Andrew:** Tomorrow, we’ll just reach into the law-making logs, and change the part about using foreign inter-dimensional Atlanteans as Sentinels, and base that off as a national security risk why we’re doing it, and make that rule effective today.

The next day, the AUSA Team makes it happen, and then they dispatch some people to arrest Merman. He is very surprised by it calling their agency illegitimate, as he cites accurate law informing them that no such entity can be approved without the authorization of The Ruler of Atlantis. And one of the guards respond,

**Arresting Guard:** He ain’t here.

He then man-handles Merman, who then fights back and all 4 guards jump on him. Merman quickly presses a distress signal on his upper-right breastplate and the high frequency signal is specially designed to reach Namor where he is. And Namor receives it on his way back to the mansion en route from one of his humanitarian meetings.

**Namor:** Something is wrong. I can feel it.

**Duke:** It might be a trap. You’ve been making a whole lot of waves here.

**Namor:** I still need to risk it. My people need me.

**Dr. Strange:** I agree with Duke. Prepare yourself for possible treachery. Let us accompany you.

Dr. Strange, Jean Grey, Bishop, and Duke all accompany Namor to see what’s up. They arrive in Atlantis through a magical portal Dr. Strange created. And the people shout,

**The Atlantean People:** NAMOR IS BACK ! ! !

An AUSA guy arrives on the scene telling Namor,

**Alexander:** We’ve made a few changes since you were gone, and according to the rules now, you can no longer choose to represent Non-Atlanteans in The Surface World.

**Namor:** How dare you! I never authorized any of this. I am your Ruler. I hereby command you to dis-engage from from this agency.

The AUSA Guy ignores his request and instead remarks,

**Alexander:** Namor, your leadership has been called into question, and I hereby request you and your Party to come with me.

They comply, showing up at a Hearing headed by an Atlantean Dragon Judge from The High Council.

**Judge Celnafermengardef:** Namor, you abandoned your people to take up the ridiculous causes of lowly humans dwelling in The Surface Realm. What do you have to say for yourself?

**Namor:** I never abandoned my Kingdom. I love my people dearly. I am also partly of The Surface Kingdom, and have been treated fairly by them, to in kind return the favor.

**Judge Celnafermengardef:** It has been brought to our attention that you are now seeking to rule over The Surface Plains. Is this true?

**Namor:** I wouldn’t exactly put it that way. They are just looking for a President.  
**Judge Celnafermengardef:** And you accepted their offer?

And before Namor can answer, Duke taps his shoulder and whispers,

**Duke:** Let me take it from here.

Namor then defers control to him.

**Duke:** Your Honor, this line of questioning is for what end? As an old wise Atlantean dealing with many matters such as this, I contend that Namor is not about to betray the best interests of our people or give up his reign here. He was simply asked to participate in a political sport. He seeks no interest in human affairs above Atlantis.

And angry at this answer are the 7 AUSA Prosecutors sitting opposite him. One of them springs up accusing Namor.

**Brett:** I have first hand evidence that he is representing a woman making trouble for the would-be Presidential Lead Candidate.

**Judge Celnafermengardef:** What say you?

**Duke:** Judge, the woman is simply an Atlantean cross-breed mermaid who is hiding her past to assimlate into human society undetected. Namor was the only one sensitive enough to accept her case.

**Judge Celnafermengardef:** Fair enough. I adjourn this hearing with no further inquiry. You are free to go.

**Brett:** But Judge!

The case is dismissed and Namor leaves with his team to find Merman. Along their route, Dr. Strange remarks,

**Dr. Strange:** That was intense. It was like they want you stripped from all your titles and power.

**Namor:** This whole thing feels very strange, no pun intended.  
**Duke:** That’s why when we get them to release Merman, I’m going to have to assert some powerful legal protections for you. I’m seeing the subtle changes in everything and believe me, you’re not safe here.

They scurry to the Imperial Court to force his release, and because Namor is still the imperial ruler of Atlantis, they must obey. Once Merman is free, another AUSA guy turns up giving Merman a legal notice to leave Atlantis. Duke takes the notice from Merman, reads it and remarks,

**Duke:** No Atlantean law will allow this. Merman is a bonafide Sea Man welcomed in our waters and entitled to the same constitutional rights as any of us. It has been our founding law since creation.

Duke tears up the document, tosses it and walks away with his team. They head back to the palace, and upon arrival are 2 other AUSA guys serving Namor with a violation that he is harboring a foreign agent. And Duke responds,

**Duke:** You’re harassing us! Namor is our Ruler. He has an imperial right to appoint any Stand-In he so chooses. Certain parts of our laws aren’t subject to change.

Knowing he’s right, The AUSA men leave them be, returning to their aquatic government building. Namor re-instates Merman as his eyes and ears in the Kingdom while he is absent. And Namor also decides to use Dr. Strange’s magic to seal off his immediate palatial quarters from AUSA invasion. And anticipating future problems, he decides to leave Bishop there to help stand guard, and also leave Jean Grey as the Telepath who will be more than aware of his Betrayers there. Duke obtains the latest codex of the changed laws, and decides to take advantage of one of the still standing laws which basically says, one can leave Atlantis, and not be tried under any changing new laws upon return, and to make a certified point of it, he goes to the highest Judge of The Imperial Court to sign off on it. That happens, and he, Namor, & Dr. Strange then leave for The Surface World.

Meanwhile, somewhere in the universe, some pretty dangerous entities sense the powerful energy in certain parts, and want to take control of the entire region. And showing up out of the blue is The Silver Surfer to stop them. All by himself, he is able to defeat a brood of villains dispatched by Thanos to take over some poor planet. And our Superhero cannot enjoy a second of rest as another skirmish breaks out over at another galaxy which he races to on his supernatural surfboard. Once there, he tackles with the forces of Ming, The Merciless. Again, all by himself he is able to subdue him and his magic, and race back to a point in the universe where he knows that there is one who will show soon who will want to devour the planet, and all the accoutrements alongside the milky way.

Meanwhile, on the Surface Plain, moving about somewhere in Hollywood is Tempest Dame, who runs into a popular British News Man name Pierce Morrison, who says to her,

**Pierce Morrison:** Tempest! Why are you wasting time with Namor? He’s crazy. Drop that case against Trump. I talk with Prosecutors regularly and I can assure you that your case will no go nowhere. We’re all trying to build a powerful syndicate here and you should be hanging out with us.

**Tempest Dame:** Oh I don’t know. I guess I should have taken the 300 pieces of gold hush money and got lost somewhere, but Namor you know; for the greater good, we’re still holding on to hope.

**Pierce Morrison:** Look Tempest, listen to me. You will lose. Right now, you should be thinking about yourself. When we seize power, there is nothing Namor can do for anybody.

**Tempest Dame:** But I’m Part-Atlantean.

**Pierce Morrison:** Yes I know who you are. I’m British. I know all about the folk-lores and legends. And you might be able to fool other people with this disguise, but I can see right through you. Come on join me for a bite to eat. I’m headed to one of my favorite taverns out here. Let me educate you about the coming take-over. We’re going to be under a new divine government.

Tempest is intrigued and she goes off with him. Meanwhile, at the X-Men mansion, Namor explains his ordeal to the rest of his mutant friends and they relate to him some new information they learned.

**Storm:** We learned more about that myth with the 3 mystery Atlanteans of The Britonic War.

**Namor:** What about them?

**Storm:** Well, they don’t exit.

**Namor:** What do you mean? We just got back from Atlantis. They are behind this whole thing.

**Storm:** I went through all our computer archives on known myths, and history, mutant backstories and so forth, and pieced together a few things that make sense to me at least. And what struck me to do it, was when you told us that Aqua Man said there were no 3 Atlanteans fitting the description in his current Kindom. So I wondered, did they survive that war 500 years ago or not. Well according to what’s known, in the battle, those 3 guys fitting that description died. Here’s an old painting of them.

Namor looks at it and remarks

**Namor:** That’s Jason, Scott, & Andrew. They look just like them.

And in that second, Namor recalls his last conversation with Aqua Man, and says,

**Namor:** No wait. Before I went back to Atlantis, in a meditation I was told that Sinestro was trying to clone himself.

**Duke:** And Sinestro is an old entity from that time, and . . . . . . .  
**Namor:** Oh no! They must be clones of themselves.  
**Duke:** To escape death. It all makes sense now.

**Dr. Strange:** But why did they choose to come to ***your*** kingdom and not Aqua Man’s instead?  
**Warlock:** Hmm, from my long time experience with magic little brother, I can firmly answer that one universe is older than the other, or maybe one person is the true original more so than the other, which means that Namor must be the true Aqua Man.

**Storm:** Warlock is right, I did do a search in our system a while back for my own edification, and I can confirm that our universe is slightly younger than theirs.

**Namor:** I’m older than my kin spirit? All this is overwhelming. Excuse me. I need to talk to him.

Namor goes to a quiet place to meditate and he psychically reaches Aqua Man, relating through thought and spirit all he has been through, and learned so far, and Aqua Man responds,

**Aqua Man:** Namor, you are in great danger. Unlike you, I am not experiencing any problems at all from anybody and now it makes sense. My Atlantis is not under attack in any way. I go and come as I please. What you need to do is prepare an army. I’ve dealt with treachery before in the past, and can recognize it anywhere. These people are coming for you. I’ll try to do everything I can to aid you. Right now the only thing I can tell you is an old business man here in our realm name Don Drumpf is about to become President, and Penguin has taken over the city. His headquarters is in Jersey. Remember the 7 day time delay between our worlds. Things happen here well before they develop in your universe. I’ll keep you informed.

Namor leaves the meditation sequence to talk to Professor Xavier.

**Namor:** Professor. We are about to lose. Trump will become the 45th President soon, and I believe The Kingpin over there in New Jersey will rule even more territories working alongside him.

**Professor Xavier:** He has all the Big Wigs backing him, and he has Magneto whipping up the troublesome Mutants to side with him.

**Namor:** Aqua Man is right. I’m sorry that I did not act on this before. I should have seen it coming. This is all about **ME** somehow. I’m going to need an army to defend myself. How quickly can we assemble what good Super Heroes we have left.

**Professor Xavier:** We still have quite a few heroes that have not defected yet, We still have Ms. Marvel, Dare-Devil, Black Panther, The Incredible Hulk . . . . . . . . .

**Namor:** Good. Tell them that war is coming. And we’re going to need the best weapons too.

A couple weeks go by, and Trump secures The Presidency, moonlighting in it for a few days. He remembers his promise to Brett The Cabbalist and moves forward to dispatch 4 Sentinels to show up at The X-Men mansion. These huge robots wreak havoc in the area and are programmed with one order, ‘Capture Namor’. As all the X-Men scramble to fight these Colossal Bots, people are screaming everywhere. Namor is angry. He is not prepared for this. He was more expecting regular villains to fight. The X-Men are masters of defeating Sentinels, and so he catches on quickly to their fight game. Realizing that the robots are more interested in him, he decides to fly out where the ocean is, and uses his telepathic power to call Cthulhu. The Sentinels chase after Namor, and not wanting to leave him to defend himself, Storm & Rogue follow suit. Cyclops and the rest are trailing. Namor manages to get all 4 in a compromising position out there on the shores to be destroyed. He times things well, and Cthulhu appears creeping on the shores impervious to their beams. If a robot could feel fear, they would know to run, and the mythic sea creature renders devastating harm. The X-Men appear to finish the job, and this whole episode becomes a wake-up call. They know now that the war has begun.

The very next day, they wake from the rubble of their once beautiful mansion. And fortunately for them, Dr. Strange and his brother, Warlock appear. They use their magic to restore their mansion. Once the X-Men step in, things are like they were.

**Storm:** Oh Dr. Strange, Warlock, our gratitude is beyond words.  
**Professor Xavier:** Well, you defeated one set back.  
**Namor:** I’m still real upset with what happened. Something needs to be done about this! They can’t just come here placing people’s lives in danger like that.

**Warlock:** It’s all over the news, and we understand the tactics. Lucky for you, my brother and I took the initiative of contacting Joseph Quinn. He specializes in dealing with stuff like this. He’s out there right now making an international case of this on your behalf.

**Gambit:** Well thank you. Like Namor, I’m still mad too. I can’t wait to get my hands on some people.  
**Cyclops:** How are we gonna win this war? The odds are stacked against us.

**Storm:** We can’t give up hope. It is who we are.

Dr. Strange & Warlock continue their magic to protect the mansion and it’s territory with a strong spell. And as the X-Men round up allies and prepare for battle, Namor contacts a number of people to let them know he cannot represent them anymore due to his current problems, and refers them to other Diplomats. The last person on his list to call is Tempest Dame, whom he’s rather angry at her from hearing on the news that she’s now a part of The Syndicate.

**Namor:** How could you betray me like that? I was protecting you.

**Tempest Dame:** Augh, Aw, oh Namor. Wait, hold on.  
**Namor:** Tempest are you drunk?

**Tempest:** Ahm, wha do ya want?

**Namor:** When you’re a bit more sober, I’ll call back and tell you.

**Tempest:** Tell me wha? You ken call back.

**Namor:** Go take care of yourself.

**Tempest:** You tek care of yo’self. You’re the loser.

**Namor:** You know it’s a shame you didn’t believe enough in yourself to make better choices.

**Tempest:** Don’t chest ties me. They gawna git rid of ya anyway.

**Namor:** Who’s they?

**Tempest:** All a dem. A pooka lips and them.

**Namor:** Tempest you’re a mess!

**Tempest:** Go on loser. I don’t need ya. I got Pears Morson.

Namor shakes his head and hangs up the phone, and says mockingly,

**Namor:** Oh, they gonna git rid a ya, a pooka lips and dem.

Storm turns around looking at Namor, and asks,

**Storm:** What?

**Namor:** I was just trying to talk to Tempest Dame. She’s drunk. She started rambling about how bad I am and how a pooka lips and dem are going to get me.

**Storm:** You mean **Apocalypse**.

Storm’s eyes just flutters in thought and she then remarks,

**Storm:** Okay, NOW this makes sense.

**Namor:** What?

Storm calls everybody into the room to discuss this.

**Storm:** I just found out the missing link to the puzzle. Namor was on the phone with Tempest Dame, and in her drunkenness she let some information slip. We now need to worry about **APOCALYPSE**.

**Namor:** Now that you say it that way, it does ring a bell. I have heard of him. Didn’t you all defeat him in some battle several years back?

**Professor Xavier:** Oh no! This cannot be happening again. We do not have the resources to fight Sentinels, and fight off everyone else, and deal with Apocalypse at the same time.

**Rogue:** So that’s it. This all has to do with the new power syndicate, but how are they gonna get Apocalypse? We buried that old Dude. He’s long gone.

**Warlock:** Let me check something.

Warlock beckons his brother, and they disappear into a portal back to Dr. Strange’s castle. They go through some star records, think about it some more and realize that the entire star system is near perfectly aligned a certain way to attempt an elaborate resurrection spell.

**Dr. Strange:** So a disembodied Apocalypse would want to choose a vessel to inhabit.

**Warlock:** Well that can be anybody.

**Dr. Strange:** So that’s what Sinestro was up to. All that chaotic energy. It makes sense now.

**Warlock:** But why was Namor sought after?

**Dr. Strange:** It might be some revenge plot for something. We need to create magic to counter it.

They work on some counter spells together. Meanwhile, at the mansion Joseph Quinn shows up. He informs Namor and the rest of the team that he successfully locked up The Government’s power from being able to negatively affect them again.

**Namor:** How the hell did you do that?

**Joseph Quinn:** I’m a master of those things. You don’t believe me, look at these documents.

Duke walks over there and looks at them. He’s impressed enough to say,

**Duke:** Superb.

Professor Xavier and the others are now curious to read them.

**Gambit:** You’re no joke Mr. Quinn. The Suckers have to recompense us. Ooh Wee, look at all that doe.

Though Namor is impressed, he’s still sickened to his stomach at what he and they have to endure, and everyone else it affects. He blurts out,

**Namor:** So how do we defeat Apocalypse?

**Joseph Quinn:** Apocalypse? He died several years ago right? Defeated somewhere in Mexico.

**Namor:** Well he’ll be back according to a spell some weirdo is doing in space.

**Joseph Quinn:** I don’t know about that. My jurisdiction is here. Now on this one, I’ll need you to sign off on this section here. I want to file this today. It bars them from taking any further punitive actions.

Professor Xavier, Duke, and Namor sign off on the document.

Meanwhile, back in the DC Universe, Superman recreated from his photographic memory the magical diagrams he saw at Sinestro’s space lab. The team ponders it, but don’t understand.

**Green Lantern:** I prefer the days when Sinestro was solely targeting me. I never knew him that well. He was always a mystery. And I wish I could help you interpret his strange magic.

The Riddler takes the parchments and his eyes dazzle looking at the cryptography.

**Lex Luthor:** It defies science. If we could only decipher those glyphs, it will all make sense.

Meanwhile in the Marvel Universe, the AUSA in Atlantis devise a new way to try and attack Namor because they heard through the grapevine that they cannot do certain things, and are mad.

**Jason:** If we could just lure him into a trap or something.

**Andrew:** He’s not stupid. If we devise something, it should be plausible enough.

**Scott:** How plausible? We’re limited now.

**Jason:** Well we still have Raymond Charles in The Treasury Department.

**Andrew:** We need to attack him on all sides at once where he can’t legally maneuver as well.

And while they’re thinking about their plan, back in the Surface World, Dr. Strange and Warlock return to the mansion with a plan.

**Warlock:** Okay, we have a workable counter-spell to all that magic Sinestro is doing, and have already set loose the first round.

**Namor:** So what’s gonna happen?

**Dr. Strange:** Well, it won’t be noticeable yet, but we’re reversing the most minor things first, and then the major. That will give us enough time to do some things without our enemies noticing the reversal.

**Warlock:** Oh, and we found out too through our magic that Sinestro’s ties to those 3 Atlanteans, 500 years ago has to do with them summoning him, and him doing a favor saving them. You see, they never truly died in that civil war as history believed. They escaped as clones of themselves through his magic. Sinestro should have remained in the prison created for him centuries ago. He was a pirate. Merlin created a glass bottle sealing him, and his pirate ship inside. It was a miniature figurine no different from the ones you see in stores now. Someway along the line it fell into different ownership and was never destroyed. The legend behind it grew thin until it fell into the hands of The Britonians. Someone was fiddling with the magic and eventually released him, and he became a problem ever since. He keeps his identity a secret by taking on certain lifestyles and jobs over the past centuries. He has been living among us as different persons from time to time, but he is always tied to a ship of some sort or some type of governance like a ship. He fakes his own origins and deaths or disappearances too.

**Namor:** So where is he now?

**Dr. Strange:** We tracked his spiritual imprint to Atlantis, but he left, and now we believe he’s back at a new location in space.

**Namor:** I want that guy stopped. I need my life back.

**Dr. Strange:** Don’t worry, we’ll get him. Also, just looking at everything from our perspective, we see where The Silver Surfer is right, but for the sake of success, we can’t tell you much.

**Duke:** Huh hmm. I already have my collection of magical items to deal with him and his spell when the time comes.

A News Flash takes their attention, Captain America is at a rally with Trump speaking to the people about making America great again.

**Captain America:** I spent my life fighting along side Super Heroes, and there’s no greater time than today to take notice of those among us who’s still misguided, not knowing what’s right for the country. That’s why I endorsed Donald Trump. The rebels are a problem. We’re already forming peace alliances with certain leaders around the globe we use to have trouble with. It’s a new dawn and a new age.

**Namor:** Turn it off. I’m so disappointed in him.

Rogue changes the channel. And they go back to discussing a plan of action. Shortly after, Namor excuses himself from the table, retreating back to his room. He’s experiencing psychic energy about him which he attributes to Aqua Man attempting to contact him. He gets into his meditative state and listens.

**Aqua Man:** Namor. Namor. I have something for you. Look at this.

At the Hall of Justice in the DC Universe, Aqua Man holds the parchments Superman drew replicating from memory Sinestro’s magic. He projects every detail in thought several times to Namor, who quickly goes over to a pen and paper to capture some of it before the image is lost in his mind.

**Namor:** I got it. What else?

**Aqua Man:** Nothing, we’re still trying to figure it out.

**Namor:** You were right. My enemies made a very desperate move days ago sending giant robots after me. I had to use Cthulhu.

**Aqua Man:** Ktulu!

**Namor:** Yeah and before, I forgot to tell you that I discovered like us, them too have a symbiosis.

**Aqua Man:** That’s good to know. Hey look brother, they’re calling me. I’ll speak to you later.

Aqua Man meets with his friends. Meanwhile, in his world, Namor looks at the glyphs he drew, and ponders them before taking it to his friends. When they get a chance to review them, Dr. Strange remarks,

**Dr. Strange:** It’s crudely drawn. Let me see here. That should more look like this.

Using his magic, Dr. Strange takes the psychic mental imprints off of Namor, and re-projects them onto the parchment exactly as Aqua Man intended.

**Namor:** Yeah, that’s what I saw.

Warlock looks at each one carefully, and says,

**Warlock:** This is very old magic. Look at the these odd symbols and the language.

**Dr. Strange:** He’s trying to summon Apocalypse remember?

**Warlock:** But how do we reverse it?

Dr. Strange is taken aback by it, because having some sense of what’s going on and seeing part of the future, isn’t enough. Duke looks at the parchments, retains it, but says nothing.

Meanwhile in Atlantis, Jason, Scott, and Andrew, come up with a new idea. Their contact Brett, has enlisted a new ally for their plot.

**Jason:** Okay, so this Scot Welles guy is gonna do the work for us. He’s already been paid 300 pieces of gold. All we have to do now is sit back and watch.  
**Scott:** Yeah, but I don’t like these Surface People Namor left behind here.

**Andrew:** Don’t worry about them? When things begin to fall apart for them, we’ll strike.

Meanwhile, back on the surface of the planet, Brett the Cabbalist meets with Trump again, and they talk awhile about Namor.

**Brett:** Can’t you do another attack on him though. I can’t believe he was lucky enough to get out of the last one.

**Donald Trump:** Well he’s a skilled Leader. I would expect that from him, and he’s got the X-Men. I was more hoping for a disaster. He’s more YOUR enemy than mine with that whole Atlantean thing.

**Brett:** We just want to rattle him further.

**Donald Trump:** If I do anything further, how would that look? I also need to observe peace agreements with certain organizations they are a part of. Some guy they have, I think his name is, oh what was it, oh his name is Joseph Quinn. He went around to all the courts and stuff locking up anybody from messing with them, and now we have to pay. But how is that raising Apocalypse thing going?

**Brett:** Something has gone wrong with Sinestro. He’s been compromised. Now we’re not sure. The chanting mistakes he’s made already caused all this.

**Donald Trump:** My kids like it. Melanie likes it, and I like it. Things have never been better. All the elites we’re hanging out with from previous times is one of those life experiences we’re lucky to have. And they are all assimilating to our current technology and way of life nicely. They don’t want to go back.

**Brett:** I’ve managed to circle in some Old Time Mobsters to help me too. I’ve got Scarface, Bugsy Siegel, and others.

Brett and The President continue to make small talk before parting ways. Meanwhile, later that day, a storm is brewing as the skies gather ominous clouds. And at her window drinking a bottle of Jack Daniels, is Tempest Dame reflecting on the past trying to convince herself that she made the right decision to leave Namor and not stand for the cause, but she recalls her conversation with Pierce, and realizes that saving her own skin is right. She tries to drink away her guilt and forget Namor. Meanwhile, invited to the mansion at a reception being held is a small group of exceptional Dignitaries, and mixed among them are those who lived in a previous life time.

**John F. Kennedy Jr,:** Namor, I must congratulate you on your presidential speech. It reminded me of my Father. I’m sorry it didn’t work out for you. You would have made a great President.

**Namor:** Thanks John.

He drifts off leaving Namor, and goes over to talk to some more people. Professor Xavier is over at the other side of the room talking with Dr. Martin Luther King.

**Dr. King:** And I missed out on all this too, due to the assassination. It’s great to be able to enjoy it now. And it’s kind of freaky being alive while being celebrated on your day. And it’s interesting to see the little anecdotes they do, like this one show I saw where they revealed to the kids that my real birth name was Michael, but I later changed it to Martin, ha ha ha.

**Professor Xavier:** Yeah, and you would have made a fine President too.

As their party continues, Rogue makes her way over to different circles of people from talking to rock stars to movies stars. Beast finds himself over there, talking to Einstein and other Intellectuals, while all the other X-Men pick out who they feel to talk to. Meanwhile, over in the DC Universe, The Riddler is determined to figure out Sinestro’s spell.

**The Riddler:** Magic is not that different from what I do. I like puzzles and conundrums.

**Lex Luthor:** Well if anybody could decipher it, it would be YOU Mr. Riddler.

**Robin:** Not so fast. Me and Batman are great at figuring out riddles too.

**Lex Luthor:** Right!

Robin works with The Riddler to try to figure out some things. Meanwhile, back in The Marvel Universe, living at the Southern-most District of New York, is Scot Welles, a young over-achieving genius who’s in an ivy-league high school, excelling in a specialized law prep program. He’s doing exceptionally well that now, he wants to achieve another impressive feat to his budding career by taking on the underworld challenge of privately helping some of the power elites effort in getting rid of Namor. He’s at his computer putting together a dossier of everything he can find on Namor. He does this for the next number of days while attending classes. He then meets up with one classmate and begins discussing plans with him.

**Scot Welles:** How would you like to NOW be able to afford the kind of life you want?

**Greg Freeman:** What do you mean?

**Scot Welles:** I’m talking about the big time. My extra-curricular activities are proving to be lucrative. I just need somebody to help me.

**Greg Freeman:** Well is it safe? I don’t want to do anything illegal.

**Scot Welles:** No, I would never ask you to do anything weird or criminal. I’m working on my career remember? I can afford to give you 72 pieces of gold.

**Greg Freeman:** 72 PIECES OF GOLD!

**Scot Welles:** Not so loud. Shut up. I’d like you to apply to this top college here. I know you are not that articulate, but I took the liberty to put what you should write. Here, take it.

**Greg Freeman:** Oh I don’t know. I know they aren’t going to accept me. That’s a racist college. Besides, my grades aren’t that good. And even though I’m excellent at basketball, they might not give me the scholarship.

**Scot Welles:** That’s what I’m hoping. When you get rejected, we’ll discuss the next stage of the plan. Here’s 5 pieces of gold. The financial markets are very favorable today.

Greg takes the payment, as money isn’t easy for him to come by. He knows his friend is very smart, and is aware of some of his past white-collar work with pretty uppity people. Greg knows that he was only lucky to get into that high school due to his athletic skills and some strings being pulled for him. And to look the part, he now has some extra money to go shopping.

Meanwhile, elsewhere in the world, warrants are out for the arrest of Sheriff Lee Roy. It’s all over the news about the abuses he and his crew were doing at the shipyard prison. And since no one seems to know exactly where he is, wanted posters are all over the place to the point where the popular appearance he’s been assuming for centuries, is too well known now. And watching the broadcast at the X-Man mansion is Duke who remarks,

**Duke:** Come out, come out wherever you are? It’s over. You can never roam the planet in that form again. Too bad!

The X-Men feel that they are finally getting somewhere and talk battle strategy since the odds are still not entirely in their favor yet.

Meanwhile, in Atlantis, Treasury Man Raymond Charles shows up at Jason’s place, showing him and his friends ***his*** findings. They go through his extensive log, and are impressed at the spending discrepancies he uncovered for their case against Namor.

**Jason:** This is great Raymond. We’ll call ya if we need you again.

Jason, and his friends continue working on trying to piece together all that stuff, with everything else of concern that makes Namor look questionable, to take to the AUSA people directly handling his case.

Meanwhile in Space, The Silver Surfer notices the subtle energy change in the spell where things in the unseen world are slightly going in a positive direction now, and he knows it’s the magic of Warlock and Dr. Strange. He also knows that after a few more series of events he anticipates happening in this time sequence, it may all be over if everything happens as it should.

Meanwhile, in the DC Universe, Robin, Scarecrow and The Riddler take note of the use of the moon, star placements, dates and time when something happened, comparing that data to whatever Lex Luthor came up with, and noticing a pattern.

**Scarecrow:** I knew Sinestro quite well, at least the part of himself he didn’t mind showing. He’s meticulous, professional and all, but I had no idea about the depth he would take his ritual practices. It’s so methodic. Even I deviate from time to time.

**Lex Luthor:** Hmm, it’s great that he operates that way for consistent studying purposes. Maybe we can predict something.

Meanwhile, in The Marvel Universe, after classes, young Scot Welles enlists another classmate in his plot, his ambitious friend Calvin Hopkins who is also feverishly working hard to become somebody in life. Scot pulls from his pocket 10 pieces of gold.       
**Scot Welles:** Here, take this. Thanks for meeting me here. You’re one of the best people for this. You know I do special work on the side to enhance my career right. Well, I can’t be everywhere at once. So I need you to follow around the X-Men, and anybody else on this list associated with Namor. Tell me what they are up to. I don’t expect what I’m doing with my higher-up contacts to take long. I can pay you in total 85 pieces of gold. How does that sound?

**Calvin Hopkins:** You’re pulling my leg. You can afford that?  
**Scot Welles:** Yes. It’s no problem. How soon can you get started?  
**Calvin Hopkins:** Well I would need some things first. I gotta get my car fixed. You remember a few months back I was shot by a Crips Gang Member.

**Scot Welles:** I’m sorry that happened to you, but this is not that dangerous. Just stay out of sight.

**Calvin Hopkins:** Well, alright.

They continue hanging out together a while longer before parting ways. Meanwhile, up in space, Sinestro is beside himself pondering what to do. He is well aware of The World looking for his human identity as Sheriff Lee Roy. His space lab is destroyed, even if he restored it, so much of the precious elements he gathered for his magic would take too long to acquire again as they were all obtained at a special time and place. He is thinking about when and how to ultimately escape, but still has to fulfill the obligations he committed to.

Meanwhile, at the X-Men mansion, Storm takes note of everything going on. And in passing, she happens to glance through the window where she sees a man standing outside, adversely. She calls Wolverine.

**Storm:** Take a look at this.

**Wolverine:** I don’t recognize him.

Gambit overhears everything and looks also.  
**Gambit:** He must be trying to break the protective magic on this place. Look at him.

Storm then calls Warlock. He comes and looks, then remarks,

**Warlock:** Oh, that’s Brett Segal The Cabbalist. Figures it would just be a matter of time before he popped up using desperate magic.

Warlock calls Dr. Strange over, as he still remarks,

**Warlock:** Let’s take care of this fool.

They both teleport outside and go into attack mode striking bolts of energy beams at Brett, who fights back with his own, but being out-numbered by 2 formidable Magicians causes him to retreat.

**Professor Xavier:** What does he want?

**Dr. Strange:** Probably just testing his magic. With the house shielded like this, it must be driving them mad. Let’s keep trying to decipher this stuff.

Professor Xavier places his hand on the parchments trying to read them psychically, then screams out,

**Professor Xavier:** AUGH!!! My mental powers are being blocked by something.

**Dr. Strange:** That’s his magic. He has some stipulation on it.

Dean then pulls out some magical elements from his pouch, and lays all 5 talismans a certain way on the parchments.

**Warlock:** Huh? I haven’t seen those seals and sigils in a very long time. Magic is a bit more modern now. Damn! And you even got an ancient root.

Within moments, a way opens up. And The Professor tries again, this time he’s able to connect to Sinestro’s mind, but Sinestro senses him and responds violently sending off a psychic attack hurting him a bit, the Professor screams out again.

**Professor Xavier:** He’s too strong.

Warlock heals The Professor, then tries something different. Storm gets excited.

**Storm:** Hmm, now we’re getting somewhere. If we could break into his mind. We’ll see everything.

Dr. Strange focuses his energy on reading Sinestro, while his hand is arched on top the parchments with the magical tokens. Due to the intense magic being wrought, the table trembles. Sinestro fights back, but his power wains. Dr. Strange reaches into his mind to obtain the secret to stop his evil magic, and as the image of something is about to come forth, out of desperation to break free from the psychic lock, Sinestro smashes his head a few times with his fists. He then quickly uses a blocking spell to shield himself from further attacks.

**Dr Strange:** I lost contact. Hmm. And I was close too. Now he knows we are closer to getting him.  
**Warlock:** Damn! He might do something desperate now. Quick, let’s get back to the castle and work our second line of defense.

Warlock and Dr. Strange disappear in a puff of smoke.  
**Storm:** Just like that?

Storm stares at the parchments, and the amulets laid out on them, and ponders.  
**Storm:** His magic seems to be protecting itself, like his energy is a person.

And Duke says in a sly way.  
**Duke:** Interesting observation.

Meanwhile, as a couple days go by a letter pops up in Greg Freeman’s mailbox, he reads it and after school, he takes it to his friend Scot Welles.  
**Greg Freeman:** You see, I told you they wouldn’t accept me.  
**Scot Welles:** That’s GREAT! Now, I want you to go all over the news and tell everybody that you were racially discriminated against. Here’s a list of some news broadcasters you should talk to. You did great, here’s 12 pieces of gold.  
**Greg Freeman:** Hey hey, My Man!

Meanwhile, in Atlantis, Jason and his friends are mighty pleased with their manufactured case to the point where they each role-play either pretending to be Namor, or an AUSA persecuting him at The High Court.  
**Scott:** I’ve worked out every defense strategy in my mind he could possibly say.

**Andrew:** I don’t see him getting out of this one.

**Jason:** Come on, let’s play some more. This time I’ll start as Namor.

Meanwhile on the other side of Atlantis, Merman, Bishop and Jean Grey are holding it down well for Namor. His people trusts them, and their presence there is warding off unwanted undesirables in favor of The Opposition.

Meanwhile, on the surface of the planet, Calvin Hopkins follows around any Superhero who’s unsuspecting of his presence that’s connected to Namor’s activities, and learns that Namor plans to attend the Council of Nations to give a speech next week. He then returns to Scot Welles to inform.  
**Scot Welles:** There are limited places I expect him to be now given my research. I only have one chance to set up Greg to meet him and accept his case for the next phase of the plan. Let me go tell my higher-level contacts. Thanks Calvin, and here’s 20 pieces of gold. Keep spying on them.

Meanwhile in the DC Universe, the Superheroes are preparing for an escalating war since all the battle lines are being drawn each day between who values the current changes and who opposes it. So it’s both the current Justice League & Legion of Doom members who remained faithful to their team, opposing former defected members and every other odd villain siding with Sinestro’s activities. Meanwhile, Sinestro himself has formulated in his head what he’s going to do in the future to settle his issues. Due to his last experience with Dr. Strange, he’s decided to change his plans a bit by not channeling his power to raise Apocalypse in The Marvel Universe, but to instead bring him directly into The DC Universe. He knows that Dr. Strange is powerful enough to challenge his power and must be actively doing the most to offset his spells. Sinestro can tell from the atmosphere that Dr. Strange’s counter-magic is more concentrated in The Marvel Universe. Sinestro releases more spells, then says his final invocation, hailing **Apocalypse**, who expects to rise at his own will in any given moment dwelling into the vessel of any being he so chooses in the realm. He waits in glee, floating about somewhere in space. Apocalypse is awake and aware of all things, but is disappointed. He so wanted to inhabit a vessel from The Marvel Universe. The entity scans the earthly terrain for one he feels is most worthy, and although there are many powerful persons, and mutants with their own legend and magic, he prefers a character more fitting a certain personality, even if he is less powerful.

**Apocalypse:** Hmm. The person I was going to choose in The DC Universe was Namor. And now that I’m here, the only person I find to be the next logical choice is Lex Luthor. Apocalypse waits until he sleeps, then with all his infernal power and might, he flows into the human vessel inhabiting him and assimilating into his being. When dawn comes, Lex wakes up a new man knowing HE IS **Apocalypse**. And the first thing he wants to do is let that be known, and take over The World. He immediately disappears out of The Hall of Justice and presents himself to the world. Way up high he flies announcing in a mighty voice who he is, and what he wants. The news people are below broadcasting this whole thing, and The Justice League are watching their monitor.  
**Robin:** Holy Legions Of Hell Batman! He was tricking us all this time. We should have suspected him.  
**Batman:** No I don’t think so Robin. I trust him. I suspect something else happened.  
**Wonder Woman:** How can we be sure?  
**Superman:** I know him. He was genuinely trying to help. It must be Sinestro’s magic.  
**Cyborg:** But why is he calling himself Apocalypse?  
**Aqua Man:** Oh no. In my conferences with Namor, something was stirring in his spirit he failed to tell me right away. I did tell him about the magical parchments before somebody called me, however I never got a chance to spiritually contact him again. He must be busy.  
**Superman:** Well you better do that now. This is a problem. Find out who this Apocalypse is and how to beat him.

Aqua Man gets to a quiet place and tries meditating to psychically reach Namor. It’s night time in The Marvel Universe and Namor is already asleep going in and out from one dream to another. Aqua Man tries harder, but he’s only getting vague dream-like images. Aqua Man then decides to project strong images of Lex Luthor in his mind along with the word Apocalypse, several times hoping he gets it. He then disengages from the meditation. The Super Friends know that with Apocalypse’s grand announcement, all the villains in their galaxy now knows who their real Leader is, and are going to show up themselves attacking an already meager group of Superheroes.

Meanwhile in The Marvel Universe, Dr. Strange & Warlock are firing off the next round of spells to correct the disorder in the universe from their castle of magic. Namor wakes up, has his cup of gourmet coffee and quality breakfast, then begins a conversation with the team.

**Namor:** You know I had an odd dream last night. There was the usual stuff, but then there was this one which came out of place having to do with the word Apocalypse and this Dude.  
**Professor Xavier:** So?  
**Namor:** I don’t know. I don’t recognize him. I almost want to say he kind of looks and behaves like me. Anyway, the dream shifted from him being just a regular savvy Business Man, Scientist, and Leader of some pack of villains, to him talking about Apocalypse.  
**Storm:** Dreams should be taken seriously. It could be a premonition.  
**Namor:** Or Aqua Man trying to reach me.  
**Professor Xavier:** Let me examine you.

Professor Xavier uses his psychic power to tap into Namor’s mind, seeing and hearing that episode.  
**Professor Xavier:** It IS Apocalypse. Somehow he has obtained a body and is in their universe. Quick, we must contact Dr. Strange and Warlock.

But before they get a chance to, both Sorcerers appear carrying an air of urgency about them.

**Dr. Strange:** We felt a cosmic shift in the universe. Is everybody okay?  
**Namor:** We just found out that Apocalypse is here, but in the other universe. I got the visions.  
**Warlock:** So that explains the psychic phenomena we felt.  
**Storm:** Well I feel bad for those people in that world. We had such a hard time defeating him here. Now he’s going to rule a brand new world.  
**Professor:** Are there any pyramids over there? We need to ask Aqua Man. We need to relate everything they’ll need to know to stop him.  
**Namor:** Now that puts a damper on things, because I was supposed to give a speech this week, and I might have to cancel it now.  
**Professor Xavier:** No. This may work to our advantage. The rest of the world is still unaware of what’s behind all these changes.  
**Namor:** And that’s what I’ve been struggling with. I really want to tell the people the truth.  
**Dr. Strange:** You can’t do that. Atleast not now. It would be irresponsible. Just continue with the vague comments and hopeful rhetoric. The people can’t know this. It will cause PANIC!

**Storm:** Meanwhile, let’s prepare ourselves since it won’t be long until this world gets affected. I feel Apocalypse will miss this world due to his ties here. He won’t leave it alone.  
**Professor Xavier:** I’m afraid you’re right.

The X-Men school Namor letting him know all kinds of details about Apocalypse, so he can intimate them in his spiritual connection to Aqua Man. Meanwhile, over in the DC Universe, Sinestro comes down from hovering in The Heavens to greet Apocalypse.  
**Sinestro:** Hey Lex, long time no see. You look phenomenal.  
**Apocalypse:** Sinestro. You hold a place of high honor in my Court bringing me back from oblivion.

**Sinestro:** I’m still shocked that I actually achieved this. My plans were not going well.  
**Apocalypse:** No matter. I will take this planet. And then we’ll enter The Marvel Universe.

Sinestro is relieved, and feels more confident dealing with his own personal problems knowing that with Apocalypse in power, he really has nothing to fear from The Marvel Universe. Apocalypse quickly assembles his armies and they go out with lethal force. Meanwhile, back in the Marvel Universe, at The White House, Trump finishes doing some important political things like signing Executive Orders for stuff. He reclines for the rest of the day making small talk with a handful of some Secret Society people who are well aware of what’s going on, including Brett Segal.  
**Donald Trump:** The time has passed and you see, no Apocalypse. I knew it wouldn’t work. That Magician you guys were using doesn’t know what he’s doing. If our current policies are supposed to herald in a New World Order under a global leader through divine means, then where is he?  
**Brett Segal:** Something must have gone wrong. He was the best Sorcerer we had to do it.  
**Mr. Bilderberg:** We have to change our plans then. We will need to consider an alternative.  
**Mr. Club of Rome:** We can always try again.  
**Mr. Skull & Bones:** No, let’s get to the bottom of this. All was going so perfectly until something happened.  
**Donald Trump:** Alright. Look into it Brett.

Meanwhile, the day arrives when Namor and other Dignitaries are supposed to attend a grand global all day event. It’s long expected and everybody who is anybody in the media is there. Namor shows up and he’s troubled about reading his speech. He’d much rather wing it and inform the people about what’s really happening, and the hidden world agenda. He then uses his time making small talk with other Dignitaries. And in the crowd, so happening to find his way in and dressed nicely is young Greg Freeman. He has no idea where Namor is, and moves about trying to find him. Namor makes up his mind to stick to the speech, but he makes some last minute changes to it where he re-phrases a few things to hint at something, hoping that some people pick up on it. A few Dignitaries spoke already and it came his turn. He went up there delivering a powerful speech as expected, and then got off stage. The interim events continue till the next Speaker, and Namor circles the place a bit. Greg Freeman, spots him and approaches.

**Greg Freeman:** Namor! Hey Namor!

Namor turns around, wondering who he is and why he’s calling him,

**Namor:** Yes?

**Greg Freeman:** Hi. That was a brilliant speech. I’m Greg Freeman. I’m a High School Senior who applied to Brentwood Hill College through their NBA program and I was rejected due to my race even though I attend an Ivy League School, and I’m a top basketball player, and my skills put me through school off their scholarship program.  
**Namor:** That’s great but I’m not taking cases right now. I can refer you to some people though.

**Greg Freeman:** But I want you on it. I’ve followed your work and I believe in what you’re saying. And you took on some similar issues like this. It’s not fair how inner-city youth like me are treated.

**Namor:** Brentwood Hill College is racist. Why did you apply there as opposed to an HBCU?

**Greg Freeman:** Oh Ahmm. Well, I applied to a few other colleges I got in, I just threw Brentwood in there because it’s a top school and I have a right to be there.  
**Namor:** Give me your information. I’ll have someone I know who handles this sort of stuff get in touch with you. I’m quite busy with extraordinary issues right now. It was nice meeting you.

Greg Freeman is a bit disappointed, but he gives Namor his information, which he takes, and then walks off.

Namor is greeted by other people complimenting his work throughout the world and as things wind down, he leaves. Meanwhile, in the DC Universe Apocalypse is vastly taking over the planet. At The Hall of Justice, the morale of The Super Friends are low.  
**Hawkman:** I never thought I would say this, but I miss Lex Luthor. I mean he was good. When he was here, things were better.  
**Wonder Twin, Zan:** He got possessed.  
**Scarecrow:** With that demon inside him, there’s no connection now.

**Wonder Woman:** I’m sorry. I have to excuse myself. This problem has gotten so big that only The Gods can help us now.

Wonder Woman then goes off to a space where she’s by herself so she can use her powers. She spins around rapidly at the same point till she disappears back into her ethereal kingdom known to mortals as Ancient Greece. There, she greets her mother and friends and explains why she’s back.

Meanwhile in The Marvel Universe in Atlantis, working late are Jason, Andrew, Brett, and Scott planning to take **jabs** at Namor again as soon as tomorrow, getting together a legal attack plan. Meanwhile, in their Castle of Magic, Dr.Strange and Warlock, fire off yet another round of spells to place the universe back in order where depending on certain factors, people may take notice that things are reversing. Morning comes and people are out and about in their respective cities living their lives. Some notice a blessed energy about them, while others are oblivious to it. Meanwhile Trump privately meets with 2 other Secret Society people.  
**Mr. Illuminati:** We can’t wait any longer on this. We need to continue with our plans. Since summoning Apocalypse failed, our people are considering using maybe Thanos, as our Leader.  
**Donald Trump:** You’re sure we can trust him?  
**Mr. Illuminati:** Our people have reached out to him.    
**Mr. Freemason:** Well our people would like Galactus as The Leader.  
**Donald Trump:** He’s too dangerous. We cannot trust him.  
**Mr. Freemason:** But he’s reasonable. We know people who have worked with him. Our galaxy will stay intact as he becomes our Sovereign Head.  
**Donald Trump:** That’s giving him too much power. I’m afraid of Galactus. Now, Thanos is not that bad.  
**Mr. Freemason:** What we’re trying to establish is dominance around the universe. Now who would mess with Galactus?

Meanwhile, Namor is at his workstation reaching out to some of his political connections, and every other X-Men is working on something. Meanwhile back in the DC Universe, The Riddler, reviews Lex Luthor’s files on the subject and co-relates some things discovering a definite attack pattern coinciding with the phases of the moon, and other astrological events, and calls everyone else to it.

**Robin:** Riddler, you’re a genius. We now know what to expect.  
**Aqua Man:** Not only that, I received a whole load of information from Namor last night in my dreams all about Apocalypse. Almost everything he does is tied to Ancient Egypt in some way, and he’s going to try to return to The Marvel Universe. We need to get some incantations together to seal him in somewhere, at least dispel his spirit out of Lex Luthor.  
**Superman:** And you know how to do that?  
**Aqua Man:** We have to.

Aqua Man continues sharing all he knows. Meanwhile in Celestial Greece, Wonder Woman visits The Fates and learn that things will soon turn awry for a close distant friend. The 3 Fate Sisters, each one embodying the past, present, and future, continue talking in riddles about what’s to come without being specific. So she does not know exactly what to expect. Frustrated, she goes to the Goddess Nike, beseeching her power to bring victory to her and her friends, and Nike responds,

**The Goddess, Nike:** There are so many in The Mortal World who invoke my name and wear it on their clothes and shoes in order to win the day. And so I ensure their victory. And there are those who show my name on their buildings and parchments who invoke me at their meetings to ensure their success over business and legal matters, so I must side with them Wonder Woman.

Disappointed, Wonder Woman walks away dull in spirit, that she sits by a fountain and cries worrying over the destiny of the world, and the seemingly hopelessness of her friends. Meanwhile, in the Marvel Universe, in Atlantis The AUSA receives and entire complaint against Namor, logs it, and begins the next phase of their legal process. Meanwhile up in The Surface World, young Scot Welles meets with Greg Freeman and pays him in full the rest of the gold he promised, and tells him,  
**Scot Welles:** I’m glad you made contact with Namor. Continue working on him. You’ll need to establish some kind engagement with him on your bogus case.  
**Greg Freeman:** Yeah but how though? I don’t know anything about Brentwood. I would never apply to that school.  
**Scot Welles:** I chose that school because of the political ties. When Namor realizes something, believe me, he’ll contact YOU! So see you around. My next class is in 20 minutes.

After school, Scot Welles meets with Calvin, paying him the rest of the gold he promised, and says,  
**Scot Welles:** Thanks for mapping these people’s whereabouts. My contacts will be pleased.

**Calvin Hopkins:** So when do we conclude all this?

**Scot Welles:** It’ll go on until my Higher-Ups feel they have compromised Namor enough to where they can ruin him, till then just keep bringing me your work.

Meanwhile at the X-Men mansion, all the news broadcast in favor of the current government annoys them that they switch off the TV. Namor gets updates on the successful turnouts on his former legal cases handled by competent people he chose. He researches some basic information on this Greg Freeman guy and sees he has a record of being a very good Player worthy of entry into Brentwood’s program. And researching them, he realizes that some of the adverse political entities he has been fighting around the globe are tied to recruiting people out of Brentwood Hills College. He then researches the school some more and finds out that they are one of a handful of private secret society schools with special programs in place since its inception where they directly recruit future leaders of the world. He then digs further into their background, concerning their recruiting process. He discovers their tentacles into several global companies around the world currently exploiting the indigenous people he swore to protect. And becoming so involved in this research, he also uncovers all kinds of scandal about them, swept under rug. He immediately picks up the phone and calls Mr. Freeman.

**Namor:** Greg, it’s Namor, I met you at the conference the other day. I got a chance to review your case and I’ll take. You’re right. You should never have been discriminated against like that. I’ll begin an investigative process and get back in touch with you.

**Greg Freeman:** Thank You.

Excited, Greg can’t wait to tell Scot. And Namor can’t wait to get started attacking The Power Elites through Greg Freeman’s case. He wastes no time in putting together letters blasting the school officials, and preparing about 500 form letters all saying the same thing calling out political corruption, which he gets around to significant people, even the President and his Cabinet. He then assembles a group of Activists informing them of his findings, and leaking information to Advocates everywhere. The X-Men are noticing the fire and zeal in Namor as he works this case. Two more days pass, and the heat he’d set on this, lights up the media. He gets on his best suits going around to all the media circuits talking about these Secret Societies, revealing all kinds of info and The People are taken in by his charisma. His expose creates a stir that The Power Elites are disturbed by it to the point where they begin a plot to move against Namor.

And excited by this is young Scot Welles, whose handiwork has taken a life of its own. Some counter-paperwork is being filed by these Power Elites and circulating through Congress and The Senate. Namor’s expose soon begins to affect corporations around the world with strong political ties, where their funding and social morale are now low. More people around the globe grow angry at their governments and begin protesting like Hell and rioting. The Leader of The Free World in his Oval Office speaks to his Cabinet Members,  
**Donald Trump:** You see, this is why we need Galactus.

The Cabinet Members agree and begin the inter-galactic conversation to bring Galactus into our Universe. Though some are worried, they more fear the global uprising of ignorant ethnic people storming The Capitol and getting their hands on their throat. Two members of Secret Societies are among them cautioning,  
**Mrs. Eastern Star:** Still, it is an extravagant move to bring Galactus. We don’t know if his temperament might change where he decides to swallow our universe. Besides, we’ve dealt with natives before. Surely there must be another solution.  
**Mr. Knights Templar:** Right, we can continue doing what we always have before. Galactus is a big move. We should take more time in finessing that.  
**Donald Trump:** The point is, things are so unstable right now, that we need to speed up the plans. We’ll deal with Galactus later if there are any problems.

And as the days go by, the economy continues to fall apart due to civil unrest. The people are so distracted that they fail to notice some obvious changes. Dr. Strange and Warlock’s magic have reversed a few things, and the only one who notices, are the people it benefited, depending. One particular person notices something different as he looks in the mirror.  
**Donald Trump:** I’m aging again, rapidly.

He calls his family to find out if the same thing is happening with them and they confirm. Livid at this, Mr. Trump thinks about it in context to everything that is happening and decides to blame Namor. He calls together members of The Justice Division to brief them. One of the men says,  
**Mr. Garringer:** But Namor could not be responsible. He’s not a Sorcerer. There are others whose magic could do this, and whoever it is has successfully reversed Sinestro’s magic a bit, but there are still issues. It’s a blessing if you think about it.

**Donald Trump:** I’m aging, do you get that? My life is about to change, and the lives of many other people. We need to put a stop to this. I know Namor and his team is responsible. Stop them.

Mr. Garringer knowing better does not argue with him. He instead follows his command leaving his Office with the other Justice Division members on a crusade to get Namor. Meanwhile in the bottom of the ocean in the city of Atlantis, Jason, Andrew, Brett, And Scott, are well aware of the Surface Poeple’s News concerning Namor and decide to add more to their initial report about it and deliver it to the AUSA to empower their case further. They quickly dispatch someone to meet with Scot Welles and his team, and also send out another person to meet with Trump. They also send another investigator to all the surface organizations Namor is a part of to gather intel for their case.

Meanwhile, in the DC Universe, Apocalypse has taken over The World and he sits on the throne as The Ruler. Aqua Man spiritually channels Namor letting him know that they lost, and to be aware of a coming world leader soon in his realm since it already happened in their world. And Namor relates the information to the X-Men before going on his way to meet with the Head of Brentwood College, Mr. Mick Jerry. Namor shows up to his office, where there also is the VP Mr. Geoff Howerback.

**Namor:** Your offenses are very serious. You discriminated against my Client. Your organization have been wreaking havoc in the lives of poor communities around the globe, exploiting the sick and the hungry to feed the rich. What do you have to say for yourself?  
**Mick Jerry:** Well we’re sorry. We did not know that he wanted to be a part of this school so badly.  
**Geoff Howerback:** I told you to overlook that C grade he received in that communications course.  
**Namor:** Look, I am willing to work with you. Let my Client into the school with a full scholarship.  
**Mick Jerry:** I am not sure how The Board will feel about that. We don’t let Blacks like him in the school. He’s course looking and uncouth.  
**Namor:** How could you say that? He is trying to better himself. He’s a talented young man deserving of a chance to become somebody in life. Look at his hard work.  
**Mick Jerry:** Well alright. I’ll talk to our board members. We’ll be in contact.

Namor is pleased that he made some headway and leaves. And just right after he completely left the property, some AUSA men show up talking to Jerry and Howerback. Meanwhile, at the mansion, Storm holds a conversation with the team.  
**Storm:** If only we could travel to the other dimension to help them.  
**Wolverine:** We can, but it wouldn’t be practical. There are a number of ways to get atleast one of us there, but to what means? If they already have their own Superheroes, then they need to do their job defending their people. We told them everything already.  
**Storm:** But we’re the ones with the most experience fighting Apocalypse. We know him.  
**Wolverine:** Let Apocalypse come to us.  
**Storm:** But so many will die.  
**Professor Xavier:** Storm is right, but we’re needed here too. All we can hope is that we are actually in the sequence The Silver Surfer spoke of, where the right possibility presents itself.

Storm trusts that logic, and begins observing Duke The Sage, Dr. Strange and Warlock interpret magic.  
They each look at the parchments again deliberating how to break Sinestro’s spell, but can’t figure out his code. Meanwhile, Namor makes the rounds at different stops about the globe using his Atlantean  teleportation technology. And each time he would meet with somebody, The Government knows about it, and The Atlantean Underworld Special Agents learn of it. And although they have their people on site to move in and arrest him. They choose not to. He returns from his peace mission back to the mansion where he is warmly greeted and encouraged by his friends. The next day, Namor receives a phone call from Mr. Jerry stating that they will not allow Greg Freeman in the school.

**Mick Jerry:** The Board is against it. They don’t want him. Several other kids were more deserving.  
**Namor:** What do you mean? What kids? Let me see their records?  
**Mick Jerry:** I’m sorry we are not allowed to show that information.  
**Namor:** I’m mediating on my Client’s behalf. What do you mean I can’t see these other kids records?  
**Mick Jerry:** Sorry we just can’t. It’s school policy.  
**Namor:** Look, I’m not playing games with you people. You know enough to know who I am and what I can do. Do you really want to lose what you have over one applicant? Do you really want to risk more embarrassment, shame, political support and money?  
**Mick Jerry:** No. Okay, let me look into some things. I’ll call you next week.  
**Namor:** Good.

Namor hangs up the phone. Meanwhile at Brentwood Hill College, two members of The Justice Division are there and were listening on the other line, recording the exchange.  
**Geoffrey Bearman:** Very good. Keep up these communications with him.  
**Mike Pedalski:** And don’t forget. We can’t go to the X-Men mansion to arrest him due to some spell they have over the property. So you need to get him here.  
**Geoff Howerback:** OK

Both Mr. Jerry and Mr. Howerback agree to the setup, and walk the Justice Division guys out.

Meanwhile traveling to the other side of town, those same Justice Division guys intercept Dr. Octopus asking him questions.  
**Mike Pedalski:** You were living at the X-Men mansion, what kind of activities did you see there?  
**John Jeffries:** I’m not a Snitch. I take no issue with them. Namor was working on my case, I got my settlement money and I bought my new home. I moved out of there several weeks ago.  
**Geoffrey Bearman:** Oh we just want to know if HE knows where Sheriff Lee Roy is?  
**John Jeffries:** If you don’t know why would he? Look I want no trouble. I’m just glad I got my money. I hope they arrest that Sheriff. He’s a terrible man. He must be in hiding somewhere.

The Justice Division guys satisfied enough with his answers, depart. Dr. Octopus senses something is wrong and decides to contact Namor.  
**Dr. Octopus:** Hey Namor, I just got accosted by some guys in The Justice Division asking about you and Sheriff Lee Roy.  
**Namor:** And?  
**Dr. Octopus:** And! To me it didn’t sound like they were that concerned for Sheriff Lee Roy. It sounded more like an interest in you and The X-Men.  
**Namor:** We’ve been having problems with them as you know from the news broadcasts. Don’t worry about it. How are you doing? How is your new home?  
**Dr. Octopus:** Oh it’s going great. I’m just getting groceries. I just wanted to warn you given my experiences with them. I can read something is wrong. I didn’t tell them anything else. Take Care.

Meanwhile out and about in the world is Donald Trump enjoying life with his family till he receives a phone call from a rich friend.  
**Donald Trump:** Hi Mr. Rockefeller.  
**Mr. Rockefeller:** One of the relatives I had that came back to life disappeared into thin air.  
**Donald Trump:** What? How?  
**Mr. Rockefeller:** There have been other vanishings of some other people too. We looked into it and conclude that this spell we’ve all been enjoying is wearing off.  
**Donald Trump:** No, I don’t think it’s wearing off. It must be Namor and his friends all over the globe. They are the only ones fighting this. Alright look, sit back. I don’t know where Sinestro is to reverse it.

Trump hangs up the phone and turns it off completely knowing full well that all kinds of calls will come in, and he’s resolved to listen to all their messages later, after he makes a few moves to address the problem. He calls someone in The Justice Division to move on capturing Namor. That person from The Justice Division then relates messages out to every last field agent that the take down must happen soon. Namor is out at one of the most expensive restaurants in town enjoying his meal and paying his bill with Atlantean gold. He leaves to enjoy the scenery of the town. He enters one department store, makes a few purchases and leaves. He finds himself home and crashes for the night. Early next day he receives a phone call from Brentwood Hills College.

**Mick Jerry:** We’d like to meet with you again today to discuss why you feel Greg Freeman should be admitted to our school.  
**Namor:** Are you serious? Didn’t we discuss this last week? And I thought we were to meet to finalize everything next week?  
**Mick Jerry:** My colleague and I are reconsidering it, but we need a statement from you to take to The Board. We’d love if you could just come in.  
**Namor:** For Ivy League people who should know better. You all could use a little lesson in recognizing your own fault at something and resolve it quickly like a Gangster. I don’t like my time being wasted. I have a good mind to make an international event of this. I can drudge up charges on you based off the inappropriate activities you’re doing around the world. In fact just the pirating activities alone on the waters is bad enough. And all that waste dumping from your companies. You Surface People are nasty. I’m just trying to do this guy a favor.  
**Mick Jerry:** Ah yes Namor. Just come in and we’ll discuss it. I’ll be here till 2pm.

Namor hangs up the phone, has his breakfast, dresses for the occasion and finds himself there by noon. As he enters the campus, 2 Justice Division members spring up on him saying,

**Justice Division Officers:** Come With Us.  
**Namor:** What’s This?

One Officer looks at the other and smiles, remembering the old TV Land *‘The Untouchables’* show and remarks to Namor,  
**The Officer:** Spoken like a true Mobster.

Namor finds The Officer’s comment ignorant, and remarks,  
**Namor:** The phrase is not unique to Mobsters. Now what’s this about? I did nothing wrong.

They walk him to their building where he learns what ***It Is*** when he sees The AUSA.    
Nicola Hans, The Atlantean of The South Seas, along with Julian Dray, The Atlantean of The Tyrrhenian Sea and their friend, Brandon Wolf, The Atlantean of The West Seas emerge from another room.  
**Namor:** You Guys!

Namor is annoyed and he throws an attitude.  
**Namor:** This is ridiculous! How dare you waste my time like this. You’re all subject to me, not the other way around. Now Kneel!

The AUSA is taken aback by his arrogance, and not sure how to respond. Geoffrey Bearman takes it from there telling Namor,  
**Geoffrey Bearman:** You’d do better lowering your voice. We know you’re The Ruler of Atlantis, but you’re operations here on our land has been called into question. There are some people not entirely pleased with you.  
**Namor:** Here’s my business card. You can contact me anytime. I have a lot of other global obligations to fulfill. Now if you’d excuse me.

Namor leaves the Justice Division building and returns home to the mansion. Mike Pedalski is dumbfounded, looking at Geoffrey and remarking,

**Mike Pedalski:** He just slipped out of your hands like that?

Geoffrey Bearman smirks and answers,  
**Geoffrey Bearman:** He’s a Diplomat remember. I have no power to hold him against his will. Plus, he’s a Monarch. Look, just open the case against him and bring the charges. I’ll handle it.

The AUSA speak amongst themselves, till one asks the question,  
**Nicola Hans:** But we have the greater jurisdiction power to have our case first. Will you take an issue to us handling him first?

**Geoffrey Bearman:** No. That might be better. We both can have our cases happening at the same time too. I prefer that. We’ll keep in touch.

The 3 AUSA guys leave their building and descend back into the sea swimming to Atlantis. When Namor returns home, he informs everyone about what happened. Duke The Sage is not surprised, given his recent ordeal with the AUSA over the same issue with Namor. He dryly remarks,  
**Duke, The Sage:** You should expect round 2 of that.

Rogue turns on the TV to watch one of her favorite shows, but instead sees a huge press conference about Namor. Geoffrey Bearman stands up there with all the media people reading off an endless list of charges against Namor, and commenting on them. He makes statements like,

**Geoffrey Bearman:** Namor is not a Diplomat. He uses his respectable title to go around bullying people, trying to extort favors. He’s a criminal. He abandoned his responsibilities to his Atlantean People leaving Strangers in charge of their underwater community. This is a guy you can’t trust.

The Justice Division Officer goes on and on with his report and then another Officer speaks. Namor is very MAD at this! Dr. Strange’s face is sullen, knowing that the next part of his vision is about to come true. He does not want to alarm Namor, but says to him,  
**Dr. Strange:** I warned you about my dream remember? Prepare yourself.

Namor tries to calm down, then remarks,  
**Namor:** They set me up. That case I was working on was all a rouse. And now they are trying to use that among other things to blow up an issue about me.  
**Rogue:** The Rascals!  
**Namor:** Dr. Octopus was right telling me to be careful. They have a real criminal to arrest like the former Lake County Sheriff Lee Roy, who we know as Sinestro, but instead they want to mess with me.  
**Duke, The Sage:** Well you know what it really is. You’re the figurehead behind this movement to reverse everything back to how it was. And now they are trying to get The People to hate you. So with enough of them hating you here, and also in Atlantis, you become an exiled King or worse.  
**Namor:** I’ll fight this.

The doorbell rings, Gambit opens the door and it’s Joesph Quinn with paperwork in hand ready to address Namor’s legal issues. Namor smiles, and goes conferring with him about his pending cases.

Meanwhile, in the DC Universe, The Super Friends realize that defeating Apocalypse is going to take more than military strategy, and that the information they learned given to Aqua Man by Namor is more the thing to use. Apocalypse needs to be weakened somehow, magically.  
**The Cheetah:** But who do we know that can do incantations reading Egyptian papyrus?  
**Toy Man:** Nobody. Maybe we can find some Scholar.  
**Superman:** We need a Master who knows about the myths.  
**Brainiac:** I can handle it. My talents are vast.

Meanwhile, Sinestro is comfortable where he is, almost neglecting that he has another life back in the Marvel Universe. He realizes that he should go back and devise his official departure from that world as Lee Roy, The Former Sheriff of Lake County, but delays it, preferring to continue living his present life here under the rulership of Apocalypse.

Meanwhile, back in the Marvel Universe. As expected, The AUSA comes for Namor when he goes out to do damage control later that day at one of the media outlets. When he’s talking to the camera, repairing his reputation for the people to understand that there’s a malicious political attack on him due to who he is and the work he’s done, out of nowhere using their Atlantean teleporting technology, appears four highly trained Atlantean Soldiers sent out to capture Namor. He fights valiantly. Some members in the audience scream panicking, and running away from the fight, while others stay cheering Namor on. The Camera Men capture everything. The Four Atlanteans mercilessly zap Namor with strange beams weakening his powers that they are able to subdue him and place him in a force-field bubble, then teleport back to their Kingdom. Once there, the four Atlantean soldiers remove their helmets showing who they are: *Nicola Hans*, *Julian Dray*, *Brandon* *Wolf*, and *Brett* Segal. An exhausted Namor sees them, and one of them remarks,  
**Brandon Wolf:** Yeah, it’s us. We went through the trouble extensively preparing for this day.

Namor, lying in pain closes his eyes. They remove the force-field he’s in, and transport him to a cell.  
Meanwhile, at the X-Men mansion, after viewing that disturbing broadcast, Duke, Dr. Strange and Warlock leave immediately for Atlantis through a magic portal Warlock creates. Once in Atlantis, they meet with Merman, Bishop, and Jean Grey, who are well aware of the AUSA’s capture of Namor.  
**Dr. Strange:** Jean, how come you missed that?  
**Jean Grey:** I don’t know how they were able to achieve that. I sensed nothing about it.  
**Warlock:** Maybe they devised some type of blocking technology to keep you from reading their minds.  
**Jean Grey:** Well what can we do? Namor can be anywhere.

**Merman:** My sources informed me that his case will begin any time soon, and none of the prisons we know of is holding him.

**Bishop:** And lucky for him, that spell you placed here, is keeping them from trashing this palace region.  
**Duke, The Sage:** So it has come to this. A Monarch who is the rightful ruler, is being challenged in his own domain by parasites. We still have an ancient legal system here, and they have no right to do this.

Dr. Strange and Warlock follow Duke to the High Atlantean Court. He reminds The Court that Namor left Atlantis in good graces with no pending legal issues. Duke pulls out the legal document The Court approved that whatever new laws which were proposed or approved in his absence will not affect him adversely. The Court agrees and still honors the agreement, but Duke is given a scroll he opens with a list of 36 charges and why, and the parchment rolls all the way out into the street. The men take to one side studying it, and getting a sense of the issue, before starting with the legal theatre again.

**Duke, The Sage:** I demand an immediate hearing!  
**The Court Appointed Clerk:** Come back tomorrow. We are about to close soon.  
**Duke, The Sage:** Rule 2, Section 244 states that in events such as this where The Royal is in distress, all efforts must be made by The Subjects to intervene.  
**The Court Appointed Clerk:** Ok, hold on a minute.

The Court Appointed Official then talks to somebody who whispers something back in his ear and then he goes back and says to Duke,

**The Court Appointed Clerk:** Can you prove *right now* that Namor is in distress.  
**Duke, The Sage:** Are you kidding me? Dr. Strange.

Dr. Strange approaches using his magic re-creating the scene of Namor’s defeat at the hands of his enemies. And though The Clerk is well aware of what happened. He was given strict instructions to do everything by the letter of the law.  
**The Court Appointed Clerk:** I’m sorry, but showing us magic does not necessarily mean that event actually happened. And Dr. Strange is not Atlantean, nor do our laws recognize him as a Counsel here.  
**Dr. Strange:** Wait. Just give me a moment.

Dr. Strange uses his magic and transforms into an Atlantean. Warlock laughs and does the same. And they both go to the counter, with Warlock telling The Clerk,  
**Warlock:** Aside from being Superheroes performing magic, we are also board certified Attorneys empowered by our Galactic Judicial System to fight in any designated Court. Do you wish to check?

The Court Appointed Clerk runs a check on them and sees the approval and their profiles.  
**The Court Appointed Clerk:** So ok. Let me see if I can get you this last minute hearing.

The Court Appointed Clerk looks at the list of available Judges, and there are only 2. Both are fair, and choosing either one would not matter. The Clerk is not happy being in this position having to work against The Leader of Atlantis, but he’s also subject to having to serve the forces behind the trouble as well. And so not wanting to make the critical choice of which Judge to choose, just in case he might be wrong, he brings all the paperwork to the counter with a stone face and announce,  
**The Court Appointed Clerk:** I have The Judges Schedule with cases they recently heard and are about to hear. So let me see here, ah, I guess these two are available. And let me look here.

And as the guy stalls and carries on, Dr. Strange touches the schedule, and using his magic, he psychically reads the spiritual imprints and vibes, and is able to deliberate which of the 2 would be the most favorable Judge, and rests his finger on the one Judge’s name. The Clerk notices this and logs in Judge Kramer. The Clerk then hurries, finalizing everything and the hearing takes place.  
**Duke, The Sage:** Your Honor. My Client was brutally beaten by 4 men dressed in full Atlantean body armor appearing through a portal into a TV studio with a program already in session, having no respect for the news broadcast Namor was doing which was ran by The Surface People. They captured our King, held him against his will in a force-field. We don’t know if he was offered any hospitality, but we do know that beams were used to render him from using his powers.  
**Judge Kramer:** These actions you stated clearly is in violation of our laws. And it’s classified as treason. I order the immediate release of Namor, but I must restrict him to remain in Atlantis until we get to the bottom of this. I’m also restricting any further action on the part of The AUSA from pursuing him until a proper inquiry is made concerning these charges. You’re now dismissed until further notice.

Warlock whispers to Duke and Dr. Strange,  
**Warlock:** Oh that was easy. I’m shocked it worked out so well.  
**Duke, The Sage:** I’m use to dealing with difficult Judges. I’m not familiar with that Dragon, nor the other one for that matter. I never had a case where I had to deal with either of them before, but the fact that she’s so understanding and willing to release him right away, tells me that we still have some people in The Justice System who remain faithful to our Sovereign.

The other Clerk dispatches a notice to the guards holding Namor at the undisclosed AUSA jail, and disheartened, they obey the notice to release him. Two AUSA men accompany him on their sea vehicle, bringing him directly to The Court where they leave him with his friends, and then promptly depart. He’s greeted warmly and Namor appreciates their help, remarking,  
**Namor:** Why Dr. Strange, Warlock, you’re Atlantean now?

They laugh changing back to their normal appearances.  
**Dr. Strange:** We just had to.

They then return to Namor’s palace, where he’s cheered on by his people there, staying up late hoping for something good like this to happen.

The next day, Namor addresses his compromised health trying to determine what power beams were used to neutralize his energy. And fortunately for him, somebody there already knows the answer.  
**Bishop:** When I got a chance to see that broadcast. I immediately knew what it was. I’m a weapons expert and I’m familiar with the ore used in making those stun beams. They can be found in The Caspean Sea. I’ll help you develop a defense for it. You’ll need to take a very high concentration of a counter herb to recuperate. It’s called hyacinth.  
**Namor:** Good. I know where we can find a multitude of that.  
**Warlock:** Great, but for now. You should have this.

Warlock, using his power, manifest out of nowhere his breakfast.  
**Namor:** What’s this?  
**Warlock:** Try it. It has a concentration of hyacinth in it, along with other special types of nutrients from certain exotic fruits & vegetables that’ll work, all mixed in this creamy smoothie I’m giving you.

Namor sips it, and favoring the taste, he continues drinking it, and says,  
**Namor:** It’s certainly delicious.

Meanwhile, on the other side of Atlantis, The AUSA decide to get some help from The Surface People by working closely with Namor’s Persecutors. They send their people out to talk to them about neutralizing Namor’s respectability and power. At one meeting, The AUSA person manages to gain access to talking to the Director of the Superhero Consulate he’s a member of to consider suspending Namor from operating through them. The Director entertains the possibility and sees them out. More AUSA people run amuck to other organizations he’s a part of to discredit his respectability, in hopes of building enough contempt worldwide to ensure his failure. They even go to the schools he attended as a young man named **Namor McKenzie** when he lived part of his human life among The Surface People. They obtain all his records, feverishly trying to fault find. And after their exploits, all of what information they gather is shared with his human Persecutors.

Meanwhile, in Atlantis, when Jason, Andrew, and Scott realize that The Court is not going to go their way since Judge Kramer is locking up all the pending charges and blocking the AUSA from moving forward with their case, they think quickly about a next plan.  
**Jason:** We need to change jurisdiction. What we’re hoping is not going to work here. Let’s send all this stuff to our allies up there.  
**Andrew:** And what about **\_***OUR***\_** spell?  
**Jason:** I was hoping that we could do it here, but since we don’t have access to Namor anymore, we’ll need another opportunity in the future, if we get a chance.  
**Scott:** That Judge ruined everything. Like who cares about practicing proper due process? Now we can’t take over Atlantis like we want.  
**Jason:** And like Andrew said, first we’ll need to drain his power using our spell and cast that energy onto ourselves. Remember Namor is special, and his powers makes him who he is. We need that.

Meanwhile at the X-Men mansion, Storm is contemplating Sinestro’s magic and Beast is there talking with her, entertaining her questions and such.  
**Beast:** But Storm, what does it matter? We’re not Sorcerers. Let’s wait till Warlock & Strange return.  
**Storm:** It might be too late then. Remember they have that case down there. The sooner we figure this thing out, the faster we can reverse Sinestro’s curse.  
**Beast:** But some people enjoy it. You’ll be ruining the adjustments they’ve made.  
**Storm:** You like the world like this? Who’s side are you on?  
**Beast:** I’m just playing. To tell you the truth I have no idea how to interpret those parchments.  
**Storm:** I’m familiar with many subjects. I may not be a Master of them all, but I am Adept as recognizing certain things.  
**Beast:** Oh yes I know you are quite intelligent. It’s why The Professor has you as his Second-In-Command, but dabbling in these affairs is not wise.  
**Storm:** You saw what happened with Namor? What do you think is influencing that?  
**Beast:** Sinestro’s curse as you call it is a blessing to certain people in power who wish to preserve their status at all cost.  
**Storm:** Right! And you want to give them another day to succeed. Remember the Sentinels they sent after us? Well, there are a lot of innocent people suffering too.  
**Beast:** I’m just a Scientist. I know nothing of Magic.  
**Storm:** Hmm, I know a thing or two. And if that parallel universe Sinestro is from, had that Mxyzptlk character Namor shared with us from his psychic conferences with Aqua Man, then I imagine that the same kind of magic in a way governs certain other spells. Remember the last time Namor got back from Atlantis when he was telling us about that 3-headed dragon who judged his case?  
**Beast:** Yes.  
**Storm:** Well he said it quickly like it was nothing and I asked him to spell it. When he wrote it down, I was pronouncing it as **Cel-na-fer-men-gar-def**, like how anyone trying to figure out how to say a name would, but Namor explained where the accent and emphasis was on that dragon’s magic name and then I caught how to say it, **Cel-nafer-men-gardef**.  
**Beast:** And?  
**Storm:** And! If you think about it, both Celnafermengardef & that other entity Mxyzptlk, are special words, pronounced a certain way.  
**Beast:** And that’s why we should stop now and not dabble further. Remember what Dr. Strange said, it was Sinestro’s mis-pronounciation of certain archaic words that led to the form and breadth of the universe changing like this, and it will take serious magic to change it back.  
**Storm:** Well I have a theory that Sinestro would not do magic carelessly as a Sorcerer, unless he did have some way of reversing it, even if he was not directly able to. Just think Beast. Would you create some highly destructive machine or disease without having some kind of program or cure to shut it down or remedy it?  
**Beast:** I wouldn’t be that careless not to.

**Storm:** Exactly! That’s what we should be looking at. We know a few things about Sinestro. He’s a perfectionist. He’s thorough. He’s old-fashioned.  
**Beast:** He likes ships.  
**Storm:** And so forth. So let’s see here. On these parchments, these symbols over here are the ancient signs for the forces of nature. And I’m not sure what these odd letters mean over here. If they were runes I could read them.  
**Beast:** The letters he’s using could be Sanskrit or some similar language. They are formed in such a crude way, it’s hard to tell.

**Storm:** And all this other symbolism here. And on this page, he has what I believe to be the incantation he said written in another language.  
**Beast:** Apocalypse would know how to say that. The writing might be one of the Egyptian forms of scripting that was much different from the hieroglyphs.  
**Storm:** And then he has here a bunch of hieroglyphs on this one.  
**Beast:** He may have been using them as tools to channel the way he did his spells.  
**Storm:** Hmm. Let me try something.

Storm then pulls out a **OUIJA** Board from the game room, and starts playing with it, moving the Planchette around, trying to open up a divine communication.  
**Beast:** What you’re doing is highly un-scientific.  
**Storm:** If you weren’t such a dis-believer, I would ask you to join me.

She does this a bit longer, getting herself in-tuned spiritually concentrating on what she would like to know, and then the planchette moves under her hands as she gently touches it. It goes over to the part of the board that says YES. And it moves to the letter **A**, pauses, and moves to the letter **B**, then moves to the letter **C**, then moves to the letter **H**, then moves to the letter **J**, circles around the letter **J** again, and then it stops directly on it, then moments after, returns to the letter **A**, circling around the letter **A** again, then staying directly on it.  
**Beast:** So much for your divination. You’re just going down part of the alphabet in circles. Ha ha ha.

Storm ignores him and concentrates again. She asks another private question, and the board says No. She then asks the same question that she wanted an answer for and the board spells out, **H**, **A**, **J**, **J**, **C**, **B**, **A**, **A**.  
**Beast:** You see what’s happening here can be scientifically explained. Your sub-conscious mind is thinking about something while your hands are moving that planchette across some letters that your mind now is going to try to interpret as something meaningful.

Storm then asks the board a private question. It takes a while, but it answers NO. And she says,  
**Storm:** I hope you are right.  
**Beast:** So now we are talking to imaginary friends?  
**Storm:** Beast! I’ve done this sort of divination before and it has been deadly accurate.

Storm puts the board away. Writes down the letters, and ponders them.  
**Storm:** Beast. Tell me what you think. Does this look like anything to you?  
**Beast:** No! I believe it’s a waste of time taking it seriously.

Storm thinks about it some more to no avail, then puts it away with the rest of the parchments containing Sinestro’s spellcraft that Dr. Strange re-created from Namor’s memory. She then leaves the room with Beast, and just moments after doing so, the parchments take on a new energy.

Meanwhile, in the DC Universe, Brainiac successfully isolates each part of the symbols on the parchments using his super computer brain which stores all the information in the universe he ever had access to.  
**Riddler:** Great! Now we’re really getting somewhere.  
**Robin:** But these are just symbols from ancient cultures, and all we have is some captions about what each one stands for. We still don’t know Sinestro’s mind, his intent, how he used them in the spell and so on. And what are we looking for anyway?  
**Riddler:** As an Expert dealing with puzzles, I’m looking for anything here that explains or decodes or unravels this thing. I know Sinestro, remember. We worked together. And though he does magic, certain principles don’t go away. I know he must have some safe-proof mechanism to undo this.  
**Robin:** That would make sense. What do you think Batman?

**Batman:** Given all what has happened and my observations of life and the universe itself. Considering our measure of it, one thing that is consistent is numbers.  
**Riddler:** That’s right. The patterns are there.  
**Robin:** It is how we are able to use math to interpret the world around us. And you think that something as subtle as that is built into his spell.  
**Batman:** Well, the universe and life as we know it can be observed mathematically, from measuring the speed of light, counting the number of chromosomes that makes up a certain species, from the repetitive sequence of our seasons and so forth.  
**Robin:** Making Magic the ultimate high science where through your own full understanding of The Universe, it’s possible to bend time and space to One’s Will. How very dangerous, if this ability were to fall into the wrong hands.  
**Batman:** Correct!  
**Riddler:** Wait, I think I found something. What is this here?  
**Robin:** Oh I don’t know. Decorations I guess.  
**Batman:** It looks too ornate along the trimmings of this parchment to mean nothing.  
**Robin:** You think?  
**Batman:** Scarecrow, do you make decorative symbols to your spellcraft just for nothing?  
**Scarecrow:** No, all things on my paper means something, even if they are decorative.  
**Riddler:** It repeats. It looks like a pattern. Eight symbols.  
**Scarecrow:** And eight, is a number meaning change. It symbolizes death and rebirth. It is infinite.  
**Riddler:** We may be on to something here. There’s a diamond, followed by eight dots, then one dot, then a diamond again, followed by two dots, then one dot, and then 3 dots again, and lastly one dot.  
**Batman:** That’s definitely a code. But what does it mean?  
**Riddler:** Brainiac, come here.  
**Brainiac:** What’s up.  
**Riddler:** Take a look at that.  
**Brainiac:** It appears to be a sequence, but there’s no repetition.  
**Robin:** Why?       
**Batman:** The universe repeats Itself.  
**Riddler:** This must be his code for something. When I do riddles for my capers, the answer should be apparent to you in some of them, since I’m practically telling you the answer in a subtle way.  
**Robin:** True. Your riddles teasing us about your criminal mischief, does seem difficult to solve if you’re not thinking.  
**Batman:** But turns out to be quite solvable when you are thinking about it. The answer sometimes is very obvious.  
**Scarecrow:** But in matters of divination, a Wizard would not disclose his spell to people, that’s the point when casting a curse, unless, he himself is not entirely given to it or he does not trust something.  
**Batman:** And don’t forget, we weren’t supposed to have these parchments anyway to even know anything about it, if not for Superman.  
**Robin:** So how do we solve this sequence? What does it mean?  
**Riddler:** Let me write this down. So we have the numbers 8, 1, 2, 1, 3, and 1.  
**Batman:** What’s the diamond for?  
**Robin:** Brainiac, do you recognize a universal pattern from that?  
**Brainiac:** I already conducted multiple scans through my Super Mainframe, and returned no significant output that can answer Sinestro’s mystery. The number sequence don’t fit anything sensible I can comment on, like the DNA make up of a particular plant or animal, nor the molecular structure of any particle or compound relative to any of this.  
**Batman:** Find out what this diamond is for?  
**Riddler:** I imagine that it might be another number.  
**Brainiac:** I’ve already identified all the different ancient number systems by separate cultures, and I don’t have an output for that one.  
**Robin:** Well maybe Samurai, Apache Chief, and El Dorado, can help.

Robin takes the sample to them inquiring, and both Apache Chief and Samurai confirm that they don’t recognize the sequence having any relevance to anything they know in their culture. When he takes it to El Dorado, his spirit immediately taps into it with him remarking,

**El Dorado:** It’s Aztec. The diamond means 10.  
**Robin:** Are you sure?  
**El Dorado:** Sure, I’m Sure.

El Dorado goes with Robin to the decoding team and assures them that he is right.  
**Batman:** Then Brainiac, I thought that we already dismissed The Aztecs?  
**Brainiac:** I have them classified with The Mayans.  
**El Dorado:** That’s an error. There are differences between The Mayans, The Olmecs, The Aztecs, and The Inca. They are not all the same, even though they are similar. Here, let me re-program you.  
**Riddler:** So El Dorado, do you see anything else here that you recognize?  
**El Dorado:** No. Just that.

Riddler then writes down the final translation, and says,  
**Riddler:** So now we have the numbers **10.8.1.10.2.1.3.1** and we are not sure what it means.

Brainiac runs the numbers through his Super Brain to get an intelligible match concerning the context of The Universe, but he delivers several outputs resulting in useless information. The Decoding Team decides to give the process a break. And in that rest time, El Dorado decides to educate Brainiac on the differences between The Aztec and Mayan number systems even though they are similar in some ways.

Meanwhile, back in The Marvel Universe in Atlantis, Kramer The Dragon knowing The Laws better than The AUSA, and can identify even the most subtle corruption in The System entertains what Duke, Dr. Strange and Warlock has to say on behalf of Namor at another hearing, and The Dragon disregards what The AUSA has to say, citing violations in the core Atlantean Laws. The Dragon then moves to declare the agency as unconstitutional, and overturns all their pending cases against Namor and his Associates. The Dragon then surmises stating,

**Dragon** **Judge Kramer:** I’ve reviewed everything, and I am dismissing this case against The Sovereign. And due to the graveness of the treachery involved, and the serious disregard for our long standing system, I will entertain Our Sovereign’s remedy and hereby exile all persons directly involved or affiliated with The AUSA from Atlantis, and also relieve them of their rights, rank, titles and properties, effective immediately.

The Court then sends out these notices, along with a fleet of Atlantean Soldiers who turn up at the various sectors of The Empire where The AUSA people live and arrests them, seizing their property and exiling them from Atlantis, but knowing the laws and what they did wrong, and already seeing this coming were: Brett, Julian, Brandon, Nicola, Andrew, Jason, and Scott. And all seven made prior arrangements with their Surface Allies and fled Atlantis. Meanwhile, at the palace, Namor puts in place future safe-guards to ensure nothing like that ever happens again. And he goes out giving a speech to his people, and they cheer. And with all dangers averted, he returns to The Surface World with Duke, Bishop, Jean Grey, Dr. Strange, and Warlock, again leaving Merman to handle his affairs while he’s absent. They arrive at the mansion and are warmly greeted by each X-Men. Storm especially hugs Namor, looking up at him and remarking,  
**Storm:** Are you alright. What happened?  
**Namor:** Nothing we couldn’t handle.  
**Storm:** I was deeply worried. Tell me, how is a Sovereign treated with such contempt.

Namor sighs, and Duke answers,

**Duke, The Sage:** It has to do with ancient times, our laws and culture. You see, unlike here, things are more intricate with us. A Sovereign is a Sovereign, but even in your world that comes under attack as you know from human history. A rightful ruler could come into power, but disgruntled Nobles or Usurpers may strike at any time. We had that problem. And being as old as I am, I’ve seen it happen almost in every century, but we eliminated the attempted coup. The People love Namor, and his rulership can continue to go un-challenged.

**Storm:** I’m relieved. We had a bit of some problems here too. Since Warlock and Dr. Strange were gone, we were under attack by some Sorcerers coming here trying to break Dr. Strange’s magical protection over our property. We responded by fighting back with our arsenal. And there were some typical fights around the country here and there that I had to dispatch our people to. I myself got involved in a few conflicts, but other than that, we had no real major issues. Oh, and I think I have something interesting for you to take a look at.

Storm then leads them to The Game Room, where she pulls out the parchments along with her recent result from playing with The Ouija Board.  
**Storm:** Look, I did my own divination and came up with this.

Beast laughs, and remarks,  
**Beast:** Her playing with a Ouija Board expecting answers, yielded that gibberish.

Dr. Strange looks at it, while holding the rest of the parchments, and immediately feels something.  
**Dr. Strange:** Where’s the board?

Storm gets it. And Warlock looks at it remarking,  
**Warlocks:** A commercially manufactured cheap imitation of an old divination art.  
**Dr. Strange:** Let me see it.

Dr. Strange using his magic twirls it around in the air, testing it, and says,  
**Dr. Strange:** It’ll do. I sense your energy the most on it Storm. And the magic I have around this place would not allow a malevolent spirit. So the answers you received is either coming from the good familiar spirits here, or something or someone or Entity in The Universe. And these letters must mean something. And you asked the right questions. I’m seeing your entire session.  
**Beast:** Unbelievable.  
**Dr. Strange:** And I feel a positive energy emanating from it. You’re right about a magic word being able to undo Sinestro’s spell. Now it’s just a matter of deciphering it.  
**Namor:** Hmm, let me take this information to Aqua Man. I’m dying to confer with him.

Namor unwinds in his room, relaxes his mind from his previous troubles, and gets into a meditative state. As he slips more and more into this cognitive exercise, he reaches telepathic communications with Aqua Man.  
**Namor:** Aqua Man, Aqua Man, are you there.  
**Aqua Man:** I hear you.  
**Namor:** Good. You wouldn’t believe what happened to me.

Namor then projects all that went down with his setup, and attack and Aqua Man responds,

**Aqua Man:** I told you. Once it starts, it continues, and you’re fortunate to have it under control now. This explains why I could not reach you before.  
**Namor:** They had me in some bizarre cell and they tried to disguise the general area so I could not identify where I was in Atlantis. So anyway, one of my friends uncovered a clue to crack Sinestro’s magic. Here it is. It’s the letters **A**, and **A** again, and another **A**. The letters **B** & **C**. The Letter **H**. The Letter **J**, and **J** again. And we don’t know what it means.  
**Aqua Man:** Hmm, that’s funny. Well our team here uncovered another code dealing with numbers, and they are **10.8.1.10.2.1.3.1.** We’re not sure what it means either.  
**Namor:** Hmm. So how are you?  
**Aqua Man:** Just protecting The rest of The World. Atlantis is fine. And I’m sensing why you are having problems is that your enemies must be divining something extraordinary, given that they received sample DNA from me. They might be trying to draw energy from you or something.  
**Namor:** I am already taking certain actions to safe-guard myself Aqua Man. Anyway, let me get back to work on this. I wish you and your friends well.

Namor then disengages from the trance, and immediately meets with Storm, Dr. Strange, Warlock and the rest of the team relating what he now knows which he wrote down.  
**Namor:** I got this from Aqua Man.  
**Beast:** Numbers. It gets stranger. No pun intended Dr. Strange.  
**Storm:** Hmm. Eight numbers.

Storm looks at both clues, and thinking further, her logic deduces.

**Storm:** Some of these numbers are repetitive like those eight letters. Oh wait a minute.

And recognizing something, she takes a pen and paper, and thinking about the alphabet, she sees the parallel, and jots down the letter **J** under the number **10**. The letter **H** under the number **8**. The letter **A** under the number **1**. The letter **J** under the number **10**. The letter **B** under the number **2**. The letter **A** under the number **1**. The letter **C** under the number **3**, and the letter **A** under the number **1**. And she looks at it remarking,

**Storm:** Why it just spells out an odd word, JHAJBACA. What does it mean?  
**Beast:** None of it makes sense. Although I can’t deny the odd coincidence with your letters just happening to match the numbers they came up with.

**Namor:** Their team noticed on the parchment what were Aztec numerals.  
**Dr. Strange:** Amazing.  
**Duke, The Sage:** Now we’re much closer to undoing something.  
**Dr. Strange:** Warlock and I can definitely do it now that we have this information and a sense of how Sinestro casted the spell in the first place with all this material.  
**Warlock:** The only problem now is **\_***timing***\_**. If we do it now, not only would everyone know, but Sinestro would know, and we don’t want him going somewhere else and recasting another problem. We need to capture him first. He should never know that we discovered his secret.  
**Duke:** I agree. But how do we get him?

**Dr. Strange:** This must be the part that The Silver Surfer was alluding to.

Storm, with a concerned face, looks upward, wondering about The Silver Surfer and this whole thing, and hoping that it all turns out right. Meanwhile, in the DC Universe, Aqua Man wrote down the information he learned from Namor and took it to his decoding team, explaining to them. And just putting the two clues together, The Riddler sees the correlation, picks up a pen and paper, and writes out,

**Jhajbaca, 10.8.1.10.2.1.3.1**

Robin then comments,  
**Robin:** Jhajbaca, what is that?  
**Brainiac:** According to my language database, it is a Hindi word meaning **“Outstanding Ship.”**  
**Superman:** That’s strange. What does it all mean?  
**Batman:** I hope he’s not conjuring anything else.  
**Superman:** Regardless, we need to come up with a plan to stop everything. Now I’ve been thinking had the timing with all this worked out and Mr. Mxyzptlk happened to be here, I could have manipulated the situation a certain way, getting him to help us indirectly. And it’s not 7 years yet till the last time we had to deal with him escaping from his dimension. And the only other powerful enemy in the universe that could help **\_***IS***\_** Darkseid. And just directly beseeching him to help us would evoke his laughter.  
**Robin:** Because it’s *OUR* problem. He lives in his own dimension where his powers reign supreme and doesn’t care too much about ours. His only interest at times is contending with us for sport.  
**Superman:** But I’m thinking that maybe we can somehow use that.  
**Batman:** You mean like engaging him in some way.  
**Robin:** Be careful, Darkseid is no fool.

Meanwhile in The Marvel Universe, the exiled Atlanteans and their leaders settle into their new lives living on The Surface staying at Trump Tower or living in Trump Palace, wherever there is one. They quickly get their act together working with their Surface Allies who have given them special protected status rivaling Namor’s. As this news breaks on certain media circuits, it disturbs Namor to now have to contend with them here. He knows about the case they’re trying to develop against here also. And he talks to Joseph Quinn.  
**Namor:** I really want to be rid of them messing with my life.  
**Joesph Quinn:** I already read your Atlantean case, I have it here, and what I gather is them trying to conform parts of it to apply to our laws here. But I only see 4 possible charges they could make stick.  
**Namor:** I am not a criminal. I’ve never been one in any part of my life. I understand that some people don’t like me for whatever reason, but I don’t live my life to suit them. I’m beloved by many who find me irresistible, and whom admire my accomplishments, tact, integrity and leadership.  
**Joseph Quinn:** I know. I’ll work on trying to stop their case from going forward.

Meanwhile at their castle, Dr. Strange & Warlock, are working on the elements to do an epic spell to break Sinestro’s magic across the universes. And elsewhere, on the streets in the city living her life normally, dining and shopping, is Jean Grey whose psychic energy each time picks up on certain vibes concerning Namor. The imagery and negative thoughts in the air become so concerning that she returns back to the mansion to see Namor, telling him,  
**Jean Grey:** Almost all the mental imprints I’m reading are coming from your enemies here. Infact, they already have a full blown case ready to go, that they’ll have somebody announce soon.  
**Namor:** Then I’m going to need another effective legal team fighting for me here.  
**Jean Grey:** I’m available. I can work with Joseph.  
**Namor:** I appreciate that.

Meanwhile, a once older gentleman affected by Sinestro’s magic, who still appears younger now, is a Prosecutor name Rudy Giuliani known for dismantling Mob Organizations over the years has been placed on Namor’s case, and he’s on the phone talking to Trump’s Attorney, Coen Michael’s about Namor. And after talking with him, he’s on the phone again taking a call from Jason, The Atlantean from The Franc Seas. Meanwhile in The Oval Office, political moves are being made in **Space Force** to facilitate a new interstellar world government under a Super Galactic Leader. Any nation on the planet not on board with the plan comes under attack where The United States of America decides to impose and uphold sanctions to that region. This affects many countries with limited access to foreign resources, healthcare, food, and so forth.  
**Mr. Garringer:** But don’t you think Mr. Trump that these abrupt changes in our long standing system of government can backfire, making the world even more unstable pursuing Galactus?

**Donald Trump:** This is what *THEY* want. Their system of government on the planet is older than ours.

And when Trump said **\_***THEY***\_**. Anybody who understands, is aware of who *THEY* are. So Mr. Garringer looks at his to-do list of the day, and moves on to addressing The Namor Issue. Later that day, the news break with Prosecutor, Nicola Hans The Atlantean of the South Seas, standing up there, doing a press conference reading off charges against Namor McKenzie, and explaining why.  
**Namor:** These people waste no time transitioning from one empire to another, and all of a sudden securing a job to continue pursuing me.  
**Duke:** This has got to stop.                
**Jean Grey:** This is happening because of the current Administration, and their power. All that is going to make your case very difficult to fight now.  
**Duke:** Brace yourself, you know how these people operate.

Namor is sullen in spirit again, thinking privately for a moment, then remarks,  
**Namor:** I just hope Dr. Strange and Warlock’s magic can beat Sinestro’s. That’s the root of all this.

Namor then leaves to go to the part of the estate where Professor X trains his X-Men. He meets up with Bishop, who he spares with, perfecting his fighting style in attempts to eliminate any weaknesses in his technique. Meanwhile eating and drinking in an Italian Restaurant across town are some old time Mobsters that came back to life due to Sinestro’s spell, having a discussion about the press conference they just saw.  
**Paul Castellano:** This government should be ashamed of itself comparing him and his activities to us.  
**Carlo Gambino:** The whole thing is stupid. Just because he tried to help people, he’s a criminal?  
**John Gotti:** I was a real Gangster in my day earning the name The Teflon Don, beating charges. And the stuff I was doing was actually criminal. Now in today’s time, The Justice System is trying to make Namor seem like a Wise Guy, and he’s not even from that.  
**Joseph Bonanno**: Yeah, since when did he become a Made Man?  
**Joseph Colombo**: It’s that whole roman mythology behind him too, and he looks Italian.  
**Vito Genovese**: Actually, in a way he is with that heritage. Namor backwards is Roman.  
**Tommy Lucchese**: I hope he beats the charges. He’s a good guy.  
**Lucky Luciano**: None of us have had any problems with him.

And they laugh at the subtext meaning behind Lucky Luciano’s joke. Meanwhile, also having an opinion on Namor’s case and knowing exactly how The Justice System works since he was there, observing how corrupt they are in that district, is a young Attorney Namor knows and met not too long ago, who decides to take interest his case. He shows up at the house.  
**Professor Xavier:** Mr. Kennedy. Nice to see you again. Come in.  
**John F. Kennedy Jr.,:** Where’s Namor?  
**Professor Xavier:** He’s refreshing himself from training. I’ll get him.

Moments after, The Professor returns with Namor, and he’s surprised to see Mr. Kennedy.  
**Namor:** Hi?  
**John F. Kennedy Jr.,:** So I’m here because as you know, these sudden charges against you are politically based, and I know a thing or two about these people fighting you. I’d like to represent you as your Lead Attorney.  
**Namor:** Oh, this is shocking. I was not expecting it at all. Well yes.  
**John F. Kennedy Jr.,:** Good. So now let me brief you on a few things, and what our strategy is going to be. I don’t mind working with Joesph Quinn, and I saw that you already have Jean Grey out there doing some things for you, but you’re going to need a bit more. I have the whole backstory of whose case they’re modeling yours off. And I know exactly how to fight them. Can we go somewhere more private and talk?

Namor, then goes off to The Den with Mr. Kennedy, and he pulls from his briefcase some documents, continuing to talk about everything concerning his case. The next day, Mr. Kennedy meets with Joseph Quinn, and Jean Grey briefing them with a defense strategy. The Court already assigned a Judge to the case who happens to be one of the deceased brought back to life through Sinestro’s magic, and who use to be **The District Attorney of The SDNY**, his name is Robert Morgenthau. Comes the day of the Pre-Trial Hearing, Namor and his Attorneys face off against The Prosecutors.

**Geoffrey Bearman:** Your Honor, we have a career criminal who goes around in the guise of a Diplomat pretending he cares about people, but it’s all a front to enhance his own popularity at the expense of these world organizations he represents why we provoked an inquiry into his status.  
**John F. Kennedy Jr.,:** Your Honor, my Client is a bonafide Monarch and Diplomat exercising every right and privilege his station calls for, it’s only natural that his position would attract popularity. The Prosecutors have no right demonizing him because of that.

**Nicola Hans:** Your Honor, The Defendant runs up numerous tabs around town with his heavy spending, and much of this money could have went to helping poor communities flourish.  
**John F. Kennedy Jr.,:** Your Honor, my Client has to maintain a regal lifestyle and decorum befitting of his status, and on occasion he offers benefaction to other Diplomats on his peace talk missions, and these sometimes include lavish parties and outings they respond favorably to why after attending his events, as Leaders of their Countries they’re more likely to comply with agreeable global agendas.  
**Van Cyrus:** We have recordings of him stating threats to a School Official.

**John F. Kennedy Jr.,:** My Client merely made a conversational point. Them interpreting that as a threat is a wide stretch.  
**Mike Pedalski:** Why is he here? Shouldn’t he be in Atlantis. He recently banished several people in his empire who were trying to govern the undersea kingdom in his absence.  
**John F. Kennedy Jr.,:** This is simply untrue Your Honor. My Client left his Second-In-Command in charge. And in his absence a coup ensued resulting in his assault and capture by one of The Perpetrators among us now.

Namor and his legal team all look at Nicola Hans, and he smirks looking away. The Judge sounds his gavel and says,  
**Judge Morgenthau:** O.k, I’ve seen and heard enough. After looking over everything, I find it necessary to proceed with a trial. We will meet a few more times for *In Limine* and *Voir Dire*. Once we agree on the evidence allowed to try this case, and examine the witnesses and jurors moving forward, I’ll set a date for the Hearing. Dismissed!

Each day, Kennedy and his Client go through the legal motions preparing for trial, and during this process, they experience attacks from Prosecutors demanding that Namor stop all diplomatic duties, surrender being Leader of Atlantis, and relocate to a new living space since they don’t want him at the X-Men mansion. Kennedy fires back telling The Court that as a Diplomat, he is immune to being tried criminally, and as The Sovereign of Atlantis, he’s entitled to remain its Ruler, and that there is absolutely no reason for him to leave Xavier’s mansion at this time. The Prosecutors fire back telling The Court that Namor being at the mansion is questionable, and since he’s a Sovereign insisting on staying among The Surface People, he should leave Atlantis, and Diplomats are subject to civil action. The tit for tat, back and forth arguments continue in the Court filings till The Judge rules for Namor to adhere from any further diplomatic activities during his trial, and for him to move to another location to live while undergoing this trial under direct supervision. Mr. Kennedy is not pleased with this, and after trying to appeal that decision, his motion is denied. He tells Namor,

**John F. Kennedy Jr.,:** So what they’re trying to do here is isolate you. You’ll no longer have the protection of the X-Men or the benefit of Dr. Strange & Warlock. And knowing their tactics, I suspect they’ll try to attack you at your new location. According to this Court Order, you can’t choose to stay at any other Super Hero’s home, or stay with any other Diplomat. And they don’t want you living by yourself. They basically want you under some designated person’s Supervision, making sure that you are not being a Diplomat, or going anywhere or doing anything.  
**Namor:** That’s restricting me from even being a Sovereign. I’ll need to return to Atlantis soon.  
**John F. Kennedy Jr.,:** That’s what I think it is also. There’s a clause in your Atlantean Constitution about abandoning your people beyond X number of days. I think they’re going to try and tie this case up to make trouble for you.  
**Namor:** We can’t afford that.  
**John F. Kennedy Jr.,:** Let’s just designate a new space for you. We’ll think of something.  
**Namor:** I have an old childhood friend name Jaye Heiman. He’s familiar with my struggles and I can count on him.

The friend is contacted and he agrees to host Namor. Kennedy informs The Court, and The Prosecutors are happy that Namor will no longer have convenient access to certain people. Arrangements are made for him to move to the house where his friend lives. The Prosecutors now fire off another demand freezing his bank accounts worldwide, seizing his properties, vehicles, and just about anything of value claiming that they discovered some new evidence where all his stuff were obtained illegally. Mr. Kennedy is upset with the action and fires off a scathing reprimand showing and proving that they had no legal right to, and demanding that they return everything. The Prosecutors fire back filing a docket stating that Namor is a criminal and that they successfully got the Galactic Counsel of Superheroes and other organizations to retract their license and/or membership from him. Kennedy reviews the attachments and confer with one of the other Attorneys on the case.

**Jean Grey:** My psychic powers tells me that one man is responsible for all this, and he’s a member of all these groups also and he has other political connections worldwide. And I’m seeing a face and a name. He’s not very popular, but he’s very powerful. Here I’ll write it down.  
**John F. Kennedy Jr.,:** Hmm. We’ll need to find out everything we can about him. Meanwhile, I’ve got to try to get these restrictions reversed.  
**Namor:** They can’t take my Atlantean money I access here. It’s entirely a different jurisdiction.  
**John F. Kennedy Jr.,:** That’s going to be one of my defenses.

Mr. Kennedy then puts together a powerful docket explaining jurisprudence, his clients rights and so forth. He cites certain cases where false evidence were used in the past against certain people to unlawfully obtain property or deny them their constitutional rights. He points out that Namor’s possessions and other property are Sovereign, protected by Private International Law and Maritime Law, and he goes deeper into that. He again reprimands The Prosecutors, calling them corrupt, and he asks The Court to reverse the decision. Judge Morgenthau is so impressed by his exquisite argument, and rules in his favor. The Prosecutors are not pleased, and they make a feeble attempt to challenge the decision, but The Judge quickly denies it. Namor is able to access his global accounts again, and the other Attorney on the case Joseph Quinn makes sure that every last piece of property is accounted for. In concerning the matter of the revoked licenses and/or memberships from various global organizations, Kennedy gets in contact with some people more powerful than the guy responsible for causing Namor’s loss, and those people decide to orchestrate some things leading to exposing that guy’s own corruption. This eventually gets brought to the attention of The Court. Namor’s legal team then contacts these groups with counter arguments resulting in them privately and publicly apologizing to Namor, and re-instating his license and/or memberships. And as things continue to look good for Namor, Prosecutors leave those types of attacks alone and focus more on what they can try to play up as an issue. They bring up Tempest Dame and also Dr. Octopus, remarking that he represented a nobody making false claims against a respectable man running for President, and that he also represented a bum who made exaggerated accusations against a highly respected man in law enforcement. Offended at their classification of these persons and the misinformation, Namor’s Attorneys respond by saying, both Tempest Dame and Dr. Octopus were members of society engaged in their Professions until they fell victim to those in Authority abusing their power, and Namor was a champion they turned to for help to rectify an injustice done to them. And as they continue with the back and forth, tit for tat, The Court finalizes a jury, evaluated and approved what will be entered as evidence for the trial, and The Judge gives a date.

Meanwhile, up in space, The Silver Surfer realizes that the current events at play is still on the proper course according to his time visions. And also being aware of other matters taking place in the universe, he shoots off to handle certain issues at times, like saving The Guardians of the Galaxy from a problem above their capacity to handle, and in another occasion, helping various Superheroes from other dimensions battle cosmic problems out of their control. Every now and then, he cruises other alternate realities, and time loops, to see what is going on, before returning to his current station in the universe to finally resolve this problem.

Meanwhile in The DC Universe, Superman is seated, brooding over a plan in his head to somehow rid their world of Apocalypse, and his dread. Batman notices him, and is doing the same kind of thought process standing at his corner of the room. Meanwhile in The Celestial Realm, where Wonder Woman went to consult The Gods, she sees Hera who tells her,  
**The Goddess Hera:** Fear not, Oh Wonder Woman. The end is near. Your friends need you.  
**Wonder Woman:** But Hera, we have never known an enemy such as this.  
**The Goddess Hera:** It will be alright, but you must keep this knowledge to yourself.  
**Wonder Woman:** So we win? But how?  
**The Goddess Hera:** What The Fates told you is correct, but it will only come true, if they are ignorant of it.

Wonder Woman then realizes that the destiny of all things have already been determined, but will only change due to certain factors offsetting them, and if she tells her friends what she learned, then they might not fight as hard or work hard enough to win. She thanks Hera, then leaves to return to the realm of mortals. When she appears back in The Hall of Justice, they inquire from her, but she shrugs, letting them know that she has no definite answer on how to stop Apocalypse. They then fill her in on some stuff she missed out on, before going back to ponder how to defeat Apocalypse.

Meanwhile in the Marvel Universe, moves are being made to assemble an army to invade Atlantis. All the exiled Atlanteans and their Leaders are quietly preparing their arsenal with the blessing of The President. And as Namor is embattled dealing with his legal case, all they can think about is when to strike. One of the Prosecutors decide to leave the case. Nicola Hans is not concerned too much about The Surface People’s affairs and he knows this whole thing against Namor is improper. He cares more about Atlantis and decides to concentrate his efforts on that. Another week will pass, and a couple other Atlantean Prosecutors also decide to leave the case. Kennedy finds this curious. He continues badgering Prosecutors about the in-validness of the case, their misconduct and such. The remaining Prosecutors continue their offense accusing Namor of being a political pimp going around global circuits manipulating unsuspecting persons, and organizations making them think he can do something for them. Kennedy answers back telling them about the many accomplishments of Namor, and how he has helped the planet, touched peoples lives, and then he attaches thank you letters, documented awards Namor won, and so forth. Later that night, The AUSA send over some guys in raid-like fashion to the house where he and his friend is staying to upset him and throw him off guard with the excuse that they were inspecting to make sure that he’s complying with The Court terms. He contacts his Attorney immediately with them there, and on speaker, Kennedy yells out at them inquiring about the real reason for their presence there. He curses them out, citing all kinds of law and demanding a call from The Prosecutor.  
**Rudy Giuliani:** Oh I’m sorry John, but we got a report that Namor was conducting some communications with a State Official and we had to check it out since it violates the terms imposed by The Court. You understand.  
**John F. Kennedy Jr.,:** What I understand is that you people are hellbent on harassing my Client, and you’ll have to answer for this.

The Prosecutor hangs up, then contacts his men to lay off, and they leave the house. Some more back and forth phone calls are made concerning it, then Kennedy calls back Namor,  
**John F. Kennedy Jr.,:** Namor?

**Namor:** Man, you were right to tell me to leave my Trident and certain other things at the mansion.  
**John F. Kennedy Jr.,:** Yes, you would not want those things falling into their hands. I knew it was THAT they were looking for. We’ll deal with this tomorrow. Get some sleep.

Meanwhile on the phone with Giuliani, is Brett Segal, The Caballist.  
**Brett:** Did you get it?  
**Rudy Giuliani:** No. They didn’t see it.  
**Brett:** We need The Trident. And we can’t access his palace in Atlantis due to some enchantment over it preventing us from getting his other Tridents. And if the one he came here with is still at the X-Men mansion, we have no way of getting it. And we don’t want people knowing we’re after it.  
**Rudy Giuliani:** Well Brett, we’ll work on keeping him tied up with this case long enough so you can quietly invade Atlantis. Don’t worry.

Brett gets off the phone with him, and stays up late continuing to strategize his team’s battle plans to take over Atlantis. The next day, Kennedy fires off a docket asking for the Prosecutors to prove that Namor contacted a State Official. They take their time and fail to respond. Another Prosecutor leaves the case. Kennedy sends an additional inquiry asking them to show proof of a contact Namor supposedly made to a State Official. And once again, The Prosecutors are timid to respond. They ignore the inquiry and instead talk about Namor being a scammer by posting a docket claiming he uses mind control powers to bend weak minded people to his will. Kennedy answers that argument dismantling it by stating how people of their own volition seek out Namor because they heard so much about him and his effectiveness at resolving certain socio-political and other global problems worldwide. He also attaches several news links of articles and videos they can watch. He then returns back to the argument of AUSA goons invading Namor’s right to privacy, roughing up him and his friend, ransacking the place using a make-believe suspicion that he violated the terms of The Court Agreement. A week passes with no response from them, and another Prosecutor knowing better, leaves the case. Meanwhile, over at the X-Men mansion, Storm receives a dispatch from one of Namor’s Diplomat friends and she alerts the others.  
**Storm:** This just came in. A guy from the Far East name Amir Ibrahim, who’s a friend of Namor, is warning that he notices ships in his region quietly moving into position and based off some intel he got from spies he sent out, they are a part of a mission to invade Atlantis.  
**Rogue:** That’s terrible!  
**Professor Xavier:** We must warn Namor.

They send the message out to Jean Grey, who relates it to him. Namor is angry, and wants to be with his people, but he’s being held captive by this case. Jean, consoles him,  
**Jean Grey:** Namor, if anything, you should see this coming. You’ve been through it before, and we will do everything in our power to help you.  
**Namor:** Tell Amir to keep me posted.

Meanwhile in Atlantis, the best of his people ever vigilant aren’t blind to the subtle shifts about them. They know their waters everywhere on the globe, and can sense negativity, especially from The Surface People. One Atlantean Princess, Alyse of Baor Isle, is making moves to secure her area of Atlantis as her people count on her, and she sends Messengers to Merman informing him of the strange surface activity. Moves are made on their part also suspecting an attack. Meanwhile, back in Court, since the case is being televised, Mr. Kennedy makes sure that each week a handful of Celebrities are present in the courtroom who are there in support of Namor. And when The Jury looks over seeing certain Stars there in his corner, it sent a message about his status. The Prosecutors try to distract Jurors when they get a chance to speak by posturing a certain way when accusing Namor of stuff, raising their tone in a theatrical manner as if playing a role on Broadway, and sometimes being repetitive with certain phrases as if they were performing mind control techniques to sway Jurors. They even design The Exhibits like that. Namor is distracted from the case worrying about his people. Kennedy contends with Prosecutor Geoffrey Bearman on some points. From his research on the current cases that Mr. Bearman is handling where there’s truly corruption, Kennedy makes it a point to mention ***one*** particular.  
**John F. Kennedy Jr.,:** Now Mr. Bearman, your Office recently arrested a man name Martin Braze The Third, standing just outside of The United Nations, who have been scamming people for years pretending to be a Diplomat, sending emails to random people in America, Australia, The U.K and so forth asking them to send him money, is that correct?  
**Geoffrey Bearman:** I’m not the one on trial here.  
**John F. Kennedy Jr.,:** Ok, so let me redirect. Here’s a recent article of the case involving an actual criminal doing the very things without question you’re accusing my Client of, except that Namor is a bonafide Diplomat who has helped many, without cheating them of their life savings.

Geoffrey Bearman was not expecting that. He was more prepared for the routine he was going to do concerning Namor’s charges, and so he’s slow to respond, but eventually does,  
**Geoffrey Bearman:** That’s another case separate from this one.  
**John F. Kennedy Jr.,:** But is it really separate though?

Kennedy goes on to detail every last crime Martin Braze did, exposing the financial fraud, the fake Diplomat license, how he gained access to places, people he met, accounts he robbed and so forth. And then he details in contrast actual political cases Namor did talking with Presidents, Sultans, Dictators, and how he was able to avert deadly international issues between nations. Geoffrey realizes that if he keeps going on that same tract discussing scams, Namor will continue to look better and better to the jury just based off Kennedy’s rebuttal, and so he chooses to rest the topic, deviating from it by mentioning Tempest Dame and Dr. Octopus again to segue to the next Prosecutor to get up and speak. Kennedy sees his trick, gives him the look, then returns to his seat. Mike Pedalski arise talking about how Dr. Octopus is a career criminal that Namor helped, and how Tempest Dame is a Grifter. Attorney Jean Grey, arises eloquently humanizing these two people to the jury, that they shed the preconceived prejudice they had in their heads in favor of the facts. Mike Pedalski tries to damage the credibility of these two people, but Jean Grey holds strong telling The Court that Namor doesn’t cruelly judge people like that, holding their past against them. The Court ends their session for the day. When both Tempest Dame and Doctor Octopus receive their subpoenas from Prosecutors, it naturally struck them as being bad, and they each were successful as getting their own Attorneys to quash the subpoenas. Kennedy, however was able to successfully get Martin Braze The Third to have to show up in court and answer some questions. The Prosecutors are not pleased.

Meanwhile, President Trump promotes the new global agenda to have an independent inter-galactic world government headed by Galactus. Though there are a few other Beings in the universe to choose for this, The Powers That Be fear the aliens, both Grays and Reptilians since they can effortlessly come here and interact with humans, taking them aboard their space vehicles at will and have been doing this for millenniums. Nobody knows who they are or what their agenda is. So we need someone powerful that can protect our Solar System. So an agent was sent out there by Nick Fury to engage Galactus that he will not devour our Solar System, but protect it, and he accepted the job. Trump is not sure if Galactus can be trusted, like some other people he still prefers Thanos, but he devises in his head some solutions he keeps to himself just in case things go awry. So for the time being, Galactus is scheduled to be on arrival into our galaxy any time soon.

Meanwhile, back in the DC Universe, Superman recalls a few magical warnings from the past which he decides to break now for a purpose. It’s well known that to keep an imp like Mxyzptlk away, it’s best not to think of him or call his name too much, since doing so can weaken the spiritual barrier that keeps him trapped in his dimension for 7 years, but Superman, has a plan where that is just one part of it. The other has to do with getting Darkseid involved somehow, and having a Clash of The Titans between him and Apocalypse. He collaborates with Batman, and they both factor in the possibilities for success as well as remedies for what may go wrong.

Meanwhile in the Marvel Universe, Kennedy decides to have Archangel as Namor’s bodyguard ever present around him given the secret developments happening that The Atlantean Underworld Special Agents are doing. When The AUSA sees Archangel around Namor, it causes some concern. They are about to attack Atlantis and they don’t need Namor or any of his connections here thwarting that. But to stave off any immediate intrusion into Atlantis with the various ships being assembled worldwide and ready to move, Storm discreetly goes out to these locations and using her powers, she creates all kinds of disturbances affecting their ability to function well, between the sudden change of weather obstructing them, and odd frequency signaling from the airwaves. Some of these vessels even end up being damaged. Storm returns home and notices that nowhere on the networks is it being reported that these ships secretly being deployed in certain places, are having serious trouble.  
**Professor Xavier:** From it being silent in The News, confirms a plan for a secret attack.  
**Storm:** Indeed.

They continue to inform Namor through his Attorneys, and although Namor is pleased that he has his friends helping him to protect Atlantis, he’s also livid at the audacity of his enemies. As more information is being learned about it, Duke The Sage returns to Atlantis to help protect it. Once there, he meets up with Merman and others to plan a defense.

Meanwhile in The Surface World at Court, Kennedy gets intel from one of the best investigators out there to help his case. He then sends off subpoenas to 3 people who did not succeed in quashing them. When he goes into the courtroom he reminds the court that according to international law concerning his Client’s status, Namor is not supposed to even be on trial, and that these trumped up charges are bogus. He then proceeds to talk about conspiracies, citing cases similar to what Namor is experiencing where tactics were employed by political enemies. He then calls Greg Freeman to The Stand. He asks him a series of roundabout questions designed to establish his own interests in targeting Namor. Greg’s friend Scot Welles is in the courtroom looking around and already realizing where this is going, and hopes that Greg does not mess up, however Kennedy is able to get Greg to admit a few things he thought were just simple questions, only to later get exposed as a person being used by someone else to target Namor. Kennedy then calls Scot Welles to The Stand. And being someone who is a bit smarter in school studying law, he already knows to assert his 5th Amendment Right each time without answering any of Kennedy’s cunning questions, and he feels like he did well doing that, except that a suave Attorney like Kennedy just indirectly proved his point to the jury since Scot is refusing to self-incriminate. He then calls Calvin Hopkins to The Stand showing him a photo the private investigator took of him, Scot and Greg hanging out together at recess. He asks Calvin to confirm who is in the photo. And he has to, being under oath. When he did, the photo got passed to the jury. He then had one more question for Calvin. Kennedy took an article Calvin wrote for his school newspaper that expounded all kinds of radical views in favor of the current Administration. He asked Calvin to read it, and he does, he realizes as he is reading it, that he’s exposed as a perpetrator in league with the ideology of some of the people trying to hurt Namor. Kennedy is happy with this result and remarks,  
**John F Kennedy Jr.,:** No further questions, Your Honor.  
The Prosecutors are not pleased at all, and they know that if they dare take on trying to refute it, more things might get exposed hurting their case when they are only supposed to just keep Namor pre-occupied for a time fighting nonsense charges. So they turn their attention to another topic distracting jurors by painting some other picture.  
**Ricky Soberman:** Namor is a real popular guy. He is so famous. That alone is a huge platform for him to go around threatening people. He only needs to go on a show with his extreme popularity and say a couple of disparaging comments against a person or organization to cause hurt. He even caused Sheriff Lee Roy to disappear.  
**John F. Kennedy Jr.,:** I object Your Honor. The Former Sheriff of Lake County is still at large for any number of reasons. Recently my Client won a case for Dr. Octopus in getting his Settlement for the abuse he suffered at Lee Roy’s prison. If he’s no where to be found, it’s understandable that he’s either in hiding or he left town due to the arrest warrant.

Judge Morgenthau is happy to have been selected to head such a high profile trial, but he does not show it. When he was The Manhattan DA for decades in his day, he saw a lot of talent he trained working for him, and some of them are also present in the courtroom. He knows he has to be an impartial Judge, but simply can’t help being amused at them sparring with one another like this.

The Current Manhattan DA, Van Cyrus gets up presenting written testimonies as evidence of former people Namor legally defeated on behalf of a Client, saying,  
**Van Cyrus:** This is how he hurts people. The lives of these folks were ruined crossing paths with him.

Kennedy frowns and says,  
**John F. Kennedy Jr.,:** Do you prefer such Criminals to be handled with loving care? Many of them you’re being compassionate for are White Collar Criminals who either defrauded HIS Clients, assaulted them in some way, committed a crime like human trafficking, kidnapping, drug smuggling, piracy, genocide, or other international concern. If he was so heavy handed at getting them prosecuted, it’s easy to understand why.

The other Prosecutor Dan Alphonso says,  
**Dan Alphonso:** And we’re trying to do the same thing because we recognize the signs of a Demagogue, would-be Dictator. He’s real good at manipulating people. With all the other Dignitaries he’s been around, we’re noticing a move to align with them to try and take over our Surface World.

Kennedy rolls his eyes and says,  
**John F. Kennedy Jr.,:** Oh come on! This is ridiculous now. Are you serious?  
**Dan Alphonso:** Look at the data. He gets along with a united nation of peoples.

Kennedy recognized Alphonso’s Freudian slip from what he said before, and remarks,

**John F. Kennedy Jr.,:** With all the resources at our disposal it would make sense that *OUR* government is the one trying to take over Atlantis.

Dan Alphonso is quiet because he just hit the nail on the head, and he’s not sure if Kennedy is just making an argument or if he might be aware of something, and being a shrewd Prosecutor, he drops any further commentary on that subject before something else gets exposed, and diverts attention back to discussing the 4 charges.  
**Dan Alphonso:** These accusations still stand Your Honor, with the threats he made to a prominent College, and his Client saying that he never approved of him saying those things, and . . . . . . . .  
**John F. Kennedy Jr.,:** Your Honor, I just proved earlier that the Witness in question was in cahoots with 2 of his friends to targeting Namor for political purposes. And so I move to have The Court drop that Services Fraud charge since The Prosecutors can’t prove otherwise.

Dan Alphonso knows that Kennedy is correct, and if he tries pushing that subject further, more incriminating things may jump out the bag since he’s friends with Scot Welles, and he’s not sure to what degree Kennedy may be aware of that with the Investigator he’s using. So he answers,  
**Dan Alphonso:** Your Honor, our Office is re-evaluating the evidence in light of this case and are willing to drop that charge.

Judge Morgenthau from his days of working with them as District Attorney is shrewd at picking up on some questionable dealings, and he gives Alphonso a look before remarking,

**Judge Morgenthau:** This Court will not tolerate the waste of Tax-Payers money on frivolous charges that can’t be proven. I expect that all efforts are being made to truthfully present evidence and details concerning this case moving forward. Is that clear?

The Prosecutors nod saying,  
”Yes Sir.”

**Judge Morgenthau:** Good. We’ll adjourn for the day.

One of the AUSA, Julian decides to leave the case, finding the whole thing stupid and now prefers to concentrate his efforts on the secret *‘Invade Atlantis’* Agenda. Meanwhile, watching The News at the mansion, the team realize that Trump and his family went back to looking young again, and it creates speculation,  
**Wolverine:** If you reversed that part of the Sinestro’s spell, then what happened?

**Dr. Strange:** My magic doesn’t fail me. I notice some interference, but it’s only happening with individuals speckled throughout the society.  
**Warlock:** It must be Dr. Doom. I feared something like that would happen, but I didn’t want to say it.  
**Wolverine:** So what do we do about him?  
**Dr. Strange:** He’s the only one right now that has enough power to contend with my magic, and if I engage him, it will greatly deviate from our plans, tying up everything where we may never get rid of Sinestro. So I’m just strictly sticking to my visions, avoiding him and anybody else who don’t belong.  
**Wolverine:** Well how do we know that Dr. Doom isn’t involved?  
**Warlock:** He may or may not know of Sinestro, but since we don’t see him doing much other than just helping individuals as a favor, I speculate that he either doesn’t care since he can protect himself magically, or he may not be entirely accepting of what’s going on, and is respecting us trying to reverse it. He has a lot of power. He could have come against me and my brother if he wanted to.  
**Gambit:** So what about Namor and Atlantis?  
**Rogue:** Hmm, we did enough damage to his enemies already. It could take well over a year till they recoup the loss.

Meanwhile, The Outcast Atlanteans are impatient and no longer wish to wait for an ideal time to invade. With the help of The Surface People’s resources fully behind them, they begin moving into place with just their own equipment and decide to take the city using guerrilla tactics.

Meanwhile in the DC Universe, out of nowhere up in the air in the middle of the bustling city appears Mxyzptlk. Though he willed himself there, he’s surprised to see it actually happened.  
**Mxyzptlk:** Hmm, I’m not due my time yet. How did this happen?

He looks around and immediately thinks about Superman and his Justice League, and misses contending with him. So he decides to make trouble by using his magic to lift a bus full of people and place it just hanging off the edge of a cliff, knowing that the media will report it, and it will draw out Superman. He laughs saying,  
**Mxyzptlk:** Oh this is going to be fun.

Superman sees and hears it on The Justice League Monitor, and flies off to the rescue. He secures the people and flies off, but is then obstructed by a giant sandman rising up with his fist grabbing him. He breaks free and uses his eye beams to destroy it, and then thinking about the two incidences, Superman discerns that it must be the work of Mxyzptlk. He then says his name and the diabolical imp appears, remarking,  
**Mxyzptlk:** Superman!  
**Superman:** What are you doing here? We got rid of you 3 years ago. You’re not supposed to be here.  
**Mxyzptlk:** Well I escaped the 5th dimension. Proud of me?  
**Superman:** Oh no! Lex Luthor’s secret weapon must have accidentally freed you.  
**Mxyzptlk:** Hmm? He’s just a Scientist. I don’t know what you’re talking about?  
**Superman:** You’ll have to excuse me. I’m in the middle of a serious problem. I can’t deal with you now.

Superman flies off, and Mxyzptlk is offended being shrugged off like that. He teleports to The Hall of Justice and sees The Superfriends hard at work busy talking about Lex Luthor’s new weapon and how powerful he is, that he’s more of a problem now than any other villain. Well, that makes no sense to Mxyzptlk, as he ponders it with his hand resting along his chin. He disappears to check out Lex Luthor, and finds him at The Head of The World, leading all the other Super Villains willing to join him.  
**Mxyzptlk:** This is unusual. A lot has happened since I left. How did he get so powerful?

Mxyzptlk then teleports back to The Hall of Justice trolling Superman, whom he loves to bother, but Superman ignores him. He sees Batman and Wonder Woman preparing for something and to get their attention, he causes water to appear on the floor and they slip. Batman angrily says,  
**Batman:** We don’t have time for your tricks! You’re an amateur now compared to what we have to deal with. Why don’t you get lost!

Mxyzptlk is angry at the comment, and shouts back,  
**Mxyzptlk:** I’ll show YOU!

And fearing that he might turn Batman into a donkey or something, Superman intervenes,  
**Superman:** Mxyzptlk! Please. We don’t mean to be rude. You see, we are way too busy now.  
**Mxyzptlk:** But I’m the greatest power in the universe you’ve ever known.  
**Wonder Woman:** Are you sure about that? There’s Darkseid!  
**Mxyzptlk:** Oh I can beat him.  
**Batman:** That’s debatable, don’t you think Robin?  
**Robin:** Yeah.  
**Mxyzptlk:** Well something is wrong with you calling yourselves Superheroes is you can’t handle Lex Luthor.  
**Robin:** Ahh, he’s gotten better over the years. He surprised us. And now he has a new secret weapon.  
**Batman:** So if you’d excuse us, we have a bigger villain to handle.

Due to their deception, Mxyzptlk, now thinks Lex Luthor is a problem coming between him and his enjoyment of battling The Super Powers Team, and he’s not use to having someone else in the picture spoiling his fun. So he goes back to Lex Luthor’s lair and starts making mischief, thinking he is just Lex Luthor. The odd stuff happening at his lair causes Apocalypse, the entity inside Lex Luthor to sense the trouble is coming from another entity. Lex Luthor rise from his throne, with his eyes all lit up. There is wind all about him and he speaks in a solemn and majestic voice,  
**Lex Luthor:** Mister Mxyzptlk. I know it is you.

Mxyzptlk, is shocked. He can tell right away that the man standing there is not really Lex Luthor as he knows him, but some demonic energy from another universe who he happens to know of.  
**Mxyzptlk:** How did YOU get here?

Apocalypse laughs, and says  
**Lex Luthor:** Nothing stops Apocalypse. I am bound by nothing.

Mxyzptlk, being all-powerful in a way to many, seeing his setup, and knowing better is aware of Apocalypse’s Marvel Universe story from what he last knew about him, given his powers to know about people and things living and happening in other dimensions which he tunes into from time to time. So now it makes sense why The Superfriends are neglecting to deal with him.  
**Lex Luthor:** Join Me.  
**Mxyzptlk:** No thanks. I Am my own power.

Mxyzptlk floats through his place taking in his vibes and knowing full well that The Superfriends are no match for him except a few who can compete for a while, but would still need help. Mxyzptlk, then disappears. Apocalypse senses that he would be a problem, and smiles evilly.

Meanwhile, at The Hall of Justice, Aqua Man receives a psychic distress signal from Namor, and excuses himself from the group.  
**Aqua Man:** Namor, what is it?  
**Namor:** Atlantis is being invaded and I’m being kept from being there due to this legal case. If I leave now, I risk breaching both the Atlantean Code of Ethics where it concerns Foreign Affairs, as well as dishonoring the legal proceedings here. And now I don’t know what to do.  
**Aqua Man:** Trust in your people. We are about to resolve our situation here with Apocalypse if things work out as expected. I’ll fill you in later. Right now, let me see if I can address your issue.

Aqua Man disconnects from Namor, and goes to his own Atlantis, where he summons the god Poseidon, beseeching him for help. Poseidon appears as a huge watery figure wearing his golden crown and holding his golden trident. He Tells Aqua Man,  
**Poseidon:** Behold! I will send you to Namor’s Atlantis as ALL Atlantis is one through time and space.

A portal then opens, and Aqua Man swims through magically appearing in Namor’s Atlantis.  
**Aqua Man:** Hmm, it doesn’t look that different. I almost feel like I know my way around.

Aqua Man swims about coming across one of Namor’s trusted allies, Alyse.  
**Alyse:** Who are you? I know all our people, even the ones I’m fighting, and I’ve never seen you before.  
**Aqua Man:** Take me to Namor’s Palace.  
**Alyse:** You’re very forward.  
**Aqua Man:** Quick, we have no time to waste. I know Namor. He needs help.

Looking at Aqua Man, his regal-ness and sensing a good vibe, Alyse then swims leading him to the palace where he sees a ready army. Duke, The Sage is taken by Aqua Man’s appearance and says,  
**Duke, The Sage:** You look like a King.  
**Aqua Man:** I’m Aqua Man.  
**Duke, The Sage:** From the moment I saw you, I sensed something special about you. We know who you are. Namor confers with you. I am Duke.  
**Aqua Man:** Namor contacted me about this problem and I’m able to cross time and space to be here by the power of Poseidon.  
**Alyse:** That’s great. We need your help. We’ve been suffering attacks.  
**Duke, The Sage:** They’re hoping that Namor will be forced to abdicate his throne due to his legal entanglements with The Surface People and the time is passing where he is not back for his people as our rules require. So now they think we have no King.  
**Aqua Man:** Our laws specify the title The Rightful Ruler of Atlantis. And Poseidon says all Atlantis is One. **SO I AM HERE!**

Duke, Alyse and their band of warriors cheer, knowing that they have the upper hand. Aqua Man then enters Namor’s Palace and they notice how Dr. Strange’s enchantment over it recognizes Aqua Man as if he **\_***WAS***\_** Namor. He is able to lift Namor’s different tridents, and go through his place as if it were his without seeming odd in it. And the people about the place, accept his presence as Namor. When The Outcast Atlanteans strike the region, Aqua Man and his team of warriors go out valiantly fighting them and winning. Some are taken prisoners. This happens again when the next attack breaks out moments after. It does not dawn on The Outcast Atlanteans that they are losing until it becomes visibly noticeable. A few of them retreat back to The Surface World, while the rest still trapped in Atlantis are defeated. And these prisoners are shocked to see Aqua Man, and wonder who he is, and just looking at his posture, his manliness, and the kind of command he has, living at the palace, they believe he must be a relative of Namor.

Meanwhile, on the surface, Namor is still embattled with his legal case where Jean Grey and Kennedy contend with Geoffrey Bearman, who is trying to establish that Namor’s friend Jaye Heiman is a bad Supervisor who is not fit to watch him. Kennedy and Jean Grey, counter by successfully proving how Namor is so respectful of The Court’s terms by producing how ignorant he is of the current diplomatic affairs and what’s happening in the world. Then Bearman rolls back his attack.

Meanwhile, back in the DC Universe, Sinestro senses a sudden change in his signature spell. A new energy about it and it makes him feel uncomfortable. He knows Dr. Strange is trying to undue his work. And what he wants to do now at his own leisure is resolve his ties from that dimension. Meanwhile, Mxyzptlk decides to make some mischief by messing around with Darkseid’s son Kalibak, by manifesting from thin air what appears to be Lex Luthor in his space cruiser attacking him. He is shocked to see that and fires back. The cruiser then trails him, shooting and knocking out his engines, and to avoid crashing into a large asteroid, he uses one of his father’s dimensional gates to escape by jumping into it, and he ends up back at his Dad’s throne room.  
**Darkseid:** Kalibak. Back so soon?  
**Kalibak:** Father, while on my way to scout out a new planet to plunder, Lex Luthor attacked my ship.  
**Darkseid:** That is unusual.

Darkseid, who has not been paying much attention to the affairs of Superman and his enemies, decide to look into his mystic portal to see what’s going on, and he notices Lex Luthor as The Man of the place. Darkseid takes his hand thoughtfully stroking his chin.  
**Darkseid:** When did he get so powerful?  
**Kalibak:** Grant me a fleet of warriors Father, I will destroy him.  
**Darkseid:** Wait! I’ve never had a quarrel with him before. I don’t know why he would dare attack you.

Darkseid observes some more and realizes that Lex Luthor appears to be empowered by some Supernatural force inhabiting him.  
**Kalibak:** See Father, he must be trying to conquer the rest of the known universe.

**Darkseid:** Very ambitious. You may have your revenge.

Kalibak readies his fleet and enters into a portal to attack Lex Luthor at his base. When Kalibak’s fleet comes in striking at everything in sight, Kalibak yells out from his starship,  
**Kalibak:** Remember me!?

Lex Luthor is surprised not knowing what he’s talking about. He is offended to see Kalibak attacking him, and he uses his Apocalypse powers to strike him down. And watching all this in his realm is Darkseid himself who mysteriously appears after.  
**Darkseid:** Luthor! You dare strike my son.  
**Lex Luthor:** I am Apocalypse!

Darkseid is taken aback. He has heard of Apocalypse, but never expected him to be in this dimension.  
**Darkseid:** This sector of the universe is ours, and there can be only one **Apokolips**, and we rule it. It is our home.  
**Lex Luthor:** Then it shall be mine to rule.

Apocalypse then attacks Darkseid, and they trade magical blows mercilessly fighting one another. Mxyzptlk is discreetly on the sidelines enjoying the conflict. They are both evenly matched, but Mxyzptlk, tips the odds in Darkseid’s favor by using his own powers to neutralize the effects of Apocalypse’s emitted energy from affecting Darkseid. Mxyzptlk, knows that Darkseid is the more powerful one, but he cannot amass the entirety of his celestial being into this limited realm, so he assumes his current form which everyone sees and knows as Darkseid. And since Apocalypse is the one that should win the fight given that he is powerful enough to defeat Darkseid in his lesser form, Mxyzptlk, ensures that he will be unable to, by constantly interfering. Both beings trash the place fighting each other that, word gets back to The Superfriends looking at their monitor as Solomon Grundy and Giganta ask for help. They lose the signal, but The Superfriends saw enough.

**Batman:** This is great. The plan is working perfectly.

Superman and a few Justice League members fly there, and upon arrival they try to contain the situation. They don’t want to hurt Lex Luthor or see him get hurt since he’s just demonically possessed by Apocalypse. And so Wonder Woman uses her magic lasso to hold Lex Luthor for a while until Scarecrow can attempt to say some incantation that might exhume Apocalypse from residing in Lex Luthor’s body. It almost works, but Apocalypse breaks free. And using his powers, he strikes at them. Mxyzptlk zaps Luthor’s back with his magic knocking him out. Apache Chief then makes some Native American symbols into the ground forming a circle he lays Lex Luthor in. Then he performs a sacred rite saying some old Indian chant. He takes his sage, burns it, passes it along Luthor’s body and finishes his ceremony. All of a sudden a greyish mist rises from Luthor’s body and travels away on it’s own. And seeing this is Mxyzptlk who yells,  
**Mxyzptlk:** Oh no you don’t!

He contains it in a crystal ball. Lex wakes up, looks around and says,  
**Lex Luthor:** What happened? Why am I here lying on the dirt?  
**Superman:** It’s okay Lex. Long story. We’ll tell you later.       
       
Darkseid then comments,  
**Darkseid:** It seems that we’ve solved both our problems.

He then calls out,  
**Darkseid:** Kalibak!

Kalibak approaches his father who is ready to go, but Mxyzptlk comments,  
**Mxyzptlk:** You should take this with you.

He then levitates the crystal towards him and Darkseid opens up one of his dimensional gates casting it into another realm far and deep where it would be lost. And before leaving into his own portal, he turns to Mxyzptlk and says,

**Darkseid:** I knew it made no sense for Lex Luthor to attack Kalibak.

And then his eyes light up with his omega beams shooting out at Mxyzptlk, who shields himself with a force-field. Darkseid steps into the portal with Kalibak back into their realm. And now that Darkseid and Apocalypse are not an issue, Superman quickly starts thinking of a way to lose Mxyzptlk. He tags along with Lex Luthor, and The Superfriends, as they return home. Once there, Mxyzptlk is happy that there are no more distractions getting in the way of the types of games he likes to play with them. And they know he is dangerous and aren’t interested in another adventure so they clue him in on something he did not know before.  
**Wonder Twins:** Hey Mxyzptlk, don’t you wanna know how Lex Luthor got Apocalypse inside of him in the first place?  
**Mxyzptlk:** I suppose.  
**Wonder Twins:** It was Sinestro’s magic. We found his spells. Here take a look.

The Wonder Twins also slip in a fake spell sheet with his name backwards. Mxyzptlk starts looking at them.  
**Mxyzptlk:** Who cares?  
**Wonder Twins:** But we care. And it’s not over yet. Sinestro is still out there.  
**Mxyzptlk:** So why don’t you undo the spell?  
**Wonder Twins:** Because we don’t read ancient hieroglyphs and other languages.

And as he goes through, he notices their trick and says,  
**Mxyzptlk:** Nice try you Wonder Idiots, you’re trying to get me to say my name backwards. Well I won’t disappear that easily. I am now free to play. You should be thanking me for helping you.

Mxyzptlk then floats up to Superman with a child-like glee in his eyes, and The Man of Steel can only wonder what sort of impish tricks he might do now, but he decides to give them a break, and disappear for a while.

Meanwhile in The Marvel Universe, Kennedy and Jean Grey are still dealing with Namor’s case. Brandon, an AUSA left the case. And today, they are battling another AUSA name Alexander The Sea Cape Wise Man, along with someone name Stacey Wilks, and Andraika Stross, arguing back and forth still trying to make the charges stick. And to answer the prejudicial claims his persecutors are making about his character again, Kennedy decides to call one of the well-known city Mobsters of his day to The Stand.  
**John F. Kennedy jr.,:** Now, what are your opinions about Namor.  
**John Gotti:** I never met him, but he seems like a nice guy.  
**John F. Kennedy jr.,:** And given what you know about him in the press, does he seem like a “Made Man” to you?  
**John Gotti:** No.  
**John F. Kennedy jr.,:** Why not?  
**John Gotti:** I know Mobsters. I can tell. I don’t know why they are calling him a Gangster.  
**John F. Kennedy jr.,:** So you don’t see a Gangster in him?  
**John Gotti:** I know Gangsters. He ain’t one. He gotta get his hands dirty.  
**John F. Kennedy jr.,:** But The Justice Division believes he is.  
**John Gotti:** If they knew this world, they wouldn’t be wasting time with him. He’s got his Superhero career, his moral code, his Diplomat stuff, and that whole Atlantis thing. Come on. He ain’t no Gangster. For example, while he’s swimming in the underworld being King of Atlantis, Mobsters are up here whacking guys and dumping them in the river. What is he doing? Going to international conferences talking about global peace.  
**John F. Kennedy jr.,:** No more questions You Honor.

The time finally comes when a jury must decide whether Namor is guilty of anything or not. And The Head Juror, **Mr. Stan Lee** comes back with the Verdict, **Not Guilty**. This is cause for celebration, the news media is all over it. They report everything from top to finish and Kennedy goes on all the shows explaining everything wrong with the case to begin with, like how Namor should never have been tried in the first place. And not caring about the publicity much, is Namor, who just wants to return to Atlantis. He finally does, and ends up meeting Aqua Man. He’s astonished to see him in the flesh.

**Namor:** Aqua Man! Thank you for being there for me.

**Aqua Man:** No problem. I couldn’t let Atlantis fall into the wrong hands.

**Namor:** Well it’s not over yet, for me I mean. We still have Sinestro to deal with among other enemies, but I can take it from here.

Aqua Man and Namor hang out a while longer, getting to know more about each other, before parting ways.

Meanwhile, on the surface, the people of Earth turn their attention to an event happening in the stars. Galactus is arriving on schedule. The X-Men and other Superheroes seeing that as a problem are ever vigilant, no one more so than The Silver Surfer himself. As Galactus draws closer, there is protest from people on the planet opposing it, this includes Black Panther, Miss Marvel, and other Superheroes and Villains. And some fights break out here and there between these Mutants. And given the cosmic level of everything, Jean Grey decides to change into The Dark Phoenix to help protect the planet from the inevitable. The United States Space Force sends a starship with Representatives to meet Galactus and they give their rehearsed speech only to be rudely interrupted by him, making an accusation in his mighty voice.

**Galactus:** You already gave me the Official USA Guardian Status. Why are you fighting me!?  
**The U.S. Representatives:** We don’t know what you mean? We’ve been nothing but welcoming to you.

**Galactus:** My Aides have informed me about an assembly to stop me. You LIED!

Galactus then takes his mighty hand, hovering over planet Earth, scaring people.  
**The U.S. Representatives:** No Galactus! There are some difficult people among us, but give us a chance to resolve it.

The U.S. Representatives, then radios The White House telling Trump there’s problems with Galactus.  
**Donald Trump:** I knew this wouldn’t work. He’s already threatening us. I don’t want him here.

And seeing his big head looking down on the planet, Trump then thinks about a solution, and employs his backup strategy by getting up on The White House roof with a high-frquency megaphone shouting at Galactus.

**Donald Trump:** Galactus! Galactus! Listen to me Galactus. Your problem is not me or my people, it’s Namor, The Sub-Mariner. He raised a mighty army up against you. He’s been up around the planet rabble-rousing people against you. HE HATES YOU!

Galactus is shocked to hear that. He was more expecting somebody who would make more sense to be opposing him like Thanos, Dr. Doom, The Beyonder, or even his former Herald, The Silver Surfer. He’s not sure how to attack the situation, and has nothing against Namor, but his protocol is to destroy his enemies. So he attempts to reach down into the waters, but then The Silver Surfer shows up to stop him.  
**Silver Surfer:** Galactus, NO!  
**Galactus:** YOU! You are no longer my Herald. You betrayed me.  
**Silver Surfer:** Yes, I escaped you, but I carry no bitterness towards you. And Namor is not your enemy. You’re being lied to.  
**Galactus:** I no longer trust you. You are protecting him.

Galactus ignores him and continues his motion for attack. The Silver Surfer then strikes at Galactus. Storm and the other X-Men watch, as well as the other people on the planet. Storm shouts,  
**Storm:** He cannot fight him alone!

Storm flies about the sky igniting her powers to the full extent creating turbulent conditions just around Galactus himself. The Silver Surfer then spots Dr. Strange who collaborates with Storm as she opens up a whirlwind into Atlantis for The Surfer to ride and go through where the portal leads directly to Namor, who’s unaware of what’s going on. The Surfer greets him, letting him know that he is ***NOW*** being attacked by Galactus, which surprises him since that came out of nowhere. And being the brave Leader he is, he has no fear defending Atlantis against any foe. He takes his Trident and triumphantly rise up out of the whirlwind portal shouting,

**Namor:** IMPERIUS REX!

Following him out also is The Silver Surfer, to meet Galactus. The X-Men are impressed by his courage but fear for his safety, so they crowd him. Galactus is amused. Though people run in fear for their lives screaming, Trump stands there looking at the live show gleefully, then remarks,  
**Donald Trump:** Come on Namor.

Namor looks up at Galactus with defiance, then uses the power of his trident hurling the most damaging energy blows at him repeatedly. Galactus strikes back with is own beams, but the power of The Trident protects him with a force-field. Storm then causes a tornado of water to rise obstructing Galactus, and it closely twirls around is body. Warlock then changes the chemical composition of the water to some odd material to encase Galactus. Then with that temporary hold, Dr. Strange and Warlock quickly begin their spell fully reversing Sinestro’s evil magic across the universe, also using his coded word during the spell, and opening up a portal into another dimension. And while in The DC Universe, Sinestro senses danger due to his own magic being tampered with, and so he creates a portal to step into the Marvel Universe, and as he goes through the cosmic tunnel, not even reaching The Marvel Universe yet, he is intercepted by The Silver Surfer in between that time and space, who uses his own power to bend the energy time-continuum, dropping him instead into the dimensional portal Dr. Strange opened up. The Silver Surfer then returns to the scene helping Dr. Strange and Warlock to get Galactus in it as well. This proves difficult as he is struggling to escape his bonds, but eventually the team succeeds. **Galactus is gone**, and everyone on the planet is safe again. And it takes time for the people to adjust to life as it was before because this was all unexpected. As a few days pass, back at the mansion Namor discusses it with The Silver Surfer.  
**Namor:** We couldn’t have done it without you. And everyone else involved was good too.  
**Silver Surfer:** This could have ended much sooner had there not been other alternate realities I cared about. You see I travel The Universes knowing all kinds of things. Aqua Man is not your only alternate reality. There are others. And there is this one man I was concerned about surviving his reality, who is not as fortunate as you, or Aqua Man or the others who had some kind of edge, or advantage, powers or a team of Superheroes to help him. So I was trying to save him too.  
**Namor:** It would nice to meet him like I did Aqua Man.  
**Silver Surfer:** I can tell you this, his name is Michael, and he looks a little more like Lex Luthor than he does you and acts a little like him too, but he is cut from the same spiritual cloth as you and has the similar inter-related destinies. And it’ll all be okay, don’t worry.

Later that day, the team bids The Surfer farewell, and wonders where he’ll go next and will they ever see him again, to which Storm answers,  
**Storm:** He’s needed elsewhere. He’s The Sentinel of the Spaceways. Where soars the Silver Surfer, there must he soar alone.

Meanwhile, in another dimension, lives similar people in their own alternate reality. A young woman is starting her day in New York and looks out her window seeing a streak of light move across the sky, and finding it interesting. And somewhere in Newport Beach, California taking a stroll is a man, who just so happens to meet up with a friend on the beach carrying his surf board.  
**The Friend:** Oh Hi Michael.  
**Michael:** Hey Jon. How’s it going?  
**The Friend:** Good. I won my last case, you?  
**Michael:** I have a few pending legal cases to deal with, but I’ll handle it. I’m just worried about the future you know, and how things might turn out for me. I’m thinking about doing a few things.  
**The Friends:** I know, but you know what? It’ll all be okay. Don’t worry. Hey, I gotta go.

The friend then moves on and as Michael walks away further, he remembers to ask him something and turns around, but the friend disappears. Michael is shocked because given that long stretch of beach, his friend should still be walking down that path. He looks around not seeing him, then wonders is it possible to walk that fast carrying a surfboard. He dismisses it, and then goes about his business.

**By: Lhisa Mrklon**

**Do You Miss Stan Lee? Scroll Down And Leave Your Reply Below.**

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192457666/Tmsvf3iMJ.html align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192458698/k1S7oA-gV.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192460015/rt9XesJQG.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192461292/5MHDo8yqn.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192462478/0LwcBgS3r.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192463831/5lOgVqs6j.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192465535/ZhuFx5sF5.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192466968/kdxx9ye59.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192468464/Uvx3He0Rt.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192470037/I_BsTS8Rq.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192471504/izknm_Jmq.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192473080/zJ9-eRHOw.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192474564/cK1tRuJsO.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192476108/PuTai1K0n.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192478007/faTmgQZ50.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192479734/7tGS-mn84.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192481214/XnniKFvMG.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192482459/1IW-d80eM.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192483759/nCW0TrqMa.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192485479/Gqk8E3xLL.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192487364/y0go-yof3.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192488805/5PmYYkSCY.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192490076/u31tk39Lq.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192491392/BGFVItM7q.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192492837/oXqiXZSyw.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192494199/vvd3zASyj.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192495757/kYlrhDrXo.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192497129/_DH3EpCZ2.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192498380/wjYlgpthD.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192499650/AnTm3uGK1.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192501188/-7kh7M1Qw.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192502931/sQ-xV_lxX.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192504549/Fc-IjGk63.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192506180/HCOaIjNd-.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192507558/GXNTLPDZD.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192508945/28ju01neb.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192510217/XVMrsUUJR.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192511362/Pck6XmnZo.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192512853/01A46xd5H.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192514301/RbxfzRLmL.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192516040/d0X61hrMO.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192517467/hM0zgIiz4.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192519071/aToJyRIn3.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192520756/w_-KrFLqX.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192522176/_ueOgxwf-.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192523881/SynwYCkNj.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192525295/L21rb1qET.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192526762/9L3uNyzpv.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192528173/-S4QE2xKv.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192529570/k1yYj_N7o.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192530971/eRS8TmU_O.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192532538/MsYGt_lGa.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192533980/FdkboQ285.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192535640/NZFy-ULjL.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192536845/u2MBCHslO.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192538027/JjxUGSP6t.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192539613/66VQVY511.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192541168/VUBBV1n00.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192542715/HK60PQ3a8.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192544480/ZeHcE9oAS.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192545749/6B8NXKrHY.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192547142/q836Gv2Ql.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192549112/p9K78RKIG.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192551025/6dizh4uVp.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192552174/AWbzLuCxb.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192553976/GWLTt3P9w.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192555626/hsHTMq65W.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192556864/tCk947pje.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192558069/kVcqEKEHa.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192559558/eEdy6Ffxg.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192561113/omDvfgE50.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192562353/IrrfrzHY9.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192563834/vaTWtqfUQ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192565562/1ygSl2mLS.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192566887/JTVgHmtc0.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192568111/Oq0U39GEr.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192569594/XebIAQegZ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192570914/R3AqEojY7.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192573053/zVzJuRaM5.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192574625/3QCQVfsOm.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192576326/w6u4OWxgY.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192577849/6LY0BoGGQ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192579092/O10TChEBv.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192580463/Q6V4SMljo.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192581730/RadXeSdlq.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192582904/fhrDz7O8h.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192584221/FkRf-glDM.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192585549/-nTP2R7U4.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192586795/gKbCdz9w4.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192588164/3JJ9OUeTg.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192589916/E2j7VeZ5m.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192591916/JegATWf1L.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192593329/9qV_vvqCw.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192595052/DJpnixQBn.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192598222/pQsbpy7xv.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192600624/ZQXrf73oO.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192603074/cwmZk5MGa.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192605260/hRA3qpWwH.png align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192606792/PFbarNPcl.jpeg align="left")](https://lightinthebox.tv2h87.net/c/3170166/805530/8199?prodsku=7920076&u=https%3A%2F%2Fwww.lightinthebox.com%2Fcurren-men-s-sport-watch-military-watch-analog-quartz-luxury-calendar-leather-wrist-watch-man-clock-fashion-chronograph-wristwatchthree-time-zones_p7920076.html%3Fcurrency%3DUSD&intsrc=PUI2_5801)

### Like this:

Like Loading...

### *Related*
