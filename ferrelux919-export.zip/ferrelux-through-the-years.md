---
title: "\U0001F4C5 Ferrelux Through The Years \U0001F4C8"
date: '2022-03-07T03:46:21.000Z'
slug: ferrelux-through-the-years
tags:
  - amazon
  - website
  - news
  - help
  - ads
  - instagram
  - organization
  - wordpress
  - facebook
  - microsoft
  - ecommerce
  - work-environment
  - phishing
  - google
  - domain
  - advertising
  - youtube
  - it
  - legal
  - flags
  - hope
  - language
  - marketplace
  - alexa
  - retail
  - yelp
  - doj
  - search-engine
  - colors
  - social-network
  - small-business
  - professional
  - information-technology
  - rules
  - companies
  - ratings
  - war
  - workplace
  - new-year
  - store
  - group
  - usa
  - competition
  - account
  - magazine
  - government
  - love
  - publication
  - constitution
  - global
  - corporate
  - content-creator
  - anchor
  - advocate
  - cybercrime
  - entertainment
  - american
  - forum
  - technical-support
  - parler
  - politics
  - ban
  - cia
  - democracy
  - power
  - charity
  - reporter
  - ukraine
  - fake
  - lawyers
  - stalking
  - influencer
  - god
  - police
  - christ
  - russia
  - piracy
  - online-fraud
  - bing
  - nazi
  - ngo
  - laws
  - bully
  - advocacy
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672208149359/e8d7c6c0-e8e3-4a12-975c-e965bffdb09f.png
canonical: 'https://ferrelux666.wordpress.com/2022/03/06/ferrelux-thru-the-years/'
---
[![Lhisa Mrklon, In Thought](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192013501/e4SMDx6g0.jpeg align="left")](https://ferrelux.com/lhisa/)

  
Meum Certamen ♠️ My Struggle

<iframe width="100%" height="100" src="https://w.soundcloud.com/player/?url=https%3A%2F%2Fapi.soundcloud.com%2Ftracks%2F564836523&auto_play=false&hide_related=false&visual=true&show_comments=true&show_user=true&show_reposts=false&color=ff5500"></iframe>

[Tibor Maris](https://soundcloud.com/tibor-maris) · [Chesney Hawkes – I Am The One And Only ének Maris Tibor](https://soundcloud.com/tibor-maris/chesney-hawkes-i-am-the-one-and-only-enek-maris-tibor)

**Lyrics:** [**https://genius.com/Chesney-hawkes-the-one-and-only-lyrics**](https://genius.com/Chesney-hawkes-the-one-and-only-lyrics)**  
I Am The One & Only, Nobody Else I’d Rather Be, I Am The One & Only, You Can’t Take That Away From Me**

**Yes, I’m well aware of the war going on between Russia and Ukraine, and remember I commented on it a couple times before it happened. As the conflict goes on, we’ll see the outcome, but right now I’m more concerned with the timeliness of this publication for Womens History Month where this time around for imperial purposes, the featured topic will be about me and my company Ferrelux.**

Now, many of you from all walks of life, following me through the years on various platforms and are aware of me and my struggles, and who know a bit more about my online history and purpose than the next person, already see and know some things I am currently battling. You see the proof of some of the stuff I’m talking about because **\_***some people***\_** just can’t lie low. When you’re right about something, it’s just a matter of a guilty hand turning and proving you correct. A lot of people take to some of the stuff I’ve written, repeating a word, phrase, re-iterating a concept and so forth. My popularity has steadily grown over the years to where **\_***my power***\_** has shown. So much so to the point where one can notice a Cabal extensively working against my First Amendment Rights. Unlike other publications out there, and those presenting facts & opinions on topics, I’ve had my own way of exposing certain things that are really happening beneath the surface of Society, that the terrible truth affects those who are trying to hide it from the public. This is why I am coming under attack right now by certain BIG companies organizing against a single Negro Female running a small business. And I put it that way because **\_***look at it***\_**. My Attackers are so far removed from reality, that anyone following it can see. One of them is Google. A company who fell under the probe of **\_***The Department of Justice***\_** suing them for Anti-Trust Violations. On other occasions, they have been guilty of other criminal offenses and held accountable. You can research the various legal articles of it. Yet, they still quietly engage in the same forms of behavior. In December of last year, I was sent an email Ad to do a business listing with them. I had recently updated this site heavily running my own ad campaigns and I thought about it, and decided why not. Now mind you, I’ve been conducting my operation for decades now online without issue, appearing at the top of Google’s search engine each time, and I never had any prior issues with them. So I signed up and everything, went through the validation process, got approved, only to experience a nightmare. I’d set up my photos and some products, where they pigeon-hole everything to manually approve one by one each item added, any change I made or other general activity. What the whole thing turned out to be was an attack on me and my business. All of a sudden, I noticed my site ranking dropped **(only in their search engine)** and almost each day information about it would shift in their attempt to marginalize me. Then all of a sudden, someone in Instagram who appears to be using the service fraudulently out of South America, was using my business name as their url handle, and then I noticed each day, a new so-called foreign business controlled by Google would pop-up also trying to bite off my enterprise. Now, none of this ever happened before. These attacks just started under Google where they decided to target me all of a sudden. I accused them of several things, and they never denied it. They also failed to make the corrections. I took records of things and am now engaged in legal action against them. They are trying to give the impression that my website isn’t significant and are marginalizing it, where it was so important to get me to sign-up for that business Ad listing to be able to do it. I’m listed in Google Maps in The United States as a closed business when I never personally closed the listing at all due to common sense, since I am still operating it. I requested for them to remove me from their listing program which should include Google Maps as well since I was never in it before. They are refusing to release my listing out of their system in their effort to control the popularity of certain people and businesses they don’t like online. I since took certain action against them, and guess **WHO** popped up in the fight attacking me? Facebook. Another company who fell under legal scrutiny for impure practices and like Google, are still under investigation, but they both don’t care, since it’s a sport for them to attack smaller competing businesses and person’s with conservative views. Now, I never had any issues with Facebook before and like Google, I had accounts with them for many years without issue. When I was logged into one of them **(Facebook.com/Lhisa666)** in the short while I was on there doing what I normally do, I was all of a sudden locked out and told if I want to re-gain access to my account, I must upload my Personal IDs. Well, I don’t use Facebook to promote paid Ads or engage in any of the other socio-political activities where they require a valid ID matching the name on the account. This poses a problem for the millions of people using Facebook who are just using monikers, pseudonyms, nicknames, fictional characters and so forth. I tried reasoning with them and made some allegations which they never denied. So now we’re talking about 2 Jewish Companies, who decided to collaborate with one another to single-out and attack a seemingly obscure Black person on the world-wide web even though I did nothing wrong to any of them. There are 2 other companies that appear to be involved which some of you might already guess, especially if you have experienced this sort of consecutive attack from them before. **They have shown their hand.** It’s safer for anyone running something of note to extensively examine the hosting companies and email services that some businesses use to see **\_***WHO***\_** might be connected to **who** and why. You doing your due diligence and making discriminatory choices by patronizing other Vendors can help protect you from Cabals like this. I’m not about to change my views on things or my right to operate as I do. **\_***And whoever they are doing it for***\_**, I’m seeing as a FOOL. I’ve now gained much insight to certain things making me even more dangerous now due to their stupidness. If I was merely concerned about my next topic for discussion, and posting cute ads here and there, Ya’ll should have left that alone. Feeling threatened by that has opened by mind to seeing just how vulnerable YOU really are because you’ve failed to cover your ass in ways that would shield you. I shouldn’t be aware of particular things concerning your group. I’m not one of you. I’m my own person and I have my own spiritual identity, Ferrelux. And though **You People** may think you are lighting the world, **I AM**. And I was mainly concerned about presenting **\_***my own***\_** mosaic, using art, music, expressing my opinions in these articles a certain way and amusing myself and others. And because **YOU** could not leave well enough alone when it actually benefited you, you’ve now made things worst. Just Watch!

\*\*  
Sign,\*\*  
**Lhisa Mrklon  
F E R R E L U X**

### Did Google And/Or Facebook Ever Target You Or Your Business Unfairly? Scroll Down And Leave Your Reply Below.

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192014927/gmNjctB6M.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192016939/JqznyJYeC.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192018459/Rz8V9MbP-.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192019793/rgnkIfdSs.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192021264/BTnFcWmxn.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192023026/yrZkEtkQ6.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192024636/BfMhEAFHh.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192025726/pYrfJjCD0.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192026893/dNGXs-eME.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192028334/AKD83uJ-B.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192030056/bfkTpHuCR.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192031589/Ui_ZPU62o.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192033035/rJ-v-cypJ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192034075/7RMMVcnlU.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192035397/OTyYVKvf2.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192037388/8kbedRZlJ.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192039629/Mi9YVdGdY.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192041400/h6Kid8v5C.jpeg align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192043254/0Cv0W3RFB.jpeg align="left")](https://lightinthebox.tv2h87.net/c/3170166/940974/8199?prodsku=8409588&u=https%3A%2F%2Fwww.lightinthebox.com%2Ftree-of-life-necklace-for-women-men-silver-with-crystal-jewelry-owl-pendant_p8409588.html&intsrc=PUI2_7362)

### Like this:

Like Loading...

### *Related*
