---
title: "Flo \U0001F485\U0001F3FE Jo"
date: '2023-02-14T21:17:24.000Z'
slug: flo-jo
tags:
  - news
  - practice
  - games
  - tv
  - health
  - hair
  - new-year
  - usa
  - fashion
  - pose
  - sports
  - entertainment
  - african-american
  - olympics
  - cosmetic
  - topics
  - running
  - christian
  - california
  - faith
  - female
  - '2023'
  - funeral
  - tournament
  - young
  - death
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1676412722016/c405a74d-a7bf-4a12-be07-501b39fb824a.jpeg
canonical: 'https://f3rr3lux.wordpress.com/2023/02/14/flo-jo/'
---
[![Flo Jo, Tiger Stripes](https://cdn.hashnode.com/res/hashnode/image/upload/v1676412696771/fd635263-2334-44b1-97ac-f5a4c589698e.jpeg align="left")](https://www.dailymotion.com/video/x6x8uyt)

[**Cafe In Havana By Yoana Cruz**](https://soundcloud.com/yoanacruz/cafe-in-havana?in=yoanacruz/sets/cafe-in-havana-afro-cuban-jazz&utm_source=clipboard&utm_medium=text&utm_campaign=social_sharing)

\*Nihil Futura Esse Te Obtulit. Tu Habeat Ad Quae Ventura. 🥇  Nothing Is Going To Be Handed To You. You Have To Make Things Happen (Flo Jo)  
\*

**So closing out this year’s Black History Month, I won’t let it pass without mentioning this other great Athlete, Florence Griffith Joyner. I grew up also watching her race around the Olympic Track, winning silver and gold. She was stylish, always making a statement. Full of vibrance, and an inspiration to Black Women everywhere. Flo Jo is known for being the fastest woman on the planet in her days of championship. And since her time, this Black Woman still holds an unbeatable World Record to this day, doing our people proud in 1988 winning the 100 Meter Race in just 10.49 Seconds.**

**Flo Jo’s Famous Quotes**  
[https://www.azquotes.com/author/7641-Florence\_Griffith\_Joyner](https://www.azquotes.com/author/7641-Florence_Griffith_Joyner)

[https://www.brainyquote.com/authors/florence-griffith-joyner-quotes](https://www.brainyquote.com/authors/florence-griffith-joyner-quotes)

---

Flo Jo News Videos & Clips\*\*\*\*  
[https://www.dailymotion.com/video/x85fb71](https://www.dailymotion.com/video/x85fb71)  
[https://www.dailymotion.com/video/x4lmbvy](https://www.dailymotion.com/video/x4lmbvy)

[https://www.dailymotion.com/video/x57ngmc](https://www.dailymotion.com/video/x57ngmc)   
[https://www.dailymotion.com/video/x57xtej](https://www.dailymotion.com/video/x57xtej)

**Articles**  
[https://www.cbsnews.com/news/clues-to-flo-jos-death/](https://www.cbsnews.com/news/clues-to-flo-jos-death/)  
[https://www.biography.com/athletes/florence-joyner](https://www.biography.com/athletes/florence-joyner)

[https://www.britannica.com/biography/Florence-Griffith-Joyner](https://www.britannica.com/biography/Florence-Griffith-Joyner)

**PEACE FLO JO**  
**WITH THE LOVE OF THE PEOPLE**  
**HAPPY VALENTINE’S DAY**

![I Love Track  Field](https://cdn.hashnode.com/res/hashnode/image/upload/v1676412698007/cd68fe87-1334-46ba-b23d-91db13f04a4c.jpeg align="left")

**And What Do YOU Recall About Flo Jo?**

**Sign,**

**Lhisa Mrklon**

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1676412699471/50976b1c-5262-4ab5-864d-e66e6c4a8049.jpeg align="left")](https://lightinthebox.tv2h87.net/c/3170166/898314/8199?prodsku=4860167&u=https%3A%2F%2Fwww.lightinthebox.com%2Ftasdan-cycling-clothing-3-4-tights-short-pants-women-s-coolmax-material-cycling-3-4-shorts_p4860167.html&intsrc=PUI2_7096)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1676412700742/1f8bf035-4218-4f2d-973b-a0554ae5ebc7.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1676412702041/c31473e2-8a02-4f03-9a65-969643887f80.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1676412703168/b451d384-e1aa-4e90-ab56-582b8260c5a1.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1676412704725/eb34bc82-8bff-4631-be45-ae1e8589b775.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1676412706477/d1fe20eb-b792-47ae-a792-814ddcfaed23.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1676412708050/73fde0fe-d534-4614-be31-ad3046ae19fd.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1676412709438/80949929-e19e-4454-844d-72d7d2b18938.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1676412710776/d2692d26-67d7-4177-b503-a76305856faf.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1676412712305/8b580089-d300-4d47-866f-9e36173980e3.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1676412713890/d9150ba6-3a08-4a2b-84d6-a11faece880a.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1676412715505/c89e0104-c7f0-465f-9280-fa4ba53e6e9a.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1676412717138/539e2768-4ae6-4c5a-a70e-af5fb0a50dfd.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1676412719213/f5e99da0-59ca-4476-ae9b-b0ce31449400.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1676412720341/a3d7c1a1-b06f-40b2-b3b5-99961383681c.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1677691580639/0fafac40-0b87-4244-b52f-aa6efa2cfa29.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1677691616693/c060539c-7677-4890-8b02-8aca0808dc73.jpeg align="center")

### Like this:

Like Loading...

### *Related*
