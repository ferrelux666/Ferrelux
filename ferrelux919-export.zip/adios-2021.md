---
title: ✨Adios  2021✨
date: '2022-01-01T21:35:26.000Z'
slug: adios-2021
tags:
  - new-year
  - party
  - fireworks
  - celebration
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672192237370/aO2xyHx3j.jpeg
canonical: 'https://ferrelux666.wordpress.com/2022/01/01/new-year-2022/'
---
[![2022 Fireworks](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192171830/xYKE5J7a2.jpeg align="left")](https://www.dailymotion.com/video/x86pqjd)

\*\*[Corona ~ Rhythm Of The Night](https://www.youtube.com/watch?v=OnT58cIJSpw)  
\*\*

Circa Rotam Fortunae 🎡 Around The Wheel Of Fortune

**So today we’re in the year 2022, and I must say that the topics I got to discuss last year exceeded my expectations for 2021 and with some carrying over into this year. Check out the photo gallery to see last year’s homepages. Now, I don’t want to say that I look forward to this year, because we’re still dealing with this global pandemic mess holding up our lives and the politics involved. So I hope that somehow one day, we can return to how life use to be, the normalcy of getting up and starting your day self-determining how we should live and think and deciding on our own what we should take or should not take without a government system interfering with the private intricacies of our lives.**

\*\*\*\*Sign,\*\*\*\***Lhisa Mrklon**

\*\*  

[![1800PetMeds](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192173397/aunFyq16J.jpeg align="left")](https://sovrn.co/1j4ozqd)

\*\*

### Are You Looking Forward To This Year Being Fruitful For You? Scroll Down And Leave Your Reply Below.

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192175039/foVVOVTH_.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192176581/ODx4PasfC.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192178045/1o3JLEujO.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192179802/M-e0_ubZb.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192181372/7xNqPSxq7.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192183429/gtwS5zGFW.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192185175/zFP4izEZ8.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192187235/T9ScnR8e6.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192189067/HZffQTJTs.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192191022/rofXNjrgf.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192192569/o_Msd4LA8.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192194539/WmTUvMp7C.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192196695/KmlPOL3KT.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192198633/iKgPdYM9B.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192200854/qu6dBzZ_V.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192203513/F6LdohiYJ.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192205517/juLLCt558.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192207549/tNEAMj0X_.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192210421/RSohait42.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192212575/nusHyUsdQ.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192215163/K42PXRmWR.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192221038/idP0MEEVw.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192223716/MQ30oYag9.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192226072/Rw9eyNsPs.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192227730/i0SHLX6yy.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192229187/yJuAVdsNQ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192230902/xxH_3Pamb.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192232619/4cDpk9IgL.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192234687/ymoynVt0F.jpeg align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192235998/I_64hmGEz.jpeg align="left")](https://lightinthebox.tv2h87.net/c/3170166/805530/8199?prodsku=8777240&u=https%3A%2F%2Fwww.lightinthebox.com%2Fs506-men-s-steel-band-luminous-watch-week-display-dual-calendar-quartz-watch-retro-waterproof-watch_p8777240.html%3Fcurrency%3DUSD&intsrc=PUI2_5801)

### Like this:

Like Loading...

### *Related*
