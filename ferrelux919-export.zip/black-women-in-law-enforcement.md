---
title: "⚖️ Black Women In Law Enforcement \U0001F46E\U0001F3FE‍♀️"
date: '2023-02-28T22:29:44.379Z'
slug: black-women-in-law-enforcement
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1677627419088/44f85788-9928-4f27-abe9-5f32874956c0.png
---
Ratione Juris 📃 By Principle Of Ones Right  
[Aretha Franklin ~ RESPECT](https://odysee.com/@MusicaDelRecuerdo:6/Aretha-Franklin-Respect:a)

FOR WOMEN'S HISTORY MONTH, FEATURING AT THE START FOR A COUPLE WEEKS, HONORING THE ACCOMPLISHMENTS OF  
TOP BLACK WOMEN OFFICERS.

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1677629541821/b2d9ddb3-d4df-4dcc-afcf-cca4c5559dcb.png align="center")](https://cops.usdoj.gov/html/dispatch/03-2022/five_field_voices.html)

**Showcasing Below Nine Top Black Women Cops**

**NYPD Police Commissioner, Keechant Sewell**  
[https://www.cnn.com/2021/12/14/us/keechant-sewell-nyc-first-female-police-commissioner/index.html](https://www.cnn.com/2021/12/14/us/keechant-sewell-nyc-first-female-police-commissioner/index.html)

**Capt Sonia Pruitt**

[https://www.blackenterprise.com/montgomerys-first-black-female-police-captain-will-teach-race-in-policing-through-new-experience/#:~:text=Retired%20Montgomery%20County%20Police%20Captain%20Sonia%20Pruitt%20made,officers%20about%20the%20history%20of%20racism%20in%20policing](https://www.blackenterprise.com/montgomerys-first-black-female-police-captain-will-teach-race-in-policing-through-new-experience/#:~:text=Retired%20Montgomery%20County%20Police%20Captain%20Sonia%20Pruitt%20made,officers%20about%20the%20history%20of%20racism%20in%20policing).

**Captain Treone Larvadain**  
[https://www.blackenterprise.com/louisiana-governor-appoints-first-black-female-police-captain-in-state-history/](https://www.blackenterprise.com/louisiana-governor-appoints-first-black-female-police-captain-in-state-history/)

**Captain Lillie Miller**  
[https://www.kcci.com/article/lillie-miller-becomes-first-black-female-captain-in-des-moines-police-department/33397640](https://www.kcci.com/article/lillie-miller-becomes-first-black-female-captain-in-des-moines-police-department/33397640)

**Captain Patricia Helliger**  
[https://www.wtnh.com/news/connecticut/new-haven/new-haven-names-first-black-female-police-captain/](https://www.wtnh.com/news/connecticut/new-haven/new-haven-names-first-black-female-police-captain/)

**Acting Police Chief, Yogananda Pittman**  
[https://www.cnn.com/2021/01/11/us/new-uscp-chief-yogananda-pittman/index.html](https://www.cnn.com/2021/01/11/us/new-uscp-chief-yogananda-pittman/index.html)

**Captain Vashina Butler**  
[https://www.oklahoman.com/story/news/politics/2011/06/24/oklahoma-city-promotes-first-black-female-police-captain/61154694007/](https://www.oklahoman.com/story/news/politics/2011/06/24/oklahoma-city-promotes-first-black-female-police-captain/61154694007/)

**Captain Adrienne Walker**  
[https://www.wbtv.com/2021/07/28/gastonia-police-department-promotes-first-black-captain-latino-assistant-chief/#:~:text=The%20department%20announced%20its%20first%20Latina%20Assistant%20Police,to%20sergeant%20in%202013%20and%20captain%20in%202020](https://www.wbtv.com/2021/07/28/gastonia-police-department-promotes-first-black-captain-latino-assistant-chief/#:~:text=The%20department%20announced%20its%20first%20Latina%20Assistant%20Police,to%20sergeant%20in%202013%20and%20captain%20in%202020)[.](https://www.wbtv.com/2021/07/28/gastonia-police-department-promotes-first-black-captain-latino-assistant-chief/#:~:text=The%20department%20announced%20its%20first%20Latina%20Assistant%20Police,to%20sergeant%20in%202013%20and%20captain%20in%202020.)

**Captain Estelle Young**  
[https://www.wistv.com/video/2023/01/15/awareness-columbias-first-black-female-police-captain-reflects-working-with-mlk/](https://www.wistv.com/video/2023/01/15/awareness-columbias-first-black-female-police-captain-reflects-working-with-mlk/)

**Do YOU Personally Know A Black Woman In Law Enforcement?**

**Sign,**  
**Lhisa Mrklon**

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1677629646881/2163b5b0-ed86-41ab-805b-739e7dffee6f.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1677629674817/b26cc253-3e29-44bf-823d-aa1c13ff1a8a.png align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1677629707187/22bab8d8-28e7-4297-90d4-9d3a2e34d7de.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1677629746793/bebbc99f-c669-4750-a765-b71ace603c4d.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1677629773798/e007fe41-9099-464f-83db-e6d37ca4c1dd.png align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1677629795172/aa82890b-61a7-430a-ab22-59ccab846e2e.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1677629813260/53e7d13f-fde1-4801-b176-d14d760518ca.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1677629846799/61006227-2564-4683-b096-0573010709e2.png align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1677629869567/7fac8b2d-3727-44a8-abfe-a7ec76ce392e.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1677629894113/ad5a6a8f-33ff-42c8-a49b-b592ace31ac4.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1677629918526/276a3116-3c8a-41ec-8cb0-3933049f64c5.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1677629943574/4f1dbe32-3053-491c-8730-9047571ff604.jpeg align="center")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1678725112059/59d47ac6-8337-4e6d-ad03-e30e7c6fb08a.jpeg align="center")](https://www.louisville-police.org/868/Our-Command-Staff)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1677629961213/543c5e41-b545-4eb8-9df6-2c7eee75d8f9.jpeg align="center")](https://www.nyc.gov/site/nypd/about/leadership/commissioner.page)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1678997914574/6e98ec44-5486-4b36-aa32-cfe6b9c7d166.jpeg align="center")](https://nleomf.org/memorial/programs/national-police-week-2023/)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1678724198535/e553092b-1f70-46bf-b108-58798f0721ab.jpeg align="center")](https://www.goodreads.com/book/show/20765060-kick-ass-self-defense-and-personal-protection-for-women-veteran-polic?from_search=true&from_srp=true&qid=1ds3VVTfkE&rank=4)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1680394002134/93eeb36d-a206-486f-bcf0-268cd4c1bbcb.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1680394026153/7726b410-91ea-4340-b368-3360b4d523d0.jpeg align="center")
