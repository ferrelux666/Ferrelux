---
title: "\U0001F39FMarvel’s Black Panther Movie 2018 (Review)\U0001F39E"
date: '2018-02-23T19:05:21.000Z'
slug: marvels-black-panther-movie-2018-review
tags:
  - cat
  - africa
  - globalization
  - entertainment
  - comics
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195588314/mWef9Pa3e.jpeg
canonical: 'https://ferrelux666.wordpress.com/2018/02/23/tchalla/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195538608/43zVWdgVV.jpeg align="left")](https://www.ferrelux.us/)

\*\*Pardus Niger Vitae 🗣 The Black Panther Lives

I LOVED THE MOVIE ~~~ It is true. By far the best Marvel Comics Movie Ever. The cinematography is like Star Wars/Star Trek meets any kind of African-based film. So I’ll try to tell you something without revealing TOO much if you didn’t see it yet because there are some surprises. FIRST, you must see the movie using the 3D glasses, you’ll cheapen the experience if you don’t. Oh, & I love the war cry of the Man-Ape Leader, M’Baku and his crew, The Jabari Tribe. And some territorial parts of the movie is reminiscent of the 80s cartoon Thundercats. The movie captures Blackness. There are comical moments breaking up the seriousness of the moment & everybody’s acting was impeccable.\*\*

**Two familial rivals at war with one another in any fictional story doesn’t get old when these types of conflicts are real. I was feeling the character Erik Killmonger’s argument about using the advanced African technology to usurp the rest of the White controlled World, & it would have been interesting to see it pop off, but the traditions of a humble people retaining their culture in a quiet & secret enclave of the continent, is the other side of the preservation argument. What I got from the movie is a dialog between The African & The African-American. The tragic colonizing & slavery experience of Blacks by another people & how it affects us today & what to do about it. So we have a dead king named T’Chaka & his son T’Challa takes over as The Black Panther, & without revealing much, he’s poised with being a leader one expects in his region, keeping all that Wakanda technology private, or deciding whether or not to be concerned with other Blacks about the globe living in our present condition as a globally persecuted people & claim us. There are definite historical issues here discussed in the film between characters & it’s authentic. You’re not being schooled or talked down to, it’s just straight-up conversation between rival characters motivated by different things.**

**The film shows the power of Women. In history, African women battled White colonialists on the battle field & WON. The narrative in this movie deals with an Outsider, representing ‘The Black Experience’ of the African-American, who returns to Africa with a lot of anger & vengeance in his heart. While King T’Challa, is the authentic African at peace with himself, with all his wealth & culture intact. So what you have is a rivalry. The tribal divisions that was already in the land was still peaceful compared to the racial torture one lives, & the backstory of the injustice of one brother to another. So it causes greater division amongst the Blacks in Wakanda. Well, what do you expect? In real life it would. Who do you follow? As usual, there would be the presence of a government Agent, representing The White People, let’s be real BUT see how all that affects him in the movie.**

**A lot of people like the movie & interpret it their way, while others have a problem, I leave the experience to you. And let’s not forget the power of The Black Panthers of the 1960s as they fought for the rights of our people to be self-determined & we see glimpses of the Black Power fist in the movie in honor of them. The film could have been made way back in the day (the 1990s) when the actor Wesley Snipes was hot, but he ended up doing ‘Blade’. The timing of movies can be an art itself. A piece of movie magic happens when something pops up at the right time with the right cast amidst a period when people need to see it while history unfolds a certain way where it becomes more meaningful. ~~ Lhisa  Ungelis  Mrklon**

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195540135/76shJgJaO.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195541455/Z9HlEFTyp.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195543005/7KS5kiSOt.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195544879/48f2NB8sA.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195546589/EgxF2uQM3.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195548013/xFf1AVAid.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195550878/H9m6CHSP0.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195552744/ulM8atbTb.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195554093/jJH9M7VIx.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195556022/ATMlUKJuR.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195557850/trtMBu7R8.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195559573/UOTHsk68z.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195561442/y7ksLX8l-.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195563108/hYpKF-1VV.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195564594/7tc4kwWPp.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195565873/4VcvjsPco.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195567215/1lnDHnEcP.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195569046/rFJDAO6s_.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195570400/RVQxTv8Fd.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195571990/2fltCVlLH.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195573620/vTkYO2Y8_.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195575316/mQdTFEOYv.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195576886/5zutjo4j9.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195578285/YS1e9NBx9.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195580044/y1MbpN7Q3.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195581966/p7b4Re9iF.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195583445/oiL91z5-r.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195585414/WzHkOggiY.jpeg align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195587080/VadzRGYPg.jpeg align="left")](https://ferrelux.com/adverts/)
