---
title: "\U0001F6442016 Year In Review\U0001F9D0"
date: '2017-01-03T19:16:58.000Z'
slug: 2016-year-in-review
tags:
  - new-year
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672196072912/5PEKSuU6f.jpeg
canonical: 'https://ferrelux666.wordpress.com/2017/01/03/2016-review/'
---
![2016-colors](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196067977/ZYKNdcxSY.jpeg align="left")

**Hey Folks.**  
**So Much Happened This Past Year.**  
**Let’s Take a Look Back…..**

[**https://www.dailymotion.com/search/2016%20Year%20In%20Review/videos**](https://www.dailymotion.com/search/2016%20Year%20In%20Review/videos)

\*\*~ Lhisa  
\*\*

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196069625/VtocTjsp5.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196071259/0Z0kO5oYX.jpeg align="left")

Calendar 2016 Vector Design Template. Week starts Monday
