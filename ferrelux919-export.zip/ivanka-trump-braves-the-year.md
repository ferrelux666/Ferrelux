---
title: ⚾ Ivanka Trump Braves The Year ⚖️
date: '2023-12-14T19:01:24.244Z'
slug: ivanka-trump-braves-the-year
tags:
  - '161'
  - michael-boulos
  - tiffany-trump
  - jews
  - ivanka-trump
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1704429515440/5b3daecc-21d0-4068-957e-3c996d0e410c.jpeg
---
Integer Vitae Scelerisque Purus 👱‍♀️ Blameless In Life And Free From Crime (Horace)

[Richard Wagner 🌸 Treulich Gefuhrt (Bridal Chorus)  
From The 1850 Opera Lohengrin](https://www.dailymotion.com/video/x74c83)  
Ofcourse the above track would more fit Tiffany Trump's article at the time, but I was inspired to use the Miss America track. And both selection of music applies to them.  
🌺 [My Article On Tiffany Trump, Dec 24 2022](https://ferrelux.com/mrs-tiffany-trump)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704422136459/20c2fc37-1687-49a2-9173-f412ef1d0cb0.jpeg align="center")

*It’s the 7<sup>th</sup> Day of Chanukah, as it began Dec 7<sup>th</sup> and today is December 14 2023. You should know that I time things a certain way as you follow my content with what I decide to do, why and when I publish something, and how long I let it run for. There was a date error saying Dec 13<sup>th</sup> due to the time zone difference which I corrected.*

So we’re having another **Trump Christmas** this year. Last year I featured Tiffany Trump as she hit another milestone in her life getting married to Michael Boulos. And this time I’ll feature her big sister Ivanka Trump as she endured some things this year amidst her father’s legal problems.

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704428849298/065a5cd1-b825-4a8d-a59f-3ce339fffbbc.jpeg align="center")

***So here's the 4th & last installment of my*** [Trump's Case & Ghetto Politics](https://ferrelux.com/trumps-case-and-ghetto-politics) ***article translation, this time in Slovenian, honoring Melania Trump. The previous ones aside from English, were in Scottish Gaelic & Czech commemorating his Mom & Ivana Trump as they would be supportive of him. The idea behind it was to do a feel-good sitcom-like video that shows how a fun-loving sophisticated family handles these types of attacks braving it with strength & grace. The Trump Winery Ads obviously are there for public consumption. I'm well aware that Donald Trump abstains from Alcohol from having followed his life.***

[**https://odysee.com/@Ferrelux666:f/Trump's-Case-And-Ghetto-Politics-In-Slovenian:c**](https://odysee.com/@Ferrelux666:f/Trump's-Case-And-Ghetto-Politics-In-Slovenian:c)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704423020411/c4c7c7a0-daa3-4daa-b19c-3f111bee4560.png align="center")

So now it’s Tuesday, **December 19, 2023** and the furor over her 77 year old Rock Star father continues, but let’s talk about Ivanka. Now, remember back when she had her business and was seeking approval to register her Trademark and though American and having rose further in life to be in The White House serving her Country, The People behind-the-scenes who really run the nation, denied her right and ***back then*** I was thinking to myself, *‘Ivanka Darling, you don’t need it. Here you are trying to do the professional thing, and your nation is making a circus of you and your Dad and it would make better sense they respected you and grant that.’* She navigated around the problem because the mindset Overseas is different. You have a Brand. They know who you are. So there is no reason to be treating you like that. And they also want to do business with you. And her luxury fashion line was nice too. So anyway, she’s married and a mom also, and is spending more of her time being there for her family. Take note of her manner in handling her problems and concerns as issues plague The Trump Empire. Last year, she was still able to attend her younger Sister’s wedding and we’re seeing her making the rounds across town attending this social event or the other.

And now it’s Friday **December 22, 2023** Christmas is right around the corner. A new movie ***Aqua Man And The Lost Kingdom*** got released today. Remember Trump is one of the main characters in a little **Marvel**ous 70+ page story I wrote back in October 2021 in a cute way concerning Trump’s 2018 Adversary. And obviously his family figures in it. I try to portray things cleverly, and point out certain things where applicable throughout my work. Take for instance this young lady, she learned grace under pressure from her Mom & Dad. All that stuff her and her family are currently dealing with would crack some people. She’s dealing with the hateful democratic politics against her family along with her other siblings. And look at the way she’s handling it. I can relate. It’s stressful and somehow having a way of managing it where it does not compromise your mental and emotional well-being is admirable. The ill-mannered work of some of these bigoted Democrats are steeped in the idea that they are doing some good, when in fact it’s leading to more problems. Trying to remove an American Icon who became President from his own legacy is CRAZY and it happening in his birth State further showing The World how disrespectful and corrupt America really is and STUPID. His Heirs are seeing a Dad that was raised in a time with old-school principles that still matter to some and we are seeing him making thoughtful and educated moves contending against his Political Haters. We can see forms of these chess moves play out the same in all his children as they compliment their Father on **The World Stage** showing US a tidy way of managing the uncouth manner of politics in our millennial time.

*And as I close out this article, remember that* ***Ivanka Trump*** *is happily married to Businessman* ***Jared Kushner***, and converted to Judaism, and has made the rounds practicing that religion. In these trying times with the attack on Israel and them currently dealing with that, remember this Christmas Holy Day, that we should all strive for Peace and a better World where the finer qualities in Mankind prevail against Our Fallen State where a Jew known as Jesus Christ, The Messiah is said to have offered his life in a pact to The Almighty for the full redemption of Humankind which sprung from the Two beings he created named Adam & Eve, that whosoever believes in him, comes to The Father through Him into Salvation.\*

**~ Lhisa Mrklon**

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1703276190538/95c08044-d7db-450e-870f-6821d0ca0c02.jpeg align="center")

**🎁 HAVE A MERRY CHRISTMAS AND A WONDERFUL NEW YEAR 🎈**

**LINKS:**   
[https://www.yahoo.com/entertainment/tiffany-trump-second-christmas-outing-170500008.html  
](https://www.yahoo.com/entertainment/tiffany-trump-second-christmas-outing-170500008.html)  
[https://www.yahoo.com/news/why-melania-trump-missing-family-221050705.html](https://www.yahoo.com/entertainment/tiffany-trump-second-christmas-outing-170500008.html)

[https://www.vanityfair.com/style/2023/08/ivanka-trump-says-lets-go-mets](https://www.yahoo.com/entertainment/tiffany-trump-second-christmas-outing-170500008.html)

[https://okmagazine.com/p/ivanka-trump-jared-kushner-kids-mets-game-photos/](https://www.yahoo.com/entertainment/tiffany-trump-second-christmas-outing-170500008.html)

[https://theblast.com/522500/is-ivanka-trump-hoping-to-make-her-debut-in-the-world-of-sports/](https://www.yahoo.com/entertainment/tiffany-trump-second-christmas-outing-170500008.html)

[https://www.theguardian.com/us-news/2023/nov/08/ivanka-trump-poise-family-trial-testimony-playbook](https://www.yahoo.com/entertainment/tiffany-trump-second-christmas-outing-170500008.html)

[https://www.cnn.com/politics/live-news/trump-civil-fraud-trial-11-08-23/index.html](https://www.yahoo.com/entertainment/tiffany-trump-second-christmas-outing-170500008.html)

[https://www.newyorker.com/news/our-columnists/ivanka-trumps-shockingly-smooth-case-of-selective-amnesia](https://www.yahoo.com/entertainment/tiffany-trump-second-christmas-outing-170500008.html)

[https://www.usnews.com/news/us/articles/2023-06-27/new-york-fraud-case-against-donald-trump-is-narrowed-ivanka-trump-dismissed-as-defendant](https://www.yahoo.com/entertainment/tiffany-trump-second-christmas-outing-170500008.html)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1703831774502/296eeac6-ed5a-4b87-b977-7e8c3a329a0d.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704083208790/393b409f-e693-4553-b142-fce5d57ac424.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704083619990/f0aed997-ccc2-40f5-b0bb-e267abeb1a3d.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704083678987/6f30e231-c94c-4b2f-81ae-2ef1befd1485.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704083643570/872bb268-a654-4202-a7dc-adc81bd361ec.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704083890487/b5b9a5fd-482d-481b-b46d-de7b96117605.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704083997427/fda2b353-3a27-4cd6-a533-ed0dd1735bf3.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704084153525/4adeb77f-d6e3-4027-be28-b83c699fa41b.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704084490845/6d6a528e-07e4-482d-bfa0-4829ede73e17.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704084512405/09de79c7-5d35-4853-82e3-22bfc59fb6c0.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704084729224/3be6a6ff-d0af-4cb3-a4ca-b698fcf03343.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704420957684/2000c07e-dfb7-49c6-8d44-b10f6fbac3f2.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704421205552/2c229f00-ff3e-4d28-9a5e-37f81567f273.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704421258697/ffe6b851-4fc7-4a92-ade9-f76695b2b36f.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704421491221/d8520a00-b9eb-4f52-bd91-48b3627423d4.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704421667638/089d810a-79ff-4c2c-903d-0a851fe2ee2b.avif align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704421833030/8dcf990b-833c-4e91-9bb6-088985400e43.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704421927356/d0941241-d246-437d-9d21-c6bf5968b934.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704422348425/f922b9e2-47d7-48cc-b830-e875e51ae18a.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704422469080/4801dc8c-459c-4842-b868-2874c4b7f03d.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704422629528/1df69b3b-e502-4c60-a5db-d7febe43b9e9.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704423116179/3b8c38a0-9771-48b0-b83f-3dfcbb6ccc2f.avif align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704423355747/f94beed1-2e3d-40ca-81f6-047c82d9960c.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704423630640/d915dd37-5c4c-4055-8c72-f0e9345606f1.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704423889728/3cc248cb-03fc-48dd-b8a7-33b6f0a32859.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704423932184/dc5ca0a5-a4db-45f8-9dd8-7b7cdee50d16.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704423967042/2ef83fe0-39a9-42de-a4b6-23d23a70e0e9.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704424284764/1b29b2f9-42f5-47eb-b84b-59923aee5b0b.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704424305230/d6eae6c1-ee65-4bad-9527-722ce6f0152b.png align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704424324233/4f21997a-d24f-4504-9283-eee080431efd.png align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704427054674/69c882f1-349f-4914-be85-98a3f85fcc18.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704424593505/90e61599-501e-4693-a4e3-bc156a772e26.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704427495814/4e0dd668-178b-4162-a82f-9dd28e3cac56.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704429477790/2740372f-1c3e-41de-9560-36e5f94ced2e.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704424867834/60175700-6e9a-444f-9c7f-17872cc4d469.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704424895604/bb994808-3aa2-4fd7-9c53-db21d0aaa184.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704425817806/a174bd17-23b4-4705-b93b-560236b4ac45.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704425880318/5e3a16bf-dfad-4c13-8a85-5cca41a04797.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704426698019/cd57ab44-d993-48b8-b522-1952915b6178.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704425898153/321aa82a-ddea-49ec-8abc-63db8ba77d0c.webp align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704428458024/de8fb3d0-3f18-4b8b-90c3-2238c8def17d.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704425943807/e290281b-4032-4b31-a8b3-05a371014e67.jpeg align="center")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704426953462/6d374256-e4ff-4036-8b55-c35aa8a19f50.jpeg align="center")](https://www.barnesandnoble.com/w/women-who-work-ivanka-trump/1123884764?ean=9780735211322)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1704426994178/8ff51aa1-7ca2-4c11-97da-274597c9d713.jpeg align="center")](https://www.newyorker.com)
