---
title: "\U0001F320Weekly Blogcast\U0001F318"
date: '2016-11-10T08:45:00.000Z'
slug: weekly-blogcast
tags:
  - blog
  - updates
  - forum
  - platform
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672196086212/FFBs-SbNr.jpeg
canonical: 'https://ferrelux666.wordpress.com/2016/11/10/updates/'
---
![blog type](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196079870/9zpXATwYW.jpeg align="left")

![Weeklyupdate](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196081492/IL8VyR9vt.jpeg align="left")

Hey folks, we transitioned the site from it’s old look on the ucoz platform to wordpress for a different look & feel for the new year. Alot of the old site features are still here though. Our old ucoz platform ([http://www.lhisa.ucoz.com/](http://www.lhisa.ucoz.com/)) hasn’t disappeared completely though, something else will be done with it for the future. While we’re here on wordpress, some of the old links have been moved around and are under different categories now.Thanks for visiting. Surf the menu to enjoy our featured sites while we’re still building. You’ll find music, products, & other lifestyle options. – Lhisa

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196082624/c5Zpcc7Xl.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196083882/KAqOpT4FU.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196084816/d-QB2PUOs.jpeg align="left")
