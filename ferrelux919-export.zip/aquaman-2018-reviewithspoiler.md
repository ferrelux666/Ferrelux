---
title: "\U0001F41F Aquaman 2018 (Review/Spoiler) \U0001F433"
date: '2019-01-25T20:03:33.000Z'
slug: aquaman-2018-reviewithspoiler
tags:
  - entertainment
  - atlantis
  - mythology
  - mermaid
  - myths
  - december
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195252327/FR_o9tPv5n.png
canonical: 'https://ferrelux666.wordpress.com/2019/01/25/aquaman2018/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195221013/b6tTo8QhQ.jpeg align="left")](https://www.rottentomatoes.com/m/aquaman_2018)

  
Ego Aquam Hominen 💧 I’m Aqua Man  
[Aqua Man Soundtrack, Black Manta Theme By Rupert Gregson-Williams](https://www.youtube.com/watch?v=RNjKGFTap-A)

Symbolically released in the I Winter Solstice 12/21/2018, I could not help looking at the Movie Aquaman, without thinking about the Marvel Comics character, The Sub-Mariner (Namor Mckenzie), known by his catch phrase, ‘Imperius Rex’ Latin for Powerful King/Imperial Ruler. He was FIRST in the comic universe in 1938 & Aquaman came about in 1941, with a very similar storyline to Sub-Mariner’s. I like them both, as in a way, they are suppose to be the same guy, BUT if I had to choose one universe, I’d go with Namor, not Arthur. Contrary to the disrespect from comedian & TV night show host, Jimmy Kimmel, using his platform to insult Sub-Mariner, Namor is indeed MORE significant, technically being more powerful than Aquaman, had he bothered to do the research. Kimmel’s only right about one thing, Sub-Mariner apparently have been forgotten about for Marvel films.

Now the Movie, first of all, Jason Mamoa was believable in the part. Long before his casting for something like this, I always thought he would be a good pick back in the day for TV movies or shows like ‘Hercules’, & ‘Xena’, playing somebody significant & now looky here…….The only thing wrong at times were the corny one-liners in the script. I always liked Aquaman and am glad somebody thought enough of him too to give the guy a complete movie. Aside from Superman, Batman, & Wonder Woman, he was one of a few DC heroes I found intriguing & mighty growing up viewing ‘The Super Friends’ animation series in all its variations, just like the Marvel Comics. Now, DC Comics was FIRST, but Stan Lee’s Marvel Universe took over the medium so people followed after them. They have way more going on, BUT, I’m proud of DC Comics for hanging in there over the decades with all the Superman & Batman stuff in film & on TV, with the recent millennial Wonder Woman film & now this latest, Aquaman. The Aquarian make-up/costumes for all the characters were done well. And the charming storyline was like being led into a nice child-like lullaby as we watch Arthur also experiencing it as he grows up later realizing it all to be true & his destiny is well within grasp.

Now,….I like villains too. Let’s get that started. I loved the way Black Manta looked in the film, the mystery & power of his presence. I liked him ALOT in the cartoons too & felt that this time around in the film’s debut, he should have been a bit more successful against Aquaman if he’s supposed to be his arch-nemesis. You can’t just prevail slapping him around like that. There are many times in the DC World, Black Manta outsmarts The Semi-Atlantean, getting him in a bind & someone from The Super Powers Team has to rescue him. So I hope if there are sequels to the film, we see that.

And now…… the pure-bred Atlantean heir to the throne, our villain, Ocean Master, ….. what can I say. He had a point. You should want to keep things correct. You just knew how things were going to go with the good wins over evil stuff. That guy was doing the right thing as he was entitled to, but as always, some one, or force works against it. I don’t think he was really a bad guy, and in all reality, given his rights & power should have won & had everyone supporting him, BUT as fate would have it, a half-breed dwelling on The Surface, must be The King & he is quietly being helped by Vulko, who’s character was played superbly well by Veteran actor Willem Dafoe . Yes, so Ocean Master beats Aquaman the first time in the challenge as expected, but Aquaman’s comeback in the end was impressive. And you could see it was his destiny to be The Ruler with the Mighty Trident and all.

My only fault with the film was not enough colored Atlanteans in the sea, as that historically & culturally would have made more sense since they’re messing with mythology too. I’d Iike to see in the future some reference to The God Poseidon/Neptune. I mean, really. The movie for me, touched a piece of the pagan past that some of us are so familiar with that it’s not just a film, but a harbinger for what to expect.

: L H I S A :

SOME LINKS  
[https://en.wikipedia.org/wiki/Namor](https://en.wikipedia.org/wiki/Namor)

[https://www.dccomics.com/characters/aquaman](https://www.dccomics.com/characters/aquaman)

[https://www.sliceofscifi.com/2013/10/22/aquaman-vs-namor/](https://www.sliceofscifi.com/2013/10/22/aquaman-vs-namor/)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195222828/Y_6on8pql.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195226001/Wi-Me1GR4.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195228670/oNQyYaI4q.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195231171/LaosMJquO.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195234491/jUWjvgzBr.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195237246/WINa2jdjF.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195240017/b9Ra6k_vJ.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195241907/47-wUcNfd.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195243818/A5TeAb2VB.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195246788/NSkAOEQHa.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195249000/HtVRCdZ8g.png align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195250389/sY1zHtRtr.jpeg align="left")](https://ferrelux.com/adverts/)
