---
title: "\U0001F945 P E L E ⚽"
date: '2023-02-01T21:12:35.000Z'
slug: p-e-l-e
tags:
  - news
  - practice
  - games
  - inspiration
  - tv
  - health
  - new-year
  - strategy
  - sports
  - field
  - goal
  - entertainment
  - brazil
  - portuguese
  - soccer
  - football
  - topics
  - '2022'
  - '2023'
  - funeral
  - tournament
  - death
  - december
  - pele
  - flag
  - sportsman
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1675292257815/41dfe428-02bf-48ce-90ed-5e6417406e41.jpeg
canonical: 'https://f3rr3lux.wordpress.com/2023/02/01/pele/'
---
[![Pele_his name](https://cdn.hashnode.com/res/hashnode/image/upload/v1675292234713/121be26d-ad5d-4602-8a30-a0041e7fa390.jpeg align="left")](https://rumble.com/v23101g-soccer-star-pele-dies-at-82.html)

<iframe width="100%" height="100" src="https://w.soundcloud.com/player/?url=https%3A%2F%2Fapi.soundcloud.com%2Ftracks%2F611720487&auto_play=false&hide_related=false&visual=true&show_comments=true&show_user=true&show_reposts=false&color=ff5500"></iframe>

[Listen Closely](https://soundcloud.com/listencloselycollective) · [PREMIERE: C. Da Afro – Brazilian Groove \[Samosa Records\]](https://soundcloud.com/listencloselycollective/c-da-afro-brazilian-groove)

***Quo Difficilior Victoria, Eo Maior Felicitas In Vinciam 🏉 The More Difficult The Victory, The Greater The Happiness In Winning (Pele)***

**So entering this year’s Black History Month, I can’t let it pass without mentioning this great Athlete. I’m still mourning his death. When I heard he was in the hospital and following the updates, I was really hoping he got better, but braced for the inevitable. Pele, who was born October 23rd 1940,  passed away December 29th 2022, 18 days shy of the century, at age 82 from health complications. And The Brazilian Soccer Star will be remembered the world over. At about age 17 he won The World Cup, and continued doing so again and again with his masterful aerodynamics and precise kicks on the ball, scoring a goal each time. I grew up over the years hearing about and seeing Pele play, the ads, memorabilia and so forth. The guys I knew who were ball-players particularly held him in high esteem. It also gave me a sense of Pride in my race knowing that one of Ours had such an impressive sports record at that time in the world and still, to this day.**

**Pele’s Famous Quotes**  
[https://www.azquotes.com/author/11478-Pele](https://www.azquotes.com/author/11478-Pele)

[https://www.brainyquote.com/authors/pele-quotes](https://www.brainyquote.com/authors/pele-quotes)

**Pele News Videos & Clips**  
[https://odysee.com/@RT:fd/pele-farewell:4](https://odysee.com/@RT:fd/pele-farewell:4)   
[https://odysee.com/@RT:fd/PELE-yt:2](https://odysee.com/@RT:fd/PELE-yt:2)

[https://www.dailymotion.com/video/x8fz5nc](https://www.dailymotion.com/video/x8fz5nc)  
[https://www.dailymotion.com/video/x8gwjoe](https://www.dailymotion.com/video/x8gwjoe)

**Articles**  
[https://www.rt.com/search?q=Pele](https://www.rt.com/search?q=Pele)

[https://www.biography.com/athletes/pele](https://www.biography.com/athletes/pele)   
[https://www.britannica.com/biography/Pele-Brazilian-athlete](https://www.britannica.com/biography/Pele-Brazilian-athlete)

**PELE FOREVER WITH THE LOVE OF THE PEOPLE HAPPY VALENTINE’S DAY**

[![Soccer Heart](https://cdn.hashnode.com/res/hashnode/image/upload/v1675292236389/06b91199-1e55-4dc1-88c2-35cdd6aad2c6.jpeg align="left")](https://www.cnn.com/2023/01/03/football/pele-wake-tuesday-santos-lula-spt-intl/index.html)

---

---

And What Is YOUR Memory Of Pele?

**Sign,**

**Lhisa Mrklon**

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1675292238054/fedf3bf5-7444-48b5-ad59-1a82b2f37003.jpeg align="left")](https://lightinthebox.tv2h87.net/c/3170166/940974/8199?prodsku=6236066&u=https%3A%2F%2Fwww.lightinthebox.com%2Fspeed-cube-set-magic-cube-iq-cube-qiheng-157-megaminx-magic-cube-puzzle-cubeadults-toy-unisex-gift_p6236066.html&intsrc=PUI2_7362)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1675292239358/cbebb155-3adb-40d2-b484-91f6c743d9e1.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1675292240484/293d86ca-b2f8-40bf-9a72-02647112638a.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1675292241817/b4dcfbd3-9886-48a6-a74d-d64ff70f3acc.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1675292243338/862187b6-04a2-4435-9d31-5792fb306a1f.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1675292244854/7d2a7aa4-ecd8-4a4f-a842-11ff8e34ce8b.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1675292246465/47df86ee-7d32-4cff-9097-2aa22dd8f9ab.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1675292247705/82178389-aea1-44de-b8fe-5a6da678e841.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1675292249513/a0e95227-4578-4de8-8387-cde7414633c9.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1675292250951/2f86e8ff-faaf-4ad3-912e-ad479289f0e7.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1675292252617/132c4d63-8cd6-47fa-9bd2-91915346c956.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1675292254153/0b8e36f3-d423-41b2-ae7e-44b78cc87143.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1675292255396/4a3429a0-4478-4c04-aed9-5b315f07914a.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1675292256781/20508b17-5236-45c3-a82b-81b2eb81df0a.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1677691869001/b9d1c739-9068-4d09-8af1-7d92f2dabf98.jpeg align="center")

Like this:

Like Loading...

### *RELATED*
