---
title: "Tupac Gets Justice Decades After His Death \U0001F409⚖️"
date: '2026-10-02T03:30:23.466Z'
slug: tupac-gets-justice-decades-after-his-death
tags:
  - 2pac
  - p-diddy
coverImage: >-
  https://cdn.hashnode.com/uploads/covers/6269a04eaedfbdb0ce1a65f6/07fce789-9f56-466f-a366-49848c5da7f2.jpg
---
Phrase coming soon . . . . .

%[https://youtu.be/h9XGfCppYyk?is=ut7OlbjhYeCfsLUN]

Today is Thursday October 1st 2026. Now, you all already watched and heard that Court Case weeks ago against Keefe D and how a Jury finally convicted him for the death of Rapper Tupac Shakur, but is there more to it in light of the whole scheme in general all those years ago concerning other skin in the game like Suge Knight, Sean Puff Daddy Combs & Snoop Doggy Dogg.

[![](https://cdn.hashnode.com/uploads/covers/6269a04eaedfbdb0ce1a65f6/965c2e3e-026b-4491-bfd1-ba8316305c32.jpg align="center")](https://indianyouth.org/indigenous-peoples-day/)

Today is Monday October 12th 2026, the so-called 82nd annual Columbus Day with so many misguided Italians Celebrating. Too bad many of them don't know their own history on that, where Italy was not crazy about Christopher Columbus and did not care to fund his voyage why he went to Spain for material support. The person to praise is Amerigo Vespucci who not only the Country is named after but he was classier and more educated than Columbus to come here, see the Indigenous People on their land, respect it and leave it alone. I appreciate NYC Mayor Mamdani making powerful a statement by not attending the event. Tupac Amaru Shakur also known as Makaveli, would have appreciated this also.

Today is Sunday October 25th 2026.

Today is Tuesday October 27th 2026.

More on Tupac Coming Soon.

Here are some speculative video perspectives on the life & death of Tupac Amaru Shakur (Makaveli)

%[https://youtu.be/tccQ_ccCD_4?is=IXqsbXG5BLVfNwXy]

%[https://youtu.be/5q3qDFH9QIA?is=zGdzDiHmHbOL0G1o]

%[https://youtu.be/-yWmJqVCQXU?is=l25Bzf6V1PB9umxe]

%[https://youtu.be/YGBMv55IYSo?is=hMxcKqahFf9V70cj]

%[https://youtu.be/xli7q0udNVc?is=o6hrzI4gJHIZMu-4]

%[https://youtu.be/NQDii_PDBtQ?is=4GzWoCAnFNcnV8aj]

%[https://youtu.be/i9nO0FozbLU?is=80blT7VGGp0QVjxO]

%[https://youtu.be/BzW3Lb6eNUg?is=YlC3OIO11UnAtaJ2]

%[https://youtu.be/n_sJAN4dbf8?is=HI_7QgB9lE3pfovm]

%[https://youtu.be/-xkJI2IwfSE?is=asA9qVPSF6JqINKJ]

%[https://youtu.be/s_M9z4AIh1M?is=_hXI8zTCLiYgQLxx]

%[https://youtu.be/-uLzV4busTY?is=daYynWskOJSlkZlP]

%[https://youtu.be/qx4MCq9i67E?is=U2YO1KkhJ_Id2h1s]

%[https://youtu.be/_bTXDbkzAbc?is=nmqTq7wBXklCBoeU]

Sign,

Lhisa Mrklon

#203
