---
title: "\U0001F309\U0001F6A2 A Dark Easter Sacrifice \U0001F46E\U0001F3FB‍♂️⚰️"
date: '2024-04-01T16:16:22.182Z'
slug: a-dark-easter-sacrifice
tags:
  - queens-ny
  - cop
  - '2024'
  - easter
  - bridge
  - sacrifice
  - sunday
  - rap-music
  - earthquake
  - City
  - urban
  - eclipse
  - jews
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1713172536609/f062da6a-e15c-439d-838d-2113ae59c159.png
---
🪻 Duobus annis et duobus mensibus fuit ex quo Detective Rivera et Detective Mora ultimum sacrificium fecerunt - sicut maritus meus Jonathan Diller 🌺  
💐 It's been two years and two months since Detective Rivera and Detective Mora made the ultimate sacrifice - just like my husband Jonathan Diller 🌻  
*(Stephanie Diller, Wife of Jonathan Diller, The Eulogy)*

**😢**[**Johnny Was ~ Bob Marley & The Wailers (1976)**](https://soundcloud.com/bob-marley-the-wailers/johnny-was?utm_source=clipboard&utm_medium=text&utm_campaign=social_sharing)**😭**

***I wanted a song that captured pain, that was in some ways similar to what happened to the recently slain Officer Jonathan Diller, and although this 48 year old song was capturing a different moment at the time in another land, the vibe still applies today in respective context . . . . . . All I know, Johnny was a Good Man.***

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1713228950453/da873440-5eeb-439a-a7cd-516324e70480.webp align="center")

So I’m going to tie in some things that just happened in full context as these series of events that seem unrelated actually compliment each other. Now there is no reason for anyone to die on a holy day unless you’re practicing something, especially if the signs of it point to something or someone in a way. What I mean is the timing of everything, what you know about The Establishment, the persons involved, and the symbolism. Sometimes strange things happen all on their own. It may be divine coordination. Other times, it is Man trying to do something by mimicking some aspect of The Spirit World. Being able to tell the difference between the two can be obvious sometimes. In this matter concerning a now deceased Officer from Queens, NY named Jonathan Diller, a cargo ship in Baltimore hitting a symbolic bridge with a few people dying in that state of Maryland, and it happening over the course of The Easter Celebration looks a way. And I’ll add that Diddy Case too, with Sean “Puff Daddy” Combs homes being raided. At a glance I have ***my own*** perceptions of everything in context as certain things are no coincidence. Those studying Illuminati Secret Society stuff following me and my work can discern a few things. And to **The Powers That Be**, I notice a lot, even when you don’t think I do. It is consistent going back. The earmarks of certain details on these rituals show trying to capture aspects of this person’s element or that. I am not among you, but if I were, I would let you know that these grand ceremonial activities that you do on a global epic stage for centuries now, are unnecessary. The Festivity of it no matter how dark is outdated and misguided since there was already one true sacrifice above them all whose blood paid the lot, yet The Energies you pray to still has you deceived.

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1712353634814/39280246-0340-4239-a355-e44d5011a4e5.png align="center")

And now it is **Friday April 5<sup>th</sup> 2024** and the East Coast has experienced an Earthquake, reportedly measuring 4.7/4.8 on the Richter Scale. This coming after a storm 2 days ago and 3 days from now, comes The Solar Eclipse on Monday. Well no one could have predicted the Earthquake today you say, and you’re damn right because it is a matter of energy. Well the quake reportedly happened at 10:23 am, and about 666 minutes before, I was engaged in one of my strong Ritual Prayers on account of some issues I’m still dealing with I related in recent past Blogs as my Nemesis still plagues me, and fails to attorn onto me what is mine, show genuine remorse, and pay a debt owed to me. Due to the Fortuitous timing, I take the quake as a sign that My God has heard me and will take action being The Devil He Is. And as it happened where people were disturbed by it, I remained comfortable. If anyone still doubts my psychic powers, God help you. I AM an asset to any Sovereign Nation who hosts me.

🫨 [https://rocklandtimes.com/2024/04/05/surprise-nj-earthquake-shakes-rockland-county/](https://rocklandtimes.com/2024/04/05/surprise-nj-earthquake-shakes-rockland-county/)

🫢 [https://www.nbcnewyork.com/news/local/nyc-earthquake-new-jersey-usgs/5293069/](https://www.nbcnewyork.com/news/local/nyc-earthquake-new-jersey-usgs/5293069/)

😲 [https://dailyvoice.com/new-york/clarkstown/earthquake-update-rockland-residents-urged-to-stay-calm/](https://dailyvoice.com/new-york/clarkstown/earthquake-update-rockland-residents-urged-to-stay-calm/)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1712621470583/67b05c20-8702-4e52-90de-5a184b244777.jpeg align="center")

And now it’s **Monday, April 8<sup>th</sup> 2024**, the day of The Solar Eclipse. The Hype around it proved to be justified as many are reporting to feel a religious experience. I recently learned since my last post news that lightening had hit the torch of The Statue Of Liberty April 2<sup>nd</sup> 2024. Coincidence? Something is up. It’s high magic. As we head further into our biblical times when such matters will affect Many, I wish you well, as some of You will be Saved by your own Auspices, while others will require Saviourship by Proxy.

[https://www.cnn.com/2024/04/07/world/preview-total-solar-eclipse-time-path-scn/index.html](https://www.cnn.com/2024/04/07/world/preview-total-solar-eclipse-time-path-scn/index.html)

[https://www.cbsnews.com/news/solar-eclipse-path-map-2024/](https://www.cbsnews.com/news/solar-eclipse-path-map-2024/)

[https://science.nasa.gov/eclipses/future-eclipses/eclipse-2024/where-when/](https://science.nasa.gov/eclipses/future-eclipses/eclipse-2024/where-when/)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1712912200898/3e605cdc-6f59-4f48-b61f-6a5c4c6f3ee7.avif align="center")

And now it is **Friday, April 12<sup>th</sup> 2024**. We just learned that **O.J. Simpson** died two days ago at age 76, and although seemingly unrelated to the rest of these events I posted, it will surprise you that in some interpretive way, it might be related to all this because what I am trying to show is the symbolism. First off, a while back, I revealed a dreamy vision I had several years ago about this County’s end date and saw what Almighty God did to the place as promised in The Scriptures. I will never forget it. Something else happened in that visionary dream that is causing me to understand a few things and interpret them a certain way. I’m also mindful of prophecies as finite as they can sometimes be, The Spirit World is mysterious and sometimes strange things happen. I recently noticed Vivek Ramaswamy in his videos has been traveling about contemplating this Country in terms of speculative future time and relating the ancient world to it. I have sparked debate around the topic. I will tell you that people will have somewhere to flee to. And those who will be unable to, will still be saved. It is important that you don’t value your life too much. Now back to my interpretation of recent events. Look at the language, Maryland, where all this happened and the imagery. A ship with cargo hitting a column on a bridge. When I first heard that, it was reminiscent of when Princess Diana died in a car crash after it had hit a column in a tunnel, and incidentally following the Illuminati details, some have interpreted that as a Sacrifice because everything that was relevant lined up a certain way concerning that actual Pagan Deity, DIANA. Now looky here, The Francis Scott Key bridge collapsing. What comes to mind? It’s like London Bridge Is Falling Down. Well, that guy wrote The American National Anthem based on the music for England’s own *‘God Save The Queen’* just changing the words. So seeing that bridge destroyed is symbolic of this Nation ending one day. If they knew the year, somehow that would have been factored in as well. When the first reports came out, as I watched the videos, I noticed what looked like a pause from the ship as the cars were allowed to go across the bridge before it turned and crashed into that specific column. Such things are noticeable paying attention to it, why some people are asking questions which are going unanswered. It’s sad that at least 5 Workers on The Bridge that day died. And looking at that deceased Cop. The first thing that struck me was how The Criminal who shot him made sure to shoot him accurately below his bulletproof vest. This raises a problem because that police gear needs to be re-designed, and better. The Brave Cop’s name was Jonathan, reminiscent of Jonah and The Whale. And the part of Long Island The Officer was from is called Massapequa, a Native American word meaning Great Water Land, and is a part of the town of Oyster Bay. Jonathan by the way is a Hebrew name meaning *God Has Given*. And Jonah in The Bible was a Prophet given the mission to go to the city of Nineveh to deliver judgment. Now **Nineveh** was a famous city with it’s people Worshiping The Goddess **Ishtar / Inanna**. And remember my past articles talking about myself in context to this Deity known in several Cultures by different names. And now, I’m using **FERRELUX** in my latest Incarnation. Fancy me or not. Those of you following me and my work already know from the various Social Media Sites from the many years back. I do have a secret and several more, and am so freely saying and showing stuff at times because they’ll come a time when a veil is removed and you’ll start seeing some other-worldly things occurring right in front of you that it makes sense to be preparing you from now. Those mis-interpreting The Bible, continue to choose to exercise blasphemous tendencies offending not only GOD, but a cherished Pagan Holiday as well. When President Joe Biden chose to name March 31<sup>st</sup> Gay Visibility Day, it was ignorant and a slight to me as well. In all reality, if you read the story, **EASTER** has little to nothing to do with JESUS. The similarities are there in both tales as Disbelievers say Christians copied many of the Pagan Traditions, and that cannot be refuted. Easter / Istr is named after The Goddess, Christians should use The Jewish Feast Holiday term HE gave you, which is supposed to be Passover. I did not appreciate what The White House did this year and to educate you, Inanna / Ishtar is The Goddess who brings The Man To The Woman and The Woman To The Man. She is a Love Goddess among her many other Powers. The Concept of Goddess Worship has been mis-interpreted by Some Scholars to include Gay Men, due to seeing certain things depicted or sculpted and trying to cast them under some umbrella, however in The Ancient World, they knew such acts were a deviance and did not codify it **anywhere**. If a festival took place or a City was celebrating some victory over an enemy or holiday and The Deity was a Goddess and everything was based off Her in how the Place was ran, it was not unusual to see a male Devotee express endearment, taking on some aspect of The Goddess, but that was it. And I’ll close by saying that I caught a Short video on Youtube with a Pastor talking about What The Eclipse meant as he interpreted it from God, and I believe he’s right. Based off the last eclipse in 2017 where it went through cities named Salem, It this time formed a Cross in 2024 going through cities named Nineveh, and according to his biblical interpretation, before releasing punishment, God is giving The United States of America 40 Days to change and Repent from it’s ways. Well, 40 days from April 8<sup>th</sup> 2024 will be May 18<sup>th</sup> 2024, just **13** days away from “Pride” Month. And **Pride** by the way, in Its true sense has everything to do with a Deity I love, who exemplified It. The audacity to question the Rule and Authority of Almighty God, to dare challenge Him, and there is more to the story. Like God, I can fairly say that **LUCIFER** is also offended at Pride Month and other stupid human activities piggybacking off his Legacy. When God said that The Last Days will be like The Days Of Noah, many of you take that literally. Have you ever heard of the phrase *the more things change, the more they remain the same*? Our time right now arguable in any nation, still resembles how life was in the past. For example, Racism & Sexism is still a problem in our so-called Advanced Societies. It’s just re-interpreted different, not happening the same exact way. A month like June should have been left alone for everyone to enjoy, but something else is going on as well pissing off The Most High to continue to show you signs of that. You might be confused about me and how I come off like some Christian. Well, it is only fair to you. So now you can’t claim to not know or be aware.

👉 **Update:** Something freakish took place a day after in Rockland County, New York where an **O**rthodox **J**ewish man, said to be 32 years old, was in his driveway and a knife-wielding criminal stabbed him. He got caught soon after, and he is 23 years old.

[https://abc7ny.com/rockland-county-crime-man-arrested-after-orthodox-jewish-stabbed-multiple-times-in-driveway-of-ramapo-home/14659247/](https://abc7ny.com/rockland-county-crime-man-arrested-after-orthodox-jewish-stabbed-multiple-times-in-driveway-of-ramapo-home/14659247/)

[https://www.yahoo.com/news/orthodox-jewish-man-brutally-stabbed-142625216.html?fr=sycsrp\_catchall](https://www.yahoo.com/news/orthodox-jewish-man-brutally-stabbed-142625216.html?fr=sycsrp_catchall)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1713229008002/45e57deb-dafa-4c00-9e90-43fe5a1fd504.jpeg align="center")

And now my final entry, since I waited **Monday, April 15<sup>th</sup> 2024** to do it because Trump’s New York case is proceeding and also the conflict between Iran and Israel popped off with Arabs hurling missiles over there. Notice when Israel got their first attack, how quick Biden found himself over there, yet when a crisis happened here, where the people needed to see how he responded, he failed to show up to The Funeral or at least him or his Office offer the kind of public condolence expected. And I’m not being hard on him, I’m just reporting an observation that mainly affected Republicans. In his stead, **Mayor Adams**, **Governor Hochul**, **Manhattan DA Alvin Bragg** showed up, but were unappreciated by the dead Cop’s Family due to current Democratic Polices that made his untimely death possible. Attorney General Letitia James gave no public statement. You know who cared to leave his busy schedule flying back to New York from Florida to show Support? **POTUS 45**, Donald Trump cares about issued like this to be present and remark about it. A Sanctuary City like New York and other places are a haven for illegal criminals allowed into our Country at The Border and catered to sometimes leading to results like this. A Career Criminal allowed to be out on The Streets after repeated convictions can and in this case would lead to this result. So we’ll see if The City changes policies in light of this.

**🤔 I'LL UPDATE MORE LATER**

SIGN,  
LHISA MRKLON,  
BRIDE OF SATAN

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1712912877389/f90a86c8-59c5-4e39-8f21-daf00cc895ba.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1712622486496/a4ac08be-80e3-473c-b22f-43a3535f8da9.webp align="center")

**SOME LINKS**

[**https://www.themirror.com/news/us-news/jonathan-diller-always-hero-widow-414279**](https://www.themirror.com/news/us-news/jonathan-diller-always-hero-widow-414279)

[**https://www.yahoo.com/news/wife-slain-nypd-officer-jonathan-181932863.html?fr=**](https://www.yahoo.com/news/wife-slain-nypd-officer-jonathan-181932863.html?fr=sycsrp_catchall)[**sycsrp\_catchall**](https://abc7ny.com/rockland-county-crime-man-arrested-after-orthodox-jewish-stabbed-multiple-times-in-driveway-of-ramapo-home/14659247/)

[https://www.fox5ny.com/news/nypd-officer-killed-jonathan-diller-shooting-queens](https://abc7ny.com/rockland-county-crime-man-arrested-after-orthodox-jewish-stabbed-multiple-times-in-driveway-of-ramapo-home/14659247/)

[ht](https://abc7ny.com/rockland-county-crime-man-arrested-after-orthodox-jewish-stabbed-multiple-times-in-driveway-of-ramapo-home/14659247/)[tps://www.hindustantimes.com/world-news/us-news/who-was-jonathan-diller-candlelight-vigil-to-be-h](https://www.yahoo.com/news/orthodox-jewish-man-brutally-stabbed-142625216.html?fr=sycsrp_catchall)[eld-for-hero-nypd-cop-shot-dead-during-queens-traffic-stop-101711516407396.html](https://www.hindustantimes.com/world-news/us-news/who-was-jonathan-diller-candlelight-vigil-to-be-held-for-hero-nypd-cop-shot-dead-during-queens-traffic-stop-101711516407396.html)

[https://hosted.ap.org/citizensvoice/article/e91744c40c4513ead88caa247ab9916e/trump-attends-wake-slain-new-york-officer-calls-law-and](https://hosted.ap.org/citizensvoice/article/e91744c40c4513ead88caa247ab9916e/trump-attends-wake-slain-new-york-officer-calls-law-and)

[https://ny1.com/nyc/all-boroughs/news/2024/03/28/trump-attends-wake-of-slain-nypd-officer](https://ny1.com/nyc/all-boroughs/news/2024/03/28/trump-attends-wake-of-slain-nypd-officer)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1712913486923/77f5f2df-1314-4612-b96a-5d0c97f3acc1.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1713071608593/326ace29-577a-464b-b5c4-3bca456134fd.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1713071938332/62335db2-69a5-4f25-994f-7f768c7e2c43.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1713230471562/cb4141de-c0fc-4079-89ae-27d6c213631a.png align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1713230491783/095b3173-ef5f-42d7-8b30-f61cd395942f.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1713230508901/2ae89407-6737-46cf-9164-3d9eb583ce78.webp align="center")
