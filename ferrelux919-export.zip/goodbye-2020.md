---
title: "Goodbye 2020 \U0001F389\U0001F384✨"
date: '2020-12-24T21:59:48.000Z'
slug: goodbye-2020
tags:
  - review
  - global
  - pandemic
  - covid-19
  - coronavirus
  - celebrity
  - death
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672193630057/Eb2K1xJXi.jpeg
canonical: 'https://ferrelux666.wordpress.com/2020/12/24/goodbye-2020/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193599510/ALwLH3ynR.png align="left")](https://www.dailymotion.com/search/2020%20year%20in%20review/videos)

[**“Live And Let Die” – Guns N’ Roses**](https://m.youtube.com/watch?v=6D9vAItORgE)

*Vive Memor Leti*  🏥  *Live Mindful Of Death*

This was a very bad year for a lot of people. Whatever constructive plans we had to unfold got fucked up bad. And it looks like it’ll carryover into the next year. I’m afraid to speculate how that’ll turn out. Anyhow, some other notable people recently died in 2020 like Jeopardy Host Alex Trebek, British Agent 007 Actor Sean Connery, Former NYC Mayor Dinkins and others. The year in review gallery blogs are what they are; tough subjects this year when it should have been lighter. Merry Christmas & Happy New Year to you all even though it’ll be lackluster this year due to the Covid restrictions. Peace.

[Celebrities Who Died In 2020](https://www.popsugar.com/celebrity/celebrities-who-died-in-2020-47084634)

Sign,  
Lhisa

### Good Riddance To The Year 2020 Holding Up Our Lives With Covid-19! Scroll Down And Leave Your Reply Below.

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193600831/fv2UL3j_x.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193602202/MuZJ8-TJe.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193603842/lC8b3kFvs.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193605444/EVshwF7-4.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193606604/J5xpBbyKr.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193607673/_on9Izwzg.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193608921/EKG24Kogv.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193610111/xgH06KWMz.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193611507/tyMWcZg7W.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193613038/nn2VCTBNm.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193614283/texyO3PRm.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193615607/2dWYoiE26.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193617234/SE30WXP4w.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193618587/QR7O3ITzk.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193619945/FM0hyw3Ph.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193621423/qJ4r9akCX.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193623303/8nsb1OIls.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193624570/P1vlGl1iD.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193625901/jssrNNh6x.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193627234/95-Uqxlo7.png align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193628771/RKOMUPYP9.png align="left")](https://ferrelux.com/adverts/)
