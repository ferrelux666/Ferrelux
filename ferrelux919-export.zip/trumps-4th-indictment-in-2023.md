---
title: "\U0001FA99 Trump’s 4th Indictment In 2023 ⚖️"
date: '2023-08-16T05:24:21.110Z'
slug: trumps-4th-indictment-in-2023
tags:
  - tish-james
  - trump
  - indictment
  - golf
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1697310962859/0e20773e-8737-429c-9140-6a3008c5038f.jpeg
---
*Fac Americae Magnum Interim 🎖️ Make America Great Again*

🎶 [Falco ~ Der Kommissar *(Extended Version)*](https://soundcloud.com/danielvj47/falco-der-kommissar-1982-disco-purrfection-version?utm_source=clipboard&utm_medium=text&utm_campaign=social_sharing)

*I use to rock Falco’s music many years back frequently performing 2 of his hits. This was one of them. The other favorite played in Clubs and on Black Radio Stations is his rap 'Rock Me Amadeus’. Falco sung some other nice tracks back in The Day both in German & English.* [The Lyrics & Some More Info On Falco](https://www.thoughtco.com/lyrics-for-falcos-biggest-hits-4075766)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1692653485792/8fcb0d39-be34-49d3-a15e-9f7be7c13606.webp align="center")](https://www.cbsnews.com/news/trump-indictments-details-guide-charges-trial-dates-people-case/)

**FIRST OFF,** The System has no right to silence his or anybody’s voice. He has his inalienable right to free speech. This is a dignified former President of the United States of America being disrespected by corrupt Officials. I remember back when people wanted him out of Office, but Trump had all his chess board pieces lined up right, he should not have lost. These ongoing aggressive attacks against the former President proves something went wrong with the Elections and he has a right to dispute it still.

*Zunächst einmal hat das System kein Recht, seine oder jemandes Stimme zum Schweigen zu bringen. Er hat sein unveräußerliches Recht auf freie Meinungsäußerung. Dies ist ein würdiger ehemaliger Präsident der Vereinigten Staaten von Amerika, der von korrupten Beamten missachtet wird. Ich erinnere mich an die Zeit, als die Leute ihn aus dem Amt haben wollten, aber Trump hatte alle seine Schachbrettfiguren richtig aufgereiht, er hätte nicht verlieren sollen. Diese anhaltenden aggressiven Angriffe gegen den ehemaligen Präsidenten beweisen, dass bei den Wahlen 2020 etwas schief gelaufen ist, und er hat das Recht, dies immer noch anzufechten.*

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1692653514401/1724acbb-5d87-4df3-bf91-4f593f8ee727.webp align="center")](https://thehill.com/regulation/court-battles/3944574-black-prosecutors-pushed-into-spotlight-with-trump-cases/)

**SECOND,** notice WHO they are using across the legal board to attack Trump. A Black Person. This is particularly offensive because outside of that, the REALITY is Trump has a lot of Black Supporters, many of them are The Common People not making a big deal about it, but when queried, they say Trump. The current Administration don’t want the rest of America to know this so they create an illusion using NYC Attorney General Letitia James, Manhattan DA Alvin Bragg, Washington Judge Tanya Chutkan, & Georgia Prosecutor Fani Willis as Surrogate Spokesperson’s from Our Communities showing us that we should support Joe Biden because Trump is a Bad Man, like we’re children. And what saddens me is how these Black Public Servants, allow themselves to be manipulated by Puppet Masters who know better why they are not doing it themselves.

*Zweitens, beachten Sie, wen sie auf juristischer Ebene einsetzen, um Trump anzugreifen. Eine schwarze Person. Das ist besonders beleidigend, denn abgesehen davon ist die REALITÄT, dass Trump viele schwarze Unterstützer hat, viele von ihnen sind die einfachen Leute, die keine große Sache damit machen, aber wenn sie gefragt werden, sagen sie Trump. Die derzeitige Regierung möchte nicht, dass der Rest von Amerika dies erfährt, also schaffen sie eine Illusion, indem sie die Generalstaatsanwältin von NYC, Letitia James, Manhattan DA Alvin Bragg, die Washingtoner Richterin Tanya Chutkan und die Staatsanwältin von Georgia, Fani Willis, als Ersatzsprecher aus unseren Gemeinden verwenden, die uns zeigen, dass wir Joe unterstützen sollten Biden, weil Trump ein böser Mann ist, als wären wir Kinder. Und was mich traurig macht, ist, wie diese schwarzen Beamten sich von Puppenspielern manipulieren lassen, die besser wissen, warum sie es nicht selbst tun.*

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1692939637202/5759625e-af95-4b0f-8f7c-c8bb69ac535e.png align="center")](https://www.donaldjtrump.com/agenda47)

**THIRDLY,** Trump won already. He’s The Front Runner despite the negativity for 2024, it’s just a matter of who his Democrat Opponent will be. Already the cracks are showing even more within that Party, which began well before the Trump indictments. When you start bashing the Vice President, Kamala Harris, and then start to speculate about brushing her aside for a new VP to side with Biden, and after vitriolically bashing him too, it shows a Party that isn’t solid. And you’re telling us to still vote for them and trust the Election process.

*Drittens hat Trump bereits gewonnen. Er ist der Spitzenreiter 2024 trotz der Negativität, es geht nur darum, wer sein demokratischer Gegner sein wird. Schon jetzt zeigen sich die Risse innerhalb dieser Partei noch mehr, was lange vor den Anklagen gegen Trump begann. Wenn Sie anfangen, die Vizepräsidentin Kamala Harris zu verprügeln und dann darüber zu spekulieren, sie beiseite zu schieben, damit sich ein neuer Vizepräsident auf die Seite von Biden stellt, und nachdem Sie ihn auch heftig verprügelt haben, zeigt dies eine Partei, die nicht solide ist. Und Sie sagen uns, dass wir immer noch für sie stimmen und dem Wahlprozess vertrauen sollen.*

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1692934511632/9a1297ed-3de7-4ca1-b901-394019857f26.jpeg align="center")](https://gaetz.house.gov/media/in-the-news/matt-gaetz-introduce-resolution-censure-judge-trump-case-blatant-political-bias)

**FOURTH,**  Manufacturing a case out of thin air and publicly asking a Former President currently running for Office again to surrender to Police for booking and so forth like he’s a common criminal is crazy. What has this Country come to? So along with 18 other so-called Co-Conspirators, an accomplished Businessman who erected high society monolith properties across the globe, subjected himself to the whims of The Justice System. The Common Folk should take note, this is unprecedented. What it means is a cataclysmic shift for many from historically supporting Democrats to now considering a change to The Republican Party since they represent The People. Hustling this Former President along with undying turpitude is further showing the inside corruption of The Political Justice System in ways that has surpassed anything we’ve seen before. You’re not seeking justice, you’re engaged in humiliating a popular, healthy and cognitive politically active Senior Citizen that many people love and want to see as President again, trifling with his morale and ability to nationally campaign. People see it, and I’ll go a step further than calling it a Banana Republic because atleast in that you can still end up being The Leader with your Militants around you, ***here,*** what we’re seeing is a foreign global power working behind the scenes who has Agents here in Corporations organizing coordinated attacks against The Welfare of the American People, and it’s not China or Russia.

*Es ist verrückt, einen Fall aus dem Nichts zu erfinden und einen ehemaligen Präsidenten, der derzeit wieder für ein Amt kandidiert, öffentlich zu bitten, sich der Polizei zur Buchung und so weiter zu ergeben, als wäre er ein gewöhnlicher Verbrecher. Wohin ist dieses Land gekommen? Zusammen mit 18 anderen sogenannten Mitverschwörern unterwarf sich ein versierter Geschäftsmann, der weltweit monolithische High-Society-Immobilien errichtete, den Launen des Justizsystems. Das gemeine Volk sollte zur Kenntnis nehmen, das ist beispiellos. Was es bedeutet, ist für viele eine katastrophale Verschiebung von der historischen Unterstützung der Demokraten hin zu einem Wechsel zur Republikanischen Partei, da sie das Volk vertreten. Diesen ehemaligen Präsidenten zusammen mit unsterblicher Verderbtheit zu drängen, zeigt die innere Korruption des politischen Justizsystems auf eine Weise, die alles übertrifft, was wir bisher gesehen haben.* Sie suchen keine Gerechtigkeit, Sie sind damit beschäftigt, einen populären, gesunden und kognitiven politisch aktiven Senioren zu demütigen, den viele Menschen lieben und wieder als Präsidenten sehen wollen, und spielen mit seiner Moral und seiner Fähigkeit, landesweit Wahlkampf zu machen. Die Leute sehen es, und ich gehe noch einen Schritt weiter, als es eine Bananenrepublik zu nennen, denn zumindest insofern, als Sie mit Ihren Militanten um Sie herum immer noch der Anführer sein können, sehen wir hier eine nichtchristliche ausländische Weltmacht, die hinter den Kulissen arbeitet und Agenten hier in Unternehmen hat, die koordinierte Angriffe gegen das Wohlergehen des amerikanischen Volkes organisieren, und es ist nicht China oder Russland.

👉 **Update: Legal Cases And Your Rights Concerning Big Tech Phone Data**  
[https://finance.yahoo.com/news/government-warrant-search-phone-cloud-fourth-amendment-legal-191533735.html](https://finance.yahoo.com/news/government-warrant-search-phone-cloud-fourth-amendment-legal-191533735.html)  
👉 **Update: Trump’s Interview With Tucker Carlson 🎙️** [https://tuckercarlson.com](https://tuckercarlson.com)  
👉 **Update: Trump’s Mugshot, August 24<sup>th</sup> 2023** [https://www.nbcnews.com/politics/donald-trump/donald-trump-mugshot-georgia-jail-fulton-county-arrest-rcna101664](https://www.nbcnews.com/politics/donald-trump/donald-trump-mugshot-georgia-jail-fulton-county-arrest-rcna101664)  
👉 **Update: The August 2023 Republican Debate Highlights**  
[https://www.cbsnews.com/news/first-republican-debate-2023-highlights-key-moments-gop-rnc/](https://www.cbsnews.com/news/first-republican-debate-2023-highlights-key-moments-gop-rnc/)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1692938127701/3c17edf3-0ae1-448d-bd67-ff2a0af7106b.webp align="center")](https://rumble.com/search/all?q=Eric%20Trump)

**FIFTH,** Trump is a five star President. He did what needed to be done. He’s not afraid to make unpopular moves if it’s right for The Country. Things were much better for me when he was in Power. Like Trump, the current disrespect I’m experiencing is happening under The Biden Administration even though I treated them fairly. Trump has a strong Team. When he gets in trouble, **The Suits** come in, and I mean his 2 sons, **Eric and Don Jr.** doing damage control with The Press. They do a great job on these social platforms and shows in the Media establishing a defense.

*FÜNFTENS ist Trump ein Fünf-Sterne-Präsident. Er hat getan, was getan werden musste. Er hat keine Angst, unpopuläre Schritte zu unternehmen, wenn es für das Land richtig ist. Es war viel besser für mich, als er an der Macht war. Wie bei Trump geschieht die derzeitige Respektlosigkeit, die ich erlebe, unter der Biden-Regierung, obwohl ich sie fair behandelt habe. Trump hat ein starkes Team. Wenn er in Schwierigkeiten gerät, kommen die Anzüge herein, und ich meine seine 2 Söhne Eric und Don Jr., die Schadensbegrenzung mit der Presse betreiben. Sie leisten auf diesen sozialen Plattformen und Shows in den Medien großartige Arbeit, um eine Verteidigung aufzubauen.*

😉 **THE THIRD TRANSLATION IS READY FROM MY APRIL TRUMP ARTICLE** 🙂

[https://odysee.com/@Ferrelux666:f/Trump's-Case-And-Ghetto-Politics-Czech-Translation:e](https://odysee.com/@Ferrelux666:f/Trump's-Case-And-Ghetto-Politics-Czech-Translation:e)

[https://ferrelux.com/trumps-case-and-ghetto-politics](https://ferrelux.com/trumps-case-and-ghetto-politics)

**Sign,**  
**Lhisa Mrklon**

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1696268717746/c2f1cc62-3fed-45b7-abfd-6c34709441ff.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1697310806738/b028a020-daec-4ecf-8267-36e6acc04bfc.jpeg align="center")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1693332201625/c21d1105-dd41-472f-b9b6-39235b7e9165.jpeg align="center")](https://www.newsweek.com/watch-tucker-carlsons-trump-interview-airing-opposite-gop-debate-1822073)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1692931971276/171d17ce-6281-437d-b552-a17a72c222f5.webp align="center")](https://www.trumpnationalbedminster.com)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1692932294138/d974d276-a725-4089-9f1a-19a04396af7b.jpeg align="center")](https://www.trumpnationalbedminster.com/golf/course-tour)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1692932535563/68f8922f-7aa1-45b9-b136-2c2b5461c955.png align="center")](https://www.trumpnationalbedminster.com/pool)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1692932742980/d9b155d2-6240-439a-867f-cc91afdba638.jpeg align="center")](https://www.trumpnationalbedminster.com/event/banquet)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1692933855749/dc1526e8-9872-4db8-b4da-e193692c41ad.png align="center")](https://www.trumpnationalbedminster.com/membership)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1695161230817/7f81a703-15fd-4e29-bd06-292dcf853228.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1697310915388/dc3635d9-8447-4397-bacf-4f18b8c88642.jpeg align="center")
