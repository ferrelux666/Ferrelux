---
title: "\U0001F3BC Bohemian Rhapsody (2018) Queen Movie Review \U0001F3B9"
date: '2019-03-27T23:38:00.000Z'
slug: bohemian-rhapsody-2018-queen-movie-review
tags:
  - music
  - ads
  - india
  - drag
  - political
  - africa
  - film
  - entertainment
  - rock
  - artist
  - commercial
  - movie-review
  - queen
  - singer
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195170702/d4QXIYKjT.png
canonical: 'https://ferrelux666.wordpress.com/2019/03/27/queenfilm/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195135506/zGGzoTcxe.jpeg align="left")](https://www.ferrelux.us/)

PLAYLIST ~ [Music By Queen](https://myspace.com/lhisa666/mixes/queen-721854)  
*Ne Cede Malis, Sed Contra Audientior*  🚲   *Do Not Yield To Misfortunes, But Go Forth More Boldly To Meet Them (Virgil)*

**Ofcourse somebody would want to make a film about the late great Freddie Mercury. I had mixed feelings over it. ALOT of the info in the movie and timeline is false. It’s a piece of fictional work designed to convey what they wanted you to know about him and the band and there experiences. Well, for something more factual, go look at the many documentaries and interviews online. For the film, they tried very hard to make the Egyptian actor Rami Malek, look, sound and act like him. The real Freddie was a physically bigger man and his striking actions and majestic persona are hard capture. I wasn’t entirely convinced of the performance and I don’t know why Rami Malek was chosen, I was more impressed at the actor’s work at the end of the film when he really came alive on stage as Freddie Mercury at the Live Aid concert. Yes, I expected it to win ALOT of awards, because of some elements in the film, even though critics like myself didn’t fancy it much**\*\*. At the time when I saw the movie, I wasn’t really happy with it to go write a rave review, but as I continue to think about this man and his work, I have to say something. Prior to the film, the music of Queen for years were in movies, TV shows & commercials, and now AFTER the film, it’s still everywhere arguably as the band with the most hits heard in ads. Now this is a testament to their greatness, the mass commercial appeal as of late. There was a time in my development where Queen was one of the rock bands, I designated a moment of my life consistently listening to. The man was a musical genius. I felt the film focused too much on the gay shit. Some of the dialogue consisted of cheesy faggot comments that made Freddie looked like he was some Rupaul Drag person, when in reality, he carried himself more like a man. He was never out there in the public eye talking like that, seeming like that, or carrying himself like that. In reality, he was masculine, that was why when he died at age 45 in the early 1990s, it shocked people when we heard he lost his life due to complications with AIDs. I remember, it saddened me as a teenager back then the way the news of it was suddenly delivered over the airwaves. I missed him. He died too early. And now, so many years later in the current heyday of the flamboyant gay rights movement, they go and make a movie using HIM & his life to be a part of the gay agenda. If you study Queen, you’d know that Freddie himself when he lived, had no interest in being a point person for the gay movement or a Spokesperson on AIDs. He was a private man who was more mindful about HIS MUSIC. I’d think if you were going to do a movie about him, you’d more concentrate on his musical genius and things that really mattered to him. His lyrics hold philosophical content. He’s a Composer, right up there with Mozart, Bach, etc. Looking at the first half of the film was making me visibly upset with them focusing on homosexuality as if that was the main thing about his life, when other people around him at the time, can account for aspects of his personality being non-gay. In reality, heterosexuality was something he valued that the movie could not deny and had to show in some way since there was a woman he was romantically involved with, that he still loved till the end of his life and he left a great deal of his fortune to her even though she married and moved on. Something happened to Freddie as a young Indian boy born in Zanzibar/Tanzania when his family moved there to flee the Uprising in India. Then he developed as a person in England. We may never know the missing info, but there might be clues out there in cyberspace and alternative media. The movie could have been done better without the gay politics. Now we have content Millennials misunderstanding some things about his life and art as we go on as a society. He’s now a Gay Icon. Oh God! He was never seen as that before though. Nor decades before now, was he dug up and embraced as one of them, even at the time he lived. Some people say he was openly gay at the time, but there is evidence suggesting otherwise. Also, homosexuality (Buggery) was still seen as a crime in Britain in the 1960s. To many Americans & others around the globe, it was either a mental problem, or a vice you engaged in and some of us still think so. And for some, cross-dressing was a look you adopted or played around with, but it didn’t mean you were actually gay or lesbian, or something. And people eventually realized if you were or not. If he was privately exploring or finding himself because of some personal issue and I saw that, I wouldn’t make a film depicting that as the central theme of his life. It was more a gay movie, than an real biopic. There was so much more beyond that and what he never got to do in life. I don’t know how he himself would feel about this film they made about his life. I know though, he would have composed a better film about his story.\*\*

**Lhisa Mrklon,**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/n_kHPk0ED6I?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/1godptB6INw?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

SOME LINKS ON FREDDIE

[https://en.wikipedia.org/wiki/Freddie\_Mercury](https://en.wikipedia.org/wiki/Freddie_Mercury)

[http://www.freddiemercury.com/](http://www.freddiemercury.com/)

[http://www.mercuryphoenixtrust.com/](http://www.mercuryphoenixtrust.com/)

[https://ultimateclassicrock.com/freddie-mercury-teeth/](https://ultimateclassicrock.com/freddie-mercury-teeth/)

[https://www.imdb.com/name/nm0006198/](https://www.imdb.com/name/nm0006198/)

[![Ferrelux Homepage_March2019-FreddieQueen](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195136638/FcTNSuErq.png align="left")](https://ferrelux666.wordpress.com/ferrelux-homepage_march2019-freddiequeen/)

[![mercury](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195137683/Msw_UpJ79.jpeg align="left")](https://ferrelux666.wordpress.com/mercury/)

[![Freddy_Mercury](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195138740/xCWGJZUna.jpeg align="left")](https://ferrelux666.wordpress.com/freddy_mercury/)

[![image-w856](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195140027/isobyGSNL.jpeg align="left")](https://ferrelux666.wordpress.com/image-w856/)

[![UNITED STATES - DECEMBER 01: MADISON SQUARE GARDEN Photo of Freddie MERCURY and QUEEN, Freddie Mercury performing in stage (Photo by Richard E. Aaron/Redferns)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195141331/RJ3u9Qr9W.jpeg align="left")](https://ferrelux666.wordpress.com/photo-of-freddie-mercury-and-queen/)

UNITED STATES – DECEMBER 01: MADISON SQUARE GARDEN Photo of Freddie MERCURY and QUEEN, Freddie Mercury performing in stage (Photo by Richard E. Aaron/Redferns)

[![Freddie-Mercury-Queen-Photo](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195142611/wdGMgqPV3.jpeg align="left")](https://ferrelux666.wordpress.com/freddie-mercury-queen-photo/)

[![freddie-mercury-queen-isolated-1200x631](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195143657/1VPCJG-Sl.jpeg align="left")](https://ferrelux666.wordpress.com/freddie-mercury-queen-isolated-1200x631/)

[![freddie-mercury-press-crop](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195144807/PqRByn1Mi.jpeg align="left")](https://ferrelux666.wordpress.com/freddie-mercury-press-crop/)

[![freddie-mercury---live-aid](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195146368/EueV_NiBy.jpeg align="left")](https://ferrelux666.wordpress.com/freddie-mercury-live-aid/)

[![LOS ANGELES, CA - SEPTEMBER 18: Actor Rami Malek attends the 68th Annual Primetime Emmy Awards at Microsoft Theater on September 18, 2016 in Los Angeles, California. (Photo by Frazer Harrison/Getty Images)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195147703/Kh_VXw2gK.jpeg align="left")](https://ferrelux666.wordpress.com/68th-annual-primetime-emmy-awards-arrivals/)

LOS ANGELES, CA – SEPTEMBER 18: Actor Rami Malek attends the 68th Annual Primetime Emmy Awards at Microsoft Theater on September 18, 2016 in Los Angeles, California. (Photo by Frazer Harrison/Getty Images)

[![freddie-mercury-queen-roznicza-smierci-393033-article](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195148924/ov-VwKMx6.jpeg align="left")](https://ferrelux666.wordpress.com/freddie-mercury-queen-roznicza-smierci-393033-article/)

[![freddie-mercury---death-and-legacy](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195150269/NgFi7_1HY.jpeg align="left")](https://ferrelux666.wordpress.com/freddie-mercury-death-and-legacy/)

[![f170ee455ab00ae06e585ec7e20408e9](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195151517/sbGBegUYB.jpeg align="left")](https://ferrelux666.wordpress.com/f170ee455ab00ae06e585ec7e20408e9/)

[![diana-freddie-t](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195152665/_FOyYEDN9.jpeg align="left")](https://ferrelux666.wordpress.com/diana-freddie-t/)

[![dd52a_1346873553_freddie_mercurys_best_outfits_large_msg_131517043638](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195153825/FauukIkhC.jpeg align="left")](https://ferrelux666.wordpress.com/dd52a_1346873553_freddie_mercurys_best_outfits_large_msg_131517043638/)

[![2012-11-14-freddie_mercury_young](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195155130/tMWQPuQCz.jpeg align="left")](https://ferrelux666.wordpress.com/2012-11-14-freddie_mercury_young/)

[![200938-004-6F2F7CB1](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195156301/nYbjfSyj6.jpeg align="left")](https://ferrelux666.wordpress.com/200938-004-6f2f7cb1/)

[![1831637-LXSQLYLY-6](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195157332/uX22NiPO4.jpeg align="left")](https://ferrelux666.wordpress.com/1831637-lxsqlyly-6/)

[![A.-Front5](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195158635/dosbtk4Y9.jpeg align="left")](https://ferrelux666.wordpress.com/a-front5/)

[![3029111740](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195159970/JyiNEUNha.jpeg align="left")](https://ferrelux666.wordpress.com/3029111740/)

[![527dcd556a2b32e06e9d57955542eb39](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195161121/UnSXRy-Qr.jpeg align="left")](https://ferrelux666.wordpress.com/527dcd556a2b32e06e9d57955542eb39/)

[![140f8cab184caaa9bfbedafb9cf61a9b](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195162463/O_Wsv8liS.jpeg align="left")](https://ferrelux666.wordpress.com/140f8cab184caaa9bfbedafb9cf61a9b/)

[![_freddie-mercury-1946---1991-of-british-rock-band-queen-with-his-friend-mary-austin-during-mercurys-38th-birthday-party-at-the-xenon-nightclub-london-uk-september-1984-p](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195163782/5ShS9vmot.jpeg align="left")](https://ferrelux666.wordpress.com/_freddie-mercury-1946-1991-of-british-rock-band-queen-with-his-friend-mary-austin-during-mercurys-38th-birthday-party-at-the-xenon-nightclub-london-uk-september-1984-p/)

[![75fca9776f77601a7b73ea27765a41ae](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195165114/1UJLJHcyJ.jpeg align="left")](https://ferrelux666.wordpress.com/75fca9776f77601a7b73ea27765a41ae/)

[![13JACKSONMERCURY2706A](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195166228/_EOGM0GDj.jpeg align="left")](https://ferrelux666.wordpress.com/13jacksonmercury2706a/)

[![9X9DNTR5](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195167713/pWnfDNcSi.jpeg align="left")](https://ferrelux666.wordpress.com/news/9x9dntr5/)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195168868/LHMQ3CRP7.jpeg align="left")](https://ferrelux.com/adverts/)
