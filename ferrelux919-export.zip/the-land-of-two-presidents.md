---
title: "\U0001F418The Land Of Two Presidents \U0001F5FA"
date: '2021-11-19T21:02:36.000Z'
slug: the-land-of-two-presidents
tags:
  - trump
  - beast
  - war
  - vp
  - usa
  - sports
  - france
  - world
  - china
  - covid-19
  - uncategorized
  - italy
  - politics
  - election
  - god
  - christian
  - america
  - russia
  - variant
  - joe-biden
  - islam
  - middle-east
  - death
  - president
  - turkey
  - desert
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672208302107/dc29275c-44c0-4c48-b002-a6c6c29b19c8.jpeg
canonical: 'https://ferrelux666.wordpress.com/2021/11/19/two-presidents/'
---
[![Trump Vs Biden Over Handling Afghanistan](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192375367/U8ebLj01c.jpeg align="left")](https://rumble.com/search/video?q=Trump%20And%20Afghanistan)

[**I, Claudius Theme**](https://www.youtube.com/watch?v=71s_Y37_KYo)[**The 1973 Movie Release, Black Caesar**](https://www.youtube.com/watch?v=gi7gDE1Ny6g)  
*And There Were Roman Emperors Of Africoid Descent By The Way*

Ego Sum, Tu Es, Sumus Omnes Caesares 🐍 I Am, You Are, We Are All Caesars

Though we have Potus 46, many are still thinking about Potus 45 and treating him as if he is still President due to a possible voting discrepancy. People want Trump back. So as the year draws to a close, everybody knows what your end-term grade is Joe Biden. It is a definite **F**. And it came unexpected. And you were doing so well in some circles. Atleast from me, your prudent grade went from a C to a C+ and I anticipated that growing, but you went and did some things that got The American People **\_***VERY***\_** angry which led to a phenomenal drop. Now this political mess started back when you eventually decided to run for President. Atleast half of The American People were satisfied with Donald Trump. I didn’t always approve of what he did or said, but I didn’t mind him continuing in power compared to some things I was seeing from the other side that I found unfavorable. And I was expecting The Lead Democrat to be Bernie Sanders at the time since his chances were that strong, but he got double-crossed by his fellow Democrats when they just handed over their entire support to Joe Biden. Now look how everything turned out. And you know what? When you’re studying politics and see some things you don’t agree with on either side, you alienate people from voting. A Democrat may have some Republican views, while a Republican might be somewhat Liberal. So a person might have to vote their conscience and sometimes that means not voting at all. And it turned out where I was right. At the time, I was not feeling you Joe, but you won and I said okay, so let’s see what happens next. And I expected the typical Presidential Rule where things kind of go how it’s supposed to and so far it did not work out that way. Now let me stop here, and begin taking on some speculations and theories. When we wake up everyday now living in a continual man-made disaster, it draws to mind some biblical prophecies, The Four Horsemen of The Apocalypse: War, Famine, Pestilence & Death. If you all are **\_***doing this***\_**, to herald in **\_***Somebody***\_** you are expecting here soon to be our solitary global leader, it isn’t necessary. You fabricating issues, and manufacturing terrific conditions, is not what *The Scriptures* meant. These things will happen on their own. Just when Joe Biden won the Presidency, there were images of him circulating with a shady halo around his head and I thought, **\_***here we go***\_**. Ya’ll need to stop man. The Scriptures can be interpreted in several ways. We can’t be too sure what *The End Times* will look like. If you deliberately failed in Afghanistan because you think that’s where The biblical battle of Megiddo will take place, then you may have mis-interpretted the circumstance. Why would you acquiesce any part of your power to an Opponent? You don’t need to go along with biblical prophecy. You might be making a mistake. How do you know that YOU aren’t the one to be Hosting the Anti-Christ’s Rulership? Why under-estimate yourselves like that? Stop playing yourselves, man? How do you know that you weren’t known about in ancient times? Can you find America in The Bible? And what was it called then? I understand looking to Rome & Asia as the place where the epic showdown might happen with The Anti-Christ and Israel, but you can’t be too sure if that’s the way it is supposed to go. Biblical Scholars feel The Coming Anti-Christ is supposed to be like Jesus, and is mistaken for him or accepted in his place, and that he will be honored by Arabs, Christians & Jews, as The Messiah, but first of all, you are looking at the philosophies of a work that has been tampered with too many times, and other regions of The World might be the actual terrain to host this prophecy as things play out. When Rome Fell, it is commonly believed by some Biblical Scholars that the other part of The Empire in Asia Minor wasn’t destroyed yet. So some look to The Byzantine Empire, Turkey, and the stretch across into The Afghanistan Area and such as being significant, however, other places on the globe can fit the description too. So trying to destroy our economy and make a mess of things is not the thing to do, nor is trying to see an Arab Leader empowered to rule The World, the best thing. It’s not for you to choose where divine prophecy should play out. Deja Vu, and other spiritual phenomena tends to happen on their own. God does not need you to move his plans into place, and neither does Satan. You’re short-changing your own power. America might be more significant than you think, especially if you are **The Beast** spoken about in The Book of Revelations. You aren’t supposed to be dismantling your own government or economy and such, you’re supposed to be building. You have the political make-up to contend. Maybe in some ways this is **Rome**. I appreciate that this past Olympics featured the *Caesars Sportsbook App* commercial as an omen. And perhaps you need to consider it. While this Country is trying to see a female Black President, but booing Kamala Harris every step of the way, after we had Barack Obama back in 2008, we still have not seen an **Italian-American President** as of yet. Isn’t it time now with all the Prospects out there: Mike Pompeo, Rudy Giuliani, Andrew Cuomo, Michael Avenatti, and others. What are you afraid of? Italy is one of America’s strongest allies, yet socially here in some circles, especially in The Justice System, you treat Italians unfairly. And you used to lynch them back in the day as you did Black People, yet your country can’t do without their favor. You even celebrate Columbus Day, when it would have been better to use Amerigo Vespucci. And here’s something to think about too. Back in the day when we had a younger Donald Trump, had he decided to run for President then, guess who might have been a good contender at the time had things went well for him, John Gotti. And I see reports out here that Tucker Carlson might run. Well, he looks Roman enough. And while you’re at it, why not throw in other ethnics like Ron DeSantis and Adriano Espaillat. Now obviously Ex-Vice President Mike Pence has a right to run, and he looks Roman too. And why not some Italian females who might be capable enough to lead like their ancestors back in the day? You’re too busy criminalizing citizens aggressively protesting and criticizing the current system. Don’t destroy your nation like this. The people have a Constitutional Right to rise against it if they disagree. YOU aren’t the one who’s supposed to destroy it. It’s time to get your act together and re-institute your greatness. You have something here your fore-fathers built. How do you think they would be perceiving your actions now? Playing political games by getting the right Contenders locked up in prison, or pushed aside with some legal scandal, which hurts The People. That’s unstable government. You look like a fool to the other nations, especially to the lesser ones who now think THEY have something better. To hold your seat of power globally, you need to stop playing yourself or China, Russia, Great Britain, France, and anybody else will displace you. There was a time you knew that. You knew doing certain things was not wise. Going over there to The Middle East telling them that you’re openly gay with rainbow flags, and talking to their kids about LGBTQ pronouns as if it was going to help you, was not only stupid, but they kicked your ass and drove you outta there. Now, other Muslims are mobilizing worldwide because your weaknesses here are showing across the globe. President Joe Biden is regularly being ridiculed in the media as an ineffective leader and whatever you all are doing behind the scenes to set up his Administration that way, needs to stop. We are **NOT** back on The World Stage! What should have happened in Afghanistan and the rest of the Middle East was a complete take over. It should have happened decades back when you first went over there. You failed to properly inhabit the region and Americanize everything. If you were afraid of looking like Colonizers and being accused of racism, then you missed an opportunity to secure a troubled region at the time. Those people do not have a problem using the same racist Colonizer techniques from the history books to fuck you up though. Stop being played by them. You should have seized control over the entire Middle East by now, or atleast shared occupancy with your allies. How is it that Arabs/Muslims are able to move into territory owned by other people and amass control in record time like pestilence? Do you want to speak Arabic and worship Allah? Keep playing yourself with these people, and you won’t have the power any more. What you need are people who understand exactly how to defeat them; the very people you’re oppressing in the empire who they’re afraid of. So anyway, since you’re playing into the prophecies, understand that the conspiracy theories proliferate as well with what you’re doing. Over the years you’ve been hinting at manifesting a Messiah. So with the known technology you have and the hidden ones, who do you plan on creating or bringing back from the dead to play the role of our new global leader? It is one of the Kennedys, Julius Caesar, Nimrod, *or Somebody else*? We’re in The End Times, right? That’s why you’re setting the stage for that Anti-Christ. And are you going to play yourself still being a fool out there in the world, or are you going to defy the odds and become The Last Longstanding Demigod Ruling Empire of The World before Christ comes back?

NOW REPEAT AFTER ME,

**I Am, You Are, We Are**

**I Am, You Are, We Are**

**I Am, You Are, We Are**

**ALL CAESAR ! ! !**

Sign,  
Lhisa 666

**Is Donald Trump Still Your President? Scroll Down And Leave Your Reply Below.**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/WmO1BTXpFvU?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/u-A1xEG811Q?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192377313/XIwFWQccX.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192379036/hNg1VLgfl.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192380429/yB2iYL4CK.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192381785/88nTNmuzQ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192383232/aSBok5A1N.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192384746/IHMssQRoF.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192386122/E4kqJs1_M.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192387536/odKfqDpvq.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192388701/cTORZ52c4.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192390171/gds_wm1Sb.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192391799/e8EjOhhNe.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192393151/pGiDZlf1I.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192394453/z1Hlz8yXb.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192395901/LGRUdwmvy.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192397574/FE-tEXaYW.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192399312/EilYWprGy.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192400662/ZJzeQrd9_.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192402155/mX2l8yoru.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192403719/rPCFD4iCA.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192405355/yW8smQH9a.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192406603/udsDhiCLy.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192408666/ThqJXtn9L.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192411685/kZjiy0i0V.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192413980/RCaRqVyuO.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192415720/OhHsT3J0L.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192417303/tg5dF1j82.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192418804/YGaHOaopk.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192421944/qSmJkOV3F.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192423496/E5LOyirrti.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192424667/LovR_oSPa.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192426074/2ekz6wsRE.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192427508/-_pRxFhnWK.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192428713/KDclUrr8q.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192429944/YjcUzGC6i.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192431483/2GGWZSIqj.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192432769/50BgnBUX9.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192434223/DDYBZqLl1.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192435998/w3F3v_9wD.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192437762/wGeGYEHv-.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192439104/bSH-N4ab4.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192440301/3M9L0i2dF.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192441791/dmQNk1Gzy.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192443626/G--DLmMWM.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192444974/9x6tOyzxp.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192446265/kXH91sttL.jpeg align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192447922/XukMIGnqf.png align="left")](https://www.usgrants.org/sign-up?affiliate=134980)

### Like this:

Like Loading...

### *Related*
