---
title: "‘Empire’ Battle: \U0001F3BC Jussie Smollet Vs Jamal Lyon \U0001F3B9"
date: '2019-07-31T20:02:07.000Z'
slug: empire-battle-jussie-smollet-vs-jamal-lyon
tags:
  - network
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672194892934/1ituziAdG.jpeg
canonical: 'https://ferrelux666.wordpress.com/2019/07/31/jussie/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194854834/8qe-Rzh87O.png align="left")](https://www.ferrelux.us/)

[Jussie Smollet ~ ‘Battle Cry](https://myspace.com/dapandakyd/music/song/battle-cry-jussie-smollett-114200692-129816719)

*Pia Fraus  ♠  Pious Fraud*

This was a story I couldn’t wait to jump on when it started back in Feb/March, but I respectfully reserved my opinion till the trial and fallout of the whole thing. There were reports circulating of the show ‘Empire’ being cancelled that was false at the time, so now most recently, Fox Producers and the show’s Creator Lee Daniels have verified that Jussie Smollett’s character Jamal Lyon, will not be in the upcoming final season. This, after the heels of not using him in the last 2 episodes of last season due to the scandal, where his presence there concerning his dying TV older brother Andre Lyon, would have made sense. So now let me start………. When the news report of his attack first broke, I felt sorry for him. This is the guy who portrays Jamal Lyon on ‘Empire’ the fun-loving gay sensitive tough guy who does R&B Soul alongside his younger rapping brother in the show Hakim Lyon, many have come to love, even those of us not exactly fond of homosexuals. So naturally, people wanted to see his hateful White attackers caught, especially the LBGTQ community. WELL, when the Chicago PD got to working, they discovered otherwise. The alleged crime unraveled as a hoax aimed in part politically against Trump, and to gain further support for Gay rights, increase his popularity to be paid a higher wage on ‘Empire’ and to sell his concert tickets which resulted in a sold out show in L.A. with him performing music from his new self-released album. The 2 African brothers he paid off from Ghana, were seen on video tape in Walmart the day before the ‘attack’ buying gear for the scam. Comedians everywhere held off long enough from making jokes about Jussie, until it was cool to do so because there is no gravity to the case. It kept looking more and more like it was. The Chicago PD came out HARD at him for wasting cops time out there searching for assailants that never existed. Jussie however, maintains to this day he was attacked by real bigots & Gays still support him & his story. I appreciate the way his Black and White female Lawyers handled it and protected him from the system because the prosecution was getting ready to lynch his ‘faggot ass’. Though it looked like what it looked like, I was hoping the Officers and Court went easy on him. He’s not a bad guy and it was better the whole thing be a lie, than a real heinous crime like that happening in their city. So the 16 felony charges were dropped, he got no jail time, just community service and he forfeited his $10,000 bond to the City of Chicago. The Fox Network were happy and the cast of the show can move on and continue filming with him, despite the awkwardness of it all. That should have been the end of it after the public broadcast, but some people can’t let go. The Black Cook County police Superintendent, Eddie T. Johnson who fiercely came at him from the beginning could not let him get away with making claims that the attack was real and the Department didn’t handle it right and so on. And this sparked Chicago Mayor Rahm Emanuel to get involved. Well, race and sexuality mattered in this case. For some, Jussie ruined the 2019 Black History month with an alleged attack that didn’t go well playing out through the news and getting President Trump, whom he dislikes involved on insisting he apologize for it since his fake attackers yelled, ‘Nigger’ and ‘This is Maga Country’. The City of Chicago where he lives, wants an apology too, which they’re still waiting for, and for him to pay about $130,000 for the cost of cops working on his case, with the line ” *I’m Sorry* ” on the check memo. Notice that this amount of money they calculated seems to match the sum of money he would have been paid atleast for the last 2 episodes of ‘Empire’ he’s omitted from. For many people, the whole real life episode of this actor exposed him. When we all accepted this relatable, humble, friendly, lovable, musical gay guy on TV, his real life self was very different. Off-Screen, he had the Black Power way he walked on the street into the court looking like Malcolm X. And I loved the way he looked over at the Prosecutors with that *‘I got something up my sleeve, you so stupid’* look while in court. This cocky Blaxploitation guy in real life was coming off more like his cocky & thuggish TV brother Hakim Lyon in ‘EMPIRE’ than the sweet Jamal Lyon and that shocked people. I guess he needed to get away from that Jamal character he played so well, and be who he really is. People aren’t feeling that though. We liked Jamal and HE RUINED THAT! So what about his career now,……… well some are saying it’s over while others are saying it’ll be a long time before he sees a comeback. Jussie was scheduled to make a Broadway début about a gay baseball player and the Production company cancelled the theatrical show. Everything else has dried up too. He’s occasionally seen in public on vacation having fun, smoking what looks like a blunt or talking on his cellphone. We may never know the full details of the scandal but, he should NOT have done it! Any speculation is plausible. It could have been a failed publicity stunt the Network plotted for ratings that went wrong, but won’t assume responsibility for since it was settled privately, why the Prosecutor won’t speak on it further, and this prompted the FBI’s curiosity. Well some things are best left alone. The people still acting a fool over it don’t understand The Industry and that sometimes with Hollywood cases, there is a bit more involved they don’t want getting out and you should just leave it alone. You can also speculate that there was a gay lovers dispute between the Brothers and Jussie and one thing led to another and it played out to this fiasco to their public embarrassment. When the White Lawyer for the African brothers wanted them to sue and take further legal action, they opted to contact Jussie behind their Lawyer’s back and make a clandestine deal to drop it, thereby squashing major shit they don’t need exposed. So when all that hit the news, you would think okay this is ‘nigger shit’ they just solved amongst themselves since they already know and worked with each other before, leave it alone, but nooooooo, Eddie Johnson, the Southern Black Police Superintendent who should know better, kept pushing. He was really pissing me off. Yeah, I get your anger, but you don’t really need to know every last detail why the case was pulled out from under you. Just go along with it. I commend the White Prosecutor (Joe Magats) for his role in dealing with the press and not revealing the very detail that made him drop the case. Now Chicago’s first Black female State Attorney Kim Foxx is under fire for not criminally lynching Jussie & I commend HER for it. A far reaching third speculation for the attack could be Illuminati punishment, because Jussie failed to do something The Establishment wanted, and they issued a fake cover-up story for the public. Also keep in mind that during this time, another case was developing against R&B singer R. Kelly, for having sex with Minors, in the same Cook County which the same Prosecutors are handling, that’s more of a real crime to punish than wasting time with Jussie. So anyway, if Jussie himself as it is now accepted is responsible for a LIE, anyone around him including his so-called attackers should have stopped it. It was a dumb idea. There were so many other ways to have kept his name and fame going without tarnishing the ‘Empire’ brand, causing its ratings to drop. You can’t think of the show now without remembering the scandal. Jussie was dissatisfied with his $65,000 per episode salary in comparison to what he thought his worth to the show was against the other top-billing stars, Terrence Howard (Luscious Lyon) and Taraji P. Henson (Cookie Lyon). Well, I’m in the Entertainment Industry too functioning in various capacities, and like other struggling actors trying to get where he is lucky to be right now, I wouldn’t mind playing some stupid ass character on TV for that pay rate. He had a point though with the billions of dollars in ad revenue the Fox Network was earning. They also wouldn’t release his music, why he went solo, producing his own record. So some people feel that Fox was responsible in some way driving him to do something desperate. Whatever the case is, I and other caring people are still supportive of Jussie Smollet. He may have had a personal breakdown, misguidance and so on, and some have suggested drug use, it’s not a time to hate on him, but be understanding and hope he reflects and recovers from it.

[CNN Coverage Prosecutor Joe Magats](https://www.cnn.com/2019/03/27/entertainment/jussie-smollett-wednesday/index.html)

[Jussie Smollet Cook County Update](https://www.google.com/search?source=hp&ei=VNhBXeOVHoTu_Qbx-534CQ&q=jussie+smollett+cook+county&oq=jussie+smollet+cook&gs_l=psy-ab.1.0.0i13l4j0i22i30l2j0i8i13i30l2.3853.15306..17463...0.0..1.511.4275.0j11j5j0j2j1......0....1..gws-wiz.....0..0i131j0j0i10.LkL08fh6tCI)

[More Jussie Smollet Case Update](https://www.google.com/search?ei=YdpBXcruEu-g_Qb9r4DQBQ&q=jussie+smollet+update&oq=jussie+smollet+update&gs_l=psy-ab.3..0i10l7.122816.129547..129964...0.0..1.466.2499.4j6j2j0j2......0....1..gws-wiz.......0i22i10i30j0i22i30.ve-C6rzZxDI&ved=0ahUKEwiKo92z4d_jAhVvUN8KHf0XAFoQ4dUDCAo&uact=5)

[Chicago State Attorney Kim Foxx](https://www.google.com/search?ei=DNpBXZaMA-bn_QbCwoC4AQ&q=jussie+smollet+kim+foxx&oq=jussie+smollet+kim+foxx&gs_l=psy-ab.3..0i13j0i7i30j0i13j0i7i30l5j0i8i7i30l2.76988.79930..80513...0.0..0.222.2336.1j11j2......0....1..gws-wiz.7tMvpt0Aphk&ved=0ahUKEwiWwomL4d_jAhXmc98KHUIhABcQ4dUDCAo&uact=5)

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/7E45gPnqnCA?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/pXLx5OY21Bk?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/yXo7IIO9uU8?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

Lhisa Mrklon,  
Special Agent 666,  
Emissary Of Fate

### Do You Believe Jussie Smollet’s Account Of What Happened? Scroll Down And Leave Your Reply Below.

[![_jussie_smollett-v2-getty-h_2019](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194856304/KA5EMRTC8.jpeg align="left")](https://ferrelux666.wordpress.com/_jussie_smollett-v2-getty-h_2019/)

[![4e24341cc6985c18b05318500e809462_md](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194857483/dEwZxyo4x.jpeg align="left")](https://ferrelux666.wordpress.com/4e24341cc6985c18b05318500e809462_md/)

[![26-jussie-smollett.w330.h330](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194858751/khgGZJhIc.jpeg align="left")](https://ferrelux666.wordpress.com/26-jussie-smollett-w330-h330/)

[![1069338046.jpg.0](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194859800/MyZmI9wlA.jpeg align="left")](https://ferrelux666.wordpress.com/1069338046-jpg-0/)

[![ct-ent-jussie-smollett-empire-20190313](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194860972/yynE6mNkR.jpeg align="left")](https://ferrelux666.wordpress.com/ct-ent-jussie-smollett-empire-20190313/)

[![Chicago-to-Sue-Jussie-Smollett-for-Refusing-to-Pay-Investigation-Fees](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194862461/Pp34g3oTZ.jpeg align="left")](https://ferrelux666.wordpress.com/chicago-to-sue-jussie-smollett-for-refusing-to-pay-investigation-fees/)

[![Bryshere_Y.Gray(26362135321)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194863912/DOvD0wgxA.jpeg align="left")](https://ferrelux666.wordpress.com/bryshere_y-_gray_26362135321/)

[![ct-met-jussie-smollett-travel-20190225](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194865397/x-2SwjRk0.jpeg align="left")](https://ferrelux666.wordpress.com/ct-met-jussie-smollett-travel-20190225/)

[![D6FeLqqUwAAORY0](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194866741/rWh_k01CB.jpeg align="left")](https://ferrelux666.wordpress.com/d6felqquwaaory0/)

[![Empire-Jussie-Smollette-Kill-Off-Recast](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194867702/DMbf_ZbyP.jpeg align="left")](https://ferrelux666.wordpress.com/empire-jussie-smollette-kill-off-recast/)

[![empire-cast-season-2-2016-billboard-1548](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194868738/LMUdSl1T_.jpeg align="left")](https://ferrelux666.wordpress.com/empire-cast-season-2-2016-billboard-1548/)

[![empire-2-e1556211228478](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194870100/mQA7awTX_.jpeg align="left")](https://ferrelux666.wordpress.com/empire-2-e1556211228478/)

[![Empire](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194871187/lAi1gI5Rz.jpeg align="left")](https://ferrelux666.wordpress.com/empire/)

[![Empire-Lucious](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194872498/9jh4aC_Sz.jpeg align="left")](https://ferrelux666.wordpress.com/empire-lucious/)

[![Empire-Rantings-Tank-Week-Two-Jussie-Smollett](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194873755/T7pmyF5ld.jpeg align="left")](https://ferrelux666.wordpress.com/empire-rantings-tank-week-two-jussie-smollett/)

[![empire-season-2-600x600](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194874726/PGmp8aE46.jpeg align="left")](https://ferrelux666.wordpress.com/empire-season-2-600x600/)

[![empire-season2-hed-2015](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194876319/mlC-NpSTYg.png align="left")](https://ferrelux666.wordpress.com/empire-season2-hed-2015/)

[![hgifgosjdsgdgf](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194877836/NSVaPI90l.jpeg align="left")](https://ferrelux666.wordpress.com/hgifgosjdsgdgf/)

[![https___blogs-images.forbes.com_adriennegibbs_files_2019_04_toby-and-jussie-1200x907](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194879351/s8QLk48x2.jpeg align="left")](https://ferrelux666.wordpress.com/https___blogs-images-forbes-com_adriennegibbs_files_2019_04_toby-and-jussie-1200x907/)

[![Jussie_Smollett_(26362136311)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194880455/bJa2MncXH.jpeg align="left")](https://ferrelux666.wordpress.com/jussie_smollett_26362136311/)

[![Lee-Daniels-and-Jussie-Smollet](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194881948/AgjnI7igO.jpeg align="left")](https://ferrelux666.wordpress.com/lee-daniels-and-jussie-smollet/)

[![RTX6R6FA_1_ie9tjj](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194883093/LmxQSWACm.jpeg align="left")](https://ferrelux666.wordpress.com/rtx6r6fa_1_ie9tjj/)

[![The-Jussie-Smollett-Allegations-A-Timeline-Of-What-Happened-When-707410475-1553724019](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194884735/e_2EpKGdU.jpeg align="left")](https://ferrelux666.wordpress.com/the-jussie-smollett-allegations-a-timeline-of-what-happened-when-707410475-1553724019/)

[![untitled (3)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194886324/KTmECMolg.png align="left")](https://ferrelux666.wordpress.com/untitled-3-4/)

[![untitled (4)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194888170/qJY_4EVjV.png align="left")](https://ferrelux666.wordpress.com/untitled-4-3/)

[![DressLily_NavyBlueMensShirt](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194890063/IvomQoNgz7.png align="left")](https://ferrelux666.wordpress.com/news/dresslily_navybluemensshirt/)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194891745/QRsqGUxUY.jpeg align="left")](https://ferrelux.com/adverts/)
