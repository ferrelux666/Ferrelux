---
title: "National Museum of African\U0001F3A5American History & Culture"
date: '2017-02-16T22:47:21.000Z'
slug: national-museum-of-africanamerican-history-and-culture
tags:
  - history
  - people
  - african-american
  - struggle
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195967320/jm0yvIlLu1.jpeg
canonical: 'https://ferrelux666.wordpress.com/2017/02/16/african-american-history/'
---
![black-power-with-chains-338x400](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195962454/jIfDl-qrQ.jpeg align="left")

**As a People, we now have another historic place showcasing our history. BEHOLD!**

**Opening Ceremony**  
[https://www.youtube.com/watch?v=9ZMuu5fi4Ic](https://www.youtube.com/watch?v=9ZMuu5fi4Ic)

**Heirloom Donation**

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/ELK_S_39GJQ?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

**Inside The Museum**  
[http://www.youtube.com/watch?v=cgmKAuwj3dM](http://www.youtube.com/watch?v=cgmKAuwj3dM)

**Another Inside Look**  
[http://www.youtube.com/watch?v=VTqcC7LeXBM](http://www.youtube.com/watch?v=VTqcC7LeXBM)

**Featuring Colin Powell**  
[http://www.youtube.com/watch?v=DBXmf7gk0qU](http://www.youtube.com/watch?v=DBXmf7gk0qU)

**Trump finally made an appearance**  
[http://www.youtube.com/watch?v=69XborXYkao](http://www.youtube.com/watch?v=69XborXYkao)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195963576/ec0f2f3Ms.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195965901/cI0ewtYMm.png align="left")
