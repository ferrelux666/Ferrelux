---
title: "\U0001F3C3\U0001F3FCThe Oscar Pistorius Case: Disgraced Blade Runner \U0001F645\U0001F3FC‍♀️"
date: '2013-02-27T14:28:04.000Z'
slug: the-oscar-pistorius-case-disgraced-blade-runner
tags:
  - crime
  - death
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672196196172/H5AbLYpPM.jpeg
canonical: 'https://ferrelux666.wordpress.com/2013/02/27/oscar-pistorius/'
---
[![Oscar Pistorius Is Sentenced For Killing Girlfriend](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196188068/m959Pro_2.jpeg align="left")](https://en.wikipedia.org/wiki/Oscar_Pistorius)

BY COURT ORDER, THIS IMAGE IS FREE TO USE. PRETORIA, SOUTH AFRICA – OCTOBER 16 (SOUTH AFRICA OUT): Oscar Pistorius attends his sentencing hearing in the Pretoria High Court on October 16, 2014, in Pretoria, South Africa. Judge Thokozile Masipa found Pistorius not guilty of murdering his girlfriend Reeva Steenkamp, but convicted him of culpable homicide. Sentencing continues today. (Photo by Alon Skuy/The Times/Gallo Images/Getty Images)

**I haven’t seen the conspiracy theorists jump on this yet. The only strange metaphysical thing I noticed was basically the murder occurred around Valentine’s Day & the killer’s name IS Oscar & why that is significant is because when he was released from jail people worldwide was preparing atleast in America, to view The Oscars. The timing of all that could just be coincidence, but if I were to entertain the conspiracy theory further, you’d have to look at the history of actors, singers, dancers, etc that sell their souls in the industry to get further & maybe, just maybe to be apart of the IN club, Oscar Pistorius needed to sacrifice his girlfriend as they say, a sacrifice is necessary to seal that pact. Just a thought. First, let us remember the victim…**

[http://www.youtube.com/watch?v=7VyZpwAeHwA&feature=player\_embedded](http://www.youtube.com/watch?v=7VyZpwAeHwA&feature=player_embedded)

[http://www.youtube.com/watch?feature=player\_embedded&v=q\_AvdOYVt6g](http://www.youtube.com/watch?feature=player_embedded&v=q_AvdOYVt6g)

[http://www.youtube.com/watch?feature=player\_embedded&v=bK\_T8uE40FU](http://www.youtube.com/watch?feature=player_embedded&v=bK_T8uE40FU)

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/sG5JSZEWxRA?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

**And his flimsy excuse was, he thought it was an intruder. He rose from his bed without bothering to check if his girlfriend was lying beside him. She locked herself in the bathroom.  We don’t know what happened that night because none of us was physically there, but it seems like they had a fight, A REALLY BAD ONE! This guy should have NEVER did what he did. He’s going down! He shamed double amputees EVERYWHERE. They now are going to be looked upon with suspicion. So the struggle to be treated equally & seen as equally capable is not hard to convince anymore. Too bad people have to see it this way. What a damn shame. This athlete, “little tink tink” built himself up to be a powerful Olympian, large companies sought him out to be the face of their product, he got a beautiful model/actress girlfriend to top it off, & he goes & does this. What argument or disagreement could have led murder? Reports say he & Reeva Steenkamp were only dating for little while (a few months). Just breakup with the woman, why tarnish your good name? Reports say his rage may have been due to steroids & those who knew him say he was calm & nice publickly, but privately he was short-tempered & may have been doing other drugs & had previous hostile bouts with others. Reeva’s ex-boyfriend, rugby player, Francois Hougaard has been reported to have warned Reeva about Oscar’s bad temper. This sort of case goes to show why shallow people still remain shallow with good cause. There are those women who could care less about Pistorius’ recent status, they would hold true to their prejudices & not even consider a physically damaged male as a lover, so here we have a guy who couldn’t appreciate someone thinking outside that mold & decided to take her for granted & punish her in such a cold & wicked manner. Despite the laxness of South African murder laws, the world is watching & anticipating when he’ll go to jail. There, I doubt fellow inmates would care too much about his status; he’s just another chump to push around & a dick hole to screw with.**

**~ Lhisa Mrklon**  
**Special Agent666**

![Oscar Pistorius, Blades For Feet](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196189471/Nvr4uhASk.jpeg align="left")

![Oscar Pistorius, Sunglasses](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196190905/WH9Kjic57.jpeg align="left")

![Oscar Pistorius, Running](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196192611/Q-DHAhQ96.jpeg align="left")

![Oscar Pistorius, On Trial](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196193786/F9xfd17G1.jpeg align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672196195018/GSKEph40X.png align="left")](https://voropro.com/training/get-your-real-estate-license/invite/2654/)
