---
title: "⛈Hurricane Harvey And Joel Osteen\U0001F32C"
date: '2017-08-31T19:05:32.000Z'
slug: hurricane-harvey-and-joel-osteen
tags:
  - houston
  - water
  - texas
  - god
  - hurricane
  - city
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195749695/jJ9Qd7HS5.png
canonical: 'https://ferrelux666.wordpress.com/2017/08/31/hurricane-harvey/'
---
**  
Labor Optimos Citat ⛪ Labor Summons The Best Men *(Seneca)***

\*\*  
Hurricane Harvey wreaked its havoc in Texas displacing people from their homes, reminiscent of Hurricane Katrina when it had hit New Orleans in 2005 & people were flooded out & homeless. Pastor Joel Osteen came under fire for not opening the doors of his Mega Church at Lakewood soon enough. When he came on the TV morning shows explaining WHY, the 2 excuses were that there was a homeless shelter they work with down the street & the organization later asked them to become a shelter, also he had concerns about the stadium being at risk for flooding itself. Well, the TV anchors let him off easy, but here’s what’s wrong with that. It’s not the first time storms hit Texas in general; most architects construct buildings with the threat of natural disasters in mind & he got exposed when people went around with cameras seeing how safe & dry his place was. This incident further exposes the separate world these wealthy Christians live in, but you keep giving your money to them. They don’t share the same reality as you. Poverty & being displaced from a residence is not something he needs to worry about. There is an obvious disconnect why it took him a while to help & the public criticism for him to open his doors to his huge space & house these victims. Other businesses & persons *(& not so religious)* helped without being asked to but Osteen failed to, when he’s supposed to be a leader from God, appointed to do the right thing. It didn’t need to get there. He’s a nice prosperity minister to listen to, but If you’re going to claim “GOD” then do what is expected of you when the time comes without hesitation.\*\*

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/jxxi050uuuI?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/16taTMe907k?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/Zy3ObRcLywk?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/VfBC3piYvD8?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/xD4KPxYk3nw?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

<iframe class="youtube-player" width="863" height="486" src="https://www.youtube.com/embed/QgLz9BRACj8?version=3&rel=1&showsearch=0&showinfo=1&iv_load_policy=1&fs=1&hl=en&autohide=2&wmode=transparent" style="border:0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>

**You can read more about the tropical storm here:**  
[**Hurricane Harvey**](https://en.wikipedia.org/wiki/Hurricane_Harvey)

**More broadcasting on the devastation:**  
[**ABC News Coverage**](http://abcnews.go.com/US/hurricane-harvey-wreaks-historic-devastation-numbers/story?id=49529063)

**You can draw comparisons to Hurricane Katrina in 2005**  
[**https://en.wikipedia.org/wiki/Hurricane\_Katrina**](https://en.wikipedia.org/wiki/Hurricane_Katrina)

**Sign**  
**Lhisa Mrklon**

### Was Joel Osteen More Concerned About Vanity Than Charity? Scroll Down and Leave Your Reply Below.

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195742104/7qSdkLZnJ.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195743810/jE1WTW2OS.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195745232/OTfiFJRfR.jpeg align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195746781/iNQejHXZ3.jpeg align="left")](https://ferrelux.com/adverts/)
