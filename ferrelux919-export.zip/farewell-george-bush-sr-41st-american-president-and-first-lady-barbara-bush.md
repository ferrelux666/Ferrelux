---
title: "\U0001F37B Farewell George Bush, Sr (41st American President) & First Lady Barbara Bush \U0001F491"
date: '2019-02-18T00:03:00.000Z'
slug: farewell-george-bush-sr-41st-american-president-and-first-lady-barbara-bush
tags:
  - trump
  - office
  - american
  - politics
  - cia
  - united-states
  - funeral
  - president
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195213857/U1LnpcGDg.jpeg
canonical: 'https://ferrelux666.wordpress.com/2019/02/17/president41/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195211240/yyzftA0d_.png align="left")](https://www.ferrelux.us/)

Since First Lady Barbara Bush passed away April 17th 2018, it was expected to see her beloved husband pass soon after. Now deceased (Nov 30th 2018), let’s look back and honor former United States of America, President 41, George Herbert Walker Bush on this year’s President’s Day. I miss him. As I watched all the televised funeral ceremonies with them shopping his body around to all the significant sites & the American band themes going, I was slightly thrown back in time for a few days remembering what a presidency was like. Bush Senior was fully in power when I was in high school about 27 years ago, with his reign ending in 1993, in my Junior year. He was handsome from his youth, good student, clean-cut, wholesome values, All-American, ivy league educated, nice military guy, CIA material, well-spoken, prudent, carried himself well as President, & I miss those days. For a one-term President, he felt more like a two-term. He kept the Oval Office DIGNIFIED!!! No reports about lewd sexist male remarks or actions, no treason allegations, no funding fraud, & especially no Nigrish White Trash behavior as we openly see and hear about with our current #45, President Donald J. Trump. You have to understand, I was reminiscing throughout the Bush footage with all the memorable stories. Many of the world leaders & political operatives were there to remember this man. Now look at our Oval Office. It began turning to shit when Bill Clinton won, with the Monica Lewinsky scandal still at play to this day on the airwaves, but Clinton managed to still keep the office semi-stable with some notable accomplishments. Then the country was graced again with ANOTHER George Bush, #43. He was ridiculed for being dumb, & punitive to critics, BUT the man held the country together still in a dignified way. AND THEN…….. There was ‘Black Panther’ Mr. Barack Obama himself, #44. His energy was cool, positive, powerful, & unifying despite what the haters have to say. He was a political Rock Star. The Bush funeral highlighted the end of an era for real. It saddened me. Even in death, The World was able to see that George H. W. Bush was able to powerfully & gracefully get a room filled with people who cared at the funeral & in our homes across the world to come together and reflect on politics and strategize hope for the future.

Lhisa,  
Special Agent 666

SOME LINKS  
[https://en.wikipedia.org/wiki/George\_H.\_W.\_Bush](https://en.wikipedia.org/wiki/George_H._W._Bush)

[https://www.whitehouse.gov/about-the-white-house/presidents/george-h-w-bush/](https://www.whitehouse.gov/about-the-white-house/presidents/george-h-w-bush/)

[https://www.whitehouse.gov/about-the-white-house/first-ladies/barbara-pierce-bush/](https://www.whitehouse.gov/about-the-white-house/first-ladies/barbara-pierce-bush/)

[http://www.firstladies.org/biographies/firstladies.aspx?biography=42](http://www.firstladies.org/biographies/firstladies.aspx?biography=42)

[https://en.wikipedia.org/wiki/Barbara\_Bush](https://en.wikipedia.org/wiki/Barbara_Bush)

\*\* [Barabara Bush Funeral Ceremony](https://www.youtube.com/results?search_query=barbara+bush+funeral&sp=mAEB)

\*\* [WATCH THE FUNERALS](https://www.youtube.com/results?search_query=bush+funeral)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195212709/dui701WCB.jpeg align="left")](https://ferrelux.com/adverts/)
