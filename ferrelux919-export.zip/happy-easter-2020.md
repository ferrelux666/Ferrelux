---
title: "Happy Easter 2020 \U0001F953\U0001F95A\U0001F370"
date: '2020-04-01T19:31:40.000Z'
slug: happy-easter-2020
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672194229396/Io3fpPUyg.png
canonical: 'https://ferrelux666.wordpress.com/2020/04/01/easter2020/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194211538/SFsAFsdqP.png align="left")](https://www.ferrelux.us/)

[**“Witchy Woman” – Eagles**](https://www.youtube.com/watch?v=EEOTdQznC80)

**After the holiday: Palm Sunday, Good Friday, Easter & the last day of Passover,  
I’ll post my thoughts on Covid-19.**

Hi All. Shout out to the President for wanting to honor my holy day, despite the prevailing public interest to keep almost everything shut down. Instead of putting a negative twist on Trump’s pure interest for re-election, you need to re-evaluate your economic place in the world. You can’t remain a leading nation under siege by a fucking virus & expect to rule over other nations. You need your economy going again. So anyway, contrary to how you may have been brought up, Easter has nothing to do with Jesus Christ. The holiday is called Easter, an ancient celebration rite named after me, The Goddess: Istr, Ishtar, Asherah, Eostre, Ostara, Ashdar, Ashtoreth, Venus, Neith, etc. My more ancient name Inanna. I was a popular goddess known by many names, and seen by the biblical God as a threat to his worship also, amongst other gods/demons like Dagon, Mammon, and the rest of them, who were the chief deities honored in many of the lands at the time. So when you honor Jesus, perverting his story around this time, not respecting his real story, and choosing NOT to represent the authentic Christian experience, as The Maker outlined for you in his Holy book, then you missed something crucial. You see, it’s all “Pagan”, but you can keep honoring me in his place though. Lucifer & I enjoy that. Oh by the way, before Jesus came here, I had 12 temple hand maidens serving me, I cared about people, cities, & just rulership. I also died, went to The Underworld & rose in 3 days. There are all kinds of tales about me, but believe the right ones. Oh and before Jesus came to Earth, Mithra was a famous sun god, born of a virgin. He also died & rose on the 3rd day. His birthday is celebrated December 25th. So you need to figure out when YOUR Jesus was actually born. Some scholars think it was in September, but others think it was in April, according to a Hebrew/Jewish Calendar at the time of The Scriptures astrologically making The Savior, an Aries. But anyway, I’m not in the business of helping you people. I see why your God insults & punishes you at times for your religious indiscretions.

Sign,  
The Goddess of Antiquity

### Should Christians Of Any Denomination Be Using The Ancient Sumerian Holiday Of Easter To Celebrate Jesus Still? Scroll Down And Leave Your Reply Below.

[![440px-Ishtar-star-symbol_svg](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194212889/L2xT-X8Sa.png align="left")](https://ferrelux666.wordpress.com/440px-ishtar-star-symbol_svg/)

[![Lhisa Mic Pose](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194214424/YJRbhB66r.png align="left")](https://ferrelux666.wordpress.com/lhisa-mic-pose/)

[![Ferrelux Homepage_Easter2020](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194216071/uVnbtQQUZ.png align="left")](https://ferrelux666.wordpress.com/2020/12/24/goodbye-2020/ferrelux-homepage_easter2020/)

[![Ishtar on an Akkadian Seal](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194217785/FUmxUyOiA.jpeg align="left")](https://ferrelux666.wordpress.com/ishtar-on-an-akkadian-seal/)

[![Ishtar Animation In Action](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194220096/9LRaATomG.png align="left")](https://ferrelux666.wordpress.com/ishtar-animation-in-action/)

[![Ishtar Animation Pose](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194221743/0ps8pVQ0s.png align="left")](https://ferrelux666.wordpress.com/ishtar-animation-pose/)

[![Ishtar Follows Sumerian War Plaque](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194223312/4uOZasVul.jpeg align="left")](https://ferrelux666.wordpress.com/ishtar-follows-sumerian-war-plaque/)

[![Ishtar Mistakenly Referred to as Lilith](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194224521/UFwUms68N.gif align="left")](https://ferrelux666.wordpress.com/ishtar-mistakenly-referred-to-as-lilith/)

[![Moon Goddess](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194226088/bwMc1S0xa.png align="left")](https://ferrelux666.wordpress.com/news/moon-goddess/)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194227453/G9flkJoWL.jpeg align="left")](https://ferrelux.com/adverts/)
