---
title: "Happy New Year 2018 \U0001F9E8\U0001F386✨"
date: '2018-01-05T21:12:11.000Z'
slug: happy-new-year-2018
tags:
  - performance
  - eve
  - fireworks
  - celebration
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195628271/Lx48aBVZM.png
canonical: 'https://ferrelux666.wordpress.com/2018/01/05/new-year-2018/'
---
![happy-new-year-2017-wallpaper_8-700x438](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195622585/CZ1Z4bUVC.jpeg align="left")

**Quod Est Opus Tuum Anni Resolutio? 🎄 What Is Your New Year Resolution?**

Maybe the better practice is not to even bother trying to make one. How many people actually fulfill them?

Sign,  
Lhisa

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195624027/9qmQ6imMr.png align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195626018/k_vts-ySt.jpeg align="left")](https://ferrelux.com/adverts/)
