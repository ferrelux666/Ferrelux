---
title: "⏳Jeopardy’s G.O.A.T Tournament Winner\U0001F9E7"
date: '2020-01-24T20:45:51.000Z'
slug: jeopardys-goat-tournament-winner
tags:
  - challenge
  - blog
  - contest
  - talent
  - tv
  - money
  - smart
  - great
  - tournament
  - genius
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672194448917/sf2v__R5I.png
canonical: 'https://ferrelux666.wordpress.com/2020/01/24/goat/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194427896/D5s8pmBpp.png align="left")](https://www.ferrelux.us/)

[**Faith No More ~ “Epic”**](https://www.youtube.com/watch?v=ZG_k5CSYKhg) *( This tune is more meant for Brad Rutter 😆 )*

Qui Maior 🤴🏻 Who’s The Greatest?

So 2020 kicked off with a promise from last year to see, Brad Rutter, Ken Jennings, & James Holtzhauer face off for the title. Each one of them with his own stellar record from playing Jeopardy over the last 15 years. Brad Rutter with the most money earned, over 4 million, Ken Jennings with the most strategic plays, and James Holtzhauer with the most wins, having 32 straight ones until Emma Boettcher, beat him back in June 2019, but in ‘The Tournament of Champions’, he defeated her in November and qualified for Jeopardy’s ‘Greatest Of All Time’ Tournament this year. And we now know WHO that is. The challenge took place before and the Winner kept it a secret for a month. So the show aired on ABC Tuesday January 7th.  At the start, it was any Man’s game until we started seeing who the 2 Head Runners would be. Ken Jennings won the first game both times with his winnings totaling over 63k points in that hour with his first checkmark in place, since the first player to win all 3 games, wins the tournament, and these were hard questions. Then the next day James Holtzhauer won his set with over 82k points. Then the third game, Ken Jennings won with over 63k points. So what happened to Brad Rutter? Well, when you are playing against people over the years that aren’t that challenging to you, then end up in a real testing situation, people get to see the dumber side of you on live TV. It was embarrassing, this guy kept ending up in the negatives answering wrong on plain questions AND the Daily Doubles. He handled his own disappointment well though. Obviously, he’s a SMART guy to even be in the tournament though. His only chance was winning at least one game in a long shot, and then another to come in the running, but that didn’t happen. But, we went into the following week anyway with a 4th game which aired Tuesday January 14th, since Ken won 2, & James won his first and could very possibly win again forcing a 5th game. So this was a real face-off due to chance since either one of them was close to winning. The host Alex Trebek even said he brought the trophy out that night just in case. Ken Jennings kept getting the Daily Doubles & risked everything correctly most of the time. James Holtzhauer for the first time, got into the red, answering incorrectly and getting negative points. And on the final question, Ken Jennings WON by strategy risking ZERO points of his over 83k total when he gave his answer, which turned out to be correct. He won the trophy and 1 Million Dollars. The other 2 players received $250,000 for just competing in the tournament. It was fun watching. Oh & yes, I was able to answer a few of those difficult questions. I always do when I watch that show. So here’s YOUR Jeopardy Answer………

“This phenomenal Blogger, exposes what’s really happening in the world in a way others are not telling you, with her candid opinion, a fitting Latin phrase & a matching song on her ad-funded platform Ferrelux.”

**Question: Who Is Lhisa?**

\*\*SOME LINKS  
\*\*[James Holtzhauer Beats Emma Boettcher](https://www.google.com/search?source=hp&ei=9VQrXuy2C4qO5wKto4DQDA&q=james+holzhauer+beats+emma+boettcher+in+%E2%80%98jeopardy+%E2%80%99+rematch&oq=james+holtzhauer+beats+emma+b&gs_l=psy-ab.1.0.0i13.8810.30767..33970...1.0..0.404.5673.5j16j5j4j1....2..0....1..gws-wiz.....6..0i362i308i154i357j0i131j0j0i13i5i30j0i8i13i30j0i5i30j0i8i30j0i13i70i251.ITk0289g2Ro#spf=1579908873595)  
[View Highlights of the Jeopardy G.O.A.T Tournament, Jan/2020](https://www.youtube.com/results?search_query=jeopardy+greatest+of+all+time)

**Sign,**  
**Lhisa Mrklon**

### Did You Thoroughly Enjoy The Jeopardy G.O.A.T Challenge? Scroll Down And Leave Your Reply Below.

[![Ferrelux Homepage_Jan2020JeopardyGOAT](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194429258/07bUroolH.png align="left")](https://ferrelux666.wordpress.com/2020/12/24/goodbye-2020/ferrelux-homepage_jan2020jeopardygoat/)

[![Ken Jennings Won The Trophy](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194430494/J1RWO8RQe.jpeg align="left")](https://ferrelux666.wordpress.com/ken-jennings-won-the-trophy/)

[![Jeopardy G.O.A.T Tournament Begins](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194431895/JqQ56oZof.jpeg align="left")](https://ferrelux666.wordpress.com/jeopardy-g-o-a-t-tournament-begins/)

[![JeopardyGOATTournament_NonFeat_Getty_Ringer](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194433148/VG61rCmmA.jpeg align="left")](https://ferrelux666.wordpress.com/jeopardygoattournament_nonfeat_getty_ringer/)

[![Jeopardy G.O.A.T challenge Feature](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194434357/KMZWa4HcM.jpeg align="left")](https://ferrelux666.wordpress.com/jeopardy-g-o-a-t-challenge-feature/)

[![Ken Jennings Gets It Right](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194436218/rOb57H2Pq.jpeg align="left")](https://ferrelux666.wordpress.com/ken-jennings-gets-it-right/)

[![Ken Jennings Wins](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194437663/ar63yKJiM.jpeg align="left")](https://ferrelux666.wordpress.com/ken-jennings-wins/)

[![Jeopardy G.O.A.T Comp Ad](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194438932/RRyB-juFs.jpeg align="left")](https://ferrelux666.wordpress.com/jeopardy-g-o-a-t-comp-ad/)

[![James, Ken, And Brad Group Shot](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194440417/8UwvU3onU.jpeg align="left")](https://ferrelux666.wordpress.com/james-ken-and-brad-group-shot/)

[![jeopardy-goat](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194441533/Mhl6oNace.jpeg align="left")](https://ferrelux666.wordpress.com/jeopardy-goat/)

[![James Holtzhauer, Brad Rutter, Ken Jennings On The Jeopardy Set](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194445336/jt8fEY2q1.png align="left")](https://ferrelux666.wordpress.com/james-holtzhauer-brad-rutter-ken-jennings-on-the-jeopardy-set/)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194446941/98FHOyGie.jpeg align="left")](https://www.usgrants.org/sign-up?affiliate=134980)
