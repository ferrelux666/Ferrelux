---
title: "Happy Easter (2019) \U0001F430\U0001F95A\U0001F36D"
date: '2019-04-12T22:24:57.000Z'
slug: happy-easter-2019
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672195128569/Z69Jvj8dW.jpeg
canonical: 'https://ferrelux666.wordpress.com/2019/04/12/easter2019/'
---
\*\*

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195122126/lLC8oMcs2.jpeg align="left")](https://www.ferrelux.us/)

  
\*\*

Playlist ~ [Easter Songs](https://myspace.com/ferrelux/mixes/easter-718845)

***Well,* I still have more stories to cover after the Easter Break. I’d love to get to some current events in the news and establish my take on it. I will be mixing some old news coverage in with a new update on some stories as they still play out in the news why I haven’t touched it yet.  
………….Stay Tuned…………**

**LHISA,**

[![background-lighting-rain-storm-Favim_com-4315167](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195123368/ofeb4lejS.jpeg align="left")](https://ferrelux666.wordpress.com/background-lighting-rain-storm-favim_com-4315167/)

[![fbe132bac169ff0a1408550fc4dec98c--storm-xmen-comics-toons](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195124714/k24qo-U56.jpeg align="left")](https://ferrelux666.wordpress.com/fbe132bac169ff0a1408550fc4dec98c-storm-xmen-comics-toons/)

[![X-Mens-Storm-Comic](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195126071/DmaXY_pdJ.jpeg align="left")](https://ferrelux666.wordpress.com/x-mens-storm-comic/)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672195127476/9hvdPzEF1.jpeg align="left")](https://ferrelux.com/adverts/)
