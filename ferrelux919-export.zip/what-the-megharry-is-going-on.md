---
title: "What The Megharry Is Going On? ☃\U0001F320\U0001F3D6"
date: '2021-05-27T00:41:24.000Z'
slug: what-the-megharry-is-going-on
tags:
  - conspiracy
  - garden
  - france
  - politics
  - accident
  - america
  - california
  - meghan-markle
  - hollywood
  - investigation
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672193057448/GDmwawGBX.jpeg
canonical: 'https://ferrelux666.wordpress.com/2021/05/26/parenting-harry/'
---
[![Princess Di](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193018366/6vTCnocUo.jpeg align="left")](https://www.rd.com/list/princess-diana-death-conspiracy-theories/)

\*\*[“Gypsy Magic” – Taureau](https://www.youtube.com/watch?v=Ss0kNti_4d0)  
\*\*Quoniam Vivo Filii Mei, Non Tollitur Sine Eis 😥 I Live For My Sons, I Would Be Lost Without Them. (Princess Di)

Before May ends, which is sad that the prevailing social politics feels it has to name it Mentally-Ill Month, I have to give the award this year around to The Duke & Duchess of Sussex. Disgraced Couple Prince Harry & Meghan Markle have been going about town talking about their problems garnering little to no sympathy from The Public At Large and people are fed up of them. Almost everyday there’s a new Brit on the airwaves with their take on it, followed by the insults of Americans who agree posting on the videos. People are out here suffering and dealing with their non-prestigious problems, and don’t need to hear about the woes of your privileged life Harry on a cheap podcast. If I’d grew up in the opulence like you, I would bloody well know what to do with it and how **\_***to handle***\_** the problem. First of all, what you’re complaining about it typical. Parenting is not a perfect art. Many families out there have particular problems to cope with and it can be artful in how a person deals with it. What I would say in your case is that there are certain crucial points you’re not hitting on with your Mother’s experience in The Royal Family and everything surrounding it, which I won’t cover. Now, if you were really unloading on the truth of all that and how it really affected **you** trying to process that growing up and being so powerless to address The Potentates behind it, then you would have our interest. The reason why your brother William is dealing with it so well is not so much because he’s older, but more that he’s a different person than you. How do you know that he’s not feeling it too, and is just calculating? I’m looking at your situation and the rest of them, and am seeing the problem play out. It’s a shame that Meghan and her family got mixed up in it though and are now permanently involved. You & Meghan running away over here will not free you from it. What you should have done was studied a bit more. Yes you feel slightly freer now, but it’s an illusion. Remember you’re not that little boy anymore “trapped” within The Regal System having to accept what happened. There are solutions. The right training and counseling from the right person would have helped you. Instead of trotting around complaining to Commoners, you would have operated shrewdly and garnered some powerful slick allies, figured out a way to turn the tide, reclaim a station of high honor and right a terrible wrong using your might. My thoughts are currently on William as the one.

Sign,  
Lhisa Mrklon  
Dark Mistress Of Power

**Should Harry & Meghan Be Frolicking Amongst The Common Folk Pretending To Be Under-privileged Like Them? Scroll Down And Leave Your Reply Below.**

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193019884/WtfM3YJuU.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193021263/bMZhGV1Cw.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193023073/pJ-agft2l.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193024535/oZ0tXufc0.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193026238/STKJJC0Wp.jpeg align="left")

Britain’s Prince William, Duke of Cambridge (3L) and his wife Britain’s Catherine, Duchess of Cambridge (2R) talk with his father Britain’s Prince Charles, Prince of Wales (R) and his wife Britain’s Camilla, Duchess of Cornwall (2L) during their visit to the Defence Medical Rehabilitation Centre (DMRC) in Loughborough, central England on February 11, 2020. – The DMRC currently provides services to a small group of veterans in the form of the Complex Prosthetic Assessment Clinic (CPAC), which is a joint MOD and NHS England commissioned outpatient clinic. (Photo by Richard Pohle / POOL / AFP) (Photo by RICHARD POHLE/POOL/AFP via Getty Images)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193027485/_sBc7Ikfx.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193028566/g_aL4c374.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193030006/O1ujasLpy.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193031648/deMG-9g7C.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193033533/i5tscff3Y.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193035097/6aqjmjEbv.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193036268/77lndkBsR.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193037635/2KISAU9cF.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193038866/7a7wro9yX.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193040439/V3OspwONS.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193041772/L8ba8fZiY.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193042874/mGOD-_gzU.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193043989/6pMoppb6P.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193045669/FB0Fq2yaV.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193046977/urfFJl5A6.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193048201/zNTYAdb2K.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193049426/0ubzywvUb.jpeg align="left")

LONDON, ENGLAND – MARCH 15: Catherine, Duchess of Cambridge and Prince Charles, Prince of Wales visit The Prince’s Foundation for Children and The Arts at Dulwich Picture Gallery on March 15, 2012 in London, England. (Photo by Danny Martindale/WireImage)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193051302/EEks2kmih.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193052950/slnrl4cRl.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193054281/8RsbBkm3u.jpeg align="left")

\*\* FILE \*\* In this file photo dated Aug. 31, 2007, Britain’s Prince Charles, left, Prince Harry, center, and Prince William, right, arrive for the Memorial Service for Diana, Princess of Wales at the Guards’ Chapel in central London. Princes William and Harry said Tuesday, Jan. 6, 2009 they have been granted their own royal “household” by their grandmother, Queen Elizabeth II. The household the two princes will share will have three main staff members, supported by a “small” team. (AP Photo/Leon Neal, Pool-File)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193055879/vbFgNF5-O.png align="left")](https://voropro.com/training/get-your-real-estate-license/invite/2654/)
