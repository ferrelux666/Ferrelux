---
title: "The Death Of Prince Philip & DMX \U0001F356\U0001F3F0\U0001F3CD"
date: '2021-04-13T17:32:46.000Z'
slug: the-death-of-prince-philip-and-dmx
tags:
  - interview
  - canada
  - online
  - internet
  - legacy
  - greece
  - dogs
  - american
  - scotland
  - x
  - meghan-markle
  - funeral
  - death
  - black
  - city
  - megyn-kelly
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672193187424/kqb72meqO.jpeg
canonical: 'https://ferrelux666.wordpress.com/2021/04/13/duke-dmx/'
---
[![Britain's State Opening of Parliament](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193147239/7iyNKGN52.jpeg align="left")](https://www.bbc.com/news/av/uk-10648666)

Queen Elizabeth II sits with Prince Philip in the House of Lords during the State Opening of Parliament.

Vivat Regina 💞 Long Live The Queen  
\*\*  
[Aaliyah ft DMX – “Back In One Piece”](https://www.youtube.com/watch?v=rMPKeG_j7QY)  
[God Save The Queen](https://www.youtube.com/watch?v=D3dR7u7TPNo)\*\*  
[**Prince Charles Talks About His Dad**](https://www.youtube.com/watch?v=XYYT-PBEey4)  
[**DMX’s Prayer To God**](https://www.youtube.com/watch?v=82PfMsaCOQI)

Hmm, ain’t it odd that Prince Philip (99) and Dark Man X (50) both died on the same day, April 9th? Also on that date, Prince Charles inherited his father’s Title as The Duke Of Edinburgh. The man simply known by the Roman numerals DMX, was also known for his command holding 2 wild dogs at bay, very reminiscent of the African War God Ogun. DMX & Prince Philip’s lives were ever so different, but some similarities are there. While Philip was born into royalty with the lifestyle and power, DMX’s birth name was Earl, also a royal title where in life he himself proved to deal with much adversities handling himself as his own Sovereign. And in doing so, attracting well, you know, it’s no secret that “some people” were trying ever so hard to kill him over the years simply because he refused to fall in line being their industry slave. In youth, Prince Philip had his royal chiseled features attracting interest, and DMX, a nice looking brother, had that striking presence in a place when you saw him. I don’t dig a lot of his raunchy rap lyrics, but the hooks were great. He brought the hood showmanship on stage and kept it real. He had that Rottweiler voice. DMX also had a strong interest in God and often prayed to Him. Where Prince Philip is concerned, he was very ill on his deathbed in a hospital, and during that unfortunate time, Prince Harry & his wife Meghan decided to interview with Oprah and disclose some troubling royal family issues. Now, I didn’t think it was cool, but I sensed some deeper problems as to why they would do it at that time, as bad as it was. How things were supposed to go is like this. After the royal wedding, and birth of Archie, and so on, as a royal couple they were expected to merrily live the life serving The Queen. Not have a fallout. It really doesn’t look good. Now I’m not a Conformist at all, I have my own rebellious ways, just shrewdly done in a suitable fashion. I expected there would be some problems with them over there, but not extending to such a decline. Personally I don’t think Meghan belonged there. And in the little Pro-Black circles on the internet, they’re seeing her as a negro Bed-Wench who married some freckled-faced Overseas Colonizer. They do not have the nicest things to say about you. And I wonder what the hell did these White People from The Firm say about you behind The Palace walls because it couldn’t compare to the rawness of your own people insulting you. I’m just being real with you. Prior to the explosive interview, we were hearing stuff and seeing signs of a crack in that whole thing and while some of us were still hopeful for you, others were just waiting for the failure so they can unleash a slew of racist things because they felt you should have married a Black Man. Listening to some of the stuff and the commentary, you’re lucky that they’re still choosing to not dwell too much on it with the ratchetness, only alluding to the fact that you got your Nigger come up, but then played yourself. The whole thing may have been Prince Harry’s idea to do The Royal Exit, but it looks really bad on you though. And one of your biggest critics is Piers Morgan, someone I’ve paid attention to over the years enough to recognize his antics. You see just a couple weeks before this Oprah interview, someone happened on a few comments I made on Youtube about someone popular embattled with legal issues and the person began attacking me on my points. As I countered this person tit for tat, I could tell from the behavior & style of writing who it might be, and if he kept coming, I was going to playfully allude a couple things letting him know. So I relate my own anecdote to suggest that people are entitled to their own opinions and to freely express them publickly or privately with you and running to complain about it and get the person fired isn’t cool. I happen to agree with him and other Brits about how out of order it was to embarrass The Royal Institution like that. I’m not exactly on their side either, but YOU didn’t belong there. You just don’t enter into a complex situation like that without the proper knowledge or preparedness, especially when there are known problems. Some of the stuff you said in that interview is questionable, and has already been disproven. If Prince Harry fell in love with a slightly darker-skinned woman who was thoroughly raised in England and is aware of royal protocols, the situation may have went better. A royal riff probably would not have happened. There are Darkies out here that encounter racism regularly and we have our own cute and classy way of dealing with it and winning. I remember in finer times when you were touring with Harry in Africa, some guy out there told the press that you should stop referring to yourself as Black because the people out there don’t really see you that way. If you were some tar-colored girl with kinky hair trying to make your way in life, your complaints would be more believable. And yet you’re out there as if you’re really suffering when girls who look like you typically do quite well in life within a racist system since slavery. And I agree with Tucker, who nicely criticized you, and some of what Megyn Kelly had to say. And if you keep complaining, it won’t be long until some hard-core ghetto girls living in the dark recesses of their neighborhoods start reading you too, and bluntly letting you know that you don’t really have a real problem compared to them getting into fights, dodging bullets in The Hood, being somebody’s baby mama, beefing with Hoodlums, dealing with a drug habit and getting in and out of jail. After a while, you’ll start looking like a fool who got ahead tremendously in life, but messed yourself up, rather than being seen as some poor victim of racism. The Royal Institution did let you in to marry Prince Harry, and they accepted you though you didn’t fit the standard of what was proven to work in the past, and any slight issue you had should have been privately and tactfully addressed with The Firm. And maybe you both did all that to no avail, but the current moves you’re making don’t look right. And I understand that you aren’t used to the British lifestyle, history, mannerisms, pomp and finery, but some of us out here are from certain parts of the globe, having a pretty interesting background where in one sense the person seems like a Commoner living humbly, but has traceable roots going all the way back to some kind of Nobility, and *the person* carries within, a rich legacy for The World to see when the time comes.

**Meghan & Harry**  
[https://www.youtube.com/watch?v=EXpFFFCvcH4](https://www.youtube.com/watch?v=EXpFFFCvcH4)   
[https://www.youtube.com/watch?v=ff3F8MwZebA](https://www.youtube.com/watch?v=ff3F8MwZebA)   
[https://www.youtube.com/watch?v=DVxhRZnp8Io](https://www.youtube.com/watch?v=DVxhRZnp8Io)  
[https://www.youtube.com/watch?v=Lc7o7ZB1Cow](https://www.youtube.com/watch?v=Lc7o7ZB1Cow)   
[https://www.youtube.com/watch?v=sG9rX6Ifzhw](https://www.youtube.com/watch?v=sG9rX6Ifzhw)

**Some Prince Philip & DMX Info**  
[https://en.wikipedia.org/wiki/Prince\_Philip,\_Duke\_of\_Edinburgh](https://en.wikipedia.org/wiki/Prince_Philip,_Duke_of_Edinburgh)   
[https://en.wikipedia.org/wiki/Duke\_of\_Edinburgh](https://en.wikipedia.org/wiki/Duke_of_Edinburgh)   
[https://en.wikipedia.org/wiki/DMX\_(rapper)](https://en.wikipedia.org/wiki/DMX_(rapper))   
[https://en.wikipedia.org/wiki/Earl](https://en.wikipedia.org/wiki/Earl)

**Some Prince Philip Videos**  
[https://www.youtube.com/watch?v=2xwhKTlrn\_s](https://www.youtube.com/watch?v=2xwhKTlrn_s)   
[https://www.youtube.com/watch?v=KTDwsXCoGE0](https://www.youtube.com/watch?v=KTDwsXCoGE0)   
[https://www.youtube.com/watch?v=XM0gsqNoYwg](https://www.youtube.com/watch?v=XM0gsqNoYwg)   
[https://www.youtube.com/watch?v=v61JI6h423E](https://www.youtube.com/watch?v=v61JI6h423E)   
[https://www.youtube.com/watch?v=uU77QhJSkYY](https://www.youtube.com/watch?v=uU77QhJSkYY)   
[https://www.youtube.com/watch?v=l–mv-tlV6g](https://www.youtube.com/watch?v=l--mv-tlV6g)

**Some DMX Videos**  
[https://www.youtube.com/watch?v=8XUpKjAx7qc](https://www.youtube.com/watch?v=8XUpKjAx7qc)   
[https://www.youtube.com/watch?v=ugX8D-Rw2PY](https://www.youtube.com/watch?v=ugX8D-Rw2PY)   
[https://www.youtube.com/watch?v=3HcdYNPVWhA](https://www.youtube.com/watch?v=3HcdYNPVWhA)  
[https://www.youtube.com/watch?v=6QTveSlPtWQ](https://www.youtube.com/watch?v=6QTveSlPtWQ)   
[https://www.youtube.com/watch?v=ljqyZaM5lUk](https://www.youtube.com/watch?v=ljqyZaM5lUk)   
[https://www.youtube.com/watch?v=mIRsdGX\_J-E](https://www.youtube.com/watch?v=mIRsdGX_J-E)

Sign,  
Lhisa Ungelis Mrklon

**Should Meghan Markle Have Even Married Prince Harry At All When The Suspicions & Racial Tensions She’s Complaining About Were There From The Beginning? Scroll Down And Leave Your Reply Below.**

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193148806/v7QGCNLZm.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193150299/iSYtRw0-P.jpeg align="left")

Queen Elizabeth II sits with Prince Philip in the House of Lords during the State Opening of Parliament. (Photo by © Pool Photograph/Corbis/Corbis via Getty Images)

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193151795/BthVNJW9C.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193153088/CwhfMsXZN.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193154268/_7n6dW0xw.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193155334/sE_scaHkD.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193156663/V8dBs_UYj.jpeg align="left")

WINDSOR, ENGLAND – JULY 22: Prince Philip, Duke of Edinburgh during the transfer of the Colonel-in-Chief of The Rifles at Windsor Castle on July 22, 2020 in Windsor, England. The Duke of Edinburgh has been Colonel-in-Chief of The Rifles since its formation in 2007. HRH served as Colonel-in-Chief of successive Regiments which now make up The Rifles since 1953. The Duchess of Cornwall was appointed Royal Colonel of 4th Battalion The Rifles in 2007. (Photo by Samir Hussein/ Samir Hussein/WireImage )

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193157731/pHiUMaRhu.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193158895/nEx4yuHUN.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193160132/E4gUcz8gN.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193161410/wGdgYLDng.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193162817/4Eu3nGF5z.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193164014/UWcI0rRvt.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193165766/5hKEvs5fH.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193167486/-64CZKwJA.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193168867/w-wOr-5Pv.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193170215/VkM-lCVBO.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193171372/kVOQSR0hP.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193172691/MLRoTxqM1.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193173773/PRvA_q6NQ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193175177/Mv3YcZtkn.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193176561/4tDRVayHm.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193177924/zZARmcM2b.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193179470/w4zOZH_oy.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193181279/ROZQasacQ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193182952/s8RiyzLOP.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193184171/CqxJK4bY2.jpeg align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193185489/mUlWpqWhq.jpeg align="left")](https://www.discovercars.com/?a_aid=Ferrelux)
