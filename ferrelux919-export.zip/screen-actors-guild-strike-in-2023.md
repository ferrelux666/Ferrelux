---
title: "\U0001F603 Screen Actors Guild Strike In 2023 \U0001F61E"
date: '2023-08-02T00:57:36.558Z'
slug: screen-actors-guild-strike-in-2023
tags:
  - sag
  - hollywood
  - actress
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1691187482550/8c6a6887-ce09-4d2d-a4c0-a6dc2ce8c15d.jpeg
---
**Tres, Duo, Unus, ACTIO 🎬 Three, Two, One, ACTION!**

[**Lisa Simpson ~ Union Strike Song (Protest)**](https://soundcloud.com/hasan-mahameed/lisa-simpson-union-strike-folk-song-protest-song?utm_source=clipboard&utm_medium=text&utm_campaign=social_sharing)

***👉* I CONCLUDED MY PIECE ON THE FBI IN ‘THE SCAM’ SECTION.** [**CHECK IT OUT.**](https://ferrelux.com/the-fbi-a-national-security-threat)

✍️ Update: [After 148 Days, The Writer’s Strike Is Over](https://www.npr.org/2023/09/26/1201936449/writers-strike-end-vote-wga-leadership)  
**👱‍♀️ Update:** [Three's Company Star, Suzanne Somer's Died Sunday Oct 15 At Age **76**](https://www.aol.com/lifestyle/suzanne-somers-threes-company-step-194020168.html)

First off, **The Rock** stepped up contributing over 7 Figures to SAG-AFTRA to help the Actors and many are grateful for that. Hollywood has had financial trouble before going all the way back over a century ago when Actress Mae West and her crew of Black Entertainers bailed out The Industry from collapsing with just their sheer talent, and it paved the way for other Legends we know now. I guess a Union will always be there, but how it used to be was working with The Studios who created and produced the material. It was how many Actors got their education too. It was direct. There’s nothing wrong with that. And some form of it still exist Today. Being a Non-Union Actor has its benefits. There are people who are doing quite well functioning this way. The option to join The Union is always there. In some cases that goes well, in others, they wish they never joined because they can’t partake in acting jobs that offer better exposure & pay. A solution for that while being in The Union is having a Fi-Core status, where you still pay to be there, but you’re also doing Non-Union stuff and the unionized Industry frowns on that. There are some Actors who were Top in their day now using Fi-Core to work after being blacklisted in a way or put on The Shelf. You’ll see those Actors Today making the rounds in some innovative circles doing quite well without Hollywood being in The Picture. If The Industry wants you in their project and you’re a Non-Union Person, they waive the fee required, and if you’re lucky, they might do it a 2<sup>nd</sup> or 3<sup>rd</sup> time, but that’s it. They expect you to join. Though you supposedly have a lot to gain by being in a Union, you also give away a lot of your rights & liberty. Everything might go well as long as you’re a darling in The Industry until you make a stand on something they don’t like or do something they don’t approve of. In some cases, you may not even be in a Union, but one of their people is watching you and they’ll be signs of that. Their way of operating is like a Cult and they’re connected to powerful people. It’s unfortunate that some people sell their soul and are willing to turn tricks or engage in other immoral conduct just to get in Hollywood at the highest levels whether they’re talented or not, while Others rough it staying in our own corners contently building and promoting ourselves till some auspices lift us to the next level. If you’re out there in the Entertainment Field trying to make it, you’ll have to decide whether you want to give them all that money every year and be owned having to follow their rules until one day they decide to cast you into something and decide how much you should earn in the caste system and so forth, or you can learn the business on your own, make wise decisions, work with the right people, and earn as much as you want, and manage your legal affairs. The only thing that can go wrong with that is a Cabal noticing you and your talent while you’re quietly building yourself, they'll study you, and see the impact you’re making with that low-budget shit you’re doing, and be conflicted with their own agenda and prejudice as they’re not quite sure what to do with you.

Sign,  
Lhisa Mrklon  
🎥 🎭 📜 🎤  
. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .🤣 [***See My Prior Article***](https://ferrelux.com/the-fbi-a-national-security-threat) 👮 ⬅️ 🐰🥚🐇 ⬇️ 👀

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1691640608617/e913ec5a-61ad-4aad-8c4b-c20047d1c472.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1691640307233/11b64bf3-82ed-4324-b273-4f58c3f0c337.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1691642316904/2a055ecb-9332-4bbd-bd1e-0397cf99be84.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1693369250694/57913bdd-9bd8-4c91-ba4c-ca84e43f2c73.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1693369272641/a3724520-8b17-42ef-8d08-b6f0cbd27e36.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1693369516505/4fe4cbbe-958e-4d50-9aa7-e46767557a65.png align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1696214862807/2bdc6f07-dc22-45cf-bdb2-9fb780ac5e6e.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1694327657227/1416577b-3f49-47ce-b193-aae54a2d1e18.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1699563438916/5e435dd6-b12e-46f8-bc4d-a5da836d9229.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1693943368729/55792617-714c-466c-9905-31e5bee11040.png align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1691967226733/6358f9c4-4ea3-427b-bada-2fa31f738767.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1691967641997/9d92e1e4-a84b-4ef1-9761-4a2823e1c3d9.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1693941703053/1703019a-5100-4da6-b30a-739d4912e7a1.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1691735995158/44273735-0354-4840-8f07-d7056598a734.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1691736026329/48fdbc40-1b12-43d9-b4c3-adde5ca2ddb4.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1693942347135/f6ba27ef-5c03-4410-9dbb-3d7fa8c0c19b.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1694327297214/de2a0168-0da7-4db0-b6c0-5ae12354b376.png align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1696216066605/1725e4e6-cc4a-42b2-9510-d94149b7fdfa.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1691189630777/a6a50fc0-a812-4546-89a4-2713f7979787.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1693944275722/c212abae-7da5-4091-90af-2d73fc1b8c21.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1691640909210/3da3b99e-ec7d-4aa3-ad5c-2fcca67d849f.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1694328134541/07d180f8-637b-4b55-a176-933b7269296b.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1692160309923/205718b7-7068-4b73-a39b-9d32bd119ee4.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1693942711576/5f500cf3-2915-471d-bf47-6e08b02cc3dc.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1696218634574/c32dd572-dc30-4056-8110-c486662a6852.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1692160326912/94e541de-c227-4a9d-83c8-c77e381bb961.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1691189657921/ee3d3a26-6595-453c-bfa1-80a6485ca479.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1691733265008/ac321bb0-55bc-450c-9e0e-62700451754d.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1696217832503/4193a9f5-02d0-4472-8890-d40039308992.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1693368687522/ba898558-dcf1-4012-911d-84c70850234c.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1691641461192/db0acf58-55a1-475d-9671-6444cc94ef46.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1691641475277/5f4651b3-550a-4267-951f-0c7d2ffb0d44.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1691968250092/64519c45-2f9e-457f-9d17-9b81a06a3a16.jpeg align="center")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1691968273222/c4a3d156-ae56-41f3-b901-b16829392c2a.jpeg align="center")

🤣 [***See My Prior Article***](https://ferrelux.com/the-fbi-a-national-security-threat) 👮 ⬅️ 🐰🥚🐇 ⬆️ 👀
