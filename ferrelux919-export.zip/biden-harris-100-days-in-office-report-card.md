---
title: "Biden-Harris 100 Days In Office Report Card \U0001F4D3\U0001F325\U0001F370"
date: '2021-04-27T20:22:17.000Z'
slug: biden-harris-100-days-in-office-report-card
tags:
  - virus
  - chinese
  - vp
  - government
  - china
  - politics
  - plane
  - immigrants
  - america
  - biden
  - meghan-markle
  - president
  - mexico
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672193140293/RgSADFSLs.png
canonical: 'https://ferrelux666.wordpress.com/2021/04/27/biden-100/'
---
[![The Biden Harris Administration](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193106606/7TNVfsslg.jpeg align="left")](https://www.cnn.com/2021/04/28/politics/president-biden-first-100-days/index.html)

\*\*[“Freedom” – Pharrell Williams](https://www.youtube.com/watch?v=LlY90lG_Fuw)  
\*\*

Est Pater Meus Numquam Desiderari Concursum 💯 I Never Missed A Rally For My Dad (Hunter Biden)

Since your election as Potus 46, you’ve been eager to get your team into The White House despite fierce opposition, and this shows a pro-active Leader’s desire to take command of a situation. And once you entered, you wasted no time in setting forth new policies and reversing old ones. You called up The World Leaders letting them know that America Is Back! You and your VP Kamala Harris make considerable use of social media, posting your accomplishments and motivational initiatives. And all along the way, your political enemies were looking for the slightest mis-policy or mess up and amongst some of the criticism, there was the familiar comedic gag of watching your feet to see if you trip up on something, and you did. For a good couple of weeks your most vocal critics were thrilled in showing the video of you tripping a few times going up the steps while attempting to board your plane, and your Political Party made an excuse saying the wind blew you. And your critics went on to say how other global leaders would view that. For the record, you picked yourself up quickly in a tidy fashion each time, all on your own and made it to the top of the steps, turned around, gave the salute, then boarded your plane. That’s indicative of how you would handle a problem. They were making fun of a senior citizen, and though amusing on a one side, the moral of the story is you’re still that same amusing Joe Biden from back in the day. The political foes overseas may be mis-reading these perceived or misconstrued failings. Are you really weaker than Trump? I know you seem less scary to them. If you needed to, would you rise to the occasion to do something really drastic, but necessary? Well, you’ve been in Washington for many years being the Youngest Incumbent Senator to now The Oldest Elected Serving President. Surely you know ALOT. They might be under-estimating you. And as you approach your 100th day in Office, the academic forecast for your grade right now will have to be a strong respectful ivy league **C** and here’s why. You still gotta work and it’s just your first 100 days in Office. If it were peacetime and everything was fairly good in The Kingdom and we’re living in a Golden Age, it would most definitely be an **A**. With all the on-going race problems, economic poverty, global strife, and so forth your Administration inherited generationally to deal with, you would need all the wisdom of former Presidents and Kamala Harris would need the same from prior deceased VP’s to try to conquer these relentless current issues. Now let’s get into some of them. It’s great that in the George Floyd case, the jury returned with a guilty verdict for that cop. Which brings me to your nationwide campaign agenda to take away The People’s right to bear arms. You would need to consider subtracting guns from cops as well to insure the safety of defenseless Black Men and Women in the streets. Many of these cops are clansmen who infiltrated Law Enforcement in their desire to attack Blacks. And the sickness has also expanded to Hispanics & Arabs, and East Indians who join the force due to some racist hostility towards Blacks. I was so turned off by the case of that Army 2nd Lieutenant Caron Nazario, who is used to being saluted on a military base, a hard-working soldier being harnessed by Racist Civilian Cops in Virginia who don’t have the degree of his training, endurance, discipline or etiquette. He did the right thing to save his life and I hope those cops get what they deserve. Incidentally, days after that George Floyd case returned with a guilty verdict for that wicked white cop, it created a pushback with officers stopping Black People out here and the stop clearly looks like what it is RACIST. There’s no reason for a cop to be harassing a poor young Black Man with his Black Female date in the car when he’s just driving along normally out here as usual. They use their badge and authority as an excuse to fuck with people and I’m proud to be actively a part of righteous causes with various organizations in curbing those practices. Some of these Cops stationed in just about every Black neighborhood also engage in the unscrupulous cointelpro practices of in-appropriately surveilling law-abiding people in ways that are so obvious and stupid. And there are some remedies for anyone experiencing that. Some of these gang-stalking activities have nothing to do with any legitimate police case. It has more to do with a cop or cops knowing a little too much personal information about somebody and engaging in a mentally-ill side activity. Perhaps **he** the cop crossed a professional line in a case and became a bit too fascinated with some woman he now privately follows on & offline, or maybe **she** the cop deceives herself thinking that she might be on to something hating on some other female she won’t admit she’s jealous of by crossing an ethical line beyond a case already done with, stalking and trying to mess her up over nothing, simply because she’s attractive and has a promising life ahead of her. Whatever the psycho-emotional fault, your Administration should extend its efforts in communicating with me and/or other Advocates & Activists in inspecting these pervasive internal corrupt activities, because they create distrust of The System and dissidence. Now, on the topic of proper police work, there are many Police Officers that go unnoticed and without credit for being there and keeping the peace while following the right procedures. Now on the topic of these racially motivated Asian attacks in the inner cities; it’s sad and very cowardly targeting their Elders. On a comedic note what would be useful for the nation to see in the press all over social media is a case where some thug(s) attacking an Asian one day, and he or she breaks out in some kung-fu action beating their ass. Now on the foreign affairs topic of China invading Taiwan, well larger nations like holding on to their sibling territories. Remember Russia and the Ukraine? It’s to be expected. So how does that affect us here and what are you going to do about it? Now, The Armenians, like other ethnic groups who are living over here in The U.S., that is an issue and they would expect you to protect them. Now on the topic of by-passing certain procedures and such that The Republicans don’t like and are complaining about you getting policies passed without their blessing and approval, to which I say touche sometimes that’s necessary. I’m not particularly all too happy with you either (smile), but work needs to be done here without it being tied up in bureaucracy. **Now**, this idea of a mandatory Covid-19 Vaccine Passport is unconstitutional. You infringe on the rights of many doing that. If America is making the move to become a full Autocracy, you need to get rid of or re-write The Constitution, and keep changing it as you move along. Now that move right there changes our current government for life. That means all the symbolism you hold dear, all the democratic history it took to get there, will be gone. I saw you on TV today with the CDC mask wearing update. Holding peoples’ normal right to a living in pursuit of happiness for ransom in exchange for taking the vaccine is wrong. Do you remember how life used to be? Well, in normal times if someone fell ill to something or was threatened for it, they opted on their own to want to take a vaccine to the surprise of a doctor in some cases. Did you get that? They wanted to. People are more likely to follow your bidding sometimes when you aren’t imposing a mandate. If this whole novel coronavirus thing is a government fraud made up just to sell pharmaceuticals as many suspect, it could have been done better. Had The Government just said while transporting a top secret scientific experiment we were conducting, a viral vapor accidentally got released into the atmosphere and now we must alert The People and get them inoculated with our makeshift medication we made from the notes in the experiment. That may have carried over better. Or if The Government said a small meteor crashed the other day over here in this state and after months of studying it, we now noticed a space virus came from it and we suspect enough of it is in the air for people to breathe so now we developed a potion for The People to take to stop potential mutations. Or if a Government Representative just came on The Air and made a grand announcement stating to The American People that we have been lying to you for many years and we just want to come clean now, there are in fact extra-terrestrials out there and some of them are living among us and we found that this particular virus we give off our bodies affects them and we need to address that, so take this formula that ours and their scientists created to minimize it. You know what I mean, please be honest with us. Now on the topic of the immigrants at the border crisis issue; what your critics want to see is Kamala make a physical appearance out there no different from when George W. Bush went out to Louisiana when the levy broke and it flooded out the people. Even non-politicians went out there trying to give direct help. Sometimes when you’re in Office, you’re targeted a certain way and held to a strict standard that may not be necessary to fulfill. Some people like the action of being out there in the thick of things protesting, while others are behind the scenes really getting the critical work done through policies and The Court System. Despite the Republican media narrative, your VP appears to be actively working on the issue. Now Kamala has been criticized for small things like failing to give a salute when the protocol called for it. This is a slighting by your political foes to expose her lack of knowledge or training on certain etiquette her position calls for, and I would be mindful of these critics everywhere you go and in everything that you do or don’t do while in the public eye. Now, on making The District of Columbia into the nation’s 51st State. Are you serious? Isn’t it too late for that? Depending on when you believe America actually received It’s independence 1776 or 1789, we’ve been a known nation at least over 230 years without DC being a State. What is the real reason for this move now? We already have 50 stars on the flag. Do you plan on losing a state to compensate? Maybe we don’t need Puerto Rico anymore. I kind of like DC as it is. I think if we lost a state like Puerto Rico due to earthquakes, economic and political problems, then taking over another place is way better. Look at what’s happening in your empire right now, the political climate, what is critical right now that we need for trade & commerce, living space and so forth. You know, unlike others, some nations prefer the presence of a foreign power helping them. And they are so dying to be assimilated into their protection and becoming one with them. And if you discover more of these nations, then the solution can be simple and cost effective. Sometimes merging one or two states together as one can keep our current flag at 50 states. Now this Meghan Markle thing, she and Harry just moved into your backyard chirping & bustling like birds out there. Now the country is still in good standing with our ally Great Britain and it needs to stay that way. And lastly, I would entertain the idea of releasing a fourth Stimulus Check that some Politicians are pushing for and here’s why. We The People have been so greatly inconvenienced in every way by this pandemic that it would be a sin not to do so. We’re talking about a year of unrecoverable difficulty. Now our government has a fiscal year too. Well what about ours? We only saw three quarters. For businesses to be fully operational again functioning at their optimum so that The Government can enjoy the boons of Its coming fiscal year, we need another offering to keep the global money machine going. So okay Joe, continue diligently working until your next political report card mid-term this year and tell Flotus I said hi.

Sign,  
Lhisa Mrklon  
Special Agent 666

### Are You Experiencing Voter’s Remorse For Picking Joe Biden As Your 46th President? Scroll Down And Leave Your Reply Below.

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193108078/qfywWtEkS.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193109915/e_e-Xm7SJ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193111325/Esd54FXmO.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193112811/L1VerdnUF.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193114100/Jzrsnmrxj.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193115627/8DwUe3j93.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193117037/1gpAgd7A8.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193118692/2oeacZDNz.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193120267/EP43sSveZ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193121768/Nfj_b9HfF.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193122972/8_O6z-69U.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193124459/7igR4gAoX.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193125999/Q0tdZM2Lp.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193127697/mDhOF4mCB.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193129091/ogVbyGTXd.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193130933/MR9RKbKwz.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193133021/x-bP9RSj_.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193134568/OKBC9Jg2T.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193135826/olvveM7uV.jpeg align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193138257/1rRgRmqzY.png align="left")](https://ferrelux.com/adverts/)
