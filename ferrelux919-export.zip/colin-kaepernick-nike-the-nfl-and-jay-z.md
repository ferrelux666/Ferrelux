---
title: "\U0001F4FAColin Kaepernick: Nike, The NFL & Jay-Z\U0001F947"
date: '2019-09-09T22:47:18.000Z'
slug: colin-kaepernick-nike-the-nfl-and-jay-z
tags:
  - ads
  - trump
  - african-american
  - urban
  - politics
  - olympics
  - soccer
  - football
  - australia
  - human-rights
  - america
  - movement
  - city
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672194771521/XsS8xBH4o.png
canonical: 'https://ferrelux666.wordpress.com/2019/09/09/olympics1968/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194744455/efNmUr2cL.jpeg align="left")](https://www.upress.umn.edu/book-division/books/not-the-triumph-but-the-struggle)

  
[Marvin Gaye ~ “What’s Going On”](https://www.youtube.com/watch?v=H-kA3UtBj4M)

*Genua Obstrepentes Quia Nigrum Certamen  🙅🏾‍♂️  I Kneel In Protest For The Black Struggle*

You know the name and the controversy. I knew not jumping on this particular story on the onset of his movement, would yield more for me to cover after we’ve seen the shit play out over the airwaves from last year till now. Who is this Hispanic-looking Brother with an Irish name? Colin Kaepernick is the bi-racial child of a blond-haired blue-eyed Mother & African-American Father and he’s a football athlete who plays for the San Francisco 49ers. With the on-going police brutality against “Black” Men & Women everywhere in America, him taking it upon himself making a striking political statement at NFL games by taking a knee during the singing of the American anthem, is in the praise-worthy spirit of deceased Civil Rights leader Dr. Martin Luther King Jr. This move drew angry criticism from a segment of the population that were “White” (racist or not) who didn’t think the NFL was the right platform to protest urban bigotry & that it showed disrespect to the flag and The Nation. Well…. Other attacks on the issue has been done before by Newscasters, Youtubers, The Common Person on the street, etc. Kaepernick is the only Football Player to put a spotlight on the problem by using the Sports Industry. The only other pivotal moment in history was the 1968 Olympics when 1st & 3rd place medalists, (Tommie Smith, Gold & John Carlos, Bronze) dark-skinned track & field athletes playing for the United States, went on the Olympic stand proudly wearing there medals, through up the Black Power fist during the American anthem for the World to see protesting in the struggle for the same racist persecutions going on at the time in America where The Black Panthers took a political stand opposing the Governments treatment of us. Admidst those medalists was the solitary 2nd place winner from Australia, Silver-Medalist, Peter Norman. People don’t know much of him, since he’s not the primary focus in that iconic photo, but he too as a “White Man” was involved in the protest in his humble way, because he decided to wear the Olympic Project for Human Rights (OPHR) badge in support which was contoversial, and ofcourse even though he was already a medalist, Australia didn’t use him again because of it for the next Olympics, but he’s also noted in history for taken that stand at the time. America punished the 2 Black athletes too expelling them from the team. The 3 athletes kept in touch with each other in life re-creating the historic pose as old men. Australia later repented declaring a Peter Norman day. When he died, the 2 surviving Black athletes carried his coffin. Why the protest at the time? THEY had to, and Kaepernick had to, the police brutality, etc. When you’re “BLACK” and you’re living it everyday, something is wrong if you’re not protesting in some way. Yes, the move drew anger from President Trump and Kap got fired. He filed a lawsuit against the NFL because after all, it IS his Constitutional right to make an expression like that. The suit yielded some pay, but not to great satisfaction, he did not get his job back. So as time went on, Sports giant Nike, entered the fray embracing Kap, and that move upset those same people who don’t like what he did. Nike stocks dropped for a while, but they kept Kaepernick & he looked and sounded great in those print and televised ads. Soon, the minds of people changed back in favor of Nike & the sales happened. And as we went on again in life, another change happened where recently Rapper Jay-Z made the comment that ‘it’s time to move beyond kneeling’ and this drew much criticism. It was taken as a diss, but the comment is subject to interpretation. Do we keep marching & kneeling as an oppressed people? That’s how many movements start before it gets physical. What he did was effective enough to draw attention to the issue. Kaepernick’s motives have been criticized by some who feel he’s just looking for attention, he wasn’t a great enough athlete and they were going to cut him, so he did that move as a tactic. Well, that’s all speculation. He got fired anyway, the point is, he inspired other NFL players to take the knee with him and The Brother, showed where he stands politically, rocking his fro. So what now? Well….., the NFL has Jay-Z with them as a part Owner and some see that as a betrayal, but Jay-Z is another strong Black Brother who declared he wants Kaepernick re-hired. Whether he has the power or not to make that happen remains to be seen, the point is, they are trying to clear up a problem. The NFL has seen a steady decline over the years in ratings & interest. They’ve lost their heyday. Just trying to pick the right Halftime performer to hold the audience & hope everything goes right is a daunting task. When they chose Adam Levine last time, Cardi B, like Rihanna stood with Kap and chose not to perform the song they did together, ‘A Girl Like You’. Adam Levine & his band Maroon 5, should NOT have taken the job, but he thought the controversy was good for him, not realizing he was further exposing himself. Months before that on ‘The Voice’, he fucked over DeAndre Nico, a strong soulful Black Contender on his team for some lesser singer (Reagan Strange), a young white female he knew personally, who was nearly voted off the prior week, who got voted off the competition the next week BECAUSE, America didn’t like that, and the fiasco was all over social media . So HIM, opposing Kap, and doing a lame performance at the Half-time show, also hurt the NFL. Until they properly solve this issue with Kap, their general approval will continue to drop.

Lhisa 666

SOME LINKS  
[https://en.wikipedia.org/wiki/Colin\_Kaepernick](https://en.wikipedia.org/wiki/Colin_Kaepernick)  
[https://en.wikipedia.org/wiki/1968\_Olympics\_Black\_Power\_salute](https://en.wikipedia.org/wiki/1968_Olympics_Black_Power_salute)  
[https://en.wikipedia.org/wiki/John\_Carlos](https://en.wikipedia.org/wiki/John_Carlos)  
[https://en.wikipedia.org/wiki/Peter\_Norman](https://en.wikipedia.org/wiki/Peter_Norman)  
[https://en.wikipedia.org/wiki/Tommie\_Smith](https://en.wikipedia.org/wiki/Tommie_Smith)  
[https://en.wikipedia.org/wiki/Olympic\_Project\_for\_Human\_Rights](https://en.wikipedia.org/wiki/Olympic_Project_for_Human_Rights)

### Was Peter Norman Right To Get Involved With That Black Civil Rights Protest At The Olympics And Risk His Career? Scroll Down And Leave Your Reply Below.

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194745689/JyP3Ik0MK.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194747076/xEVOmtlZl.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194748188/W6Gn7GFoI.jpeg align="left")

  

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194749178/ulmPJX1fO.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194750288/RCnT1GZYm.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194751541/2llIQHjZ4.jpeg align="left")

  

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194752705/S2kUFYJjr.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194754083/MtQnIZ7Nn.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194755350/ptRFB2y8t.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194756427/9yJ1bx-27.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194757603/mtCOp7EYh.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194759171/yvWMO4KfU.jpeg align="left")

  

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194760421/5PeOGiaFF.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194761659/nQxEtBby-K.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194762647/vwRYsFJdW_.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194764060/Bc7O42GbY.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194765475/Styt2Iwno.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194767201/PKlJykqzs.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194768748/9-KE-bh9D.jpeg align="left")

The American sprinters Tommie Smith,John Carlos and Peter Norman during the award ceremony of the 200 m race at the Mexican Olympic games. During the awards ceremony, Smith and Carlos protested against racial discrimination: they went barefoot on the podium and listened to their anthem bowing their heads and raising a fist with a black glove. Mexico City, Mexico, 1968 Mexico city, Mexico, 1968

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194769962/vj2Hm3VKU.jpeg align="left")](https://ferrelux.com/adverts/)
