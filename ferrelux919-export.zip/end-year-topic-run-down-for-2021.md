---
title: "\U0001F384End Year Topic Run Down For 2021\U0001F9E8"
date: '2021-12-19T21:46:03.000Z'
slug: end-year-topic-run-down-for-2021
tags:
  - news
  - general
  - hel
  - attack
  - tornado
  - war
  - new-year
  - halloween
  - trial
  - pandemic
  - covid-19
  - christmas
  - topics
  - inflation
  - abortion
  - variant
  - financial-market
  - funeral
  - death
  - court
  - xmas
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672192307241/UJVrjWKN_.jpeg
canonical: 'https://ferrelux666.wordpress.com/2021/12/19/christmas-2021/'
---
![2022 Loading](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192245464/ZKmzZLL8k.jpeg align="left")

[**R. Kelly ~ Christmas Party**](https://www.youtube.com/watch?v=uCeBeZQOUTg)

**Hic Iterum Itur 😧 Here We Go Again!**

So I pre-occupied myself with presenting my views on other topics earlier in the year, with some issues you know I cared so much about discussing. And below, are ***twelve and three*** more subjects with my brief take on them, some of which I might extend further coverage on in the future.

**Covid-19 Variants: Delta, Omicron, . . . ?**

It looks like all this pandemic stuff will stick around well into another damn year. And they are still pushing this vaccination requirement, and imposing mandates again. Some cities across the world have already began shutdowns. Well, if you are going to inconvenience people from making a living again and enjoying the right to live normally, you are seriously hurting your economy. And for what?

**Tornadoes Devastating the Mid-West**

Oh it’s terrible what happened! So many lives lost. So many properties destroyed. People losing their livelihoods and so forth. But was it truly a natural disaster? Given what we know from the past, these things are weaponized for a purpose and can be created by using HAARP and other technology.

**The Abortion Issue**  
Women have the right to choose. And if you value a woman’s rights, her choices should be respected. The only thing you can do is offer ministry or counseling. No matter what you believe, it is also immoral to force your will upon someone and risk compounding a worse situation. No one can guarantee for sure that keeping a child would be properly loved and provided for. That child’s destiny may be ill-fated or it might grow up to be a detriment to society. On the other hand, some people are better off not being born.

**The Ghislaine Maxwell Case**

Well Jeffrey Epstein got out of his criminal case by suicide, so they say, and now his Socialite girlfriend is trapped with it. In all reality pre-teens & teenagers are aware of sex. They know what prostitution is, and some of them being wild and running away from home are willing to whore themselves for money. If you look at it, I doubt they were that naive. Imagine, had they not met that wealthy couple, they most likely would have been strung out on drugs with some street pimp of ethnic descent slapping them around, and them having sex with dirty men in some cheap dug out.

**Chris Cuomo Getting Fired From CNN**

He had a right as an Attorney, and a Journalist to investigate allegations against his brother, Ex-Governor of New York, Andrew Cuomo.

**Alec Baldwin Firing A Loaded Gun On Set Killing Halyna Hutchins**

This incident happened just before the week of Halloween, and the timing harkened thoughts of a possible Illuminati Sacrifice due to the fact that things like this get exposed in the form of conspiracy theories. The Ukrainian Cinematographer’s name is Halyna, spelt differently than Helena. And Hel is the Norse Death Goddess of The Underworld. So anyway, back to the legalities of the case. When I first heard it, the whole thing sounded suspicious. I mean WHY would something like that happen? And it being Alec Baldwin, a person from a Hollywood family who is no stranger to controversy. I liked the quality TV Talk Show he was doing on ABC a couple years ago till it got canceled prematurely. Just before they pulled the plug on it, he had a scuffle with somebody in New York over parking space. And now this happened, and “Rust” is his production. The Arms person he hired looks questionable. And when he went in front of cameras explaining himself in those interviews, I was thinking, Alec, what the hell are you doing? You shouldn’t be on the scene like that. First of all, on the onset of the incident with the photos taken of him grieving, it didn’t look that different from him acting a role. And the excuses being made for the incident even happening in the first place isn’t plausible. He had no business waving a gun around, let alone pointing it at anyone, especially when he is a known anti-gun advocate, which sparks a thought to wonder if foul-play such as this could serve the extreme interest of an anti-gun advocate. Hollywood is a strange place, weird stuff happens on set a lot, so one should be suspicious at all times, especially if someone might be trying to set you up. Somebody loaded a bullet in that gun expecting that to happen.

**The Kyle Rittenhouse Trial**

Many of The Republican White People loved that he was not found guilty and are ready to welcome him in their arms and into their establishments, giving no thought that he was a teenager who felt that he needed to have a rifle in his hand and get involved in the Black Lives Matter rioting in the streets, where he ultimately killed 2 people and wounded a 3rd victim, in what he claims was self-defense. Though they were unsavory types in society, he could have merely injured them instead of shooting to kill. Republicans like talking about the Abortion issue and killing an infant, but if all life is sacred, why not care about a criminal’s as well.

**George Floyd’s Killer Trying To Appeal His Guilty Verdict**

I was so turned off watching that Derek Chauvin Trial and his Lawyers trying to make excuses for this murderer. It was so despicable. They should be ashamed of themselves. I’m glad that his appeal is not being taken seriously due to the over-bearing guilt of killing an innocent Black Man. He deserved the 2 and a half year extension he got to his already 22.5 years in prison. George Floyd was a guy he knew from working with him as a Security Guard at a club and whatever squabble they had there, should not have found itself in the streets with him abusing his cop status to settle a petty score. And now his crazy ass is locked up in the penitentiary among some inmates knowing who he is, what he did, and may want to beat his ass on top of it.

---

Ahmaud Arberry\*\*\*\*

He should never had been killed. He had a right to jog anywhere he wanted. Of the 3 White Men involved in the crime and found guilty of it, the one amongst them who appears the least understanding of the gravity of the situation is the youngest, whom was the one that killed young Ahmaud.

**The Illegal Migrants At The Border**

Ya’ll wouldn’t have a problem with it if they were Caucasians coming through.

**Woke / Critical Race Theory**

People are so offended and they keep talking about this topic like a fool. Well it ALL came from somewhere. And rather than joining the argument, how about doing your research to find out exactly how it all came into the press in the first place. You might learn all that if you just **\_***Follow Me***\_**

**Continued Attacks on Asians**

That’s still a thing, even though Asians are the least of our problems in the inner city. I’m surprised that Blacks are not attacking the actual people trying to take over our communities and displace us, migrating from The Middle East, made possible by Democratic policies. And all we can do as a collective people is spend our dollar at non-Arab/Islamic facilities where possible.

**Continued Attacks on Jews**

Well ofcourse, that’s been going on more now in the recent years despite all the social distractions happening this year, the hatemongers didn’t forget them at all, but it takes two to tango. These so-called isolated incidents are not happening all on their own out of the blue. Something caused it.

**Israel Defends Itself**

I support Israel defending Itself because if you think about it, The Arabs are not all that innocent anyway. If given a chance to wipe Israel off the map, they would.

**Dead This Year**

The Great General & Former Secretary Of State **\_***Colin Powell***\_** died at 84, and here is a link of some other notable people who past away this year so far.

[https://en.wikipedia.org/wiki/Deaths\_in\_2021](https://en.wikipedia.org/wiki/Deaths_in_2021)

\*\*AND I’LL UPDATE THIS AS SOON AS ANY OTHER ISSUES THAT ARISE BEFORE THE YEAR ENDS  
\*\*

**Merry Christmas**

**And Have A**

**Safe & Blessed New Year**

**And Now I Have A Brand New Topic To Remark On**\*\*\*\*,  
\*\*\*\***South Africa’s Activist Desmond Tutu Died At Age 90, On 12/26/2021**  
[https://www.nobelprize.org/prizes/peace/1984/tutu/biographical/](https://www.nobelprize.org/prizes/peace/1984/tutu/biographical/)  
[https://en.wikipedia.org/wiki/Desmond\_Tutu](https://en.wikipedia.org/wiki/Desmond_Tutu)

\*\*\*\*Also Actress Betty White Died At Age 99, On 12/31/2021  
\*\*\*\*[https://en.wikipedia.org/wiki/Betty\_White](https://en.wikipedia.org/wiki/Betty_White)   
[https://www.imdb.com/name/nm0924508/](https://www.imdb.com/name/nm0924508/)

\*\*Sign,  
\*\*\*\*L H I S A  
\*\*

### Was This Year A Bit Better For You Than Last Year? Scroll Down And Leave Your Reply Below.

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192246684/eeDjRSrQ2.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192248468/F3fN3OB5S.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192249752/Cm55BKoZ5.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192251559/IIsGfp1mQ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192252931/y4J6bRy5m.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192254226/_JtbS7Y2g.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192255566/TADsPdpm4.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192257328/_8QpdeuBU.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192259252/fPP5ENYJc.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192261838/_5MZAfPSn.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192263491/R2elk7XuO.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192264865/9J2TSXM2v.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192266038/6nNDUiuma.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192267416/RQXqAfBU7.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192269099/WlHAgWhNQ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192270249/vprDWYW6D.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192271473/H_fffnQoT.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192272811/DbhKlqdFv.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192274506/ziRfD7M4P.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192275887/k0QP8kv2p.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192277166/ulIy3-iam.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192278546/AcBFEE-H-.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192280024/_Jnx6yLTp.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192282114/Jj4OcbtBp.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192283996/nSViRc18e.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192285403/VfCY7jPAG.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192286908/mbgKvtTug.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192289473/W9_7Z8ylS.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192290998/ZwLcCXJ-y.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192292452/bfKaSSGWm.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192293978/9foX1Bqud.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192295193/PequL8NYQ.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192296427/cShlfr7Sh.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192297840/6Lw9jG_BV.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192299590/wE_CVUWul.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192301100/mYJxLWDVL.png align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192302561/sDPKEwl0d.jpeg align="left")

![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192303909/jRuA7al6X.jpeg align="left")

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672192305434/kAv6Re_tI.jpeg align="left")](https://lightinthebox.tv2h87.net/c/3170166/805530/8199?prodsku=6013441&u=https%3A%2F%2Fwww.lightinthebox.com%2Fskmei-men-s-outdoor-sports-multifunction-dual-time-zones-wrist-watch-50m-waterproof-assorted-colors_p6013441.html%3Fcurrency%3DUSD&intsrc=PUI2_5801)

### Like this:

Like Loading...

### *Related*
