---
title: "The 2020 Race To The Presidency \U0001F4C9♟\U0001F30E"
date: '2020-10-29T21:59:23.000Z'
slug: the-2020-race-to-the-presidency
tags:
  - convention
  - news
  - icon
  - community
  - media
  - conspiracy
  - lawyer
  - attorney
  - african-american
  - covid-19
  - uncategorized
  - politics
  - debate
  - election
  - america
  - california
  - joe-biden
  - investigation
  - new-york
  - campaign
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672193827456/9cSstsEwR.png
canonical: 'https://ferrelux666.wordpress.com/2020/10/29/election2020/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193739973/4p60f7GoS.jpeg align="left")](https://www.nbcnews.com/video/michael-avenatti-addresses-democrats-at-wing-ding-dinner-1296922691753)

[**“A Piece of the Pie” – Randy Newman**](https://www.youtube.com/watch?v=PusmGLrDQFs)

*Ut Optimus Victor Candidatum* 📜 *May The Best Candidate Win*

**I wanted to cover this story from early September, commenting on the Republican & Democratic Conventions but it got postponed due to covering the surprising death of ‘Black Panther’ Star Chadwick Boseman, and the death of Ronald Bell from ‘Kool & The Gang’ and also the death of guitarist Eddie Van Halen, amidst other things happening in Current Events. So I decided to lump all that political stuff in this one post.**

\_  
Okay so now, a few things have happened. Feminist Icon Helen Reddy, the singer famous for her iconic 1975 song “I Am Woman”, passed away on September 29th 2020 at age 78. Another Womens Liberation Icon, Ruth Bader Ginsberg died 11 days before on September 18th 2020 at age 87. But I would not refer to her as **RBG**, because I know better. That acronym means something in The Black Community, The Red, Black & Green African-American Flag and also in its Confederate version. And what it stands for, doesn’t exactly match her. Although she was a modern Pioneer for Womens Rights at the time using the Judicial System, it went into seeking Gay Rights, mixing one political movement with another amidst a conflicting Black Culture where the Indigenous Belief System on certain things are still currently infiltrated and under attack. It’s a shame when a bonafide movement gets hijacked by another culture using if to promote their own wanton problems.\_

\*\*  
ON ANOTHER NOTE,\*\* where the current race for President is concerned, Joe Biden was not the Candidate I expected to take the Democratic Lead. I wanted Michael Avenatti. I think if you’re President Trump, and a good chunk of Americans want you out of Office, it’s better to lose to someone good, than potentially get booted out of Office by some “lame” Politician. I mean come on man, I expected better from you, or at least an Advisor in your camp. ***I wanted to see a fight.*** The People got robbed from a Main Event. Avenatti had the momentum, the look, the confidence, the attitude, the skill, the Lawyership, and so forth. A real Candidate, The Democrats so badly needed. A Fighter. Then an ugly act of jealousy and malice was orchestrated to eliminate him from being a threat. ***He should never had been convicted over that Nike shit in the Southern District of New York Courthouse, and him still having to fight another difficult case in California.*** On the surface the charges all looks bad, but when you scrutinize the alleged crimes he supposedly committed, one can see strong signs of a contrived Conspiracy; and there are laws still on the books validating Avenatti’s activities on both Coast at the time, which were not criminal. He’s not a ‘Con-Artist’ or ‘Creepy Porn Lawyer’. He’s a Good Man: Talented, Scholarly, enjoys life among things, and cares about The American People. I always say leave a person or thing alone. Wouldn’t it be better if you’d let Avenatti ran amidst the other 20+ Candidates and let the chips fall where they may. You don’t know for a fact **IF** he would have made it as the Head Democratic Nominee, but ***Somebody*** was scared he would. I guess when they saw his potential for the win well before The Kickoffs, a notorious team effort was put forth to bind up his ability to move politically by setting him up. *Oh, and it’s provable; all the earmarks are there.* The whole thing looks like how you’d expect it to look. Much of the Naïve Public already bought into the Media Blitz ran by Republican Trump Supporters, to make sure you see and hear exactly what THEY want you to know about Avenatti without you having any suspicion or doubt. Meanwhile, if these people were all back in Grade School, Junior or High School, they’d see it clear as day. All the childish shenanigans is there. This one, does not like that one; and since I have the money and the power, I’m going to do the spoilt thing and get you off The Political Scene. Boy, you all really disappointed me. What I expected Trump to do was face-off against Avenatti. *You fighting Joe Biden is stupid.* I guess you thought beating him would be easier, BUT he’s a former Vice President and if People want you out of Power, they don’t care if Joe might be a bit slow or what, they’ll vote him in because he has a VP & other Constituents to help. It don’t look good for you because you said *‘Obama pulled Biden out of the trash heap’*, and made other humorous disparaging comments. So as a Leader, you should want to fight someone more worthy like Michael Avenatti, unless you were SCARED! If you’ve got a loud mouth, and HE’S got a loud mouth, then America was cheated from viewing a real Title Fight. Back in The 80s when America was great, you would have known that. It was an era when YOU were great. And now being the current heavyweight reigning Champion, defending your Presidency in the political ring, you don’t go up against a slow elderly boxer who was out there training others, you fight that young mean Italian making his name in the Political Boxing World. That’s what people would pay money to see. You hurt yourself when you play a card too soon in the game only to lose later. If your democratically elect opponent turned out to be Avenatti, you go along with it, save what you know to use to attack him later publicly, then possibly hold on to The Presidency by a slight marginal win if The People were bothered by the accusations of his past Clients or any new scandal arising, but your Team got him off The Scene and under-estimated Joe Biden not realizing that he was still the next best bet even though he was seen by some as an unlikely Top Contender in the race since he was over-shadowed by bigger Personalities running. What if you lose the 2020 Election to Joe Biden, maybe by a landslide? How would you feel? It would look much better had The Candidate who beat you was Michael Avenatti. **WHY?** Remember your show *‘The Apprentice’* and how certain people looked during the process? At home viewing the show, people had in mind who should go back to The Fantasy Suite, who should go home that episode, or WIN in the end, but if that did not happen, at least the person lost to somebody good. Now, let’s say you victor over Joe Biden by some chance, okay, *you won* but it does not carry the same feel of a true victory. **WHY?** There’s a great school of People, who believe that you cheat, and you mis-use your power in ways to ensure success for yourself. You’ve been accused of collusion with Russia; the legitimacy of your Presidency came under question, and even when you escaped ‘The Mueller Report’ and other trials, your true redemption would have been to ***ride the lightening*** and bet on yourself, not sacrificing your better judgment and show people that you can meet a threat to your Presidency face to face and battle a worthy Democratic Opponent, empowered by the depths of his own being as a warrior ascending to new heights. YOU and your TRUMPIRE contending against this one Romantic Hero The People wanted. It would be a contest no different from *‘The Apprentice’* where the final episode of The Season featured 2 Great Candidates people are excited about vying to be HIRED by The American People. You’re now out there in the history textbooks for 2020 fighting Joe Biden, a guy you say is washed-up and so on, potentially beating you because YOU let some fake legal shit wrap around a nice Italian guy you didn’t like name Michael Avenatti. REALLY? Okay…….let’s take a step back. You had to fire A LOT of people you hired when you won The White House, who did an imperfect job and failed you. That’s Typical. So you didn’t get anybody effective enough like a Michael Avenatti to work with you who was Republican and had some sense, to help you. So then you hated on him for being an effective Democrat at the time, a thorn in your side helping THEM instead, as he did since College, working on numerous Campaigns. That shouldn’t have bothered you though. There’s a time when events shape up a certain way in life and you shouldn’t be offended. Simply showing that weakness at times for a discerning eye to read, opens up all kinds of interpretations. For the HYPE, you would have been better off up on **The Big Screen** fighting Attorney Michael Avenatti. The exciting news broadcast, the print media, the ratings, the Commentators, and so on; it would have been **EPIC**. Even if it all happened through the Covid-19 Restrictions, it would have popped-off better than the tame choreographed conventions and debates. On the Democratic side, Michelle Obama made some effective points in her stinging comments against you and Bernie Sanders certainly said what he had to say. A few other Speakers did well also. On the Republican side, Melania spoke really well and Donald Trump Jr., effectively presented his message, as did a couple other Speakers. Because you may have The Power to throw someone’s life off-track doesn’t mean you should capriciously use it. Exercising wisdom and weighing the odds can sometimes work better in your favor. People support you still. The Republican Party still maintains a standard that Conservative people respect, while The Democrats have suddenly become a Gay Party, naïve to a foreign infiltration and attempted take-over, highly liberal wanton values, and so forth. A lot of people privately agree with you and your efforts at restoring order even if it comes off a way. Some of the things you said and did made sense if some of your enemies would look at it fairly. Likewise, people favored “The Newcomer” Michael Avenatti and what he had to bring to The Nation, and if he was doing well in the polls, then said or did something a person or group questioned, then it would present an opportunity for you to relate to Voters a certain way instead of cramping up at the challenge and getting goons in The Judicial System to promptly remove him from your sight. So now instead of a viable foe, you got ahmm, a Nominee you say is The Loch Ness Monster that have been lurking around Washington for many years, and how ineffective he is. Well…….he got the Former 44th President Barack Obama, and former Prosecutor turned Senator and now his chosen VP Kamala Harris, and a lot of other significant People supporting him. They already turned over their campaign money to him and were out there campaigning on his behalf. Him winning The Election brings back that Obama Ring again instead of a completely new person. So if you got voted out of Office, YOU should have chosen your Successor right. It was easy. Michael Avenatti has been compared to you by some people with their own negative analogies, but I disagree with all that because some common experiences with another don’t entirely make you like them. If I were to entertain the idea in any way, I’d more shape it in this context as if YOU were contending against a make-believe younger version of yourself just coming up. Avenatti should have been allowed to continue as he was with his luxury cars, airplanes, companies, real estate and whatever and we would get to see which version of a person in time is best suited to lead NOW, but as a nation we got robbed from viewing the results of that social science project. Michael Avenatti had already terminated his Campaign due to *(your)* unforeseen attacks coming out from nowhere affecting his personal life. But I bet your Camp thought THAT was not enough, since Avenatti’s influence alone would boost Democrats with him out there supporting another Candidate, which he did by endorsing Joe Biden, even allowing him to use his campaign slogan. *And THAT bothered you?* An outright low-ball attack on his integrity and career by your Camp, was so ignorant. The treachery, far greater than what an actual guilty White-Collar Criminal ever did over the years. ***You all know damn well that the attack on his character with the negative media propaganda, the well-targeted social manipulations, the financial and legal attacks, the orchestrated setups and all the contrived charges are all bogus.*** His profile don’t fit the Crimes, and Ya’ll went too far. The charges on both Coast should have been DROPPED! You had already fulfilled what you wanted to not have let it gone on that far. You felt threatened by your own imagination, imbuing something about him that didn’t even get a chance to exist yet. When you start to attack persons of your own Social Class in that manner, you set a bad precedent. You crossed a line. How would you like your Peers crossing that fine line too, oblivious to your inalienable rights and decide to use people and circumstances to manipulate certain things a certain way in an extreme effort to criminalize you? And before you say it happened with those Federal Investigations, I’ll point out that as messy as that was, they honored the privileges your status offered and you were still respected and treated fairly. Your case was heard and you remained Our President. So many people wanted YOU off The Scene and were all over the airwaves talking smack and waiting for your demise. With all those heavy treasonous incriminating charges, you weren’t under-siege by S.W.A.T at the White House, taking you by force into custody, your Oval Office ransacked with them looking for shit and seizing your belongings, YOU on trial getting stripped of your Presidency and Convicted. You didn’t end up in a wartime jail with hardened Criminals, eating a cold stale meal to survive another day, living in a shithole cell with guards harassing you, them seeing you use the toilet and shower naked, and your general safety in The Pen at risk or suffering in solitary confinement, while depleting all your wealth to obtain the best legal help, remaining Indigent under imposed financial and internet restrictions designed to keep you from being able to adequately defend your case in Court. NO, you were treated NICE for someone who’s alleged “crimes” were much greater than Michael Avenatti’s. What a shame you couldn’t return that same democratic favor. As soon as you were found not guilty of any wrongdoing at that Hearing, with the Mueller Report and so forth, *gee look*, Michael Avenatti got snatched up the next day after, by “Your Rigged System” on some Trumped Up Charges pathetically trying to make him look like an Ivy League Mobster in the case, with the weight of The United States behind it, and you’re having him tried in The Ronald Reagan (Make America Great Again) Courthouse. **Goddamn!** And he was not even The One responsible for all those initial investigations against you, because you certainly could not have done that with any of the real people behind it. He was just a guy out there in The Democratic Community, Kennedy-like with his Iowa Wingding Convention Speech, and The People liked him. A Hero. He was building himself nicely and well on his way to realizing a dream, and you had to go and short-change *yourself* from receiving the better boon in history of possibly having faith in yourself that *just by chance*, if it came down to that one state for the win, you probably could have beaten a **great opponent** fair and square even if it were just by 7 narrow votes *(also on the recount)* casted by the hand of your beloved family.

[![Ferrelux Homepage_2020ThePresident-Elect](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193741931/I8rkSfUAL.png align="left")](https://ferrelux666.wordpress.com/2020/12/24/goodbye-2020/ferrelux-homepage_2020thepresident-elect/)

[![VP Nominee Kamala Harris](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193743713/XXoIAmfMp.jpeg align="left")](https://ferrelux666.wordpress.com/vp-nominee-kamala-harris/)

[![VP Mike Pence](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193745243/nUCC1NG-o.jpeg align="left")](https://ferrelux666.wordpress.com/vp-mike-pence/)

[![VP Mike Pence Face Off With Kamala Harris](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193746503/fovAzy_7U.jpeg align="left")](https://ferrelux666.wordpress.com/vp-mike-pence-face-off-with-kamala-harris/)

[![Vice President Mike Pence](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193747691/DZSRdNCAx.jpeg align="left")](https://ferrelux666.wordpress.com/vice-president-mike-pence/)

[![The Faith of Mike Pence](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193748870/sopxpfsy_.jpeg align="left")](https://ferrelux666.wordpress.com/the-faith-of-mike-pence/)

[![The Biden Plan](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193750072/wFjZ-qUGi.jpeg align="left")](https://ferrelux666.wordpress.com/the-biden-plan/)

[![Stormy Daniels](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193752100/F_qCp6YRW.jpeg align="left")](https://ferrelux666.wordpress.com/stormy-daniels/)

[![Statesman, Michael Avenatti](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193753453/eFmH3GgVt.png align="left")](https://ferrelux666.wordpress.com/statesman-michael-avenatti/)

[![Senator Kamala Harris](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193754706/KcVVGxpny.jpeg align="left")](https://ferrelux666.wordpress.com/senator-kamala-harris/)

[![Ruth Bader Ginsburg](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193756338/MLFdlQ29v.jpeg align="left")](https://ferrelux666.wordpress.com/ruth-bader-ginsburg/)

[![RBG Flag with Africa Outline](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193757516/hB2mDT8ss.gif align="left")](https://ferrelux666.wordpress.com/rbg-flag-with-africa-outline/)

[![RBG Flag, Black Female](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193758547/OXSly6UlL.png align="left")](https://ferrelux666.wordpress.com/rbg-flag-black-female/)

[![RBG Flag, Black Fist](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193759653/P_MqS8lRj.png align="left")](https://ferrelux666.wordpress.com/rbg-flag-black-fist/)

[![RBG Flag, BLM](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193761243/6hrAFKgle.png align="left")](https://ferrelux666.wordpress.com/rbg-flag-blm/)

[![Ruth Bader Ginsburg Listening](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193762948/N-OuXMRWL.jpeg align="left")](https://ferrelux666.wordpress.com/ruth-bader-ginsburg-listening/)

[![Ruth Bader Ginsburg, Columbia University](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193765070/DqtESOQM9.png align="left")](https://ferrelux666.wordpress.com/ruth-bader-ginsburg-columbia-university/)

[![Ruth Bader Ginsburg, Time Magazine](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193766626/r8xSOueo7.jpeg align="left")](https://ferrelux666.wordpress.com/ruth-bader-ginsburg-time-magazine/)

[![Michael Avenatti Wing Ding Democratic Speech In Iowa](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193767781/Ymy4DB8Og.jpeg align="left")](https://ferrelux666.wordpress.com/news/michael-avenatti-wing-ding-democratic-speech-in-iowa/)

[![Michael Avenatti, Today's Politics News Headlines](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193768852/mGjCU6N8q.jpeg align="left")](https://ferrelux666.wordpress.com/michael-avenatti-todays-politics-news-headlines/)

[![Lawyer Michael Avenatti](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193770089/PvnL1sDHh.png align="left")](https://ferrelux666.wordpress.com/lawyer-michael-avenatti/)

[![Judge Ruth Bader Ginsburg](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193772218/L1XYxV7z1.png align="left")](https://ferrelux666.wordpress.com/judge-ruth-bader-ginsburg/)

[![Obama Campaigning for Joe Biden](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193773529/TRiCRc-FP.jpeg align="left")](https://ferrelux666.wordpress.com/obama-campaigning-for-joe-biden/)

[![News 21 Decision 2020](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193775218/Nz5X6hVap.png align="left")](https://ferrelux666.wordpress.com/news-21-decision-2020/)

[![RBG Africa over BxW American Flag](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193776657/wgVpe4hnZ.jpeg align="left")](https://ferrelux666.wordpress.com/rbg-africa-over-bxw-american-flag/)

[![RBG Flag On Wall](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193778128/oMU47nL3R.jpeg align="left")](https://ferrelux666.wordpress.com/rbg-flag-on-wall/)

[![Melania & Donald Trump](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193779344/IanWY7N-P.jpeg align="left")](https://ferrelux666.wordpress.com/melania-donald-trump/)

[![Kamala Harris](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193780596/6SFqxaba_.jpeg align="left")](https://ferrelux666.wordpress.com/kamala-harris/)

[![Juneteenth African American Flag](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193781891/4oZDc_OrG.jpeg align="left")](https://ferrelux666.wordpress.com/juneteenth-african-american-flag/)

[![Melania Trump, Official Portrait](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193783192/1ksaLINcE.jpeg align="left")](https://ferrelux666.wordpress.com/melania-trump-official-portrait/)

[![Melania Trump](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193784518/iL3zBSDub.jpeg align="left")](https://ferrelux666.wordpress.com/melania-trump/)

[![Melania Trump Seated](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193785898/au9M9GQC4.jpeg align="left")](https://ferrelux666.wordpress.com/melania-trump-seated/)

[![Melania Trump Out And About](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193787105/-4reclwUs.jpeg align="left")](https://ferrelux666.wordpress.com/melania-trump-out-and-about/)

[![Melania Trump Campaigning](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193788407/huvGQmBnO.jpeg align="left")](https://ferrelux666.wordpress.com/melania-trump-campaigning/)

[![Jill Biden, Official Portrait](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193789648/Tbd1afpyZ.jpeg align="left")](https://ferrelux666.wordpress.com/jill-biden-official-portrait/)

[![Jill & Joe Biden](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193790856/GxGhnxJPL.jpeg align="left")](https://ferrelux666.wordpress.com/jill-joe-biden/)

[![Joe Biden & Michelle Obama](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193792314/RxtF_nD4F.jpeg align="left")](https://ferrelux666.wordpress.com/joe-biden-michelle-obama/)

[![Hollywood Reporter Avenatti Illustration](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193793547/M4C4pcP2c.jpeg align="left")](https://ferrelux666.wordpress.com/hollywood-reporter-avenatti-illustration/)

[![Go, Michael](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193794639/TRA_IqY5Q.jpeg align="left")](https://ferrelux666.wordpress.com/go-michael/)

[![Helen Reddy At Her Show Performing](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193796041/oCBfAsfL9.jpeg align="left")](https://ferrelux666.wordpress.com/helen-reddy-at-her-show-performing/)

[![UNITED KINGDOM - JANUARY 01: Photo of Helen REDDY (Photo by David Redfern/Redferns)](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193797340/oQtPhXtc-.jpeg align="left")](https://ferrelux666.wordpress.com/photo-of-helen-reddy/)

UNITED KINGDOM – JANUARY 01: Photo of Helen REDDY (Photo by David Redfern/Redferns)

[![HELEN REDDY](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193798593/ugJfNPzrM.jpeg align="left")](https://ferrelux666.wordpress.com/helen-reddy/)

[![Donald Trump Jr., Feuding With Michael Avenatti](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193799692/P9arLyvH9.jpeg align="left")](https://ferrelux666.wordpress.com/donald-trump-jr-feuding-with-michael-avenatti/)

[![Donald & Melania Trump](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193800719/3xK76bBAi.jpeg align="left")](https://ferrelux666.wordpress.com/donald-melania-trump/)

[![Democratic VP Nominee Kamala Harris](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193802131/acnODIxlU.jpeg align="left")](https://ferrelux666.wordpress.com/democratic-vp-nominee-kamala-harris/)

[![BLACK LIVES MATTER FACE MASKS](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193807379/hHPuJFIlIX.png align="left")](https://ferrelux666.wordpress.com/black-lives-matter-face-masks/)

[![Flag, Protesting Police Brutality](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193809324/xfe4ubv4n.png align="left")](https://ferrelux666.wordpress.com/flag-protesting-police-brutality/)

[![African American Confederate Flag](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193811073/_xtpyM08o.gif align="left")](https://ferrelux666.wordpress.com/african-american-confederate-flag/)

[![B&W American Flag, And The Black Female](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193812398/0AsUpUoPI.jpeg align="left")](https://ferrelux666.wordpress.com/bw-american-flag-and-the-black-female/)

[![2016 Democratic Convention](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193813669/pDpVS9Qp2.jpeg align="left")](https://ferrelux666.wordpress.com/2016-democratic-convention/)

[![Avenatti 2020 Gray T-Shirt](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193814834/S6v6zTVMm.jpeg align="left")](https://ferrelux666.wordpress.com/avenatti-2020-gray-t-shirt/)

[![Barack Obama & Joe Biden Steppin'](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193815917/UVed4urqK.jpeg align="left")](https://ferrelux666.wordpress.com/barack-obama-joe-biden-steppin/)

[![Barack Obama & Joe Biden](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193817524/qE-lXVCau.png align="left")](https://ferrelux666.wordpress.com/barack-obama-joe-biden/)

[![2020 Trump vs Biden Presidential Debate](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193819107/bSOMpmerK.jpeg align="left")](https://ferrelux666.wordpress.com/2020-trump-vs-biden-presidential-debate/)

[![A Younger Mike Pence](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193820364/wBYp57xDj.jpeg align="left")](https://ferrelux666.wordpress.com/a-younger-mike-pence/)

**Some Links**

[https://en.wikipedia.org/wiki/Helen\_Reddy](https://en.wikipedia.org/wiki/Helen_Reddy)  
[https://en.wikipedia.org/wiki/Ruth\_Bader\_Ginsburg](https://en.wikipedia.org/wiki/Ruth_Bader_Ginsburg)  
[https://www.themarshallproject.org/2020/09/23/rbg-s-mixed-record-on-race-and-criminal-justice](https://www.themarshallproject.org/2020/09/23/rbg-s-mixed-record-on-race-and-criminal-justice)

[https://www.demconvention.com/watch-the-convention/#how-to-watch](https://www.demconvention.com/watch-the-convention/#how-to-watch) *(Democratic Convention)*  
[https://www.2020gopconvention.com/blog/category/the-latest/](https://www.2020gopconvention.com/blog/category/the-latest/) *(Republican Convention)*

**Sign,**  
**:LHISA:**

### Was Michael Avenatti Robbed Of His Chance To Run For President? Scroll Down And Leave Your Reply Below.

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672193821712/_OKBS3TUj.jpeg align="left")](https://globalacn.org/business-grants/?ref=Ferrelux)
