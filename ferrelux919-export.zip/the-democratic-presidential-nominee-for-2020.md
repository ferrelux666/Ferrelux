---
title: "The Democratic Presidential Nominee for 2020 ☎\U0001F3D9\U0001F4C5"
date: '2020-05-14T20:22:25.000Z'
slug: the-democratic-presidential-nominee-for-2020
tags:
  - trump
  - country
  - programs
  - travel
  - women
  - vp
  - government
  - globalization
  - vote
  - uncategorized
  - american
  - politics
  - human-rights
  - welfare
  - biden
  - islam
  - president
  - city
  - campaign
coverImage: >-
  https://cdn.hashnode.com/res/hashnode/image/upload/v1672194180551/lQvHMWOnO.png
canonical: 'https://ferrelux666.wordpress.com/2020/05/14/democratic-2020/'
---
[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194140621/mbaQFvN_H.jpeg align="left")](https://www.ferrelux.us/)

[**Theme from the TV Show “The District”**](https://www.youtube.com/watch?v=WOFJA3uza2k)

*Caelum Non Animum, Mutant Qui Mare Currunt* 🌏 *Those Who Cross The Sea Change Only Their Climate, Not Their Minds (Horace)*

It’s sad that the leading 2020 Democratic Candidate is going to be Joe Biden. WHY, because he had his chance before & didn’t take it. I brought this up last year in a post about him. NOW, he’s older and being out there campaigning, talking shit sometimes and not remembering facts, critical people are finding fault with him. They’re now re-hashing the touchy feely sexual shit with him & women. THE TIME to win was running after Obama, but many are handling that episode with him like it was okay due to his reasons. Deaths and other personal tragedies around you are defining moments in life. I expected him to ascend to the Presidency then securing the spot for ALL OF US, then take time off some time AFTER the 100 day mark in Office when he would have already some significant accomplishment he did for the country to talk about why he can take a moment to deal with his pain, and letting the VP & others manage things for a while. JUST THINK, if someone he loves around him dies again, his whole campaign could fall apart due to the emotionalism. If he wins the Presidency, and somewhere along the way this happens, the nation may not be managed well under his leadership. I’m concerned about boldness, strength and the ability to lead effectively in the face of hardship. There are some nasty energies out there that may be looking at him a certain way, and quietly trying to figure out how to fuck up his direct line to power, even if he gets there, knowing his disposition. At least with Trump, you need to be careful because if somebody tried setting him off, you might not have properly calculated how he’d react. Plus, he has Advisors around him, so you can’t factor who might reach his ear at the time & you get the wrong response, so your plan gets fucked up. This is how Voters need to estimate. Will Joe Biden be predictable to a shrewd enemy overseas trying to fuck over America? Will all that liberal politics ruin us in the end? Democrats are so blind to that. More so NOW in our time. Do we need more bullshit ‘I’m trying to help you’ Minority programs out there, yet we still can’t get our frigging come up in mass having voted Democrat in the past. At least with a Republican Presidency we stand a better chance of seeing the light. What the hell do you think Joe Biden is going to do for you? Have you looked at his record? The radical Bernie Sanders is a little better, and the other candidates fucked him out of a chance throwing all their support over to Biden. He could ruin his campaign if he picks the wrong person for VP feeding into that liberal shit again, because picking the right VP is essentially choosing a Candidate for the next President after him. The Republicans are great at protecting their best interest in case you haven’t noticed. If they helped Trump stay in power this long after all the mess he had to deal with, do you think they are going to let Joe Biden run up and win the Presidency? When they get to figuring out how to stop him, then what? This argument leads back to what I posted a year ago. The best time, was the last time his chances of success was greatest. It’s HARDER now, too many challenges. He’d be lucky if he wins. So if he does, CAN HE HANDLE THE REAL ISSUES? THE COUNTRY IS NOT THE SAME ANYMORE. There are people here from places in the world that don’t like America and are here with an agenda against YOU and they are living in cities where they can freely operate. So are we going to continue to see a deference in the interest of these people hiding behind YOUR Human Rights Laws as a cover to go around empowering their people here by securing whole neighborhoods, institutions infiltrated where they can protect their own, controlling franchises where they only hire their own, and socially going around imposing their religion & belief system on YOU, the real American, openly. You see, this is all made possible by Democratic Liberalism over the decades when before, there were only small pockets of them in society who were here either truly escaping persecution and/or just a poor family looking for a better life, but they knew their place. There was no political agenda, and they were more likely to adopt a new way of life here. NOW, if you live in one of these highly concentrated Refugee cities in America, what you are seeing is An AGENDA! They are given license by a dumb American system to come here and automatically be on EQUAL FOOTING with Full Constitutional Rights amongst long standing native-born Americans, or Americanized immigrants who have been here for many years. They AREN’T “Americans”. They DON’T have an appreciation for your ways. Their loyalty is to Islam and their culturally oppressive traditions why they remain very much in contact with their overseas interests, purely Muslim businesses, Muslim newspapers and hangouts where they are safe because you don’t know the language or writing, and their fellow Arabs at the Police Station or other U.S Government division, is more endeared to their fellow countryman to really interfere with THEIR OVERALL PLAN. They would more use their American-given legal status and power to prosecute a non-Muslim. And don’t be fooled by the ones born here. Many of them are indoctrinated in such a way that it’s as if they were born overseas. Their loyalty is to the land of their parents and forefathers and their religion & customs. So when you see them, moving about, carrying themselves like that, even normally dressed, acting strange or weird with you, IT’S THAT. Moving into an area as a people & growing numerous in the land, in their minds gives them the right to “take over” and disregard YOU & your rights, yet these are some of the same peoples out there in the world who claimed they were the victim of White Imperialism, but now are doing the same wickedness in THEIR OWN cultural ethnic way to Whites and the other groups around them. In some cases, their presence is corrupting some of the less mentally stable Hispanics & Blacks defecting to their customs as a sport to go around harassing or intimidating women of their own group they see in passing. Nowhere on American soil did that ever happen before. When you grew up in your normal American neighborhood many years ago you saw someone that looked like you or someone you knew running the stores or other centers servicing you in that typical transaction. NOW your encounters with Haji or Mohammed come with the weirdness in getting something because they don’t belong here and they don’t understand certain things and their religious customs get in the way, yet your city force you to have to deal with them locally. Nor did your women need to have apprehensions when walking on the sidewalk or crossing the street because some Arab/Muslim male with cultural sexist views is looking at you with hate and trying to get you to move out of his way. We’ve seen the end result of other countries around the world engaging WAY TOO MUCH with these people importing them in certain pockets of their communities over time. It led to them imposing Sharia Law, when there was already a legal system in that Sovereign nation, it also led to them imposing their customs on you when you already have your own religion and ways, it also led to their men enjoying a deviant practice targeting non-Muslim females intimidating them or raping them due to a lack of respect for their rights based off their religion. And when the people of these places, mainly Africa, Europe, & The U.K, woke up and resisted fighting back, they were criticized for being racist or xenophobic, and all these offenders have to do, is hide behind vague Human Rights Laws, which were meant in spirit to cover the basic rights of a decent human being. So do we need a President ignorant to that, who keeps going along with these Muslim Empowerment programs in your neighborhood OR do we need a President who once knew what that same neighborhood use to look like before they migrated in it? You see **HE** would know what to do. Biden Vs TRUMP!

Lhisa,  
Informed Renegade

### Are Arabs/Muslims Taking Over Your Neighborhood? 😄😆😃 Scroll Down And Leave Your Reply Below.

[![Ferrelux Homepage_May2020](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194142182/oerkfDk40.png align="left")](https://ferrelux666.wordpress.com/2020/05/14/democratic-2020/ferrelux-homepage_may2020/)

[![The 20 Democratic Candidates for 2020](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194143646/XIQ3M0nKh.jpeg align="left")](https://ferrelux666.wordpress.com/the-20-democratic-candidates-for-2020/)

[![The Top 10 Democratic Candidates for 2020](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194145181/AH6W-2thL.jpeg align="left")](https://ferrelux666.wordpress.com/the-top-10-democratic-candidates-for-2020/)

[![Trump 2020](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194146552/qEmYwg_Bv.jpeg align="left")](https://ferrelux666.wordpress.com/trump-2020/)

[![Trump Maga Hat And Fist](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194148078/sDOJgoIYn4.jpeg align="left")](https://ferrelux666.wordpress.com/trump-maga-hat-and-fist/)

[![Sanders Vs Trump 2020](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194149372/MjL_gx1iH.jpeg align="left")](https://ferrelux666.wordpress.com/sanders-vs-trump-2020/)

[![Democratic Candidate Julian Castro](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194150616/cvqkaZ_db.jpeg align="left")](https://ferrelux666.wordpress.com/democratic-candidate-julian-castro/)

[![Democrats In Favor of Cuba](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194151787/GDWujSj8S.png align="left")](https://ferrelux666.wordpress.com/democrats-in-favor-of-cuba/)

[![Press Coverage of The 2020 Candidates](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194153147/-swJMdhoY.jpeg align="left")](https://ferrelux666.wordpress.com/press-coverage-of-the-2020-candidates/)

[![Mike Bloomberg And The People](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194154451/syHqbaO2f.jpeg align="left")](https://ferrelux666.wordpress.com/mike-bloomberg-and-the-people/)

[![Former VP, Joe Biden Wins Preference](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194155667/ygd6tDohK.jpeg align="left")](https://ferrelux666.wordpress.com/former-vp-joe-biden-wins-preference/)

[![Joe Biden 2020 Election Run](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194157005/JCTi61cNz.jpeg align="left")](https://ferrelux666.wordpress.com/joe-biden-2020-election-run/)

[![Joe Biden Campaigns](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194158433/VonfCnUy2.jpeg align="left")](https://ferrelux666.wordpress.com/joe-biden-campaigns/)

[![Trump Vs All The 2020 Democratic Candidates](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194159489/epsn0gjo4.jpeg align="left")](https://ferrelux666.wordpress.com/trump-vs-all-the-2020-democratic-candidates/)

[![Sanders](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194160638/J1V1M7Fbm.jpeg align="left")](https://ferrelux666.wordpress.com/sanders/)

[![2020 Democratic Candidate Andrew Yang](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194161787/eS8sOFIuY.jpeg align="left")](https://ferrelux666.wordpress.com/2020-democratic-candidate-andrew-yang/)

[![2020 Election American Flag Map](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194163120/XOnLucPG2G.png align="left")](https://ferrelux666.wordpress.com/2020-election-american-flag-map/)

[![Andrew Yang Gang](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194164342/MlD1AKW2m.jpeg align="left")](https://ferrelux666.wordpress.com/andrew-yang-gang/)

[![Bloomberg & Obama](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194165632/_QLaK48Uh.jpeg align="left")](https://ferrelux666.wordpress.com/bloomberg-obama/)

[![Biden, Warren & Sanders](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194166896/1mYMchUWK.jpeg align="left")](https://ferrelux666.wordpress.com/biden-warren-sanders/)

[![Biden Talks](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194168184/Z9_g2GM4o.jpeg align="left")](https://ferrelux666.wordpress.com/biden-talks/)

[![Andrew Yang's Fundraising Soars](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194169673/qDHHkZOXG.png align="left")](https://ferrelux666.wordpress.com/andrew-yangs-fundraising-soars/)

[![Biden Campaigns](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194171073/G5pt4WkDh.jpeg align="left")](https://ferrelux666.wordpress.com/biden-campaigns/)

[![Bush Jr., Obama, & Trump](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194172461/N4AdgDyws.jpeg align="left")](https://ferrelux666.wordpress.com/bush-jr-obama-trump/)

[![Bloomberg Campaign Ad](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194173761/bRvAmfdDP.jpeg align="left")](https://ferrelux666.wordpress.com/bloomberg-campaign-ad/)

[![2020 Candidate Mike Bloomberg](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194174919/2a6fktYkw.jpeg align="left")](https://ferrelux666.wordpress.com/2020-candidate-mike-bloomberg/)

[![Mens Royal Blue Suit](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194176273/mjZF8mfB7.jpeg align="left")](https://ferrelux666.wordpress.com/news/mens-royal-blue-suit/)

[![](https://cdn.hashnode.com/res/hashnode/image/upload/v1672194177397/gPiWK9h4A.jpeg align="left")](https://ferrelux.com/adverts/)
